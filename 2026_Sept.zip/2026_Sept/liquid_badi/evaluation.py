"""Scenario-aware pressure metrics. All pressure columns are in psia."""
from __future__ import annotations

import numpy as np
import pandas as pd


PRESSURE_EDGES = [-np.inf, 44.7, 75, 100, 150, 200, 250, 300, np.inf]
PRESSURE_LABELS = [
    "<44.7", "44.7-75", "75-100", "100-150",
    "150-200", "200-250", "250-300", ">=300",
]


def scenario_split(scenario_ids, seed=2026, validation_fraction=0.15,
                   test_fraction=0.05):
    """Keep the same simulation ID together across every trunk and node."""
    if not 0 < validation_fraction < 1 or not 0 < test_fraction < 1:
        raise ValueError("Validation and test fractions must be between zero and one.")
    if validation_fraction + test_fraction >= 1:
        raise ValueError("The training fraction must be positive.")
    ids = sorted({str(value) for value in scenario_ids})
    if len(ids) < 3:
        raise ValueError("At least three independent simulation IDs are required.")
    shuffled = np.random.default_rng(seed).permutation(ids).tolist()
    n_val = max(1, round(len(ids) * validation_fraction))
    n_test = max(1, round(len(ids) * test_fraction))
    if n_val + n_test >= len(ids):
        raise ValueError("The selected fractions leave no training simulations.")
    return {
        "train": sorted(shuffled[n_test + n_val:]),
        "validation": sorted(shuffled[n_test:n_test + n_val]),
        "test": sorted(shuffled[:n_test]),
    }


def _scores(frame):
    error = frame["predicted_psia"].to_numpy() - frame["pressure_psia"].to_numpy()
    return {
        "rows": len(frame),
        "bias_psi": float(np.mean(error)),
        "mae_psi": float(np.mean(np.abs(error))),
        "rmse_psi": float(np.sqrt(np.mean(error ** 2))),
        "p95_absolute_error_psi": float(np.quantile(np.abs(error), 0.95)),
        "max_absolute_error_psi": float(np.max(np.abs(error))),
    }


def pressure_report(predictions, bootstrap_samples=1000, seed=2026):
    """Exclude hard-anchored sinks; bootstrap whole simulation IDs, not rows."""
    required = {
        "scenario", "trunk", "pressure_psia", "predicted_psia", "is_sink",
    }
    missing = required - set(predictions.columns)
    if missing:
        raise ValueError(f"Missing prediction columns: {sorted(missing)}")
    frame = predictions.copy()
    numeric = frame[["pressure_psia", "predicted_psia"]].to_numpy(dtype=float)
    if not np.isfinite(numeric).all():
        raise ValueError("Pressure metrics require finite predictions and labels.")
    if not pd.api.types.is_bool_dtype(frame["is_sink"]):
        raise ValueError("is_sink must be boolean, not strings or missing values.")
    if frame[["scenario", "trunk"]].isna().any().any():
        raise ValueError("Scenario and trunk identifiers cannot be missing.")
    if bootstrap_samples < 0:
        raise ValueError("bootstrap_samples cannot be negative.")
    sink = frame.loc[frame["is_sink"]]
    frame = frame.loc[~frame["is_sink"]].copy()
    if frame.empty:
        raise ValueError("No non-boundary pressure observations to evaluate.")
    frame["pressure_bin"] = pd.cut(
        frame["pressure_psia"], PRESSURE_EDGES, labels=PRESSURE_LABELS, right=False,
    )
    per_scenario = [
        {"scenario": str(key), **_scores(group)}
        for key, group in frame.groupby("scenario", sort=True)
    ]
    per_trunk = [
        {"trunk": str(key), **_scores(group)}
        for key, group in frame.groupby("trunk", sort=True)
    ]
    per_bin = [
        {"pressure_bin_psia": str(key), **_scores(group)}
        for key, group in frame.groupby("pressure_bin", observed=True, sort=True)
    ]
    per_trunk_bin = [
        {"trunk": str(trunk), "pressure_bin_psia": str(bin_name), **_scores(group)}
        for (trunk, bin_name), group in frame.groupby(
            ["trunk", "pressure_bin"], observed=True, sort=True,
        )
    ]
    scenario_mae = np.array([row["mae_psi"] for row in per_scenario])
    interval = None
    if bootstrap_samples and len(scenario_mae) > 1:
        rng = np.random.default_rng(seed)
        resampled = [
            float(rng.choice(scenario_mae, size=len(scenario_mae), replace=True).mean())
            for _ in range(bootstrap_samples)
        ]
        interval = np.quantile(resampled, [0.025, 0.975]).tolist()
    return {
        "pressure_convention": "psia",
        "error_units": "psi",
        "pooled_non_sink": _scores(frame),
        "scenario_macro_mae_psi": float(scenario_mae.mean()),
        "scenario_bootstrap_macro_mae_95_interval_psi": interval,
        "trunk_macro_mae_psi": float(np.mean([r["mae_psi"] for r in per_trunk])),
        "pressure_bin_macro_mae_psi": float(np.mean([r["mae_psi"] for r in per_bin])),
        "sink_rows_excluded": len(sink),
        "sink_max_boundary_error_psi": (
            float(np.max(np.abs(sink["predicted_psia"] - 44.7)))
            if len(sink) else None
        ),
        "sink_label_max_deviation_psi": (
            float(np.max(np.abs(sink["pressure_psia"] - 44.7)))
            if len(sink) else None
        ),
        "per_scenario": per_scenario,
        "per_trunk": per_trunk,
        "per_pressure_bin": per_bin,
        "per_trunk_pressure_bin": per_trunk_bin,
    }
