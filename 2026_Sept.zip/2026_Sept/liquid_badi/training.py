"""Convergence-triggered fitting and complete, matched model checkpoints."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass
from pathlib import Path
import random
import time

import numpy as np
import torch
from torch.nn import functional as F


@dataclass(frozen=True)
class TrainingConfig:
    # These are optimization scales, not validated uncertainty or acceptance limits.
    pressure_absolute_scale_psi: float = 2.0
    pressure_relative_scale: float = 0.02
    temperature_scale_k: float = 1.0
    temperature_weight: float = 1.0
    learning_rate: float = 0.001
    batch_scenarios: int = 8
    minimum_data_epochs: int = 20
    data_patience: int = 20
    maximum_data_epochs: int = 300
    regularization_epochs: int = 100
    ramp_epochs: int = 30
    regularization_weight: float = 0.01
    relative_improvement: float = 0.0001
    maximum_validation_degradation: float = 0.10
    gradient_clip: float = 10.0
    seed: int = 2026

    def __post_init__(self):
        values = asdict(self)
        for key, value in values.items():
            if not np.isfinite(value):
                raise ValueError(f"{key} must be finite.")
        for key in (
            "pressure_absolute_scale_psi", "temperature_scale_k",
            "learning_rate", "batch_scenarios", "data_patience",
            "maximum_data_epochs", "ramp_epochs", "gradient_clip",
        ):
            if values[key] <= 0:
                raise ValueError(f"{key} must be positive.")
        for key in (
            "pressure_relative_scale", "temperature_weight", "minimum_data_epochs",
            "regularization_epochs", "regularization_weight", "relative_improvement",
            "maximum_validation_degradation",
        ):
            if values[key] < 0:
                raise ValueError(f"{key} cannot be negative.")
        if self.minimum_data_epochs > self.maximum_data_epochs:
            raise ValueError("minimum_data_epochs exceeds maximum_data_epochs.")
        if self.relative_improvement >= 1:
            raise ValueError("relative_improvement must be less than one.")


def normalized_pressure_loss(prediction_psia, target_psia, non_sink, config):
    if non_sink.dtype != torch.bool or non_sink.shape != target_psia.shape:
        raise ValueError("non_sink must be a boolean mask matching pressure labels.")
    if not bool(non_sink.any()):
        raise ValueError("A scenario must contain at least one non-sink pressure label.")
    predicted, target = prediction_psia[non_sink], target_psia[non_sink]
    if not bool(torch.isfinite(predicted).all() & torch.isfinite(target).all()):
        raise ValueError("Nonfinite pressure prediction or label.")
    scale = torch.sqrt(
        config.pressure_absolute_scale_psi ** 2
        + (config.pressure_relative_scale * target.abs()) ** 2
    )
    return F.huber_loss((predicted - target) / scale, torch.zeros_like(target))


def temperature_loss(prediction_k, target_k, config):
    if prediction_k.shape != target_k.shape or target_k.numel() == 0:
        raise ValueError("Temperature labels must be nonempty and match predictions.")
    if not bool(torch.isfinite(prediction_k).all() & torch.isfinite(target_k).all()):
        raise ValueError("Nonfinite temperature prediction or label.")
    return F.huber_loss(
        (prediction_k - target_k) / config.temperature_scale_k,
        torch.zeros_like(target_k),
    )


def _snapshot(model, optimizer, epoch, stage, score):
    return {
        "model_state_dict": deepcopy(model.state_dict()),
        "optimizer_state_dict": deepcopy(optimizer.state_dict()),
        "epoch": epoch, "stage": stage, "validation_data_loss": score,
    }


def fit(model, train_cases, validation_cases, loss_for_case, prior_loss,
        config=None):
    """Fit using whole-simulation cases; never accept blind cases here.

    loss_for_case(model, case, config) returns a scalar pressure+temperature
    objective, already averaged over trunks/nodes within that simulation.
    prior_loss(model) returns the independent constitutive prior, not a
    duplicate residual of equations already enforced by the integrator.
    """
    config = config or TrainingConfig()
    if not train_cases or not validation_cases:
        raise ValueError("Both training and validation simulations are required.")
    random.seed(config.seed)
    np.random.seed(config.seed)
    torch.manual_seed(config.seed)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config.learning_rate, weight_decay=0.0,
    )
    history = []
    best = None
    convergence_score = float("inf")
    stale = 0
    converged = False
    rng = np.random.default_rng(config.seed)
    start = time.perf_counter()

    def validation():
        model.eval()
        with torch.no_grad():
            losses = [float(loss_for_case(model, case, config))
                      for case in validation_cases]
        score = float(np.mean(losses))
        if not np.isfinite(score):
            raise FloatingPointError("Validation loss is not finite.")
        return score

    def epoch_step(epoch, stage, weight):
        model.train()
        order = rng.permutation(len(train_cases))
        total = 0.
        for offset in range(0, len(order), config.batch_scenarios):
            batch = order[offset:offset + config.batch_scenarios]
            optimizer.zero_grad(set_to_none=True)
            data_loss = torch.stack([
                loss_for_case(model, train_cases[int(i)], config) for i in batch
            ]).mean()
            loss = data_loss
            if weight:
                loss = loss + weight * prior_loss(model)
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError(f"Nonfinite training loss in {stage} epoch {epoch}.")
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(
                model.parameters(), config.gradient_clip, error_if_nonfinite=True,
            )
            if not bool(torch.isfinite(norm)):
                raise FloatingPointError("Nonfinite parameter gradient.")
            optimizer.step()
            total += float(data_loss.detach()) * len(batch)
        score = validation()
        history.append({
            "epoch": epoch, "stage": stage, "prior_weight": weight,
            "training_data_loss": total / len(train_cases),
            "validation_data_loss": score,
        })
        return score

    for epoch in range(config.maximum_data_epochs):
        score = epoch_step(epoch, "data", 0.0)
        if best is None or score < best["validation_data_loss"]:
            best = _snapshot(model, optimizer, epoch, "data", score)
        if score < convergence_score * (1 - config.relative_improvement):
            convergence_score, stale = score, 0
        else:
            stale += 1
        if epoch + 1 >= config.minimum_data_epochs and stale >= config.data_patience:
            converged = True
            break
    if best is None:
        raise RuntimeError("No completed data-fitting epoch.")
    model.load_state_dict(best["model_state_dict"])
    optimizer.load_state_dict(best["optimizer_state_dict"])
    data_best = best["validation_data_loss"]
    stage2_rejected = False
    if converged:
        for epoch in range(config.regularization_epochs):
            weight = config.regularization_weight * min(1., (epoch + 1) / config.ramp_epochs)
            score = epoch_step(epoch, "regularization", weight)
            if score > data_best * (1 + config.maximum_validation_degradation):
                stage2_rejected = True
                break
            if score < best["validation_data_loss"]:
                best = _snapshot(model, optimizer, epoch, "regularization", score)
    model.load_state_dict(best["model_state_dict"])
    optimizer.load_state_dict(best["optimizer_state_dict"])
    model.eval()
    return {
        **best,
        "training_config": asdict(config),
        "history": history,
        "data_stage_converged": converged,
        "status": "converged" if converged else "data_budget_exhausted",
        "regularization_rejected_for_degradation": stage2_rejected,
        "training_seconds": time.perf_counter() - start,
        "torch_version": str(torch.__version__),
        "torch_rng_state": torch.get_rng_state(),
    }


def save_checkpoint(path, fitted_state, deployment_config, splits, provenance):
    """Atomically persist matched neural/physical state plus its inference contract."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "format_version": 1,
        **fitted_state,
        "deployment_config": deployment_config,
        "splits": splits,
        "provenance": provenance,
    }
    temporary = path.with_suffix(path.suffix + ".tmp")
    if temporary.exists():
        raise FileExistsError(f"Refusing to overwrite an existing temporary file: {temporary}")
    try:
        torch.save(payload, temporary)
        temporary.replace(path)
    finally:
        if temporary.exists():
            temporary.unlink()
