"""Local sensitivity checks; these do not prove global identifiability."""
from __future__ import annotations

import torch


def scalar_parameter_sensitivity(model, response, parameter_names):
    """Differentiate a small, dimensionless response vector wrt named scalars.

    Pass pressure/temperature predictions divided by declared scales in
    ``response(model)``. Select physical scalars, not thousands of NN weights.
    Derivatives are with respect to the actual parameterization (e.g. logits).
    """
    parameters = dict(model.named_parameters())
    if not parameter_names or len(set(parameter_names)) != len(parameter_names):
        raise ValueError("Provide a nonempty unique list of scalar parameter names.")
    selected = []
    for name in parameter_names:
        if name not in parameters:
            raise ValueError(f"Unknown trainable parameter: {name}")
        value = parameters[name]
        if value.numel() != 1 or not value.requires_grad:
            raise ValueError(f"{name} must be a trainable scalar.")
        selected.append(value)
    with torch.enable_grad():
        values = response(model).reshape(-1)
        if not values.numel() or not bool(torch.isfinite(values).all()):
            raise ValueError("Sensitivity response must be nonempty and finite.")
        rows = []
        for value in values:
            if value.requires_grad:
                derivatives = torch.autograd.grad(
                    value, selected, allow_unused=True, retain_graph=True,
                )
            else:
                derivatives = [None] * len(selected)
            rows.append(torch.stack([
                derivative.reshape(()) if derivative is not None else param.new_zeros(())
                for derivative, param in zip(derivatives, selected)
            ]))
        jacobian = torch.stack(rows).detach()
    norms = torch.linalg.vector_norm(jacobian, dim=0)
    normalized = jacobian / norms.clamp_min(torch.finfo(jacobian.dtype).tiny)
    singular = torch.linalg.svdvals(normalized)
    rank = int(torch.linalg.matrix_rank(normalized))
    return {
        "parameter_names": list(parameter_names),
        "response_count": len(values),
        "parameterization": "stored trainable scalars, not transformed physical values",
        "sensitivity_column_norms": norms.cpu().tolist(),
        "inactive_parameters": [
            name for name, norm in zip(parameter_names, norms) if float(norm) == 0.
        ],
        "normalized_jacobian_singular_values": singular.cpu().tolist(),
        "normalized_jacobian_rank": rank,
        "sensitivity_cosine_matrix": (normalized.T @ normalized).cpu().tolist(),
        "warning": (
            "Local diagnostic only. Near-collinear/zero sensitivities flag weak "
            "identifiability; full rank does not establish unique fluid properties."
        ),
    }
