"""Explicit units and deployment-boundary validation; no simulator fallbacks."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


PSI_TO_PA = 6894.757293168
BBL_DAY_TO_M3_S = 0.158987294928 / 86400.
FT_TO_M = 0.3048
IN_TO_M = 0.0254


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def temperature_kelvin(values, unit):
    values = np.asarray(values, dtype=float)
    if not np.isfinite(values).all():
        raise ValueError("Temperature contains missing or nonfinite values.")
    if unit == "degF":
        result = (values - 32.) * 5. / 9. + 273.15
    elif unit == "degC":
        result = values + 273.15
    elif unit == "K":
        result = values.copy()
    else:
        raise ValueError("Temperature unit must be explicitly degF, degC, or K.")
    if (result <= 0).any():
        raise ValueError("Temperature must be above absolute zero.")
    return result


def geometry_fingerprint(geometry):
    encoded = json.dumps(
        geometry, sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def fixed_source_temperatures(source_observations, training_ids, tolerance_k=0.1):
    """Extract constants only from training simulations, validating each source."""
    required = {"scenario", "source_id", "temperature_k"}
    if not required <= set(source_observations.columns):
        raise ValueError(f"Missing source-temperature columns: {required - set(source_observations.columns)}")
    if not np.isfinite(tolerance_k) or tolerance_k < 0:
        raise ValueError("Source-temperature constancy tolerance must be finite and nonnegative.")
    frame = source_observations.copy()
    if frame[["scenario", "source_id"]].isna().any().any():
        raise ValueError("Missing source or scenario identifier.")
    frame["scenario"] = frame["scenario"].astype(str)
    frame["source_id"] = frame["source_id"].astype(str)
    training_ids = {str(value) for value in training_ids}
    if not training_ids:
        raise ValueError("Training simulation IDs cannot be empty.")
    frame = frame.loc[frame["scenario"].isin(training_ids)]
    if frame.empty:
        raise ValueError("No training source-temperature observations.")
    if not np.isfinite(frame["temperature_k"].to_numpy(dtype=float)).all():
        raise ValueError("Training source temperatures must be finite.")
    if (frame["temperature_k"] <= 0).any():
        raise ValueError("Training source temperatures must be positive kelvin.")
    constants, audit = {}, []
    for source, group in frame.groupby("source_id", sort=True):
        if group["scenario"].duplicated().any():
            raise ValueError(f"Duplicate source/scenario temperature for {source}.")
        if set(group["scenario"]) != training_ids:
            raise ValueError(f"Source {source} is missing in some training simulations.")
        low, high = float(group["temperature_k"].min()), float(group["temperature_k"].max())
        if high - low > tolerance_k:
            raise ValueError(
                f"Source {source} is not fixed: temperature spans {low:.6g}-{high:.6g} K "
                f"(allowed range {tolerance_k:g} K). Supply measured deployment temperatures "
                "or reconcile the export; do not substitute the mean silently."
            )
        constants[str(source)] = float(group["temperature_k"].median())
        audit.append({
            "source_id": str(source), "temperature_min_k": low,
            "temperature_max_k": high, "training_scenarios": len(group),
            "saved_temperature_k": constants[str(source)],
            "constancy_tolerance_k": tolerance_k,
        })
    return constants, audit


def validate_source_inputs(source_ids, rates, watercuts):
    expected = set(source_ids)
    for name, values in (("rates", rates), ("watercuts", watercuts)):
        if set(values) != expected:
            raise ValueError(
                f"{name} source keys differ: missing={sorted(expected - set(values))}, "
                f"unexpected={sorted(set(values) - expected)}."
            )
    q = np.array([rates[key] for key in source_ids], dtype=float)
    wc = np.array([watercuts[key] for key in source_ids], dtype=float)
    if not np.isfinite(q).all() or (q < 0).any():
        raise ValueError("Source liquid rates must be finite and nonnegative.")
    if not np.isfinite(wc).all() or ((wc < 0) | (wc > 1)).any():
        raise ValueError("Watercut must be a fraction in [0, 1], not a percentage.")
    return q, wc
