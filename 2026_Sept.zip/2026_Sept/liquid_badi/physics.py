"""Provisional incompressible oil/water physics in SI units."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math

import numpy as np
import torch
from torch import nn

from .closures import FrictionClosure


@dataclass(frozen=True)
class FluidConfig:
    rho_oil_kg_m3: float
    rho_water_kg_m3: float
    cp_oil_j_kg_k: float = 2000.
    cp_water_j_kg_k: float = 4180.
    water_viscosity_pa_s: float = 0.001
    ambient_initial_k: float = 300.
    ambient_bounds_k: tuple = (289., 320.)
    conductance_initial_w_m_k: float = 2.
    conductance_bounds_w_m_k: tuple = (0.001, 50.)
    mixing_rule: str = "arithmetic"
    n_quad: int = 5

    def __post_init__(self):
        for name in ("rho_oil_kg_m3", "rho_water_kg_m3", "cp_oil_j_kg_k",
                     "cp_water_j_kg_k", "water_viscosity_pa_s"):
            if not math.isfinite(getattr(self, name)) or getattr(self, name) <= 0:
                raise ValueError(f"{name} must be finite and positive.")
        for bounds, value in (
            (self.ambient_bounds_k, self.ambient_initial_k),
            (self.conductance_bounds_w_m_k, self.conductance_initial_w_m_k),
        ):
            if len(bounds) != 2 or not all(math.isfinite(v) for v in (*bounds, value)):
                raise ValueError("Thermal bounds and initial values must be finite.")
            if not 0 < bounds[0] < value < bounds[1]:
                raise ValueError("Thermal initial values must be strictly inside positive bounds.")
        if self.mixing_rule not in {"arithmetic", "logarithmic"}:
            raise ValueError("Select an explicit arithmetic or logarithmic viscosity rule.")
        if self.n_quad < 1:
            raise ValueError("n_quad must be positive.")


def bounded_parameter(initial, bounds):
    fraction = (initial - bounds[0]) / (bounds[1] - bounds[0])
    return nn.Parameter(torch.tensor(math.log(fraction / (1 - fraction)), dtype=torch.float64))


def darcy_friction(reynolds, relative_roughness):
    """Churchill Darcy convention; low-Re wall shear is handled separately."""
    re = reynolds.clamp_min(1.)
    inner = (7 / re).pow(0.9) + 0.27 * relative_roughness
    log_a = 16 * (2.457 * torch.log(1 / inner)).abs().clamp_min(1e-30).log()
    log_b = 16 * (math.log(37530.) - re.log())
    log_sum = torch.logaddexp(12 * (math.log(8.) - re.log()),
                              -1.5 * torch.logaddexp(log_a, log_b))
    return 8 * torch.exp(log_sum / 12)


class LiquidPhysics(nn.Module):
    def __init__(self, config, temperature_k, viscosity_pa_s, closure_config=None):
        super().__init__()
        self.config = config if isinstance(config, FluidConfig) else FluidConfig(**config)
        t, mu = np.asarray(temperature_k, float), np.asarray(viscosity_pa_s, float)
        if t.ndim != 1 or len(t) < 2 or t.shape != mu.shape:
            raise ValueError("PVT needs matching one-dimensional temperature/viscosity arrays.")
        if not (np.isfinite(t).all() and np.isfinite(mu).all()
                and (t > 0).all() and (mu > 0).all()
                and (np.diff(t) > 0).all() and (np.diff(mu) < 0).all()):
            raise ValueError("PVT must be finite, positive and strictly monotone.")
        self.register_buffer("table_temperature_k", torch.tensor(t, dtype=torch.float64))
        self.register_buffer("table_log_mu", torch.tensor(np.log(mu), dtype=torch.float64))
        x, w = np.polynomial.legendre.leggauss(self.config.n_quad)
        self.register_buffer("quad_x", torch.tensor((x + 1) / 2, dtype=torch.float64))
        self.register_buffer("quad_w", torch.tensor(w / 2, dtype=torch.float64))
        self.ambient_logit = bounded_parameter(
            self.config.ambient_initial_k, self.config.ambient_bounds_k,
        )
        self.conductance_logit = bounded_parameter(
            self.config.conductance_initial_w_m_k, self.config.conductance_bounds_w_m_k,
        )
        self.closure = FrictionClosure(**(closure_config or {})).double()

    @property
    def ambient_k(self):
        low, high = self.config.ambient_bounds_k
        return low + (high - low) * self.ambient_logit.sigmoid()

    @property
    def conductance(self):
        low, high = self.config.conductance_bounds_w_m_k
        return low + (high - low) * self.conductance_logit.sigmoid()

    def oil_viscosity(self, temperature):
        table = self.table_temperature_k
        if not bool(torch.isfinite(temperature).all()):
            raise ValueError("Nonfinite temperature in PVT evaluation.")
        if bool(((temperature < table[0]) | (temperature > table[-1])).any()):
            raise ValueError(
                f"Temperature outside dead-oil table [{float(table[0]):g}, "
                f"{float(table[-1]):g}] K. No extrapolation is permitted."
            )
        i = torch.searchsorted(table, temperature.contiguous(), right=True).clamp(1, len(table) - 1)
        fraction = (temperature - table[i - 1]) / (table[i] - table[i - 1])
        return torch.exp(self.table_log_mu[i - 1]
                         + fraction * (self.table_log_mu[i] - self.table_log_mu[i - 1]))

    def density(self, wc):
        return (1 - wc) * self.config.rho_oil_kg_m3 + wc * self.config.rho_water_kg_m3

    def heat_capacity_rate(self, q, wc):
        c = self.config
        return q * ((1 - wc) * c.rho_oil_kg_m3 * c.cp_oil_j_kg_k
                    + wc * c.rho_water_kg_m3 * c.cp_water_j_kg_k)

    def temperature_at(self, inlet_k, distance_m, q, wc):
        capacity = self.heat_capacity_rate(q, wc)
        active = capacity > 1e-12
        exponent = -self.conductance * distance_m / capacity.clamp_min(1e-12)
        flowing = self.ambient_k + (inlet_k - self.ambient_k) * exponent.exp()
        return torch.where(active, flowing, self.ambient_k.expand_as(flowing))

    def friction_gradient(self, q, wc, temperature, diameter, roughness):
        oil_mu = self.oil_viscosity(temperature)
        water_mu = self.config.water_viscosity_pa_s
        if self.config.mixing_rule == "arithmetic":
            mu = (1 - wc) * oil_mu + wc * water_mu
        else:
            mu = ((1 - wc) * oil_mu.log() + wc * math.log(water_mu)).exp()
        rho = self.density(wc)
        velocity = 4 * q / (math.pi * diameter.square())
        re = rho * velocity.abs() * diameter / mu
        rr = roughness / diameter
        f = darcy_friction(re, rr)
        classical = torch.where(
            re < 100, 32 * mu * velocity / diameter.square(),
            f * rho * velocity.abs() * velocity / (2 * diameter),
        )
        features = torch.stack(torch.broadcast_tensors(
            torch.tanh(torch.log1p(re) / 8 - 1), 2 * wc - 1,
            2 * (temperature - self.table_temperature_k[0])
            / (self.table_temperature_k[-1] - self.table_temperature_k[0]) - 1,
            torch.tanh(torch.log(rr.clamp_min(1e-12)) / 10),
        ), dim=-1)
        return classical * self.closure(features)

    def segment_drop(self, q, wc, inlet_k, start_m, length_m, dz_m, diameter, roughness):
        temperature = self.temperature_at(
            inlet_k, start_m[..., None] + length_m[..., None] * self.quad_x, q, wc,
        )
        friction = self.friction_gradient(
            q, wc, temperature, diameter[..., None], roughness[..., None],
        )
        return length_m * (friction * self.quad_w).sum(-1) + self.density(wc) * 9.80665 * dz_m

    def export_config(self):
        return {
            "config": asdict(self.config),
            "temperature_k": self.table_temperature_k.detach().cpu().tolist(),
            "viscosity_pa_s": self.table_log_mu.detach().exp().cpu().tolist(),
            "closure_config": self.closure.config,
        }
