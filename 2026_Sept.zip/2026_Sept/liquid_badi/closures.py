"""One bounded constitutive correction, with comparable small architectures."""
from __future__ import annotations

import math
import torch
from torch import nn


class PolynomialKANLayer(nn.Module):
    """Trainable univariate Chebyshev edge functions, summed at each output."""

    def __init__(self, inputs, outputs, order=3, zero=False):
        super().__init__()
        self.order = order
        self.coefficients = nn.Parameter(torch.zeros(outputs, inputs, order + 1))
        if not zero:
            nn.init.normal_(self.coefficients, std=0.1 / math.sqrt(inputs))

    def forward(self, x):
        x = torch.tanh(x)
        basis = [torch.ones_like(x), x]
        for _ in range(2, self.order + 1):
            basis.append(2 * x * basis[-1] - basis[-2])
        return torch.einsum("...ik,oik->...o", torch.stack(basis, dim=-1), self.coefficients)


class FrictionClosure(nn.Module):
    def __init__(self, kind="mlp", width=32, log_bound=math.log(2.), seed=2026):
        super().__init__()
        if kind not in {"none", "scalar", "mlp", "fourier_mlp", "kan"}:
            raise ValueError(f"Unknown closure: {kind}")
        if width < 1 or not math.isfinite(log_bound) or log_bound <= 0:
            raise ValueError("Closure width and log_bound must be positive.")
        self.config = dict(kind=kind, width=width, log_bound=log_bound, seed=seed)
        self.kind, self.log_bound = kind, log_bound
        if kind == "scalar":
            self.logit = nn.Parameter(torch.zeros(()))
        elif kind == "kan":
            self.net = nn.Sequential(
                PolynomialKANLayer(4, width), PolynomialKANLayer(width, 1, zero=True),
            )
        elif kind in {"mlp", "fourier_mlp"}:
            inputs = 4
            if kind == "fourier_mlp":
                generator = torch.Generator().manual_seed(seed)
                self.register_buffer("frequencies", torch.randn(4, 8, generator=generator) * 0.5)
                inputs += 16
            self.net = nn.Sequential(
                nn.Linear(inputs, width), nn.Tanh(), nn.Linear(width, width),
                nn.Tanh(), nn.Linear(width, 1),
            )
            nn.init.zeros_(self.net[-1].weight)
            nn.init.zeros_(self.net[-1].bias)

    def latent(self, features):
        if self.kind == "none":
            return torch.zeros_like(features[..., 0])
        if self.kind == "scalar":
            return self.logit.expand(features.shape[:-1])
        if self.kind == "fourier_mlp":
            phase = features @ self.frequencies
            features = torch.cat([features, phase.sin(), phase.cos()], dim=-1)
        return self.net(features).squeeze(-1)

    def forward(self, features):
        return torch.exp(self.log_bound * torch.tanh(self.latent(features)))

    def prior(self):
        parameters = list(self.parameters())
        if not parameters:
            return torch.zeros(())
        return torch.stack([p.square().mean() for p in parameters]).mean()
