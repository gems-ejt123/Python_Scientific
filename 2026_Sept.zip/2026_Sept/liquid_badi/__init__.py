"""Liquid-only, boundary-anchored differentiable network integration."""
