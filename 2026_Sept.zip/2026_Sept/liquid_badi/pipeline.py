"""Training and deployment use the same source-only solver path."""
from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn

from .contracts import BBL_DAY_TO_M3_S, PSI_TO_PA, file_sha256, validate_source_inputs
from .evaluation import pressure_report
from .network import LiquidNetwork
from .physics import LiquidPhysics
from .training import fit, normalized_pressure_loss, save_checkpoint, temperature_loss


class MultiTrunkModel(nn.Module):
    def __init__(self, specs, layouts, physics_config, solver_config=None):
        super().__init__()
        self.specs, self.layouts = copy.deepcopy(specs), copy.deepcopy(layouts)
        self.solver_config = solver_config or {}
        self.physics = LiquidPhysics(**physics_config)
        self.networks = nn.ModuleDict({
            trunk: LiquidNetwork(spec, self.physics, **self.solver_config)
            for trunk, spec in specs.items()
        })

    def predict_trunk(self, trunk, rates_m3_s, watercuts, validate_pressure=True):
        if trunk not in self.networks:
            raise ValueError(f"Unknown trunk {trunk}.")
        device = self.physics.table_temperature_k.device
        rates = torch.as_tensor(rates_m3_s, dtype=torch.float64, device=device)
        wc = torch.as_tensor(watercuts, dtype=torch.float64, device=device)
        return self.networks[trunk](rates, wc, validate_pressure=validate_pressure)

    def profile_outputs(self, trunk, state, node_ids):
        network, layout = self.networks[trunk], self.layouts[trunk]
        edge_ids = {edge["id"]: i for i, edge in enumerate(network.edges)}
        pressure, temperature = [], []
        for node in node_ids:
            location = layout[node]
            i, j = edge_ids[location["edge_id"]], location["profile_index"]
            pressure.append(state["pressure_profiles_pa"][i][j] / PSI_TO_PA)
            temperature.append(state["temperature_profiles"][i][j])
        return torch.stack(pressure), torch.stack(temperature)

    def export_config(self):
        return {
            "specs": self.specs, "layouts": self.layouts,
            "physics_config": self.physics.export_config(),
            "solver_config": self.solver_config,
        }


def case_loss(model, case, config):
    losses = []
    for trunk, values in case.items():
        state = model.predict_trunk(trunk, values["rates_m3_s"], values["watercuts"],
                                    validate_pressure=False)
        p, t = model.profile_outputs(trunk, state, values["node_ids"])
        target_p = p.new_tensor(values["pressure_psia"])
        target_t = t.new_tensor(values["temperature_k"])
        mask = torch.tensor(values["is_sink"], dtype=torch.bool, device=p.device)
        losses.append(
            normalized_pressure_loss(p, target_p, ~mask, config)
            + config.temperature_weight * temperature_loss(t, target_t, config),
        )
    if not losses:
        raise ValueError("A simulation contains no trunks.")
    return torch.stack(losses).mean()


def constitutive_prior(model):
    prior = model.physics.closure.prior().to(model.physics.ambient_logit)
    return prior


def fit_and_save(model, prepared, output_directory, config, provenance):
    output_directory = Path(output_directory)
    if output_directory.exists() and any(output_directory.iterdir()):
        raise FileExistsError("Select a new empty run directory; previous experiments are preserved.")
    provenance = copy.deepcopy(provenance)
    for key in ("archive", "source_map"):
        if key in provenance:
            provenance[key + "_sha256"] = file_sha256(provenance[key])
    result = fit(
        model, [prepared.cases[i] for i in prepared.splits["train"]],
        [prepared.cases[i] for i in prepared.splits["validation"]],
        case_loss, constitutive_prior, config,
    )
    save_checkpoint(
        output_directory / "model.pt", result, model.export_config(),
        prepared.splits, {**provenance, "data_audit": prepared.audit},
    )
    pd.DataFrame(result["history"]).to_csv(output_directory / "training_history.csv", index=False)
    with (output_directory / "status.json").open("w") as stream:
        json.dump({key: result[key] for key in (
            "status", "data_stage_converged", "epoch", "stage", "validation_data_loss",
            "training_seconds",
        )}, stream, indent=2, allow_nan=False)
    return result


def load_model(checkpoint_path, device="cpu"):
    payload = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
    if payload.get("format_version") != 1:
        raise ValueError("Unsupported liquid BADI checkpoint version.")
    model = MultiTrunkModel(**payload["deployment_config"])
    model.load_state_dict(payload["model_state_dict"], strict=True)
    model.to(device).eval()
    return model, payload


def predict_sources(model, trunk, source_rates_bbl_day, source_watercuts, queries=None):
    if trunk not in model.networks:
        raise ValueError(f"Unknown trunk {trunk}.")
    network = model.networks[trunk]
    q, wc = validate_source_inputs(
        network.source_ids, source_rates_bbl_day, source_watercuts,
    )
    model.eval()
    with torch.no_grad():
        state = model.predict_trunk(trunk, q * BBL_DAY_TO_M3_S, wc)
        rows = []
        for edge, p, t in zip(network.edges, state["pressure_profiles_pa"], state["temperature_profiles"]):
            for s, pressure, temperature in zip(edge["distance_m"], p, t):
                rows.append({
                    "trunk": trunk, "edge_id": edge["id"], "distance_m": s,
                    "pressure_psia": float(pressure / PSI_TO_PA), "temperature_k": float(temperature),
                })
        interior = []
        for edge_id, distance in queries or []:
            pressure, temperature = network.query(state, edge_id, distance)
            if float(pressure) <= 0:
                raise ValueError("Nonpositive psia at the queried interior point.")
            interior.append({
                "edge_id": edge_id, "distance_m": distance,
                "pressure_psia": float(pressure / PSI_TO_PA), "temperature_k": float(temperature),
            })
    return pd.DataFrame(rows), pd.DataFrame(interior)


def evaluate_cases(model, cases, bootstrap_samples=1000):
    rows, diagnostic_rows, drop_rows = [], [], []
    model.eval()
    with torch.no_grad():
        for scenario, case in cases.items():
            for trunk, values in case.items():
                state = model.predict_trunk(trunk, values["rates_m3_s"], values["watercuts"])
                p, t = model.profile_outputs(trunk, state, values["node_ids"])
                edge_indices = {edge["id"]: i for i, edge in enumerate(model.networks[trunk].edges)}
                for i, node in enumerate(values["node_ids"]):
                    location = model.layouts[trunk][node]
                    e = edge_indices[location["edge_id"]]
                    rows.append({
                        "scenario": scenario, "trunk": trunk, "node_id": node,
                        "pressure_psia": values["pressure_psia"][i], "predicted_psia": float(p[i]),
                        "temperature_k": values["temperature_k"][i], "predicted_temperature_k": float(t[i]),
                        "is_sink": values["is_sink"][i],
                        "edge_id": location["edge_id"],
                        "distance_m": model.networks[trunk].edges[e]["distance_m"][location["profile_index"]],
                        "flow_bbl_day": float(state["flow_m3_s"][e] / BBL_DAY_TO_M3_S),
                        "watercut": float(state["wc"][e]),
                    })
                targets = dict(zip(values["node_ids"], values["pressure_psia"]))
                for edge, predicted in zip(model.networks[trunk].edges, state["pressure_profiles_pa"]):
                    if "profile_node_ids" not in edge:
                        raise ValueError("Evaluation requires profile_node_ids to audit pressure drops.")
                    target = predicted.new_tensor([targets[n] for n in edge["profile_node_ids"]])
                    error = (-predicted.diff() / PSI_TO_PA) - (-target.diff())
                    drop_rows.extend({"scenario": scenario, "trunk": trunk, "error_psi": float(value)}
                                     for value in error)
                cycle = state["cycle_residual_pa"]
                diagnostic_rows.append({
                    "scenario": scenario, "trunk": trunk,
                    "cycle_residual_max_pa": float(cycle.abs().max()) if cycle.numel() else 0.,
                    "flow_residual_max_m3_s": float(state["flow_residual_m3_s"].abs().max()),
                    "water_residual_max_m3_s": float(state["water_residual_m3_s"].abs().max()),
                    "oil_residual_max_m3_s": float(state["oil_residual_m3_s"].abs().max()),
                    "junction_enthalpy_residual_max_w": float(state["junction_enthalpy_residual_w"].abs().max()),
                    "solver_iterations": state["iterations"],
                })
    predictions = pd.DataFrame(rows)
    report = pressure_report(predictions, bootstrap_samples=bootstrap_samples)
    error_t = predictions["predicted_temperature_k"] - predictions["temperature_k"]
    report["temperature_mae_k"] = float(error_t.abs().mean())
    report["temperature_rmse_k"] = float(np.sqrt((error_t ** 2).mean()))
    drop_frame = pd.DataFrame(drop_rows)
    drop_error = drop_frame["error_psi"]
    report["pressure_drop"] = {
        "segments": len(drop_frame), "bias_psi": float(drop_error.mean()),
        "mae_psi": float(drop_error.abs().mean()),
        "rmse_psi": float(np.sqrt((drop_error ** 2).mean())),
        "scenario_macro_mae_psi": float(
            drop_frame.assign(absolute_error=drop_error.abs()).groupby("scenario")["absolute_error"].mean().mean()
        ),
    }
    for column, bins in (
        ("flow_bbl_day", [0., 1000., 10000., 50000., 100000., float("inf")]),
        ("watercut", [0., .5, .8, .9, .95, 1.]),
    ):
        grouped = predictions.loc[~predictions["is_sink"]].copy()
        grouped["_bin"] = pd.cut(grouped[column], bins, include_lowest=True)
        grouped["_error"] = grouped["predicted_psia"] - grouped["pressure_psia"]
        report["per_" + column + "_bin"] = [
            {"bin": str(name), "rows": len(group), "bias_psi": float(group["_error"].mean()),
             "mae_psi": float(group["_error"].abs().mean()),
             "rmse_psi": float(np.sqrt((group["_error"] ** 2).mean()))}
            for name, group in grouped.groupby("_bin", observed=True)
        ]
    return predictions, report, pd.DataFrame(diagnostic_rows)
