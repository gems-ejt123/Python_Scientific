"""Strict CSV/ZIP ingestion with explicit columns and simulation membership."""
from __future__ import annotations

from pathlib import Path
import zipfile

import numpy as np
import pandas as pd

from .contracts import temperature_kelvin


def csv_members(path):
    path = Path(path)
    if path.suffix.lower() == ".csv":
        return [None]
    if path.suffix.lower() != ".zip":
        raise ValueError(f"Expected a CSV or ZIP export: {path}")
    with zipfile.ZipFile(path) as archive:
        members = [info.filename for info in archive.infolist()
                   if not info.is_dir() and (
                       info.filename.lower().endswith(".csv")
                       or not Path(info.filename).suffix
                   )]
    if not members:
        raise ValueError(f"No CSV members in {path}")
    return sorted(members)


def read_export(path, *, member=None, **kwargs):
    """Never select an arbitrary ZIP member or dataset by directory order."""
    path = Path(path)
    members = csv_members(path)
    if path.suffix.lower() == ".csv":
        if member is not None:
            raise ValueError("member is only valid for ZIP input.")
        return pd.read_csv(path, **kwargs)
    if member is None:
        if len(members) != 1:
            raise ValueError(f"Select one CSV member explicitly from {members}")
        member = members[0]
    if member not in members:
        raise ValueError(f"CSV member {member!r} not found in {path}.")
    with zipfile.ZipFile(path) as archive, archive.open(member) as stream:
        frame = pd.read_csv(stream, **kwargs)
    if not isinstance(frame, pd.DataFrame):
        raise ValueError("Streaming iterators are unsupported; request a bounded DataFrame.")
    if len(frame.columns) < 2:
        raise ValueError("Selected archive member is not a tabular CSV; check its delimiter.")
    return frame


def normalize_labels(frame, *, scenario_column, pressure_column,
                     temperature_column, temperature_unit, trunk_column):
    required = {scenario_column, pressure_column, temperature_column, trunk_column}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(
            f"Training export lacks required columns {sorted(missing)}. "
            "Node temperature must be supplied as a target; PVT calibration "
            "temperatures are not a substitute."
        )
    result = frame.copy()
    for column in required:
        if result[column].isna().any():
            raise ValueError(f"Missing values in required column {column}.")
    pressure = pd.to_numeric(result[pressure_column], errors="raise").to_numpy(dtype=float)
    if not np.isfinite(pressure).all() or (pressure <= 0).any():
        raise ValueError("Pressure targets must be finite positive psia; check units/sentinels.")
    temperature = pd.to_numeric(result[temperature_column], errors="raise")
    result["scenario"] = result[scenario_column].astype(str)
    result["trunk"] = result[trunk_column].astype(str)
    result["pressure_psia"] = pressure
    result["temperature_k"] = temperature_kelvin(temperature, temperature_unit)
    return result
