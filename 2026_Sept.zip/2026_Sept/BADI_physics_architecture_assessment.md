# BADI: physics formulation and architecture recommendation

Assessment date: 2026-09-09.

**Implementation follow-up:** the new
[liquid-thermal CPF2 notebook](./BADI_Liquid_Thermal_CPF2.ipynb) and
[implementation guide](./README.md) now implement the provisional solver and
training/deployment workflow. The user confirmed psia pressures, no free gas,
fixed source temperatures, and approved a provisional dead-oil baseline with
bounded fitted thermal parameters. A later screenshot adds API 13 and water
SG 1.02; see the guide for reference-state handling. The present CPF2 archive
was directly checked and still lacks temperature; the user will provide an
updated export. Synthetic/analytical verification is not a real-data
retraining result. The audit and historical comparisons below remain unchanged.

Scope: the [current BADI notebook](../PINN_MultiTrunk_PI-KAN_2026_BADI_PHYS.ipynb), its supporting implementation, the [PVT image](../pvt_rub.png), and the [supplied papers](../Papers/). This is a design assessment, not a newly trained model or a claim of improved accuracy.

## 1. Recommendation

**Keep the exact sink anchoring and network integration. Replace independently adjustable pressure, friction, viscosity, and density corrections with a small, shared constitutive model inside a differentiable one-dimensional network solver. Start with a smooth MLP closure, not a larger pressure-predicting KAN.**

The most important decisions are the fluid regime, property consistency, deployment input contract, and loss scaling. Changing the neural architecture cannot resolve missing thermodynamic inputs or non-identifiable parameters.

**The implementation audit identifies issues to address before architecture comparisons:** a physically unjustified sink-pressure floor, inconsistent source-only inputs between encoder and backbone, imperfect junction/source aggregation, and an active "KAN" that is actually a dense MLP. Section 12 gives code locations, measured saved-replay errors, and verification limits.

Recommended progression:

1. A calibrated, liquid-only hydraulic solver, **if negligible free gas and a defensible thermal assumption are established**.
2. A small shared correction to the uncertain liquid/emulsion viscosity law, or to the friction closure, but not both freely.
3. Coupled thermal or gas-liquid physics only when the corresponding boundary conditions and fluid characterization are available.
4. Fourier features and low-order KAN/FEKAN as controlled ablations of the same closure, solver, and training data.

The exported PIPESIM `lambda` must **not** be labeled or supervised as a Darcy/Fanning friction factor merely because it appears in a pressure-loss expression. Its exact documented definition must be established first. A simulator correction factor and a wall-friction factor are different quantities.

## 2. Define the deployment problem before the network

Known at inference:

- Source `FlowrateLiquidInSitu` and `Watercut`.
- Fixed network connectivity and geometry: length, diameter, and elevation profile.
- Sink pressure of 44.7 psi, with its **absolute/gauge convention explicitly specified**.

The following assumptions must be recorded, not learned implicitly:

- Whether flows are steady and the network has a unique downstream path to the sink.
- Whether watercut is an in-situ or standard-condition liquid volume fraction.
- The pressure/temperature basis of the source in-situ liquid rates.
- Whether free gas is negligible everywhere, including the lowest-pressure locations.
- Whether inlet temperatures, ambient conditions, valve settings, roughness, and fluid composition remain fixed.

### Junction conservation

For incompressible oil and water on a consistent volume basis:

$$
Q_{w,e}=\sum_{i\in U(e)} WC_i Q_{L,i},\qquad
Q_{o,e}=\sum_{i\in U(e)}(1-WC_i)Q_{L,i},
$$
$$
Q_{L,e}=Q_{o,e}+Q_{w,e},\qquad WC_e=Q_{w,e}/Q_{L,e}.
$$

Here \(U(e)\) contains the sources feeding edge \(e\). These quantities should be constructed from source inputs, not copied from a simulator's internal profile during validation.

For pressure/temperature-dependent densities, conserve **component mass rates**, and reconstruct local phase volumes using local properties. Summing actual volumetric rates measured at different states is not exact conservation. In black-oil flow, dissolved/free-gas transfer also requires conserving components rather than gas and oil phase volumes separately.

Source *in-situ* rate presents a subtle coupling: conversion to mass requires source density, which may depend on the source pressure being solved for. A consistent implicit boundary calculation or a documented incompressible/reference-state approximation is required.

For a sink-directed tree with prescribed source injections, edge flows follow from conservation. For loops or split flow paths, one sink boundary plus source injections does not prescribe every edge flow: solve pressures and flow splits simultaneously.

## 3. Pressure balance: integrate physical contributions, not arbitrary offsets

Let \(s\) increase downstream toward the sink, with \(z\) positive upward. For steady, no-slip liquid flow within a constant-area element:

$$
\frac{dP}{ds}
=-\rho_Lg\frac{dz}{ds}
-\frac{f_D}{D}\frac{\rho_Lu|u|}{2}
-\rho_Lu\frac{du}{ds},
\qquad u=\frac{Q_L}{\pi D^2/4}.
$$

For positive downstream flow and path endpoint \(S\):

$$
P(s)=P_{\rm sink}
+\int_s^S\left[
\rho_Lg z'
+\frac{f_D}{D}\frac{\rho_Lu^2}{2}
+\rho_Lu u'
\right]d\xi
+\sum_{\text{downstream fittings}}K\frac{\rho_Lu^2}{2}.
$$

Important distinctions:

- Friction dissipates energy; the hydrostatic contribution is signed.
- Pressure need not fall monotonically along a downhill pipe. Do **not** impose \(P\geq P_{\rm sink}\) everywhere.
- Acceleration vanishes for incompressible flow within a constant-diameter element. Treat diameter changes and local losses explicitly rather than differentiating across a geometry discontinuity.
- \(f_D\) is dimensionless **Darcy** friction; \(f_D=4f_F\) if using a Fanning convention.
- Use SI internally: Pa, m, kg/s or m3/s on a declared state basis, kg/m3, Pa s, and K. Convert pressure to psi only at interfaces.

Retain the useful BADI structure:

$$
\mathbf P=P_{\rm sink}\mathbf 1+
A\,\Delta\mathbf P_{\rm physical}(\mathbf P,\mathbf T,\dot{\mathbf m};\theta),
$$

where \(A\) is the correctly oriented sink-path integration operator for a tree. The sink row is zero. Junctions use one shared pressure.

Unlike a fixed backbone plus free additive segment offsets, the recommended edge increments are computed from consistent properties and wall shear. If properties depend on pressure or temperature, this is an implicit system, not a single multiplication by \(A\).

An appropriate differentiable midpoint discretization is

$$
P_i-P_{i+1}=\Delta s_i\,
\Phi(P_{i+1/2},T_{i+1/2},\dot m_i,D_i,z'_i;\theta).
$$

Solve the discretized equations to a reported tolerance and differentiate through the converged solve or a verified unrolled iteration. Unconverged iterations, detached property evaluations, or target pressures in the property calculation give a different model.

### Pressure at any point

An endpoint model is not automatically a continuous pressure model. For a query inside an edge, integrate from its downstream node to the query position, using the local elevation/diameter profile and property evaluation. A proportional fraction of endpoint pressure drop is justified only under a constant-gradient approximation.

If only total length and net elevation difference are available, arbitrary interior pressure is not uniquely specified for a nonuniform pipe. Supply \(z(s)\) and diameter/fitting breakpoints, or explicitly assume constant diameter and linear elevation between known points.

## 4. Train constitutive parameters, not three independent physical fields

### A defensible liquid parameterization

For no-slip liquid phases with watercut defined at the local state:

$$
\rho_L=WC\,\rho_w(P,T)+(1-WC)\rho_o(P,T).
$$

The mixture viscosity should follow a specified oil/water or emulsion mixing model:

$$
\mu_L=\mu_{\rm mix}\big(\mu_o(P,T),\mu_w(P,T),WC;\theta_{\rm emul}\big).
$$

Watercut does not, by itself, identify emulsion state or phase inversion. Reproduce the configured simulator rule for the simulator-emulation baseline; do not invent a different blending formula from the screenshot's label.

Compute

$$
Re=\rho_L|u|D/\mu_L,\qquad
f_D=f_{\rm corr}(Re,\epsilon/D).
$$

Use \(64/Re\) in laminar flow and a validated turbulent relation with a documented transition treatment. A turbulent-only correlation is not a valid universal closure for viscous heavy oil. At zero flow, use a nonsingular formulation of wall shear; the laminar pressure-gradient form is linear in \(Q\).

The **first trainable parameter set** should be small:

| Quantity | Preferred treatment | Evidence needed to release more freedom |
|---|---|---|
| Oil/water density | Fixed PVT/reference law initially | Density or hydrostatic observations and well-defined phase fractions |
| Oil viscosity | PVT temperature law | Direct viscosity/PVT constraints for any correction |
| Emulsion/mixing behavior | A small shared calibration, if uncertain | Watercut coverage and temperature/viscosity evidence |
| Roughness | Positive, bounded parameter per material/pipe class, if informative | Geometry/material priors and turbulent-flow sensitivity |
| Darcy friction | Derived from \(Re,\epsilon/D\); not an independent scalar field | A separately justified effective closure mismatch |
| Local-loss coefficients | Fixed known fittings or a few grouped coefficients | Identified equipment and enough excitation to separate from distributed loss |

**Choose among potentially confounded parameters; do not automatically train every row in this table.** Roughness will be weakly or wholly unobservable in laminar flow.

If a residual remains, one possible friction correction is

$$
f_{\rm eff}=f_{\rm corr}\exp\{b\tanh N_\theta(\log Re,\epsilon/D,WC,\ldots)\}.
$$

The multiplier equals one at zero network output, remains positive, and is bounded. Choose its allowed range from property uncertainty and validation, not as another unconstrained tuning knob. Keep the governing hydrostatic term separate. Alternatively place the one correction in the uncertain viscosity/mixing law, with friction then derived consistently.

### Why unrestricted trainable \(f,\rho,\mu\) is not a clean inverse problem

At fixed actual volume rate, horizontal turbulent pressure loss contains approximately \(f_D\rho Q^2\); with fixed mass rate, it contains \(f_D\dot m^2/\rho\). Pressure can constrain these combinations without uniquely determining their factors.

In laminar flow:

$$
\Delta P_f=\frac{128\mu LQ}{\pi D^4},
$$

so density cancels entirely from friction loss. In fully rough turbulent flow, viscosity has little influence on friction. In gas-liquid flow, hydrostatic measurements constrain holdup-weighted density, not necessarily density and holdup separately.

Therefore, positivity, bounded outputs, 300 scenarios, and a small momentum residual do not establish simultaneous identifiability. Use pressure-sensitivity Jacobian singular values, parameter correlations, profile likelihoods, and scenario-bootstrap stability. If inferred properties vary substantially while pressures remain stable, report them as effective closure parameters, not recovered fluid properties.

## 5. What the supplied PVT image actually supports

The [image](../pvt_rub.png) shows:

- A **dead-oil viscosity versus temperature** table.
- Undersaturated-oil correlation: De Ghetto, Paone and Villa (1995).
- Live-oil correlation: Beggs and Robinson (1975).
- An emulsion-viscosity setting labeled "Volume ratio of oil and water viscosities."

It does **not** contain a full pressure-temperature PVT grid, oil/water densities, bubble point, solution GOR, formation volume factors, gas properties, or thermal boundary conditions.

Visible table values were manually transcribed into [pvt_dead_oil_viscosity_transcribed.csv](./pvt_dead_oil_viscosity_transcribed.csv). This is an image transcription, **not a validated digital PVT export**.

- 60 F: 25,689.92 cP.
- 100 F: 2,091.45 cP = 2.09145 Pa s.
- 160 F: 208.06 cP.
- The 60-to-160 F viscosity ratio is approximately **123.47**.
- The 100-to-110 F ratio is approximately **1.60**.

That sensitivity makes an unknown temperature capable of appearing as an apparent friction correction. It does not prove that temperature caused the observed pressure errors; watercut, emulsion behavior, gas, and flow regime also matter.

For interpolation, use a positive, monotone table representation, preferably interpolating **log viscosity** rather than raw viscosity. Piecewise log-linear interpolation is continuous and differentiable almost everywhere, usually sufficient for first-order solver differentiation; use a monotone differentiable smoother if higher derivatives are required. Do not silently extrapolate beyond 60-160 F or substitute dead-oil viscosity for live-oil viscosity without justification.

### Does this require temperature as an output?

**Not necessarily.**

1. **Known, effectively isothermal case:** evaluate viscosity at the known fixed temperature. No additional output is needed.
2. **Known temperature profile:** use that profile as fixed model information.
3. **Non-isothermal operation with known/fixed thermal boundaries:** solve temperature as a physical state, possibly with temperature supervision from the simulations.
4. **Unobserved, varying inlet temperature or thermal conditions:** adding a temperature head does not make the source-\(Q,WC\)-to-pressure map well posed. Additional deployment measurements, justified fixed assumptions, or explicit conditional uncertainty are necessary.

For a reduced, liquid sensible-heat model:

$$
\dot m c_p\frac{dT}{ds}=-U\pi D_o(T-T_{\rm ambient}).
$$

This approximation omits important effects if pressure-work, Joule-Thomson, phase change, or kinetic/potential energy changes are appreciable. In that case use a thermodynamically consistent enthalpy/energy balance. Thermal integration follows source inlet-temperature boundaries; pressure uses the sink boundary, so pressure and temperature may need a coupled solve.

At junctions mix enthalpy using mass conservation, rather than taking an unweighted average of temperatures. Do not infer both heat-transfer coefficients and unconstrained inlet temperatures from pressure alone without a demonstrably informative inverse problem.

Simulator temperatures and phase properties can be **training-only auxiliary labels** if they are exported. They are not acceptable hidden inference inputs. Exporting them does not require making them deployment features.

## 6. If free gas matters, use gas-liquid physics

The lowest-pressure region is a reason to check bubble-point crossing and gas expansion, not proof that either occurs.

If free gas is appreciable, the liquid-only expression is insufficient. A schematic constant-area summed momentum balance is

$$
-\frac{dP}{ds}
=\rho_hg z'
+\frac{4\tau_w}{D}
+\frac{d}{ds}\left(\sum_k\rho_k\alpha_k u_k^2\right),
\qquad \rho_h=\sum_k\alpha_k\rho_k.
$$

Here \(\alpha_k\) is phase holdup and \(u_k\) is phase velocity. Phase slip changes the hydrostatic density and momentum flux. A standard Beggs-Brill or validated drift-flux/two-fluid closure is a defensible baseline [R2, R3]. Its holdup, friction, and acceleration conventions must be implemented consistently.

Do not replace density in every liquid term by the same arbitrary "mixture density": holdup density and a friction correlation's no-slip reference density can differ. Likewise, a Beggs-Brill acceleration denominator is closure-specific and should not be copied as a universal compressibility correction.

Required characterization includes gas/component rates or a justified fixed GOR, oil/gas/water PVT, bubble point/solution-gas behavior, and temperature assumptions. The supplied viscosity image cannot close this system. If these quantities vary independently but remain unobserved at inference, exact pressure prediction from only \(Q_L,WC\) is not physically identifiable.

## 7. Address low-pressure error with diagnosis and a suitable objective

First distinguish:

- **Absolute error:** psi error is actually worse in the low-pressure region.
- **Relative-error effect:** comparable psi error becomes a larger percentage at lower pressure.
- **Domain mismatch:** low pressure coincides with a particular trunk, flow range, watercut, phase regime, or simulator/deployment feature mismatch.

Report both pressure and **signed** sink-referenced increments \(P-P_{\rm sink}\). Never divide percentage error by a pressure increment that approaches zero at the sink.

A suitable data objective is a scenario-balanced, scale-normalized Huber loss:

$$
\mathcal L_P=
\frac{1}{N_{\rm scenarios}}\sum_c\frac{1}{n_c}
\sum_{i\in c}\operatorname{Huber}
\left[
\frac{\widehat P_i-P_i}
{\sqrt{\sigma_{\rm abs}^2+(r|P_i|)^2}}
\right].
$$

\(\sigma_{\rm abs}>0\) is a documented absolute accuracy scale in psi, and \(r\) is the desired relative scale. They are engineering tolerances or validation-selected scales, **not inferred measurement uncertainties unless calibrated as such**. Fix the pressure convention before defining relative error. This objective reduces high-pressure dominance without a singular low-pressure weight.

Other useful measures:

- Macro-average over pressure bins and trunks when evaluating model selection, rather than letting dense high-pressure regions dominate.
- Monitor edge pressure-drop errors where both endpoint targets exist; use absolute-error floors and geometry-aware weighting.
- Exclude exactly enforced sink points from headline predictive accuracy so they do not inflate scores.
- Keep hydrostatic sign changes and uphill/downhill subsets visible.
- Do not use blanket pressure floors to make predictions look physical.

A loss change alone cannot repair wrong units, source aggregation, a friction-factor convention, or a missing gas/temperature state.

## 8. Architecture: a closure network inside the solver

```text
Source QL, WC + fixed topology/geometry + declared fluid/thermal assumptions
                               |
          conservative component/phase-flow construction
                               |
           PVT + classical hydraulic closure + small NN correction
                               |
       differentiable edge integration / coupled network solve
          exact sink pressure and shared junction pressures
                               |
            P at nodes and arbitrary positions along edges
```

Recommended initial neural closure: **2-3 hidden layers, 32-64 units, tanh or SiLU**, with shared weights across edges. This size is a starting hypothesis, not an established optimum. Use a linear latent output followed by the explicitly bounded constitutive transform.

Feed physically useful local, deployment-computable quantities: watercut, Reynolds number and relative roughness computed consistently inside the solver, and temperature/phase quantities only when actually provided by a valid state calculation. Avoid arbitrary segment IDs and unnecessary raw spatial coordinates in a constitutive law.

| Candidate | Recommendation |
|---|---|
| Shared smooth MLP closure | First neural model: small, stable, easy to constrain and compare |
| Fourier-feature MLP closure | Add only if residuals show unresolved multiscale structure; retain raw inputs and tune modest bandwidth |
| Low-order KAN/FEKAN closure | Useful ablation for nonlinear constitutive relations; compare total solve/training cost, seeds, and extrapolation |
| Independent large networks per trunk | Not the first choice with 300 scenarios; share constitutive information and retain explicit network coupling |
| Direct pressure-coordinate PINN | Secondary baseline; it must relearn integration and junction constraints that the solver already knows |
| Graph neural network/neural operator | More compelling when transferring across many topologies; not automatically warranted for one small fixed network |

Fourier features target spectral bias, not missing physics. Heavy-oil viscosity can vary sharply with temperature while remaining smooth and nonperiodic; a table/PVT law often represents it better than high-frequency spatial features.

KAN has no demonstrated universal superiority for this problem. Feature enrichment can improve the underlying KAN, but the supplied FEKAN article itself discusses feature-selection sensitivity and overfitting [R8]. General PINN/PIKAN comparisons do not constitute field validation of oil/water network pressure predictions [R5, R6].

## 9. Training and the evidence needed to choose a winner

Use a genuinely data-converged-first recipe. The current loop starts introducing physics at epoch 1, rather than waiting for data convergence; it does not implement adaptive loss balancing:

1. **Data-fit stage:** fixed physical assumptions and the smallest selected trainable closure; optimize pressure and any legitimately available auxiliary labels. Soft physics/closure-regularization penalties start at zero. Exact architectural sink anchoring and conservation remain in force.
2. **Physics/regularization stage:** after held-out data fitting stabilizes, gradually ramp closure priors, auxiliary constitutive consistency, and any genuinely independent residual penalties. If introducing adaptive balancing, validate it as a separate change; monitor pressure-bin errors throughout.
3. **Selection:** restore the best validation checkpoint, with scalers, source-conservation rules, geometry, property tables, pressure convention, and solver tolerances bundled.

For a solver that already satisfies the discretized momentum equation, a second penalty for the identical equation is redundant. Its residual is primarily a convergence/discretization diagnostic. Physics integration does not require inventing another contradictory momentum target.

Use **whole simulation IDs** for every train/validation/test split. All trunks, nodes, and sampled positions from one simulation stay together. Fit scalers and any backbone calibration on training simulations only. Hundreds of thousands of profile rows do not create hundreds of thousands of independent operating scenarios.

With 300 cases, a locked test set plus scenario-grouped validation is more informative than a single row-wise split. Also evaluate held-out low-flow, high-watercut, and other operating-envelope extremes. Keep the final test set out of architecture selection.

Compare, on identical inputs and splits:

1. Current BADI, with its production inference route.
2. Clean classical solver with a few calibrated parameters and no NN.
3. Solver plus small MLP closure.
4. Same solver plus Fourier-MLP closure.
5. Same solver plus low-order KAN/FEKAN closure.

Change formulation and architecture in separate ablations; otherwise their contributions are confounded.

Required outputs:

- MAE/RMSE/bias in psi by pressure bin, trunk, flow, and watercut.
- Scenario-macro scores, percentile/worst-case errors, and scenario-bootstrap intervals.
- Pressure-drop error, exact sink error, and junction/component conservation.
- Grid refinement and interior-point pressure accuracy.
- Sensitivity/identifiability of calibrated parameters and closure bounds.
- Solver convergence failures, inference latency, training cost, and seed variability.
- Learning curves over subsets of the available simulations.

Acceptance must be based on specified engineering tolerances and held-out scenarios, not a generic R2/MAPE threshold. A future calibrated uncertainty interval should respect scenario dependence; pointwise residual pooling across correlated nodes does not establish network-wide coverage.

No architecture comparison or retraining has been performed in this assessment. Section 12 reports differences between existing frozen-model replays with and without the backbone floor; those are not retrained-model or production-field improvements. Agreement with PIPESIM establishes simulator emulation, not independent field validation.

## 10. Literature: what is actually supported

### Direct oil-and-gas evidence

**[R1] Pan et al. (2024), "Oil-Gas Multiphase Flow Surrogate Model Embedded With Mechanism Formulas."** ASME IPC2024-133744. [DOI](https://doi.org/10.1115/IPC2024-133744). Supplied [paper](../Papers/OIL-GAS%20MULTIPHASE%20FLOW%20SURROGATE%20MODEL%20EMBEDDED%20WITH%20MECHANISM.pdf) and [text extraction](../Papers/OIL_GAS_MULTIPHASE_FLOW_extracted.txt).

- PDF pp. 3-4: momentum/property consistency and predictions of pressure, temperature, gas density, gas superficial velocity, holdup, and two-phase friction factor. Viscosity is not an output.
- PDF p. 5: 172,972 PIPESIM-generated samples; this is not a 300-scenario network study.
- PDF pp. 5-7: improvement over a data-only model, but no field validation, no water phase, and fixed standard-condition fluid densities.
- Table 2 pressure-MAPE values 0.0143 versus 0.0235 imply about 39.1% reduction; do not repeat the inconsistent 67.6% prose claim.
- Useful mechanism-informed precedent, **not proof that pressure-only data identify all intermediate properties**.

**[R2] Kanin et al. (2019), "A predictive model for steady-state multiphase pipe flow: Machine learning on lab data."** Journal of Petroleum Science and Engineering 180, 727-746. [DOI](https://doi.org/10.1016/j.petrol.2019.05.055), [primary manuscript](https://ar5iv.labs.arxiv.org/html/1905.09746).

- Learns holdup, flow regime, and friction-related closures inside a segmented pressure calculation.
- Trains on laboratory data and tests endpoint pressure on Forties/Ekofisk wells and Prudhoe Bay flowlines.
- Field performance is competitive, **not uniformly better than the best classical comparator**. Inferred internal profiles are not independently measured field truth.
- The closest evidence here for learning closures while retaining momentum integration; not a demonstration of arbitrary network-topology transfer.

**[R3] Beggs and Brill (1973), "A Study of Two-Phase Flow in Inclined Pipes."** JPT 25(5), 607-617. [DOI](https://doi.org/10.2118/4007-PA), [supplied paper](../Papers/A%20Study%20of%20Two-Phase%20Flow%20in%20Inclined%20Pipes.pdf).

- Experimental/empirical holdup and friction closure, including inclination effects; an established baseline, not universal first-principles multiphase physics.
- Bibliographic identity and original abstract/introduction verified; the supplied PDF is scanned, so its full coefficients were not rederived here.

### Solver and architecture evidence: relevant, but not oilfield proof

**[R4] Xu and Darve (2022), "Physics constrained learning for data-driven inverse modeling from sparse observations."** JCP 453, 110938. [DOI](https://doi.org/10.1016/j.jcp.2021.110938), [primary manuscript](https://ar5iv.labs.arxiv.org/html/2002.10521).

- Section 2.3 supports learning unknown embedded functions through an implicit physics solve, with \(du/d\theta=-F_u^{-1}F_\theta\).
- Methodological support for the recommended structure; not a guarantee of identifiability or oilfield performance.

**[R5] Toscano et al. (2025), "From PINNs to PIKANs: recent advances in physics-informed machine learning."** Machine Learning for Computational Science and Engineering 1:15. [DOI](https://doi.org/10.1007/s44379-025-00015-1), [actual supplied PIKAN_vs_PINN.pdf](../Papers/PIKAN_vs_PINN.pdf).

- This supplied file is a **review**, not the FAIR-comparison paper below.
- PDF pp. 5-6 discuss feature expansions, hard constraints, and KAN representations. It supports considering these methods, not declaring one best for this network.

**[R6] Shukla et al. (2024), "A comprehensive and FAIR comparison between MLP and KAN representations for differential equations and operator networks."** CMAME 431, 117290. [DOI](https://doi.org/10.1016/j.cma.2024.117290), [primary manuscript](https://ar5iv.labs.arxiv.org/html/2406.02917).

- Accuracy, stability, polynomial order, seed, and per-iteration cost all matter. Section 3.4/Table 4 does not establish universal PIKAN superiority.
- Its artificial entropy-viscosity stabilization is **not** recovery of physical fluid viscosity.

**[R7] Wang, Wang and Perdikaris (2021), "On the eigenvector bias of Fourier feature networks: From regression to solving multi-scale PDEs with physics-informed neural networks."** CMAME, 113938. [DOI](https://doi.org/10.1016/j.cma.2021.113938), [primary manuscript](https://ar5iv.labs.arxiv.org/html/2012.10047).

- Section 3.2 explains frequency-bandwidth effects; sparse-data examples also show overfitting/oscillatory interpolation with excessive bandwidth.
- Supports a tuned Fourier-feature ablation, not blanket use of high-frequency encodings.

**[R8] Menon and Jagtap (2026), "FEKAN: Feature-Enriched Kolmogorov-Arnold Networks."** CMAME 461, 119141. [DOI](https://doi.org/10.1016/j.cma.2026.119141), [supplied journal article](../Papers/FEKAN.pdf).

- The supplied title page states **available online 16 June 2026**. This is a journal article, not merely an unverified preprint.
- PDF pp. 5, 18, 30-32: feature enrichment improves several KAN/PDE/operator benchmarks, but feature choice, bandwidth, and overfitting remain limitations.
- Not an oil-and-gas network benchmark and not evidence that FEKAN beats a tuned Fourier-MLP for these 300 scenarios.

**[R9] Dwivedi, Sixou and Sigovan (2025), "Curriculum learning-driven PIELMs for fluid flow simulations."** Neurocomputing 650, 130924. [DOI](https://doi.org/10.1016/j.neucom.2025.130924), [supplied preprint](../Papers/Curriculum_Learning-Driven_PIELMs_for_Fluid_Flow_S.pdf).

- Nonlinear-PDE continuation and physically informed basis placement; Burgers, cavity, and stenotic-vessel examples.
- Useful optimization ideas, but not multiphase network inversion or simultaneous recovery of friction, density, and viscosity.

The supplied [Brill/Beggs book scan](../Papers/James%20P%20Brill%20,%20H%20Dale%20Beggs%20-%20Two-phase%20flow%20in%20pipes%20%20-s.n.%5D%20(1991).pdf) was identified as an image-based 640-page file. Its filename's edition/year was not independently established; no page-specific quantitative claim depends on it.

## 11. Decisions required before implementation

1. Is the 44.7 psi sink boundary **psia or psig**, and are all pressure targets on the same convention?
2. What precisely does exported `lambda` mean in this PIPESIM case/export?
3. Are gas rates/GOR and bubble-point information available, and is the network demonstrably liquid-only?
4. What temperatures were prescribed/generated in the 300 simulations, and what thermal conditions are known or fixed at deployment?
5. Can the digital PVT, temperature/phase-property labels, and full along-pipe geometry be exported?
6. What low-pressure error tolerance in psi is operationally required?

Until these are answered, the defensible deliverable is a conditional formulation and a controlled comparison, not an assertion that three free trainable physical properties or a larger KAN will solve the error.

## 12. Verified audit of the current implementation

Notebook cell indexes below are **zero-based**, with persistent cell IDs where useful. Module references use one-based source line numbers. No existing notebook, library, checkpoint, or diagnostic file was modified.

### 12.1 Active architecture and output semantics

Configuration: notebook cell 4 (`ad6f2707`); model construction: cell 11 (`5e294c8e`), cell-source lines 198-207.

- CPF2 data, five trunks, 300 scenarios per trunk.
- Eight encoder inputs: the five named features, segment elevation/length increments, and local collocation coordinate.
- Width 256; four affine/SiLU/LayerNorm blocks; two outputs; **268,034 parameters per trunk**.
- Three-point Gauss-Legendre quadrature.
- `pinn` preset, Churchill friction, nominal drift-flux holdup, effective initial viscosity 450 cP.
- Fixed oil/water density constants 46/64 lbm/ft3 and roughness 0.0018 in.

The factory selects `simple_enhanced` in [pikan_trainer.py](../libraries/pikan_trainer.py#L33), constructs `SimpleEnhancedKAN` through [pinn_models.py](../libraries/pinn_models.py#L1236), and executes the dense architecture in [kan_architecture.py](../libraries/kan_architecture.py#L286). Spline arguments are explicitly unused at lines 305-306.

**This run is not a spline KAN or FEKAN run.** It has neither Fourier enrichment nor graph message passing.

The model applies tanh to the first output and softplus to the auxiliary output; cell 11 then applies tanh and sigmoid again. Consequently:

$$
|\delta_{\rm segment}| < 7.55\tanh(1)\simeq5.7500\ {\rm psi},
\qquad \widehat H_L=\operatorname{sigmoid}(\operatorname{softplus}(a))\in(0.5,1).
$$

These are verified output restrictions, not a measured explanation of all pressure errors. Return explicit raw logits and transform each physical quantity once in a future implementation. A fixed correction allowance per segment also needs a mesh-refinement check.

### 12.2 Lambda is already separate from Darcy friction in the active path

- [deployable backbone preparation](../libraries/deploy_predict.py#L46) sets exported `lambda_friction` to 1 and reconstructs liquid velocity/density.
- The backbone fits effective per-flowline coefficients to training pressures; these are not measured fluid friction factors.
- Cell 11 passes `lam=None` to the Churchill momentum branch.
- [physics_residual.py](../libraries/physics_residual.py#L188) computes Darcy friction from Reynolds number and relative roughness.
- Only the optional non-Churchill branch uses `f = f0 * lam`.

Thus the active run does **not** feed exported PIPESIM lambda into its backbone or Churchill closure. There is no need to "learn lambda as Darcy f." The optional multiplier interpretation remains a modeling assumption until the export definition is confirmed.

An executed autograd check found `phys.log_f0.grad is None` in the active Churchill branch. The printed unchanged value near 0.0273 is **not an identified friction parameter**.

### 12.3 Low-pressure error: a verified floor effect, not just MAPE

The [backbone reconstruction](../libraries/backbone_reconstruction.py#L367) defaults to `floor="sink"` and replaces the backbone by its maximum with 44.7 psi. The neural residual can still lower the final notebook prediction, so this is a **backbone floor**, not an absolute lower bound on every notebook prediction.

Separately, [predict_network](../libraries/deploy_predict.py#L448) can floor the final output. Notebook evaluation and the source-scenario API do not apply that same final-output floor. These paths therefore have different low-pressure behavior.

The saved blind labels contain **1,153 pressures below 44.7 psi**, reaching **22.685 psi**. The sink pressure is a boundary value, not a physically valid network-wide minimum.

The audit calculated the following from existing frozen-model replay files:

- [Notebook-backbone-floor replay](../outputs/pressure_accuracy_publication/inputs/blind_predictions_notebook_backbone_floor.csv).
- [Unfloored-backbone replay](../outputs/pressure_accuracy_publication/inputs/blind_predictions.csv).

| True pressure, psi | Node rows | Floor bias, psi | Floor MAE, psi | No-floor bias, psi | No-floor MAE, psi |
|---|---:|---:|---:|---:|---:|
| <44.7 | 1,153 | +8.583 | 8.882 | -2.563 | 5.103 |
| 44.7-75 | 13,251 | +0.743 | 3.444 | +0.254 | 3.499 |
| 75-100 | 14,827 | -0.145 | 3.181 | -0.153 | 3.189 |
| 100-150 | 33,785 | -0.035 | 3.012 | -0.035 | 3.012 |
| 150-200 | 16,674 | +0.699 | 2.172 | +0.699 | 2.172 |
| 200-250 | 6,302 | +1.117 | 2.541 | +1.117 | 2.541 |
| 250-300 | 858 | +1.120 | 1.909 | +1.120 | 1.909 |
| >=300 | 690 | +0.609 | 1.526 | +0.609 | 1.526 |

This supports a floor-induced positive bias in the **lowest bin**. It does not show that removing the floor improves every low-pressure bin or fully resolves the problem.

These are comparisons of saved frozen-model replays, **not new training runs**. The floor replay reproduces historical per-trunk MAEs within about 0.000012 psi, but [replay provenance](../outputs/pressure_accuracy_publication/inputs/replay_provenance.json) explicitly does not certify immutable original-run identity. Node rows are correlated, not independent replicates.

Additional verified issues:

- [Pressure weighting](../libraries/physics_decoder.py#L435) explicitly increases weight above 250 psi:
  \(w(P)=\min[3,1+0.5\max((P-250)/100,0)]\).
  The training loop uses raw-psi weighted MSE, without corresponding low-pressure balancing. This is a plausible optimization contributor, not an isolated causal result.
- Saved sink-node labels span about 44.2403-45.1913 psi despite the hard 44.7 boundary. Determine whether this is boundary variation, perturbation, or node/export semantics.
- Notebook cell 28 (`05c7b93c`) labels MAE/RMSE as "bar" without conversion. Saved pooled MAE 2.9671 and RMSE 4.5185 are **psi**.

### 12.4 The current validation is not fully source-only

Notebook cell 11, cell-source lines 89-99 and 131-139, constructs a source-reconstructed frame for the encoder but calls backbone preparation on the original simulator frame. The backbone and momentum inputs consequently retain **simulator local Q/WC**, not the same propagated source-only values.

The same distinction is documented in [publication_pressure_replay.py](../publication_pressure_replay.py#L182). This is an unavailable-at-deployment state-input mismatch, even though pressure itself is not an encoder feature.

Replacing local simulator values with source-only backbone inputs shifted the backbone by mean absolute amounts of 0.305, 0.773, 0.245, 2.728, and 0.007 psi for trunks 10, 2-2A, 4-9, 7-7A, and 7C respectively. **Only one representative saved scenario per trunk was checked**; these are not full blind-set deployment errors.

Use one validated source reconstruction for backbone, encoder, physics closure, training, and every inference API. Reject unresolved branches or missing sources explicitly rather than retaining template values.

### 12.5 Conservation, junctions, and geometry require correction

An executed minimal test of [topology_ensamble.py](../utils/topology_ensamble.py#L160) exposed an early-propagation defect: a merger receiving Q=10, WC=0.8 through an intermediate branch and Q=20, WC=0.5 directly should output **Q=30, WC=0.6**. It returned **Q=20, WC=0.5** because the outlet was filled before all incoming contributions arrived and was not revisited.

This demonstrates a helper defect, not that every existing field scenario loses that amount of flow.

The graph/path audit also found:

- Two multiple-outlet junctions in each of trunks 10, 2-2A, 4-9, and 7-7A; none in 7C.
- Coincident junction rows with different integration paths and saved blind junction spreads of approximately 0.095, 0.524, 0.507, 0.179, and 0 psi respectively.
- Local segment incidence identities pass, but [path construction](../libraries/physics_decoder.py#L163) retains one carried path per junction, which is insufficient to guarantee alternative-path consistency.
- Some unreached branches can receive empty paths. Distinguish real hydraulic splits from duplicate/topology-encoding artifacts before selecting a tree or coupled-loop solver.

For trunk 7-7A, 55 matched deployment-template nodes have inconsistent `TotalDistance`, with maximum discrepancy about **466.652 ft**. A [node-count-only check](../libraries/deploy_predict.py#L529) does not detect this. Incoming geometry features and backbone channels can then disagree with the saved segment lengths and incidence representation.

The current deployment returns saved nodes only. A continuous correction coordinate exists internally, but no arbitrary-interior-pressure query API was found. This is a separate implementation requirement from training nodal pressure accurately.

### 12.6 The active nominal two-phase closure is effectively liquid-only

Although drift-flux holdup is configured, the inspected archive/templates lack `DensityGasInSitu`. Cell 11 therefore falls back to liquid density, independent of predicted holdup, in the active momentum calculation.

The auxiliary drift-flux loss uses simulator `VelocityGas`; the inspected metadata does not establish whether it is superficial or actual phase velocity. They are not interchangeable. This training-only signal also needs a deployment/physics interpretation.

Exported `HoldupFractionLiquid` spans approximately **1.5827-100**, consistent with percent rather than fraction units. The optional supervised branch clamps those values to at most 1 rather than first validating/converting units. That branch is **not active** in the present drift-flux run, but should not be enabled as-is.

Current trainable/fixed state:

- Effective viscosity is trainable; saved final values range roughly **101-617 cP across trunks**.
- Oil/water density and roughness are fixed.
- Backbone gravity/per-line friction scales are fitted offline and frozen.
- Drift-flux parameters are trainable but do not make the active density calculation genuinely two-phase.
- No temperature state or thermal equation is present; the inspected training archive also lacks temperature.
- Best-epoch restoration saves the encoder but not the physical-parameter module. The deployment bundle omits the learned physical parameters, and deployment pressure inference does not evaluate that learned momentum law.

The present viscosity estimates are effective compensating parameters, not validated PVT recovery. A physics-integrated inference model must restore and persist its physical state with the same best checkpoint as the neural closure.

### 12.7 Training and validation facts

- Current loop: only epoch 0 is physics-free; momentum ramps to full weight by epoch 25; the full auxiliary holdup weight starts once physics is nonzero. Data fitting has not converged before that ramp.
- No adaptive loss balancing was found in this loop.
- Per trunk, [scenario splitting](../libraries/multitrunk.py#L287) produces 240 train / 45 validation / 15 blind scenarios by pressure-max stratification. This is scenario-based, not a random-node split, but mainly assesses interpolation.
- The pooled blind replay has 87,540 rows but only 75 trunk-scenario groups and 69 distinct numeric scenario IDs. Establish whether IDs link common network realizations before defining global-network folds.
- Existing displayed conformal calibration uses a row-level holdout in [fit_from_blind](../conformal_pressure.py#L236); it does not demonstrate coverage for whole unseen operating scenarios and consumes blind data for calibration.

### 12.8 Verification performed and immediate order of work

Executed read-only checks included the existing physics-residual self-test in `pinn_env` (passed; midpoint-equivalence error about 7.11e-15), architecture/output bounds, the inactive friction-parameter gradient, saved-graph incidence checks, the merger reproduction, representative source/backbone comparisons, archived schema/scenario checks, and the pressure-bin calculations above.

The PVT transcription was checked for its 11-point temperature grid, positive viscosity, and strictly decreasing values. Its image provenance remains distinct from a digital PVT export.

**Recommended implementation order:**

1. Correct and unify topology, source aggregation, geometry identity, pressure units, and inference inputs.
2. Remove unjustified sink-minimum assumptions consistently across APIs, then retrain and assess low-pressure bins with a balanced objective.
3. Correct output transforms, use a truly converged data-first stage, and persist matched physical/neural checkpoints.
4. Establish the clean liquid/PVT-constrained solver baseline; add thermal/multiphase states only with sufficient inputs.
5. Compare small MLP, Fourier-MLP, and genuine KAN/FEKAN closures on that same corrected problem.

These are recommendations, **not implemented fixes**. Only this assessment and the image-transcribed viscosity CSV were added under `2026_Sept`.
