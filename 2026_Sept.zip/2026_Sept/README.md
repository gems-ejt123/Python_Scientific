# Liquid-only BADI implementation

Start with **[BADI_Liquid_Thermal_CPF2.ipynb](./BADI_Liquid_Thermal_CPF2.ipynb)**.
Select the existing **Python (pinn_env)** kernel
(`/home/azureuser/pinn_env/bin/python`), not the workspace's minimal `.conda`
interpreter. No shared interpreter or existing model has been changed.

This directory contains the replacement implementation associated with
[the assessment](./BADI_physics_architecture_assessment.md). The original
notebook and its libraries are preserved. A test-passing implementation is
not evidence of improved held-out accuracy; only a completed, documented
training/evaluation run can establish that.

## Running the notebook

1. Run setup, configuration and the explicitly synthetic one-pipe example.
2. Supply the updated CPF2 ZIP with node temperatures. The current archive
   has **29 columns and no temperature column**; its extensionless CSV member
   is supported, but temperature cannot be inferred from the PVT screenshots.
3. Set `TEMPERATURE_COLUMN` and `TEMPERATURE_UNIT` from the updated export.
   The unit intentionally defaults to `None`.
4. Run preflight and data preparation for all five CPF2 trunks. Missing sources,
   nonconstant source temperatures, incompatible geometry or ambiguous
   junctions stop with an explicit error. Correct these inputs rather than
   increasing tolerances to hide discrepancies.
5. Enable `RUN_SMOKE_TRAINING` for a two-epoch wiring test. Enable
   `RUN_FULL_TRAINING` separately when ready for the full manual run.
6. Reload the saved checkpoint to evaluate and predict from source Q/WC.
   The notebook includes an arbitrary interior-pipe query and profile plots.

Outputs stay under `runs/<RUN_NAME>/`. Each new fit requires an empty run
directory and preserves earlier experiments. Full training, architecture
comparisons and opening the locked test set are separate opt-in controls.
`SPLIT_SEED` remains fixed when experimenting with different training seeds.

**Not yet established:** real CPF2 accuracy, all-five-trunk topology validity
against the updated export, or superiority over the old BADI. Full field-data
training has not run.

## Confirmed deployment contract

- Pressure inputs, labels and outputs are **psia**; pressure errors are **psi**.
- The sink boundary is exactly **44.7 psia**, not a network-wide minimum.
- No free-gas state, gas-velocity input, drift-flux loss or holdup head is used.
- Deployment accepts source liquid in-situ flow and watercut, fixed geometry,
  and saved, fixed source temperatures.
- Interior node temperatures are supervised training targets, never hidden
  inference inputs.
- The user approved fitting an effective ambient temperature and heat-transfer
  coefficient from training temperatures, then freezing them for deployment.
  These parameters must not be described as measured soil properties.

## Provisional property assumptions

The user approved a provisional baseline using
[the image-transcribed dead-oil viscosity table](./pvt_dead_oil_viscosity_transcribed.csv),
fixed phase densities and **one** bounded learned friction correction. This
does not authorize treating the table as a complete pressure-dependent PVT
model or simultaneously freeing density, viscosity and friction corrections.

The latest properties screenshot specifies **13 degrees API** and **water
specific gravity 1.02**. The implied stock-tank oil SG is
`141.5 / (13 + 131.5) = 0.97924`, not the old 46-lbm/ft3 oil assumption.
The adapter freezes phase-density medians from **training-only exported
density labels**, reports their provenance, and retains API/SG as reference
checks. Stock-tank and local in-situ densities are not silently equated.
The screenshot's watercut of 92.24% is a fluid-setup value, not a replacement
for each scenario's source watercut.

The additional PVT calibration screenshot records:

| Calibration quantity | Value | Calibration pressure | Temperature |
|---|---:|---:|---:|
| Saturated solution gas | 9.898 SCF/STB | 90.53995 **psig** | 151.9 degF |
| Oil formation volume factor | 1.0108 | 90.53995 **psig** | 151.9 degF |
| Gas viscosity | 0.138 cP | 85.3 **psig** | 140 degF |
| Gas Z | 0.995 | 85.3 **psig** | 140 degF |

The live-oil viscosity calibration entry is blank. These are calibration
states, **not source, pipeline-profile or ambient temperatures**. Their
explicit psig units must not be silently relabeled psia. No gauge-to-absolute
conversion or live-oil correlation is inferred from the screenshot.

No free gas does not necessarily mean no dissolved gas. The solution-gas and
FVF calibration therefore remain a limitation of the incompressible dead-oil
approximation, not extra training labels. Use a digital liquid-property export
before claiming pressure-dependent property accuracy. An oil/water viscosity
mixing rule must be named explicitly; the screenshot's wording alone does not
verify an implementation of the simulator's emulsion model.

## Safeguards

- [Physics](./liquid_badi/physics.py): stable Darcy friction including laminar
  wall shear at zero flow, strict log-viscosity interpolation, signed gravity,
  heat-capacity transport and bounded effective thermal parameters.
- [Network solver](./liquid_badi/network.py): canonical junctions, conservative
  mergers, cycle-flow balancing for split/merge parallel paths, implicit
  gradients, exact sink anchoring, and partial-profile integration.
- [CPF2 adapter](./liquid_badi/data.py): source-only scenario inputs, explicit
  mixed-unit conversion, fixed-source-temperature audits and geometry checks.
- [Pipeline](./liquid_badi/pipeline.py): the same solver for fitting and
  deployment, input-file SHA256 provenance, checkpoint reload, pressure-drop
  errors and pressure/temperature evaluation.
- [Closures](./liquid_badi/closures.py): classical, scalar, small MLP,
  Fourier-MLP and genuine Chebyshev edge-function KAN alternatives.
- [Input contracts](./liquid_badi/contracts.py): explicit temperature units,
  source-key completeness, watercut fractions, fixed-source-temperature
  verification using training cases only, and geometry fingerprints.
- [Ingestion](./liquid_badi/ingest.py): explicit archive/member selection,
  finite positive psia labels, and a required node-temperature column. Missing
  temperature is an error, not an invitation to use 151.9 degF everywhere.
- [Training](./liquid_badi/training.py): scenario-balanced, scale-normalized
  Huber pressure loss; temperature supervision; validation-convergence-triggered
  regularization; paired restoration of all physical/neural parameters and
  optimizer state; complete deployment metadata in checkpoints.
- [Evaluation](./liquid_badi/evaluation.py): pressure-bin and trunk metrics,
  whole-simulation splitting and bootstrap intervals, and sink exclusion from
  headline accuracy.
- [Sensitivity diagnostics](./liquid_badi/diagnostics.py): inactive scalar
  parameters and locally confounded sensitivities. Full local rank is not a
  proof of global identifiability.

The default loss scales (2 psi absolute, 2% relative, 1 K temperature) are
explicit optimization choices, **not agreed operational tolerances or
calibrated measurement uncertainties**. A run that exhausts its data-fitting
budget is marked `data_budget_exhausted`; it does not silently enter the
regularization stage or claim convergence.

## Validation

Latest implementation verification: **32 tests passed**, including all 12
notebook code cells executed in a fresh `pinn_env` kernel with synthetic data.
No real CPF2 training or accuracy improvement is claimed.

Use the existing project environment, without changing the shared workspace's
selected interpreter:

```bash
cd "/home/azureuser/cloudfiles/code/Shared/Rubiales/Código/SANDBOX/2026_Final_Models/2026_Sept"
/home/azureuser/pinn_env/bin/python -m unittest discover -s tests -v
```

The tests use the standard-library `unittest` runner. No new testing or linting
dependency is required.

The notebook validation uses the **already installed** Jupyter client and
registered `pinn_env` kernel; no new package was installed. It executes all
code cells in a fresh kernel against a clearly labeled synthetic export,
including small training runs for all five closure choices, evaluation,
checkpoint reload and interior prediction.

The [validation summary](./validation/notebook_validation.json) and
[executed synthetic notebook copy](./validation/synthetic_notebook_execution.ipynb)
are persistent evidence of wiring checks, **not CPF2 training results**.
Temporary fixture input/checkpoint paths shown in that copy are cleaned up.

### Deliberate physical limitations

- The network transport orientation must be a directed acyclic source-to-sink
  graph. Undirected hydraulic cycles/parallel paths are solved; reverse flow
  or directed circulation is rejected with diagnostics.
- Zero-flow pipe temperature uses the ambient zero-advection limit, not a
  conductive shut-in model. Fixed source temperatures enter through nonzero
  source enthalpy flux.
- Geometry is piecewise linear in elevation with piecewise constant diameter.
  Diameter-transition kinetic head is included within profiles. Configurable
  minor losses default to zero and junctions are ideal static-pressure mixing
  nodes; unprovided fitting losses are not invented.
- Oil/water heat capacities, water viscosity and roughness are visible
  provisional constants. Thermal pressure-work and black-oil phase changes
  are not modeled. This model does not reconstruct full PVT from screenshots.
- Source maps must identify genuine source rows, not accumulated branch flow.
  Co-located independent sources or injections into an inflowing pipe need
  separate injection-rate labels; ambiguous mappings are not silently merged.

### Omitted connectors and shared-source flowlines

The CPF2 adapter treats unreported PIPESIM connectors/auxiliary junctions as
ideal zero-loss junctions. A mapped source row anchors a canonical coordinate
(`coordinate_decimals`, default 8). Other exported source rows at that coordinate
are associated with the same external source only when ownership is unambiguous
and every row is a branch inlet. Multiple separately mapped source IDs at that
coordinate are rejected rather than silently combined. Unmapped source rows at
other coordinates and sources on inflowing branches still require reconciliation.

Each flowline remains a separate edge with its own diameter, distance, elevation,
profile identifiers and pressure/temperature observations. The solver determines
the branch flow split; measured branch rates do not prescribe it. One shared
source supplies the sum of the branch liquid rates, with liquid-flow-weighted
watercut. This conserves phase volumes and phase mass under the existing frozen
model densities, not exact mass computed from varying exported densities.
At zero total flow, the mapped anchor's validated watercut is retained (it
carries no phase flux); no branch rate is copied or counted twice.

Inlet agreement is validated **within every scenario**, including held-out
scenarios, before accepting the grouped inputs:

| Inlet quantity | Agreement rule |
|---|---|
| Pressure (psia) | Exact equality; not a prescribed source-pressure boundary |
| Elevation (m) | Spread <= `geometry_tolerance_m` (default 0.01) |
| Temperature (K) | Spread <= `source_temperature_tolerance_k` (default 0.1) |
| Watercut (fraction) | Spread <= `source_watercut_tolerance` (default 1e-7) |
| Each phase density | Spread <= `source_density_rtol` times the minimum absolute density (default 1e-5, independent of density units) |

All tolerances must be finite and nonnegative. The temperature of the mapped
anchor supplies one observation per source/scenario to the existing training-only
fixed-temperature contract; all grouped inlet temperatures must also satisfy
that saved constant. Branch/source identity and junction coordinates must remain
consistent across scenarios. Agreement does not imply duplicate pipes.

The notebook exposes `SOURCE_WATERCUT_TOLERANCE` and `SOURCE_DENSITY_RTOL`.
Source audits record grouped profile IDs, branches, maximum inlet discrepancies
and zero-flow scenario counts. Cases retain original per-branch flow, watercut
and density observations in `source_branch_observations`; deployment specs retain
source profile IDs, so grouped membership is covered by the geometry fingerprint.
The preparation audit records the aggregation convention and tolerances.

### Scenario exclusions and optional geometry screening

The notebook excludes scenarios `92` (traversal/label misalignment) and `110`
(distance mismatch) through `EXCLUDED_SCENARIOS`. Entire simulations are removed
from **every trunk**, before final train/validation/test splitting. The original
CSV/ZIP is never modified.

Set `REMOVE_INCONSISTENT_SCENARIOS = True` to additionally screen all remaining
scenarios. It defaults to `False`. The adapter's `filter_inconsistent_scenarios`
uses the same node-set, branch/node-type identity and numeric geometry checks as
`prepare_data`, including distance/diameter conversion to metres and the existing
coordinate precision tolerance. Missing trunks and duplicate profile node IDs
also exclude the whole simulation. All detected discrepancies are reported, not
just the first failing scenario. Changes to pressure, temperature, flow or fluid
properties are **not** grounds for this automatic geometry exclusion; source-map
errors and physical consistency errors still fail explicitly.

After manual exclusions, screening chooses the first training scenario from the
seeded provisional split as its fixed geometry reference. The reference ID is
passed to preparation as `geometry_reference_scenario`, preventing a changed
final split from silently switching geometry references. Only static geometry
uses this pinned reference; density and source-temperature estimation still use
the final training split. Invalid reference data and fewer than three remaining
simulations are hard errors, not automatic reference replacement.

Excluded rows remain available separately for diagnostics. The notebook prints
the removed IDs, per-trunk row counts and discrepancy table, and stores these in
`prepared.audit['scenario_exclusions']` for checkpoint provenance. Exclusion
changes the final split; do not compare results as though the held-out population
were unchanged.
