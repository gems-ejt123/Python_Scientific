import unittest

import torch

from liquid_badi.closures import FrictionClosure
from liquid_badi.physics import darcy_friction
from test_network import physics


class PhysicsTests(unittest.TestCase):
    def test_pvt_monotone_and_differentiable(self):
        model = physics()
        t = torch.tensor([300., 320.], dtype=torch.float64, requires_grad=True)
        mu = model.oil_viscosity(t)
        self.assertGreater(float(mu[0]), float(mu[1]))
        mu.sum().backward()
        self.assertTrue((t.grad < 0).all())
        with self.assertRaisesRegex(ValueError, "outside"):
            model.oil_viscosity(torch.tensor([351.], dtype=torch.float64))

    def test_darcy_laminar_convention(self):
        re = torch.tensor([10., 100., 1000.], dtype=torch.float64)
        torch.testing.assert_close(darcy_friction(re, re * 0), 64 / re, rtol=1e-6, atol=1e-8)

    def test_closure_alternatives_are_bounded_and_start_classical(self):
        for kind in ("none", "scalar", "mlp", "fourier_mlp", "kan"):
            closure = FrictionClosure(kind=kind).double()
            result = closure(torch.randn(8, 4, dtype=torch.float64))
            torch.testing.assert_close(result, torch.ones_like(result))
            self.assertTrue(((result >= .5) & (result <= 2.)).all())

    def test_exponential_temperature_is_physical_state(self):
        model = physics()
        q, wc = torch.tensor(.001), torch.tensor(.5)
        t = model.temperature_at(torch.tensor(330.), torch.tensor([0., 100.]), q, wc)
        self.assertAlmostEqual(float(t[0]), 330., places=4)
        self.assertGreater(float(t[1]), float(model.ambient_k))
        self.assertLess(float(t[1]), 330.)


if __name__ == "__main__":
    unittest.main()
