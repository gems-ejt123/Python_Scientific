import unittest

import torch

from liquid_badi.diagnostics import scalar_parameter_sensitivity


class ScalarModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.a = torch.nn.Parameter(torch.tensor(2., dtype=torch.float64))
        self.b = torch.nn.Parameter(torch.tensor(3., dtype=torch.float64))
        self.unused = torch.nn.Parameter(torch.tensor(1., dtype=torch.float64))


class DiagnosticTests(unittest.TestCase):
    def test_confounded_and_inactive_scalars_are_reported(self):
        model = ScalarModel()
        report = scalar_parameter_sensitivity(
            model, lambda m: (m.a * m.b) * torch.arange(1., 5., dtype=torch.float64),
            ["a", "b", "unused"],
        )
        self.assertEqual(report["normalized_jacobian_rank"], 1)
        self.assertEqual(report["inactive_parameters"], ["unused"])
        self.assertAlmostEqual(report["sensitivity_cosine_matrix"][0][1], 1.)


if __name__ == "__main__":
    unittest.main()
