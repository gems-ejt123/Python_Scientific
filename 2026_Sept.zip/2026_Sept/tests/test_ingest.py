import tempfile
from pathlib import Path
import unittest
import zipfile

import pandas as pd

from liquid_badi.ingest import normalize_labels, read_export


class IngestTests(unittest.TestCase):
    def test_actual_extensionless_member_is_supported(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "profiles.zip"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("full_data_training_rubiales_CPF2_local", "Pressure,scenario\n30,1\n")
            frame = read_export(path, member="full_data_training_rubiales_CPF2_local")
            self.assertEqual(frame.loc[0, "Pressure"], 30)

    def test_zip_selection_is_explicit(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "profiles.zip"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("first.csv", "a,b\n1,2\n")
                archive.writestr("second.csv", "a,b\n3,4\n")
            with self.assertRaisesRegex(ValueError, "explicitly"):
                read_export(path)
            self.assertEqual(read_export(path, member="second.csv").iloc[0, 0], 3)

    def test_temperature_is_required_not_imputed(self):
        frame = pd.DataFrame({"sim": [1], "P": [30.], "trunk_id": ["a"]})
        with self.assertRaisesRegex(ValueError, "Node temperature"):
            normalize_labels(frame, scenario_column="sim", pressure_column="P",
                             temperature_column="T", temperature_unit="degF",
                             trunk_column="trunk_id")
        frame["T"] = 100.
        result = normalize_labels(
            frame, scenario_column="sim", pressure_column="P",
            temperature_column="T", temperature_unit="degF", trunk_column="trunk_id",
        )
        self.assertEqual(result.loc[0, "pressure_psia"], 30.)
        self.assertAlmostEqual(result.loc[0, "temperature_k"], 310.9277777778)


if __name__ == "__main__":
    unittest.main()
