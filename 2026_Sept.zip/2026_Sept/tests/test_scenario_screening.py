import json
import unittest

import pandas as pd

from liquid_badi.data import filter_inconsistent_scenarios, prepare_data
from liquid_badi.evaluation import scenario_split
from test_source_junctions import parallel_profiles


class ScenarioScreeningTests(unittest.TestCase):
    def test_removes_complete_scenarios_and_reports_every_geometry_issue(self):
        frame, mapping = parallel_profiles()
        other = frame.assign(trunk="other", Troncal="other")
        frame = pd.concat([frame, other], ignore_index=True)
        mapping = pd.concat([mapping, mapping.assign(Troncal="other")], ignore_index=True)
        reference = scenario_split(frame.scenario)["train"][0]
        bad = next(s for s in sorted(set(frame.scenario)) if s != reference)
        mask = (frame.trunk == "toy") & (frame.scenario == bad) & (frame.node_id == "pipe-1")
        frame.loc[mask, "TotalDistance"] += 10.
        frame.loc[mask, "Elevation"] += 1.
        before = frame.copy(deep=True)
        filtered, audit = filter_inconsistent_scenarios(frame)
        self.assertEqual(audit["excluded_scenario_ids"], [bad])
        self.assertEqual({i["column"] for i in audit["issues"]}, {"TotalDistance", "Elevation"})
        self.assertEqual(audit["removed_rows_by_trunk"], {"other": 4, "toy": 4})
        self.assertFalse(filtered.scenario.eq(bad).any())
        pd.testing.assert_frame_equal(frame, before)
        json.dumps(audit, allow_nan=False)
        prepared = prepare_data(filtered, mapping, geometry_reference_scenario=audit["reference_scenario"])
        self.assertNotIn(bad, prepared.cases)
        self.assertTrue(all(bad not in ids for ids in prepared.splits.values()))
        self.assertEqual(prepared.audit["geometry_reference_scenario"], reference)

    def test_node_sets_identity_duplicates_and_missing_trunks(self):
        for change, column in (
            ("missing_node", "node_id"), ("extra_node", "node_id"),
            ("duplicate", "node_id"), ("branch", "BranchEquipment"), ("type", "node_type"),
            ("missing_trunk", "scenario"),
        ):
            with self.subTest(change=change):
                frame, _ = parallel_profiles()
                frame = pd.concat([frame, frame.assign(trunk="other", Troncal="other")], ignore_index=True)
                reference = scenario_split(frame.scenario)["train"][0]
                bad = next(s for s in sorted(set(frame.scenario)) if s != reference)
                mask = (frame.trunk == "toy") & (frame.scenario == bad)
                index = frame.loc[mask].index[0]
                if change == "missing_node":
                    frame = frame.drop(index)
                elif change == "extra_node":
                    frame.loc[index, "node_id"] = "unknown"
                elif change == "duplicate":
                    frame = pd.concat([frame, frame.loc[[index]]])
                elif change == "branch":
                    frame.loc[index, "BranchEquipment"] = "wrong"
                elif change == "type":
                    frame.loc[index, "node_type"] = 0
                else:
                    frame = frame.loc[~mask]
                filtered, audit = filter_inconsistent_scenarios(frame)
                self.assertEqual(audit["excluded_scenario_ids"], [bad])
                self.assertEqual(audit["issues"][0]["column"], column)
                self.assertFalse(filtered.scenario.eq(bad).any())

    def test_geometry_tolerances_use_preparation_units(self):
        for column, inside, outside in (
            ("TotalDistance", .02, .04), ("Elevation", .005, .02),
            ("PipeInsideDiameter", .2, .5), ("long", 5e-9, 2e-8),
            ("lat", 5e-9, 2e-8),
        ):
            with self.subTest(column=column):
                frame, _ = parallel_profiles()
                reference = scenario_split(frame.scenario)["train"][0]
                bad = next(s for s in sorted(set(frame.scenario)) if s != reference)
                mask = (frame.scenario == bad) & (frame.node_id == "pipe-1")
                frame.loc[mask, column] += inside
                _, audit = filter_inconsistent_scenarios(frame)
                self.assertEqual(audit["excluded_scenario_ids"], [])
                frame.loc[mask, column] += outside
                _, audit = filter_inconsistent_scenarios(frame)
                self.assertEqual(audit["excluded_scenario_ids"], [bad])
                self.assertEqual(audit["issues"][0]["column"], column)

    def test_reference_is_not_replaced_by_the_majority(self):
        frame, _ = parallel_profiles()
        reference = scenario_split(frame.scenario)["train"][0]
        frame.loc[frame.scenario != reference, "Elevation"] = 100.
        with self.assertRaisesRegex(ValueError, "fewer than three"):
            filter_inconsistent_scenarios(frame)

    def test_invalid_reference_is_a_hard_error(self):
        frame, _ = parallel_profiles()
        reference = scenario_split(frame.scenario)["train"][0]
        row = frame.loc[frame.scenario == reference].iloc[[0]]
        with self.assertRaisesRegex(ValueError, "Invalid screening reference"):
            filter_inconsistent_scenarios(pd.concat([frame, row]))

    def test_label_errors_are_not_automatically_dropped(self):
        frame, mapping = parallel_profiles()
        frame.loc[frame.node_id == "parallel-0", "pressure_psia"] += 1.
        filtered, audit = filter_inconsistent_scenarios(frame)
        self.assertEqual(audit["excluded_scenario_ids"], [])
        with self.assertRaisesRegex(ValueError, "Shared-source inlet disagreement"):
            prepare_data(filtered, mapping, geometry_reference_scenario=audit["reference_scenario"])

    def test_deterministic_noop_and_invalid_reference_argument(self):
        frame, mapping = parallel_profiles()
        kept, audit = filter_inconsistent_scenarios(frame)
        pd.testing.assert_frame_equal(kept, frame)
        _, repeated = filter_inconsistent_scenarios(frame.sample(frac=1., random_state=3))
        self.assertEqual(audit, repeated)
        with self.assertRaisesRegex(ValueError, "Geometry reference scenario absent is absent"):
            prepare_data(frame, mapping, geometry_reference_scenario="absent")


if __name__ == "__main__":
    unittest.main()
