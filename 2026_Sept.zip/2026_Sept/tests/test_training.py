import tempfile
from pathlib import Path
import unittest

import torch

from liquid_badi.training import (
    TrainingConfig, fit, normalized_pressure_loss, save_checkpoint,
)


class TrainingTests(unittest.TestCase):
    def test_finite_balanced_loss_below_sink(self):
        prediction = torch.tensor([25., 250., 44.7], requires_grad=True)
        target = torch.tensor([23., 248., 44.7])
        mask = torch.tensor([True, True, False])
        loss = normalized_pressure_loss(prediction, target, mask, TrainingConfig())
        loss.backward()
        self.assertGreater(prediction.grad[0], prediction.grad[1])
        self.assertEqual(prediction.grad[2], 0.)

    def test_budget_exhaustion_does_not_trigger_physics(self):
        model = torch.nn.Linear(1, 1).double()
        cfg = TrainingConfig(minimum_data_epochs=1, maximum_data_epochs=1,
                             data_patience=5, regularization_epochs=2)
        result = fit(model, [1], [1], self.loss, self.prior, cfg)
        self.assertEqual(result["status"], "data_budget_exhausted")
        self.assertTrue(all(row["stage"] == "data" for row in result["history"]))
        for key, value in model.state_dict().items():
            torch.testing.assert_close(value, result["model_state_dict"][key])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.pt"
            save_checkpoint(path, result, {"pressure_reference": "psia"},
                            {"train": ["1"], "validation": ["2"], "test": ["3"]},
                            {"purpose": "unit test"})
            loaded = torch.load(path, weights_only=True)
            self.assertEqual(loaded["deployment_config"]["pressure_reference"], "psia")
            self.assertIn("optimizer_state_dict", loaded)
            self.assertFalse(path.with_suffix(".pt.tmp").exists())

    def test_stage_two_requires_validation_plateau(self):
        model = torch.nn.Linear(1, 1).double()
        cfg = TrainingConfig(minimum_data_epochs=1, maximum_data_epochs=3,
                             data_patience=1, relative_improvement=0.999,
                             regularization_epochs=2, maximum_validation_degradation=100.)
        result = fit(model, [1], [1], self.loss, self.prior, cfg)
        self.assertTrue(result["data_stage_converged"])
        self.assertEqual([row["stage"] for row in result["history"]][:2], ["data", "data"])
        self.assertIn("regularization", [row["stage"] for row in result["history"]])

    @staticmethod
    def loss(model, case, config):
        return (model(torch.ones(1, 1, dtype=torch.float64)) - case).square().mean()

    @staticmethod
    def prior(model):
        return sum(p.square().mean() for p in model.parameters())


if __name__ == "__main__":
    unittest.main()
