import json
import unittest

import numpy as np
import pandas as pd
import torch

from liquid_badi.contracts import BBL_DAY_TO_M3_S, geometry_fingerprint
from liquid_badi.data import _source_inlet_state, prepare_data
from liquid_badi.pipeline import MultiTrunkModel
from test_network import physics


def parallel_profiles():
    rows = []
    for scenario in range(10):
        for branch, diameter, rate, wc in (
            ("pipe", 10.02, 10. + scenario, .5),
            ("parallel", 12., 20. + scenario, .5 + 5e-8),
        ):
            for i in range(2):
                rows.append({
                    "scenario": str(scenario), "trunk": "toy", "Troncal": "toy",
                    "node_id": f"{branch}-{i}", "node_type": 1 if i == 0 else -1,
                    "BranchEquipment": branch, "TotalDistance": i * 100.,
                    "Elevation": 0., "PipeInsideDiameter": diameter,
                    "long": float(i), "lat": 0.,
                    "FlowrateLiquidInsitu": rate, "Watercut": wc,
                    "temperature_k": 310., "pressure_psia": 44.8 if i == 0 else 44.7,
                    "DensityOilInSitu": 61., "DensityWaterInSitu": 63.,
                })
    mapping = pd.DataFrame([dict(
        source="well", Troncal="toy", BranchEquipment="pipe", long=0., lat=0.,
    )])
    return pd.DataFrame(rows), mapping


class SourceJunctionTests(unittest.TestCase):
    def test_group_retains_edges_targets_and_conserves_phase_inputs(self):
        frame, mapping = parallel_profiles()
        prepared = prepare_data(frame, mapping)
        spec = prepared.specs["toy"]
        self.assertEqual(list(spec["sources"]), ["well"])
        self.assertEqual(spec["sources"]["well"]["profile_node_ids"], ["pipe-0", "parallel-0"])
        self.assertEqual(len(spec["edges"]), 2)
        self.assertNotEqual(spec["edges"][0]["diameter_m"], spec["edges"][1]["diameter_m"])
        self.assertEqual(len(prepared.layouts["toy"]), 4)
        for scenario, trunks in prepared.cases.items():
            case = trunks["toy"]
            inlets = frame.loc[(frame.scenario == scenario) & (frame.node_type == 1)]
            q = inlets.FlowrateLiquidInsitu.to_numpy() * BBL_DAY_TO_M3_S
            wc = inlets.Watercut.to_numpy()
            self.assertAlmostEqual(case["rates_m3_s"][0], q.sum())
            self.assertAlmostEqual(case["rates_m3_s"][0] * case["watercuts"][0], (q * wc).sum())
            self.assertAlmostEqual(case["rates_m3_s"][0] * (1 - case["watercuts"][0]),
                                   (q * (1 - wc)).sum())
            self.assertEqual(len(case["node_ids"]), 4)
            observed = case["source_branch_observations"]["well"]
            self.assertEqual(observed["node_ids"], ["pipe-0", "parallel-0"])
            self.assertEqual(len(observed["rates_bbl_day"]), 2)
        audit = prepared.audit["trunks"]["toy"]["sources"][0]
        self.assertEqual(audit["branches"], ["pipe", "parallel"])
        self.assertGreater(audit["max_inlet_spreads"]["Watercut"], 0.)
        json.dumps(prepared.audit, allow_nan=False)

    def test_group_reaches_solver_with_one_injection_and_distinct_outputs(self):
        prepared = prepare_data(*parallel_profiles())
        model = MultiTrunkModel(prepared.specs, prepared.layouts, physics().export_config())
        case = prepared.cases["0"]["toy"]
        state = model.predict_trunk("toy", case["rates_m3_s"], case["watercuts"])
        torch.testing.assert_close(state["flow_m3_s"].sum(),
                                   torch.tensor(case["rates_m3_s"][0], dtype=torch.float64))
        self.assertNotEqual(float(state["flow_m3_s"][0]), float(state["flow_m3_s"][1]))
        for residual in ("flow_residual_m3_s", "water_residual_m3_s"):
            self.assertLess(float(state[residual].abs().max()), 1e-12)
        p, t = model.profile_outputs("toy", state, ["pipe-0", "parallel-0"])
        torch.testing.assert_close(p[0], p[1])
        torch.testing.assert_close(t[0], t[1])
        exported = json.loads(json.dumps(model.export_config()))
        restored = MultiTrunkModel(**exported)
        self.assertEqual(model.networks["toy"].geometry_hash, restored.networks["toy"].geometry_hash)
        altered = json.loads(json.dumps(prepared.specs["toy"]))
        altered["sources"]["well"]["profile_node_ids"] = ["pipe-0"]
        self.assertNotEqual(geometry_fingerprint(altered), geometry_fingerprint(prepared.specs["toy"]))

    def test_zero_total_flow_keeps_anchor_composition(self):
        frame, mapping = parallel_profiles()
        frame["FlowrateLiquidInsitu"] = 0.
        prepared = prepare_data(frame, mapping)
        self.assertEqual(prepared.cases["0"]["toy"]["rates_m3_s"], [0.])
        self.assertEqual(prepared.cases["0"]["toy"]["watercuts"], [.5])
        self.assertEqual(prepared.audit["trunks"]["toy"]["sources"][0]["zero_flow_scenarios"], 10)

    def test_agreement_tolerances_accept_boundary_and_reject_excess(self):
        frame, _ = parallel_profiles()
        original = frame.loc[(frame.scenario == "0") & (frame.node_type == 1)].set_index("node_id")
        for column, tolerance in (
            ("pressure_psia", 0.), ("Elevation", .01), ("temperature_k", .1),
            ("Watercut", 1e-7), ("DensityOilInSitu", 61. * 1e-5),
            ("DensityWaterInSitu", 63. * 1e-5),
        ):
            with self.subTest(column=column):
                inlets = original.copy()
                base = float(inlets[column].iloc[0])
                inlets[column] = base
                if tolerance:
                    inlets.iloc[1, inlets.columns.get_loc(column)] = np.nextafter(base + tolerance, base)
                _source_inlet_state(inlets, "toy/well/0", .1, .01, 1e-7, 1e-5)
                inlets.iloc[1, inlets.columns.get_loc(column)] = base + max(2 * tolerance, 1e-8)
                with self.assertRaisesRegex(ValueError, f"toy/well/0/{column}"):
                    _source_inlet_state(inlets, "toy/well/0", .1, .01, 1e-7, 1e-5)

    def test_disagreement_in_nonreference_scenario_is_not_hidden(self):
        for column, difference in (
            ("pressure_psia", .01), ("Watercut", .001),
            ("DensityOilInSitu", .1), ("temperature_k", 1.),
        ):
            with self.subTest(column=column):
                frame, mapping = parallel_profiles()
                frame.loc[(frame.scenario == "9") & (frame.node_id == "parallel-0"), column] += difference
                with self.assertRaisesRegex(ValueError, f"toy/well/9/{column}"):
                    prepare_data(frame, mapping)

    def test_uncovered_or_ambiguous_sources_remain_errors(self):
        frame, mapping = parallel_profiles()
        frame.loc[frame.node_id == "parallel-0", "long"] = .5
        with self.assertRaisesRegex(ValueError, "does not cover exactly"):
            prepare_data(frame, mapping)
        frame, mapping = parallel_profiles()
        other = mapping.copy()
        other["source"], other["BranchEquipment"] = "other", "parallel"
        with self.assertRaisesRegex(ValueError, "Ambiguous source ownership"):
            prepare_data(frame, pd.concat([mapping, other], ignore_index=True))

    def test_branch_and_source_identity_changes_remain_errors(self):
        for column, value in (("BranchEquipment", "changed"), ("node_type", 0)):
            with self.subTest(column=column):
                frame, mapping = parallel_profiles()
                frame.loc[(frame.scenario == "9") & (frame.node_id == "parallel-0"), column] = value
                with self.assertRaisesRegex(ValueError, f"{column} identity changed"):
                    prepare_data(frame, mapping)

    def test_noninlet_source_row_is_rejected(self):
        frame, mapping = parallel_profiles()
        frame.loc[frame.node_id == "parallel-0", "TotalDistance"] = 200.
        with self.assertRaisesRegex(ValueError, "non-inlet source row"):
            prepare_data(frame, mapping)

    def test_source_temperature_still_must_be_fixed_across_scenarios(self):
        frame, mapping = parallel_profiles()
        frame.loc[frame.scenario == "9", "temperature_k"] += 1.
        with self.assertRaisesRegex(ValueError, "not fixed|Fixed source temperature"):
            prepare_data(frame, mapping)

    def test_tolerances_must_be_explicit_finite_nonnegative_numbers(self):
        for value in (-1., float("nan"), float("inf")):
            with self.subTest(value=value):
                with self.assertRaisesRegex(ValueError, "source_watercut_tolerance"):
                    prepare_data(*parallel_profiles(), source_watercut_tolerance=value)
                with self.assertRaisesRegex(ValueError, "source_density_rtol"):
                    prepare_data(*parallel_profiles(), source_density_rtol=value)


if __name__ == "__main__":
    unittest.main()
