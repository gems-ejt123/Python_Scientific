import copy
import math
import unittest

import torch

from liquid_badi.contracts import PSI_TO_PA
from liquid_badi.network import LiquidNetwork
from liquid_badi.physics import FluidConfig, LiquidPhysics


def physics(kind="none"):
    return LiquidPhysics(
        FluidConfig(980., 1020., ambient_initial_k=310.,
                    ambient_bounds_k=(290., 320.), n_quad=5),
        [280., 310., 350.], [0.2, 0.1, 0.05], {"kind": kind},
    )


def edge(name, up, down, length=100., dz=0., diameter=0.1):
    return dict(id=name, up=up, down=down, distance_m=[0., length],
                elevation_m=[0., dz], diameter_m=[diameter], roughness_m=0.)


def one_pipe(dz=0.):
    return dict(nodes=["source", "sink"], sink="sink",
                sources={"well": dict(node="source", temperature_k=310.)},
                edges=[edge("pipe", "source", "sink", dz=dz)])


class NetworkTests(unittest.TestCase):
    def test_laminar_exact_sink_and_interior(self):
        model = LiquidNetwork(one_pipe(), physics())
        q, wc = torch.tensor([1e-5], dtype=torch.float64), torch.zeros(1, dtype=torch.float64)
        state = model(q, wc)
        expected = 128 * .1 * 100 * float(q[0]) / (math.pi * .1 ** 4)
        self.assertAlmostEqual(float(state["pressure_pa"][0]) - 44.7 * PSI_TO_PA, expected, places=7)
        self.assertEqual(float(state["pressure_pa"][1]), 44.7 * PSI_TO_PA)
        p, t = model.query(state, "pipe", 50.)
        self.assertAlmostEqual(float(p) - 44.7 * PSI_TO_PA, expected / 2, places=7)
        self.assertAlmostEqual(float(t), 310.)

    def test_below_sink_hydrostatic_is_not_clamped(self):
        model = LiquidNetwork(one_pipe(dz=-10.), physics())
        state = model(torch.zeros(1, dtype=torch.float64), torch.zeros(1, dtype=torch.float64))
        self.assertLess(float(state["pressure_pa"][0]), 44.7 * PSI_TO_PA)
        self.assertGreater(float(state["pressure_pa"][0]), 0.)
        self.assertTrue(torch.isfinite(state["temperature_k"]).all())

    def test_merger_order_and_component_conservation(self):
        spec = dict(
            nodes=["a", "x", "b", "merge", "sink"], sink="sink",
            sources={"one": dict(node="a", temperature_k=310.),
                     "two": dict(node="b", temperature_k=310.)},
            edges=[edge("a-x", "a", "x"), edge("x-m", "x", "merge"),
                   edge("b-m", "b", "merge"), edge("m-s", "merge", "sink")],
        )
        q = torch.tensor([10., 20.], dtype=torch.float64) * 1e-6
        wc = torch.tensor([.8, .5], dtype=torch.float64)
        for reverse in (False, True):
            trial = copy.deepcopy(spec)
            if reverse:
                trial["edges"].reverse()
            model = LiquidNetwork(trial, physics())
            state = model(q, wc)
            i = [e["id"] for e in model.edges].index("m-s")
            self.assertAlmostEqual(float(state["flow_m3_s"][i]), 30e-6)
            self.assertAlmostEqual(float(state["wc"][i]), .6)
            self.assertLess(float(state["flow_residual_m3_s"].abs().max()), 1e-15)

    def test_parallel_flow_balance_and_implicit_gradient(self):
        spec = one_pipe()
        spec["edges"] = [edge("short", "source", "sink", length=100.),
                         edge("long", "source", "sink", length=200.)]
        model = LiquidNetwork(spec, physics("scalar"))
        q = torch.tensor([3e-5], dtype=torch.float64)
        wc = torch.zeros(1, dtype=torch.float64)
        state = model(q, wc)
        torch.testing.assert_close(state["flow_m3_s"], torch.tensor([2e-5, 1e-5], dtype=torch.float64))
        self.assertLess(float(state["cycle_residual_pa"].abs().max()), model.tolerance_pa)
        gradient, = torch.autograd.grad(state["pressure_pa"][0], model.physics.closure.logit)
        self.assertGreater(float(gradient), 0.)
        with torch.no_grad():
            reference = model(q, wc)["pressure_pa"]
        torch.testing.assert_close(reference, state["pressure_pa"])

    def test_missing_source_and_directed_cycle_rejected(self):
        spec = one_pipe()
        spec["sources"] = {"other": dict(node="absent", temperature_k=310.)}
        with self.assertRaises(ValueError):
            LiquidNetwork(spec, physics())
        directed_cycle = dict(
            nodes=["a", "b", "c", "sink"], sink="sink",
            sources={"well": dict(node="a", temperature_k=310.)},
            edges=[edge("a-b", "a", "b"), edge("b-c", "b", "c"),
                   edge("c-a", "c", "a"), edge("c-s", "c", "sink")],
        )
        with self.assertRaisesRegex(ValueError, "Directed circulation"):
            LiquidNetwork(directed_cycle, physics())

    def test_nonpositive_interior_pressure_is_reported(self):
        spec = one_pipe()
        spec["edges"][0].update(
            distance_m=[0., 100., 200.], elevation_m=[0., 60., 0.], diameter_m=[.1, .1],
        )
        model = LiquidNetwork(spec, physics())
        with self.assertRaisesRegex(ValueError, "Nonpositive psia"):
            model(torch.zeros(1, dtype=torch.float64), torch.zeros(1, dtype=torch.float64))

    def test_implicit_thermal_gradient_matches_finite_difference(self):
        spec = one_pipe()
        spec["sources"]["well"]["temperature_k"] = 330.
        spec["edges"] = [edge("short", "source", "sink", length=100.),
                         edge("long", "source", "sink", length=200.)]
        model = LiquidNetwork(spec, physics("scalar"), tolerance_pa=1e-7)
        q, wc = torch.tensor([.001], dtype=torch.float64), torch.tensor([.2], dtype=torch.float64)
        pressure = model(q, wc)["pressure_pa"][0]
        parameter = model.physics.ambient_logit
        gradient, = torch.autograd.grad(pressure, parameter)
        original = float(parameter.detach())
        epsilon = 1e-4
        with torch.no_grad():
            parameter.fill_(original + epsilon)
            plus = model(q, wc)["pressure_pa"][0]
            parameter.fill_(original - epsilon)
            minus = model(q, wc)["pressure_pa"][0]
            parameter.fill_(original)
        torch.testing.assert_close(gradient, (plus - minus) / (2 * epsilon), rtol=1e-4, atol=1e-4)

    def test_junction_heat_and_partial_integration_refinement(self):
        spec = dict(
            nodes=["a", "b", "m", "sink"], sink="sink",
            sources={"a": dict(node="a", temperature_k=320.), "b": dict(node="b", temperature_k=330.)},
            edges=[edge("a-m", "a", "m"), edge("b-m", "b", "m"), edge("out", "m", "sink")],
        )
        model = LiquidNetwork(spec, physics())
        q, wc = torch.tensor([.0001, .0002], dtype=torch.float64), torch.tensor([.8, .5], dtype=torch.float64)
        state = model(q, wc)
        self.assertLess(float(state["junction_enthalpy_residual_w"].abs().max()), 1e-8)
        self.assertLess(float(state["water_residual_m3_s"].abs().max()), 1e-12)
        query_p, _ = model.query(state, "out", 50.)
        refined_spec = copy.deepcopy(spec)
        refined_spec["edges"][-1].update(distance_m=[0., 50., 100.], elevation_m=[0., 0., 0.],
                                         diameter_m=[.1, .1])
        refined = LiquidNetwork(refined_spec, model.physics)
        refined_p = refined(q, wc)["pressure_profiles_pa"][-1][1]
        torch.testing.assert_close(query_p, refined_p, rtol=1e-7, atol=0.01)


if __name__ == "__main__":
    unittest.main()
