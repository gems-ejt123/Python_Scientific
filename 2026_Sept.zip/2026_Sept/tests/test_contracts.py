import unittest

import numpy as np
import pandas as pd

from liquid_badi.contracts import (
    fixed_source_temperatures, geometry_fingerprint, temperature_kelvin,
    validate_source_inputs,
)


class ContractTests(unittest.TestCase):
    def test_explicit_temperature_units(self):
        np.testing.assert_allclose(temperature_kelvin([32., 212.], "degF"), [273.15, 373.15])
        with self.assertRaises(ValueError):
            temperature_kelvin([100.], "unknown")

    def test_only_training_temperature_is_saved(self):
        frame = pd.DataFrame({
            "scenario": [1, 2, 3], "source_id": ["s"] * 3,
            "temperature_k": [310., 310., 350.],
        })
        constants, _ = fixed_source_temperatures(frame, ["1", "2"])
        self.assertEqual(constants, {"s": 310.})
        with self.assertRaisesRegex(ValueError, "not fixed"):
            fixed_source_temperatures(frame, ["1", "2", "3"])

    def test_missing_source_and_percentage_fail(self):
        with self.assertRaisesRegex(ValueError, "missing"):
            validate_source_inputs(["a", "b"], {"a": 1.}, {"a": 0.5})
        with self.assertRaisesRegex(ValueError, "fraction"):
            validate_source_inputs(["a"], {"a": 1.}, {"a": 50.})

    def test_geometry_fingerprint_checks_values_not_counts(self):
        self.assertNotEqual(geometry_fingerprint({"length": [1., 2.]}),
                            geometry_fingerprint({"length": [1., 3.]}))
        self.assertEqual(geometry_fingerprint({"a": 1, "b": 2}),
                         geometry_fingerprint({"b": 2, "a": 1}))


if __name__ == "__main__":
    unittest.main()
