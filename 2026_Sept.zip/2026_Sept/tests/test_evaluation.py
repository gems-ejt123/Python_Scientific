import unittest

import pandas as pd

from liquid_badi.evaluation import pressure_report, scenario_split


class EvaluationTests(unittest.TestCase):
    def test_split_keeps_simulations_together(self):
        split = scenario_split(list(range(300)) * 5)
        self.assertEqual([len(split[k]) for k in ("train", "validation", "test")],
                         [240, 45, 15])
        self.assertFalse(set(split["train"]) & set(split["validation"]))
        self.assertFalse(set(split["train"]) & set(split["test"]))
        self.assertEqual(split, scenario_split(list(reversed(range(300)))))

    def test_macro_metrics_and_boundary_exclusion(self):
        frame = pd.DataFrame({
            "scenario": ["1", "1", "1", "2"],
            "trunk": ["a"] * 4,
            "pressure_psia": [30., 60., 44.7, 100.],
            "predicted_psia": [32., 62., 44.7, 110.],
            "is_sink": [False, False, True, False],
        })
        result = pressure_report(frame, bootstrap_samples=20)
        self.assertEqual(result["scenario_macro_mae_psi"], 6.)
        self.assertAlmostEqual(result["pooled_non_sink"]["mae_psi"], 14 / 3)
        self.assertEqual(result["sink_rows_excluded"], 1)
        self.assertEqual(result["sink_max_boundary_error_psi"], 0.)
        self.assertEqual(result["per_pressure_bin"][0]["pressure_bin_psia"], "<44.7")

    def test_invalid_metrics_are_not_silently_dropped(self):
        frame = pd.DataFrame({
            "scenario": [1], "trunk": ["a"], "pressure_psia": [30.],
            "predicted_psia": [float("nan")], "is_sink": [False],
        })
        with self.assertRaises(ValueError):
            pressure_report(frame)


if __name__ == "__main__":
    unittest.main()
