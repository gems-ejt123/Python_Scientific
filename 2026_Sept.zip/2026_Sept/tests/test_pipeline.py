from dataclasses import replace
import tempfile
from pathlib import Path
import unittest

import pandas as pd
import torch

from liquid_badi.data import prepare_data
from liquid_badi.pipeline import (
    MultiTrunkModel, case_loss, constitutive_prior, evaluate_cases, fit_and_save,
    load_model, predict_sources,
)
from liquid_badi.training import TrainingConfig
from test_network import one_pipe, physics


def prepared_fixture():
    rows = []
    for scenario in range(10):
        for i in range(2):
            rows.append({
                "scenario": str(scenario), "trunk": "toy", "Troncal": "toy",
                "node_id": str(i), "node_type": 1 if i == 0 else -1,
                "BranchEquipment": "pipe", "TotalDistance": i * 100,
                "Elevation": 0., "PipeInsideDiameter": 4., "long": float(i), "lat": 0.,
                "FlowrateLiquidInsitu": 10. + scenario, "Watercut": .5,
                "temperature_k": 310., "pressure_psia": 44.8 if i == 0 else 44.7,
                "DensityOilInSitu": 61., "DensityWaterInSitu": 63.,
            })
    mapping = pd.DataFrame([dict(
        source="well", Troncal="toy", BranchEquipment="pipe", long=0., lat=0.,
    )])
    return prepare_data(pd.DataFrame(rows), mapping)


class PipelineTests(unittest.TestCase):
    def test_real_pipeline_smoke_and_reload_without_label_inputs(self):
        prepared = prepared_fixture()
        model = MultiTrunkModel(prepared.specs, prepared.layouts, physics("mlp").export_config())
        config = TrainingConfig(minimum_data_epochs=1, maximum_data_epochs=2,
                                data_patience=3, regularization_epochs=0)
        with tempfile.TemporaryDirectory() as directory:
            result = fit_and_save(model, prepared, Path(directory) / "run", config,
                                  {"data": "synthetic analytical fixture, not CPF2"})
            self.assertEqual(result["status"], "data_budget_exhausted")
            restored, _ = load_model(Path(directory) / "run/model.pt")
            q, wc = {"well": 12.}, {"well": .5}
            predicted, interior = predict_sources(
                restored, "toy", q, wc, queries=[("pipe::part0", 10.)],
            )
            reference, _ = predict_sources(model, "toy", q, wc)
            pd.testing.assert_frame_equal(predicted, reference)
            self.assertEqual(len(interior), 1)
            _, metrics, diagnostics = evaluate_cases(
                restored, {i: prepared.cases[i] for i in prepared.splits["validation"]},
                bootstrap_samples=0,
            )
            self.assertEqual(metrics["sink_max_boundary_error_psi"], 0.)
            self.assertLess(diagnostics["flow_residual_max_m3_s"].max(), 1e-12)

    def test_geometry_changes_are_not_node_count_checks(self):
        prepared = prepared_fixture()
        spec = one_pipe()
        spec["edges"][0]["distance_m"][-1] += 1
        model = MultiTrunkModel(prepared.specs, prepared.layouts, physics().export_config())
        before = model.networks["toy"].geometry_hash
        altered = dict(prepared.specs["toy"])
        altered["edges"] = [dict(e) for e in altered["edges"]]
        altered["edges"][0]["distance_m"] = [0., 31.]
        other = MultiTrunkModel({"toy": altered}, prepared.layouts, physics().export_config())
        self.assertNotEqual(before, other.networks["toy"].geometry_hash)

    def test_parameter_gradient_remains_finite(self):
        prepared = prepared_fixture()
        model = MultiTrunkModel(prepared.specs, prepared.layouts, physics("scalar").export_config())
        loss = case_loss(model, next(iter(prepared.cases.values())), TrainingConfig())
        loss = loss + .01 * constitutive_prior(model)
        loss.backward()
        self.assertTrue(torch.isfinite(model.physics.closure.logit.grad))


if __name__ == "__main__":
    unittest.main()
