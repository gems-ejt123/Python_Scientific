import ast
import json
import os
from pathlib import Path
import tempfile
import unittest

import nbformat
from jupyter_client import KernelManager
import pandas as pd

from liquid_badi.data import inspect_export


ROOT = Path(__file__).resolve().parents[1]
NOTEBOOK = ROOT / "BADI_Liquid_Thermal_CPF2.ipynb"


class NotebookTests(unittest.TestCase):
    def test_notebook_schema_and_python_syntax(self):
        notebook = nbformat.read(NOTEBOOK, as_version=4)
        nbformat.validate(notebook)
        for cell in notebook.cells:
            if cell.cell_type == "code":
                ast.parse(cell.source)
        self.assertEqual(notebook.metadata.kernelspec.name, "pinn_env")

    def test_current_archive_reports_missing_temperature(self):
        audit = inspect_export(
            ROOT.parent / "data_processed/full_data_training_rubiales_CPF2_local.zip",
            "Temperature", "full_data_training_rubiales_CPF2_local",
        )
        # A future updated export legitimately changes this result.
        self.assertIn("Pressure", audit["columns"])
        self.assertEqual(audit["temperature_available"], "Temperature" in audit["columns"])

    def test_fresh_kernel_full_notebook_with_synthetic_export(self):
        with (tempfile.TemporaryDirectory(dir=ROOT) as directory,
              tempfile.TemporaryDirectory(prefix="badi-ipc-") as ipc_directory):
            temporary = Path(directory)
            records = []
            for scenario in range(10):
                for i in range(2):
                    records.append({
                        "scenario": scenario, "Troncal": "toy", "node_id": str(i),
                        "node_type": 1 if i == 0 else -1, "BranchEquipment": "pipe",
                        "TotalDistance": i * 100., "Elevation": 0., "PipeInsideDiameter": 4.,
                        "long": float(i), "lat": 0., "FlowrateLiquidInsitu": 10. + scenario,
                        "Watercut": .5, "Temperature": 310.,
                        "Pressure": 44.8 if i == 0 else 44.7,
                        "DensityOilInSitu": 61., "DensityWaterInSitu": 63.,
                    })
            pd.DataFrame(records).to_csv(temporary / "synthetic.csv", index=False)
            pd.DataFrame([{
                "source": "well", "Troncal": "toy", "BranchEquipment": "pipe",
                "long": 0., "lat": 0.,
            }]).to_csv(temporary / "sources.csv", index=False)
            notebook = nbformat.read(NOTEBOOK, as_version=4)
            notebook.cells.insert(0, nbformat.v4.new_markdown_cell(
                "# Validation artifact: synthetic data only\n"
                "This executed COPY checks notebook wiring in a fresh pinn_env kernel. "
                "It is not CPF2 training or an accuracy claim. Temporary input/checkpoint "
                "paths in the outputs are removed after the test."
            ))
            config = next(cell for cell in notebook.cells if cell.get("id") == "configuration")
            config.source += (
                f"\nDATA_FILE = Path({str(temporary / 'synthetic.csv')!r})"
                f"\nSOURCE_MAP_FILE = Path({str(temporary / 'sources.csv')!r})"
                "\nZIP_MEMBER = None\nTEMPERATURE_UNIT = 'K'\nSELECTED_TRUNKS = ['toy']"
                "\nRUN_SMOKE_TRAINING = True\nRUN_FULL_TRAINING = True"
                "\nRUN_ARCHITECTURE_COMPARISON = True"
                "\nTRAIN_CONFIG = replace(TRAIN_CONFIG, minimum_data_epochs=1, "
                "maximum_data_epochs=2, data_patience=3, regularization_epochs=0)"
                f"\nRUN_DIR = Path({str(temporary / 'runs')!r})\n"
            )
            manager = KernelManager(
                kernel_name="pinn_env", transport="ipc",
                ip=str(Path(ipc_directory) / "kernel"),
                connection_file=str(Path(ipc_directory) / "connection.json"),
            )
            manager.start_kernel(cwd=str(ROOT), env={
                **os.environ, "IPYTHONDIR": str(Path(ipc_directory) / "ipython"),
                "MPLCONFIGDIR": str(Path(ipc_directory) / "matplotlib"),
            })
            client = manager.client()
            client.start_channels()
            try:
                client.wait_for_ready(timeout=60)
                for cell in notebook.cells:
                    if cell.cell_type != "code":
                        continue
                    cell.outputs = []

                    def record_output(message):
                        if message["msg_type"] in {"stream", "display_data", "execute_result", "error"}:
                            cell.outputs.append(nbformat.v4.output_from_msg(message))

                    reply = client.execute_interactive(
                        cell.source, timeout=180, output_hook=record_output,
                    )
                    self.assertEqual(reply["content"]["status"], "ok",
                                     f"Notebook cell {cell.get('id')} failed: {reply['content']}")
                    cell.execution_count = reply["content"]["execution_count"]
            finally:
                client.stop_channels()
                manager.shutdown_kernel(now=True)
            executed = notebook
            errors = [
                output for cell in executed.cells if cell.cell_type == "code"
                for output in cell.get("outputs", []) if output.get("output_type") == "error"
            ]
            self.assertEqual(errors, [])
            self.assertTrue((temporary / "runs/mlp/model.pt").is_file())
            self.assertTrue((temporary / "runs/comparison/validation_comparison.csv").is_file())
            metrics = json.loads((temporary / "runs/mlp/validation/metrics.json").read_text())
            self.assertEqual(metrics["sink_max_boundary_error_psi"], 0.)
            artifact_directory = os.environ.get("BADI_TEST_ARTIFACT_DIR")
            if artifact_directory:
                artifacts = Path(artifact_directory).resolve()
                if ROOT not in artifacts.parents:
                    raise ValueError("Test artifacts must stay under 2026_Sept.")
                artifacts.mkdir(parents=True, exist_ok=True)
                nbformat.write(executed, artifacts / "synthetic_notebook_execution.ipynb")
                summary = {
                    "kernel": "pinn_env", "notebook_execution": "passed, fresh kernel",
                    "data": "synthetic 10-scenario one-pipe fixture, not CPF2",
                    "code_cells_executed": sum(c.cell_type == "code" for c in executed.cells),
                    "training": "two epochs per closure; smoke and checkpoint parity exercised",
                    "closures_exercised": ["none", "scalar", "mlp", "fourier_mlp", "kan"],
                    "sink_boundary_error_psi": metrics["sink_max_boundary_error_psi"],
                    "real_cpf2_training": "not run; requires updated temperature-enabled export",
                }
                (artifacts / "notebook_validation.json").write_text(json.dumps(summary, indent=2))


if __name__ == "__main__":
    unittest.main()
