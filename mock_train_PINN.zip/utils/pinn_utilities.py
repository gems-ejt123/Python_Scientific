import numpy as np
import torch
from .pinn_models import TrunkPINN

def preprocess_network_topology(network_topology, base_cols):
    # Ensure all base feature columns are present and finite
    base_cols = ['FlowrateLiquidInsitu','Watercut','ElevationDifference','TotalDistance','lambda_friction','PipeInsideDiameter']

    for c in base_cols:
        if c not in network_topology.columns:
            raise ValueError(f"Required column missing: {c}")
        # Replace inf with NaN for uniform handling
        network_topology[c].replace([np.inf, -np.inf], np.nan, inplace=True)

    lf_col = 'lambda_friction'
    if lf_col in network_topology.columns:
        nan_count = network_topology[lf_col].isna().sum()
        if nan_count > 0:
            # Branch-level median
            branch_median_series = network_topology.groupby('BranchEquipment')[lf_col].transform('median')
            global_median = network_topology[lf_col].median()
            fallback = 0.02 if np.isnan(global_median) else float(global_median)
            # Fill with branch median then fallback
            network_topology[lf_col] = network_topology[lf_col].fillna(branch_median_series)
            network_topology[lf_col] = network_topology[lf_col].fillna(fallback)
            # Clamp to physically reasonable friction factor range
            network_topology[lf_col] = network_topology[lf_col].clip(lower=0.005, upper=0.15)
            remaining = network_topology[lf_col].isna().sum()
            print(f"Imputed {nan_count} NaN lambda_friction values (remaining {remaining}). Fallback used={fallback:.5f}")
        else:
            print("No NaNs in lambda_friction.")
    else:
        print("lambda_friction column not found (cannot impute).")

    # Final sanity check
    bad_any = []
    for c in base_cols:
        if network_topology[c].isna().any():
            bc = network_topology[c].isna().sum()
            bad_any.append((c, bc))
    if bad_any:
        print("WARNING: Remaining NaNs after cleaning:", bad_any)
    else:
        print("All base feature columns are finite after cleaning.")

def make_predictions(MODEL_PATH, network_topology, base_cols, device):

    X_raw = network_topology[base_cols].astype(float).values
    assert np.isfinite(X_raw).all(), "Non-finite values remained after cleaning."

    ckpt = torch.load(MODEL_PATH, map_location=device, weights_only=False)
    state_like = ckpt.get('multi_trunk_state_dict', ckpt.get('state_dict', ckpt))
    
    # Infer model parameters from actual weight shapes
    # KAN models use hidden_width and num_layers (not hidden_layers list)
    # Fourier models use hidden_layers list
    hidden_layers = [64,128,256,512,128,64]  # Default for Fourier
    hidden_width = 128  # Default for KAN
    num_layers = 4  # Default for KAN
    
    sample_trunk_keys = [k for k in list(state_like.keys())[:200] if '.base_model.network.0.weight' in k]
    
    if sample_trunk_keys:
        # Get first layer shape to infer hidden_width
        first_layer_key = sample_trunk_keys[0]
        first_layer_shape = state_like[first_layer_key].shape
        hidden_width = first_layer_shape[0]  # Infer hidden dimension (e.g., 128 for KAN)
        
        # Count hidden layers to infer num_layers for KAN
        # SimpleEnhancedKAN structure: Input + (Linear+SiLU+LayerNorm)*num_layers + Output
        # Pattern: layer 0 (input), then every 3rd layer is a Linear (2, 5, 8, 11, ...), last is output
        trunk_prefix = first_layer_key.split('.network.')[0]
        hidden_layer_keys = []
        for k in state_like.keys():
            if k.startswith(trunk_prefix + '.network.') and '.weight' in k:
                layer_id_str = k.split('.network.')[1].split('.')[0]
                if layer_id_str.isdigit():
                    layer_id = int(layer_id_str)
                    shape = state_like[k].shape
                    # Hidden layers have shape [hidden_width, hidden_width]
                    if shape == (hidden_width, hidden_width):
                        hidden_layer_keys.append(layer_id)
        
        if hidden_layer_keys:
            num_layers = len(hidden_layer_keys)
        
        print(f"Inferred KAN parameters: hidden_width={hidden_width}, num_layers={num_layers}")
    else:
        print(f"Using default parameters: hidden_width={hidden_width}, num_layers={num_layers}")

    selected_trunk = None
    filtered_state = {}
    trunk_names = set()

    if isinstance(state_like, dict) and any(isinstance(v, torch.Tensor) for v in state_like.values()):
        for k in state_like.keys():
            if k.startswith('trunk_models.') and '.base_model.' in k:
                trunk_part = k[len('trunk_models.'):].split('.base_model.')[0]
                trunk_names.add(trunk_part)
        if trunk_names:
            selected_trunk = sorted(trunk_names)[0]
            print(f"Detected trunks ({len(trunk_names)}): {sorted(list(trunk_names))[:6]}{' ...' if len(trunk_names)>6 else ''}")
            print(f"Using trunk: {selected_trunk}")
            prefix = f'trunk_models.{selected_trunk}.base_model.'
            for k,v in state_like.items():
                if k.startswith(prefix):
                    new_key = 'base_model.' + k[len(prefix):]
                    filtered_state[new_key] = v
        else:
            raise RuntimeError("No trunk_models.* keys found in checkpoint.")
    else:
        raise RuntimeError("Unexpected checkpoint structure; expected flat tensor mapping of trunks.")

    # Detect architecture from checkpoint structure
    network_pattern_count = sum(1 for key in state_like.keys() if 'network.' in key)
    fourier_pattern_count = sum(1 for key in state_like.keys() if 'fourier' in key.lower())
    
    if network_pattern_count > 0 and fourier_pattern_count == 0:
        architecture = 'kan'
        print(f"Detected architecture: KAN (network layers: {network_pattern_count})")
    else:
        architecture = 'fourier_batchnorm'
        print(f"Detected architecture: Fourier BatchNorm")
    
    # Create model with appropriate parameters
    if architecture == 'kan':
        print(f"Creating KAN model with hidden_width={hidden_width}, num_layers={num_layers}")
        model = TrunkPINN(
            trunk_name=selected_trunk or 'FULL', 
            input_dim=6, 
            output_dim=1, 
            architecture=architecture,
            hidden_width=hidden_width,
            num_layers=num_layers
        ).to(device)
    else:
        print(f"Creating Fourier model with hidden_layers={hidden_layers}")
        model = TrunkPINN(
            trunk_name=selected_trunk or 'FULL', 
            input_dim=6, 
            output_dim=1, 
            architecture=architecture,
            hidden_layers=hidden_layers
        ).to(device)
    model.eval()
    missing, unexpected = model.load_state_dict(filtered_state, strict=False)
    if missing or unexpected:
        print(f"WARNING: mismatch loading state (missing={len(missing)} unexpected={len(unexpected)})")
    else:
        model.load_state_dict(filtered_state, strict=True)
        print("Strict load succeeded (0 missing / 0 unexpected).")

    # Apply input scaler if available
    X_input = X_raw
    if 'trunk_scalers' in ckpt and selected_trunk in ckpt['trunk_scalers']:
        scalers = ckpt['trunk_scalers'][selected_trunk]
        input_scaler = scalers.get('input_scaler')
        
        if input_scaler is not None:
            if hasattr(input_scaler, 'transform'):
                X_input = input_scaler.transform(X_raw)
                print(f"Applied input normalization using {type(input_scaler).__name__}")
            elif isinstance(input_scaler, dict):
                # Handle dict-based scalers
                if 'data_min_' in input_scaler and 'scale_' in input_scaler and 'min_' in input_scaler:
                    data_min_ = np.array(input_scaler['data_min_'])
                    scale_ = np.array(input_scaler['scale_'])
                    min_vec = np.array(input_scaler['min_'])
                    X_input = (X_raw - data_min_) * scale_ + min_vec
                    print("Applied input normalization using MinMaxScaler (dict)")
                elif 'mean_' in input_scaler and 'scale_' in input_scaler:
                    mean_ = np.array(input_scaler['mean_'])
                    scale_ = np.array(input_scaler['scale_'])
                    X_input = (X_raw - mean_) / scale_
                    print("Applied input normalization using StandardScaler (dict)")
        else:
            print("Warning: No input_scaler found in checkpoint, using raw inputs")
    else:
        print("Warning: No trunk_scalers found in checkpoint, using raw inputs")

    X_tensor = torch.tensor(X_input, dtype=torch.float32, device=device)
    with torch.no_grad():
        preds = model(X_tensor).squeeze().detach().cpu().numpy()

    if not np.isfinite(preds).all():
        bad_idx = np.where(~np.isfinite(preds))[0][:10]
        print("Non-finite predictions still present; showing first few indices:", bad_idx)
    else:
        print(f"Predictions OK. Range psi: min={preds.min():.2f} max={preds.max():.2f} mean={preds.mean():.2f} std={preds.std():.2f}")
    
    network_topology['Pressure_Pred_PINN'] = preds

    return network_topology, selected_trunk, model


def unscale_predictions(MODEL_PATH, network_topology, base_cols, selected_trunk, model, device):
    
    if 'ckpt' not in globals():
        ckpt = torch.load(MODEL_PATH, map_location=device, weights_only=False)

    scalers = None
    if 'trunk_scalers' in ckpt and selected_trunk in ckpt['trunk_scalers']:
        scalers = ckpt['trunk_scalers'][selected_trunk]
        print(f"Scaler bundle keys: {list(scalers.keys())}")
    else:
        print("No scaler bundle present for selected trunk; skipping scaling logic.")

    raw_X = network_topology[base_cols].values.astype(float)

    scaled_pred = None
    inverse_pred = None

    # Functions to detect and apply scaler dicts (sklearn-like stored as dict)

    def apply_input_scaler(X, scaler_obj):
        if scaler_obj is None:
            return X, 'none'
        # Direct sklearn object with transform()
        if hasattr(scaler_obj, 'transform'):
            return scaler_obj.transform(X), type(scaler_obj).__name__
        if isinstance(scaler_obj, dict):
            keys = set(scaler_obj.keys())
            # StandardScaler pattern
            if {'mean_', 'scale_'}.issubset(keys):
                mean_ = np.array(scaler_obj['mean_'])
                scale_ = np.array(scaler_obj['scale_'])
                return (X - mean_) / scale_, 'StandardScaler(dict)'
            # MinMaxScaler internal representation
            if {'data_min_', 'scale_', 'min_'}.issubset(keys):
                data_min_ = np.array(scaler_obj['data_min_'])
                scale_ = np.array(scaler_obj['scale_'])
                min_vec = np.array(scaler_obj['min_'])  # translation term
                # forward: X_scaled = (X - data_min_) * scale_ + min_vec
                return (X - data_min_) * scale_ + min_vec, 'MinMaxScaler(dict-internal)'
            # Simplified range spec
            if {'min', 'max'}.issubset(keys):
                minv = np.array(scaler_obj['min'])
                maxv = np.array(scaler_obj['max'])
                return (X - minv) / (maxv - minv + 1e-12), 'RangeScaler(dict)'
        
        return X, 'unrecognized'

    def inverse_output_scaler(y, scaler_obj):
        if scaler_obj is None:
            return y, 'none'
        if hasattr(scaler_obj, 'inverse_transform'):
            return scaler_obj.inverse_transform(y.reshape(-1,1)).ravel(), type(scaler_obj).__name__
        if isinstance(scaler_obj, dict):
            keys = set(scaler_obj.keys())
            # StandardScaler
            if {'mean_', 'scale_'}.issubset(keys):
                mean_ = float(np.array(scaler_obj['mean_']).ravel()[0])
                scale_ = float(np.array(scaler_obj['scale_']).ravel()[0])
                return y * scale_ + mean_, 'StandardScaler(dict)'
            # MinMaxScaler internal (X_scaled = (X - data_min_) * scale_ + min_vec)
            if {'data_min_', 'scale_', 'min_'}.issubset(keys):
                data_min_ = float(np.array(scaler_obj['data_min_']).ravel()[0])
                scale_ = float(np.array(scaler_obj['scale_']).ravel()[0])
                min_vec = float(np.array(scaler_obj['min_']).ravel()[0])
                # invert: X = ( (X_scaled - min_vec) / scale_ ) + data_min_
                return ((y - min_vec) / (scale_ + 1e-12)) + data_min_, 'MinMaxScaler(dict-internal)'
            # Simple range scaler (y_scaled = (y - min)/(max-min))
            if {'min', 'max'}.issubset(keys):
                minv = float(np.array(scaler_obj['min']).ravel()[0])
                maxv = float(np.array(scaler_obj['max']).ravel()[0])

                return y * (maxv - minv) + minv, 'RangeScaler(dict)'
        
        return y, 'unrecognized'

    input_scale_type = 'none'
    output_scale_type = 'none'

    if scalers:
        input_scaler = scalers.get('input_scaler')
        output_scaler = scalers.get('output_scaler')

        # Strategy: try scaled inference and compare variance with raw inference
        X_scaled, input_scale_type = apply_input_scaler(raw_X, input_scaler)
        X_tensor_scaled = torch.tensor(X_scaled, dtype=torch.float32, device=device)
        with torch.no_grad():
            preds_scaled = model(X_tensor_scaled).squeeze().detach().cpu().numpy()
        scaled_pred = preds_scaled
        inverse_pred, output_scale_type = inverse_output_scaler(preds_scaled, output_scaler)

        print(f"Input scaler applied: {input_scale_type}; Output scaler inversion: {output_scale_type}")
        print(f"Raw preds stats  : min={network_topology['Pressure_Pred_PINN'].min():.4f} max={network_topology['Pressure_Pred_PINN'].max():.4f} std={network_topology['Pressure_Pred_PINN'].std():.4f}")
        print(f"Scaled preds stats: min={preds_scaled.min():.4f} max={preds_scaled.max():.4f} std={preds_scaled.std():.4f}")
        print(f"Inverse preds stats: min={inverse_pred.min():.4f} max={inverse_pred.max():.4f} std={inverse_pred.std():.4f}")
       
        # Choose final pressure column: prefer inverse transformed if variance > tiny threshold
        chosen = inverse_pred if inverse_pred is not None and np.isfinite(inverse_pred).all() and inverse_pred.std() > 1e-6 else network_topology['Pressure_Pred_PINN'].values
        network_topology['Pressure_Pred_PINN_rawModel'] = network_topology['Pressure_Pred_PINN']
        network_topology['Pressure_Pred_PINN'] = chosen/1.2
    else:
        print("No scalers to apply; retaining raw model outputs.")

    network_topology[['Pressure_Pred_PINN_rawModel','Pressure_Pred_PINN']].head(10) if 'Pressure_Pred_PINN_rawModel' in network_topology.columns else network_topology[['Pressure_Pred_PINN']].head(10)

    return network_topology