"""Flow propagation utilities for pipeline network (per Troncal).

Core function:
    propagate_flowrates(input_df, topology_df, sources_branch_df, sink_df, ...)

Design goals:
    - Minimal dependencies (pandas, numpy)
    - Deterministic, single pass + limited fallback iterations
    - Conservative (never invents splits); ambiguous multi-out junctions reported
    - Watercut mixing: volumetric weighted at merges

Assumptions:
    - Each row of topology_df is a node on a BranchEquipment with monotonically increasing TotalDistance.
    - Flow along a BranchEquipment is constant (no sources/sinks mid-branch).
    - Multiple wells (UWI) map to a CLUSTER (source). Active wells have STATUS_OPT_OUTPUT == 1.
    - Cluster flow = sum FLUID_PRED of active wells. Cluster watercut = sum WATER_PRED / sum FLUID_PRED (active only).
    - sources_branch_df maps source (CLUSTER) -> initial BranchEquipment.
    - No recirculation; each Troncal is independent.
    - sink_df contains coordinates (long, lat) of sink nodes; these are marked node_type = -1.

Return values:
    updated_topology_df, diagnostics_dict

Diagnostics keys:
    ambiguous_split_count
    unfilled_branch_count
    unfilled_branches_sample
    troncal_stats (list of per-troncal dicts)

Future extensions:
    - Implement split heuristics (e.g., diameter weighting) for ambiguous multi-out.
    - Integrate pressure-loss models coupled to PINN boundary conditions.
     - Optionally push back computed branch flows to create synthetic training sets for PINN boundary nodes.

Example
-------
>>> from flow_propagation import propagate_flowrates
>>> updated, diag, amb = propagate_flowrates(
...     input_df=prod_df,
...     topology_df=topology_df,
...     sources_branch_df=sources_branch,
...     sink_df=sink_coord,
...     round_decimals=8)
>>> print(diag['ambiguous_split_count'])
>>> # Merge updated flows back into model feature set
>>> features = updated[['BranchEquipment','TotalDistance','FlowrateLiquidInsitu','Watercut']]

Edge Cases & Handling
---------------------
1. Ambiguous split (one coordinate, multiple zero-flow outgoing branches):
    - The function leaves those branches unassigned (FlowrateLiquidInsitu stays 0) and records them in the ambiguous DataFrame.
    - You can resolve by adding a split allocation rule and re-running.
2. Disconnected branches (no upstream flow ever reaches them):
    - Reported among unfilled branches; verify topology or source mapping.
3. Multiple sources feeding same first BranchEquipment:
    - Their flows and water volumes are summed before propagation (reason = 'source_sum').
4. Sinks mid-branch:
    - All nodes on a branch containing any sink coordinate keep the branch flow; the specific sink node is node_type = -1.
5. Watercut and zero flow:
    - Watercut only meaningful where flow > 0; zeros remain 0.
6. Balance residual per Troncal:
    - If residual is large, check for ambiguous splits or missing sinks.
"""
from __future__ import annotations
import pandas as pd
import numpy as np
from collections import defaultdict, deque
from typing import Dict, Tuple, List

# ---------------------------------------------------------------------------
# Helper computations
# ---------------------------------------------------------------------------

def _round_coord(lon: float, lat: float, dec: int) -> Tuple[float, float]:
    return (round(float(lon), dec), round(float(lat), dec))


def _compute_cluster_flows(input_df: pd.DataFrame) -> Tuple[Dict[str, float], Dict[str, float]]:
    required = ["CLUSTER", "FLUID_PRED", "WATER_PRED", "STATUS_OPT_OUTPUT"]
    miss = [c for c in required if c not in input_df.columns]
    if miss:
        raise ValueError(f"Input production data missing required columns: {miss}")
    active = input_df[input_df["STATUS_OPT_OUTPUT"] == 1].copy()
    grp = active.groupby("CLUSTER").agg({"FLUID_PRED": "sum", "WATER_PRED": "sum"})
    grp["watercut"] = 0.0
    mask = grp["FLUID_PRED"] > 0
    grp.loc[mask, "watercut"] = grp.loc[mask, "WATER_PRED"] / grp.loc[mask, "FLUID_PRED"].replace(0, np.nan)
    cluster_flows = grp["FLUID_PRED"].to_dict()
    cluster_wc = grp["watercut"].to_dict()
    return cluster_flows, cluster_wc

# ---------------------------------------------------------------------------
# Main propagation
# ---------------------------------------------------------------------------

def propagate_flowrates(
    input_df: pd.DataFrame,
    topology_df: pd.DataFrame,
    sources_branch_df: pd.DataFrame,
    sink_df: pd.DataFrame,
    round_decimals: int = 8,
    max_linear_iters: int = 50,
    verbose: bool = True,
):
    """Propagate FlowrateLiquidInsitu & Watercut across all Troncales.

    Parameters
    ----------
    input_df : DataFrame
        Well-level production input containing at least CLUSTER, FLUID_PRED, WATER_PRED, STATUS_OPT_OUTPUT.
    topology_df : DataFrame
        Network nodes with columns: BranchEquipment, TotalDistance, long, lat, Troncal, (optional existing node_type, FlowrateLiquidInsitu, Watercut).
    sources_branch_df : DataFrame
        Mapping of source (CLUSTER) to BranchEquipment (first downstream branch). Columns: source, BranchEquipment.
    sink_df : DataFrame
        Coordinates of sink nodes (long, lat). If multiple sinks per Troncal they are all marked node_type=-1.
    round_decimals : int
        Rounding precision for coordinate-based matching.
    max_linear_iters : int
        Max iterations for linear continuation fallback.
    verbose : bool
        Print summary diagnostics.
    """
    required_topo = ["BranchEquipment", "TotalDistance", "long", "lat", "Troncal"]
    miss_topo = [c for c in required_topo if c not in topology_df.columns]
    if miss_topo:
        raise ValueError(f"Topology missing columns: {miss_topo}")

    topo = topology_df.copy()
    # Ensure baseline columns
    if "node_type" not in topo.columns:
        topo["node_type"] = 0
    if "FlowrateLiquidInsitu" not in topo.columns:
        topo["FlowrateLiquidInsitu"] = 0.0
    if "Watercut" not in topo.columns:
        topo["Watercut"] = 0.0

    # Mark sinks
    sink_set = {_round_coord(r.long, r.lat, round_decimals) for r in sink_df.itertuples() if not pd.isna(r.long) and not pd.isna(r.lat)}
    topo_coords = topo[["long", "lat"]].apply(lambda r: _round_coord(r.long, r.lat, round_decimals), axis=1)
    topo.loc[topo_coords.isin(sink_set), "node_type"] = -1

    # Cluster (source) aggregated flows & watercuts
    cluster_flows, cluster_wc = _compute_cluster_flows(input_df)

    # Map cluster sources to initial BranchEquipment
    if not {"source", "BranchEquipment"}.issubset(sources_branch_df.columns):
        raise ValueError("sources_branch_df must contain 'source' and 'BranchEquipment'")

    # Assign source branch flows
    # If multiple sources map to same branch, sum flows and water volumes
    branch_source_agg: Dict[str, Dict[str, float]] = {}
    for row in sources_branch_df.itertuples():
        cl = getattr(row, "source")
        be = getattr(row, "BranchEquipment")
        if cl not in cluster_flows:
            continue
        branch_source_agg.setdefault(be, {"flow": 0.0, "water_vol": 0.0})
        f = cluster_flows[cl]
        wc = cluster_wc.get(cl, 0.0)
        branch_source_agg[be]["flow"] += f
        branch_source_agg[be]["water_vol"] += f * wc

    # For performance, pre-seg by branch
    topo.sort_values(["BranchEquipment", "TotalDistance"], inplace=True)

    # Keep track of true source branches (from cluster mapping)
    true_source_branches = set(branch_source_agg.keys())

    def set_branch(be: str, flow: float, wc: float, reason: str):
        """Assign flow & watercut to an entire branch but only mark its FIRST non-sink node as node_type=1.

        Previous version incorrectly labeled all nodes in the branch as sources (node_type=1).
        This corrected version:
          - Sets flow & watercut for all nodes.
          - Resets non-sink nodes in the branch to 0 first (safety if function re-run).
          - Marks only the first node (smallest TotalDistance) as node_type=1 (if not a sink).
        """
        mask = topo["BranchEquipment"] == be
        topo.loc[mask, "FlowrateLiquidInsitu"] = flow
        topo.loc[mask, "Watercut"] = wc
        # Reset prior mistaken source flags (avoid touching sinks)
        topo.loc[mask & (topo["node_type"] != -1), "node_type"] = 0
        # Identify first node by distance
        branch_nodes = topo[mask].sort_values("TotalDistance")
        if not branch_nodes.empty:
            first_idx = branch_nodes.index[0]
            if topo.loc[first_idx, "node_type"] != -1:  # do not override sink if coincident
                topo.loc[first_idx, "node_type"] = 1
        topo.loc[mask, "_reason"] = reason

    topo["_reason"] = ""

    for be, agg in branch_source_agg.items():
        total_flow = agg["flow"]
        wc = agg["water_vol"] / total_flow if total_flow > 0 else 0.0
        set_branch(be, total_flow, wc, "source_sum")

    # Enforce single source node_type per branch (defensive cleanup in case of legacy data):
    for be, bdf in topo.groupby("BranchEquipment"):
        # If multiple node_type==1 (and not sinks), keep only first by distance
        bsorted = bdf.sort_values("TotalDistance")
        source_flags = (bsorted["node_type"] == 1) & (bsorted["node_type"] != -1)
        if source_flags.sum() > 1:
            # Reset all to 0 then set first
            idxs = bsorted.index
            topo.loc[idxs[source_flags], "node_type"] = 0
            first_idx = bsorted.index[0]
            if topo.loc[first_idx, "node_type"] != -1:
                topo.loc[first_idx, "node_type"] = 1

    # Build branch endpoints per Troncal
    troncal_stats: List[Dict[str, object]] = []
    ambiguous_records: List[Dict[str, object]] = []

    # We'll process Troncal by Troncal
    updated_troncal_frames = []
    for troncal, tdf in topo.groupby("Troncal"):
        tdf = tdf.copy()
        # endpoints
        endpoints = {}
        starts_at = defaultdict(list)
        ends_at = defaultdict(list)
        for be, bdf in tdf.groupby("BranchEquipment"):
            bsort = bdf.sort_values("TotalDistance")
            start = _round_coord(bsort.iloc[0].long, bsort.iloc[0].lat, round_decimals)
            end = _round_coord(bsort.iloc[-1].long, bsort.iloc[-1].lat, round_decimals)
            endpoints[be] = {"start": start, "end": end}
            starts_at[start].append(be)
            ends_at[end].append(be)

        def branch_flow(be):
            sub = tdf[tdf["BranchEquipment"] == be]
            return float(sub["FlowrateLiquidInsitu"].iloc[0]) if not sub.empty else 0.0
        def branch_wc(be):
            sub = tdf[tdf["BranchEquipment"] == be]
            return float(sub["Watercut"].iloc[0]) if not sub.empty else 0.0
        def set_branch_local(be, flow, wc, reason, upstream_list):
            mask = tdf["BranchEquipment"] == be
            tdf.loc[mask, "FlowrateLiquidInsitu"] = flow
            tdf.loc[mask, "Watercut"] = wc
            # DO NOT promote to source (node_type=1) here; only original cluster sources are sources.
            tdf.loc[mask, "_reason"] = reason
            tdf.loc[mask, "_upstream"] = ",".join(upstream_list) if upstream_list else ""

        # Initialize queue
        queue = deque()
        enqueued = set()
        coords = set(list(starts_at.keys()) + list(ends_at.keys()))
        for coord in coords:
            if any(branch_flow(b) > 0 for b in ends_at.get(coord, [])) and any(branch_flow(b) == 0 for b in starts_at.get(coord, [])):
                queue.append(coord)
                enqueued.add(coord)

        junction_assignments = 0
        ambiguous_splits = 0

        while queue:
            coord = queue.popleft()
            incoming = [b for b in ends_at.get(coord, []) if branch_flow(b) > 0]
            outgoing_zero = [b for b in starts_at.get(coord, []) if branch_flow(b) == 0]
            if not incoming or not outgoing_zero:
                continue
            if len(outgoing_zero) > 1:
                # Ambiguous split – record but skip assignment
                ambiguous_splits += 1
                ambiguous_records.append({
                    "Troncal": troncal,
                    "coord": coord,
                    "incoming": incoming,
                    "outgoing_candidates": outgoing_zero,
                })
                continue
            target = outgoing_zero[0]
            q_sum = sum(branch_flow(b) for b in incoming)
            if q_sum <= 0:
                continue
            water_vol = sum(branch_flow(b) * branch_wc(b) for b in incoming)
            wc_mix = water_vol / q_sum if q_sum > 0 else 0.0
            set_branch_local(target, q_sum, wc_mix, "junction_sum", incoming)
            junction_assignments += 1
            down_coord = endpoints[target]["end"]
            if any(branch_flow(b) == 0 for b in starts_at.get(down_coord, [])) and down_coord not in enqueued:
                queue.append(down_coord)
                enqueued.add(down_coord)

        # Linear continuation fallback
        linear_events = 0
        for _ in range(max_linear_iters):
            changes = 0
            zero_branches = [be for be in tdf["BranchEquipment"].unique() if branch_flow(be) == 0]
            if not zero_branches:
                break
            for be in zero_branches:
                start_coord = endpoints[be]["start"]
                incoming = [b for b in ends_at.get(start_coord, []) if branch_flow(b) > 0]
                if len(incoming) == 1:  # simple continuation
                    up = incoming[0]
                    q = branch_flow(up)
                    wc = branch_wc(up)
                    if q > 0:
                        set_branch_local(be, q, wc, "linear_inherit", [up])
                        changes += 1
                        linear_events += 1
            if changes == 0:
                break

        # Collect stats
        unfilled_branches = [be for be in tdf["BranchEquipment"].unique() if branch_flow(be) == 0]
        source_flow_sum = tdf.loc[tdf["node_type"] == 1, "FlowrateLiquidInsitu"].groupby(tdf["BranchEquipment"]).first().sum()
        sink_nodes = tdf[tdf["node_type"] == -1]
        sink_flow_sum = 0.0
        if not sink_nodes.empty:
            # sink branch flows: flow associated with branches that contain at least one sink node
            sink_flow_sum = sink_nodes.groupby("BranchEquipment")["FlowrateLiquidInsitu"].first().sum()
        troncal_stats.append({
            "Troncal": troncal,
            "branches": tdf["BranchEquipment"].nunique(),
            "junction_assignments": junction_assignments,
            "linear_events": linear_events,
            "ambiguous_splits": ambiguous_splits,
            "unfilled_branch_count": len(unfilled_branches),
            "unfilled_sample": unfilled_branches[:5],
            "source_flow_sum": float(source_flow_sum),
            "sink_flow_sum": float(sink_flow_sum),
            "balance_residual": (abs(source_flow_sum - sink_flow_sum) / max(source_flow_sum, 1e-9)) if source_flow_sum > 0 else 0.0,
        })
        updated_troncal_frames.append(tdf)

    updated = pd.concat(updated_troncal_frames, axis=0).sort_index()

    # --- Final cleanup of node_type flags ---
    # Reset all non-sink node_types to 0, then mark only first node of true source branches as 1.
    non_sink_mask = updated["node_type"] != -1
    updated.loc[non_sink_mask, "node_type"] = 0
    for be in true_source_branches:
        bdf = updated[updated["BranchEquipment"] == be].sort_values("TotalDistance")
        if bdf.empty:
            continue
        first_idx = bdf.index[0]
        if updated.loc[first_idx, "node_type"] != -1:
            updated.loc[first_idx, "node_type"] = 1

    # True source flow sum from original branches
    true_source_flow_sum = (
        updated.loc[updated["node_type"] == 1]
        .groupby("BranchEquipment")["FlowrateLiquidInsitu"].first().sum()
    )
    diagnostics = {
        "ambiguous_split_count": len(ambiguous_records),
        "unfilled_branch_count": int((updated["FlowrateLiquidInsitu"] == 0).sum() > 0),
        "unfilled_branches_sample": updated.loc[updated["FlowrateLiquidInsitu"] == 0, "BranchEquipment"].unique()[:10].tolist(),
        "troncal_stats": troncal_stats,
        "true_source_flow_sum": float(true_source_flow_sum),
    }

    if verbose:
        print(f"Flow propagation finished. Ambiguous splits: {diagnostics['ambiguous_split_count']}")
        worst = max((s['balance_residual'] for s in troncal_stats), default=0.0)
        print(f"Worst balance residual across Troncales: {worst:.3e}")

    return updated, diagnostics, pd.DataFrame(ambiguous_records)

__all__ = ["propagate_flowrates"]
