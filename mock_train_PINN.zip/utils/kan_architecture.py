"""
Kolmogorov-Arnold Network (KAN) Implementation for Pipeline Pressure Prediction.

This module provides different KAN implementations optimized for fluid dynamics modeling.
KANs are based on Kolmogorov-Arnold representation theorem which states that any multivariate
continuous function can be represented as a composition of univariate functions.

For pipeline pressure prediction, KANs offer several advantages:
1. Better capability to model complex non-linear relationships in fluid dynamics
2. More interpretable than standard neural networks due to the univariate function representation
3. Better generalization to unseen data in physical systems

References:
- Kolmogorov, A. N. (1957). On the representation of continuous functions of many variables by 
  superposition of continuous functions of one variable and addition.
- Liu et al. (2023). "The Kolmogorov-Arnold Network," arXiv:2306.00350
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class BSplineBasis(nn.Module):
    """
    B-spline basis functions for KAN implementation
    """
    def __init__(self, num_basis=10, spline_degree=3, range_min=-1.0, range_max=1.0, learnable=True):
        super(BSplineBasis, self).__init__()
        self.num_basis = num_basis
        self.spline_degree = spline_degree
        self.range_min = range_min
        self.range_max = range_max
        self.learnable = learnable
        
        # Create initial knot positions
        # We need (num_basis + spline_degree + 1) knots
        num_knots = num_basis + spline_degree + 1
        uniform_knots = torch.linspace(-spline_degree, num_basis, num_knots)
        
        # Store all knots but make only interior ones learnable
        self.register_buffer('all_knots', uniform_knots.clone())
        
        if learnable:
            # Make the interior knots learnable
            interior_knots = uniform_knots[spline_degree:-spline_degree].clone()
            self.register_parameter('learnable_interior', nn.Parameter(interior_knots))
    
    def forward(self, x):
        """
        Compute all basis functions for each input value
        
        Args:
            x: Input tensor of shape [batch_size, 1]
            
        Returns:
            Tensor: Shape [batch_size, num_basis] with each basis function evaluated
        """
        # Update interior knots if they're learnable
        if self.learnable:
            # Copy the learnable interior knots to the all_knots buffer
            self.all_knots[self.spline_degree:-self.spline_degree] = self.learnable_interior
            
        # Scale x to the spline domain
        x_scaled = (x - self.range_min) / (self.range_max - self.range_min) * (self.num_basis - 1)
        
        # Compute all basis functions
        basis_values = []
        for i in range(self.num_basis):
            basis_values.append(self.basis_function(x_scaled, i, self.spline_degree))
        
        # Stack along dimension 1 to get [batch_size, num_basis]
        result = torch.stack(basis_values, dim=1)
        
        # Ensure numerical stability
        row_sums = result.sum(dim=1, keepdim=True)
        mask = row_sums > 0
        result = torch.where(mask, result / row_sums, result)
        
        return result
    
    def basis_function(self, x, idx, degree):
        """
        Recursive implementation of Cox-de Boor algorithm for B-spline basis
        
        Args:
            x: Input tensor
            idx: Index of the basis function
            degree: Degree of the spline
            
        Returns:
            Tensor: Values of the basis function at x
        """
        if degree == 0:
            # Base case: degree-0 basis is a step function
            return ((x >= self.all_knots[idx]) & (x < self.all_knots[idx + 1])).float()
        
        term1 = torch.zeros_like(x)
        term2 = torch.zeros_like(x)
        
        # Avoid division by zero
        denom1 = self.all_knots[idx + degree] - self.all_knots[idx]
        if denom1 > 1e-10:
            num1 = x - self.all_knots[idx]
            term1 = num1 / denom1 * self.basis_function(x, idx, degree - 1)
        
        denom2 = self.all_knots[idx + degree + 1] - self.all_knots[idx + 1]
        if denom2 > 1e-10:
            num2 = self.all_knots[idx + degree + 1] - x
            term2 = num2 / denom2 * self.basis_function(x, idx + 1, degree - 1)
        
        return term1 + term2


class EnhancedKAN(nn.Module):
    """
    Enhanced Kolmogorov-Arnold Network for pipeline pressure prediction.
    
    This implementation better follows the Kolmogorov-Arnold representation theorem
    by using proper basis functions and the canonical KAN structure:
    f(x₁,...,xₙ) = ∑ᵢ gᵢ(∑ⱼ ϕᵢⱼ(xⱼ))
    
    The model uses B-splines for the univariate functions ϕᵢⱼ, making it more
    expressive for modeling complex physical relationships in pipeline networks.
    
    Attributes:
        n_input (int): Number of input features
        n_output (int): Number of output features
        pressure_activation_type (str): Type of activation for pressure output
        basis_functions (ModuleList): List of B-spline basis functions
        first_layer_weights (Parameter): Weights for the first layer
        combination_layer (Linear): Layer combining univariate functions
        extra_layers (ModuleList): Additional network layers
        output_layer (Linear): Final output layer
    """
    def __init__(self, n_input, n_output, hidden_width=32, num_layers=2, 
                 pressure_activation="tanh", spline_degree=3, num_basis=10):
        """
        Initialize the enhanced KAN model.
        
        Args:
            n_input (int): Number of input features
            n_output (int): Number of output features (usually 1 for pressure or 2 for pressure+mass flow)
            hidden_width (int): Width of hidden layers
            num_layers (int): Number of transformation layers
            pressure_activation (str): Activation function for pressure output ("tanh", "silu", or None)
            spline_degree (int): Degree of B-spline basis (usually 3 for cubic splines)
            num_basis (int): Number of basis functions per feature
        """
        super(EnhancedKAN, self).__init__()
        self.n_input = n_input
        self.n_output = n_output
        self.pressure_activation_type = pressure_activation
        self.num_basis = num_basis
        self.spline_degree = spline_degree
        self.hidden_width = hidden_width
        
        # KAN structure: first layer of univariate functions
        # These weights are used to weight the univariate function outputs
        self.first_layer_weights = nn.Parameter(torch.randn(n_input, hidden_width) * 0.1)
        self.first_layer_bias = nn.Parameter(torch.zeros(hidden_width))
        
        # Create basis functions for each input feature-hidden node combination
        # This follows the original KAN paper's architecture
        self.basis_functions = nn.ModuleList([
            BSplineBasis(num_basis=num_basis, spline_degree=spline_degree, learnable=True)
            for _ in range(n_input * hidden_width)
        ])
        
        # Layer for combining the univariate functions
        # This implements the outer sum in the KAN formulation
        self.combination_layer = nn.Linear(hidden_width * num_basis, hidden_width)
        
        # Optional deeper layers for more expressiveness
        self.extra_layers = nn.ModuleList()
        for _ in range(num_layers - 1):
            self.extra_layers.append(nn.Sequential(
                nn.Linear(hidden_width, hidden_width),
                nn.SiLU(),
                nn.Linear(hidden_width, hidden_width),
                nn.SiLU()
            ))
        
        # Output layer
        self.output_layer = nn.Linear(hidden_width, n_output)
        
        # Activation functions for physics constraints
        # Different outputs may need different activations to maintain physical meaning
        if pressure_activation == "tanh":
            self.pressure_activation = nn.Tanh()
        elif pressure_activation == "silu":
            self.pressure_activation = nn.SiLU()
        else:
            self.pressure_activation = nn.Identity()
            
        # Mass flow should always be positive
        self.massflow_activation = nn.Softplus()
    
    def forward(self, x):
        """
        Forward pass through the Enhanced KAN model.
        
        Args:
            x (Tensor): Input tensor of shape [batch_size, n_input]
            
        Returns:
            Tensor: Network output of shape [batch_size, n_output]
        """
        batch_size = x.shape[0]
        
        # Apply the first layer of univariate functions (KAN structure)
        transformed_features = []
        
        # For each input feature and hidden unit combination
        for i in range(self.n_input):
            for j in range(self.hidden_width):
                # Get the corresponding basis function
                basis_idx = i * self.hidden_width + j
                # Apply the basis function to the input feature
                basis_values = self.basis_functions[basis_idx](x[:, i:i+1])
                # Weight the basis values
                weighted_basis = basis_values * self.first_layer_weights[i, j]
                transformed_features.append(weighted_basis)
        
        # Combine the transformed features
        combined = torch.cat(transformed_features, dim=1)
        h = self.combination_layer(combined)
        h = F.silu(h + self.first_layer_bias)
        
        # Apply additional layers if requested
        for layer in self.extra_layers:
            h = layer(h) + h  # Residual connection for better gradient flow
        
        # Output layer
        outputs = self.output_layer(h)
        
        # Apply different activations to maintain physics constraints
        if self.n_output > 1:
            # Process pressure output (first element)
            pressure = self.pressure_activation(outputs[:, 0]).unsqueeze(1)
            
            # Process mass flow outputs (remaining elements) - always positive
            massflow = self.massflow_activation(outputs[:, 1:])
            
            # Combine outputs
            outputs = torch.cat([pressure, massflow], dim=1)
        else:
            # If only predicting pressure
            outputs = self.pressure_activation(outputs)
            
        return outputs
    
    def get_activation_types(self):
        """
        Return the activation types used for each output.
        
        Returns:
            dict: Dictionary of activation types for each output
        """
        return {
            "pressure": self.pressure_activation_type,
            "mass_flow": "softplus"  # Always use softplus for mass flow
        }


class SimpleEnhancedKAN(nn.Module):
    """
    A simplified but improved version of KAN for pipeline pressure prediction.
    
    This implementation uses a much simpler approach that avoids complex tensor reshaping
    by using standard neural network layers with learnable activation functions.
    """
    def __init__(self, n_input, n_output, hidden_width=32, num_layers=2, 
                 pressure_activation="tanh", spline_degree=3, num_basis=8):
        """
        Initialize the simplified enhanced KAN model.
        
        Args:
            n_input (int): Number of input features
            n_output (int): Number of output features
            hidden_width (int): Width of hidden layers
            num_layers (int): Number of transformation layers
            pressure_activation (str): Activation function for pressure output
            spline_degree (int): Degree of B-spline basis (not used in this simplified version)
            num_basis (int): Number of basis functions per feature (not used in this simplified version)
        """
        super(SimpleEnhancedKAN, self).__init__()
        self.n_input = n_input
        self.n_output = n_output
        self.pressure_activation_type = pressure_activation
        self.hidden_width = hidden_width
        self.num_basis = num_basis
        
        # Use a simple but effective architecture
        layers = []
        
        # Input layer
        layers.append(nn.Linear(n_input, hidden_width))
        layers.append(nn.SiLU())
        
        # Hidden layers with learnable activations (simplified KAN concept)
        for i in range(num_layers):
            layers.append(nn.Linear(hidden_width, hidden_width))
            layers.append(nn.SiLU())
            layers.append(nn.LayerNorm(hidden_width))  # For stability
            
        # Output layer
        layers.append(nn.Linear(hidden_width, n_output))
        
        self.network = nn.Sequential(*layers)
        
        # Activation functions for physics constraints
        if pressure_activation == "tanh":
            self.pressure_activation = nn.Tanh()
        elif pressure_activation == "silu":
            self.pressure_activation = nn.SiLU()
        else:
            self.pressure_activation = nn.Identity()
            
        self.massflow_activation = nn.Softplus()  # Always positive
    
    def forward(self, x):
        """
        Forward pass through the SimpleEnhancedKAN model.
        
        Args:
            x (Tensor): Input tensor of shape [batch_size, n_input]
            
        Returns:
            Tensor: Network output of shape [batch_size, n_output]
        """
        # Apply the network
        outputs = self.network(x)
        
        # Apply different activations to maintain physics constraints
        if self.n_output > 1:
            # Process pressure output (first element)
            pressure = self.pressure_activation(outputs[:, 0]).unsqueeze(1)
            
            # Process mass flow outputs (remaining elements)
            massflow = self.massflow_activation(outputs[:, 1:])
            
            # Combine outputs
            outputs = torch.cat([pressure, massflow], dim=1)
        else:
            # If only predicting pressure
            outputs = self.pressure_activation(outputs)
            
        return outputs
    
    def get_activation_types(self):
        """
        Return the activation types used for each output.
        
        Returns:
            dict: Dictionary of activation types for each output
        """
        return {
            "pressure": self.pressure_activation_type,
            "mass_flow": "softplus"  # Always use softplus for mass flow
        }



# Keep the original KAN class for backward compatibility
class KAN(nn.Module):
    """
    A simplified Kolmogorov-Arnold Network for pipeline pressure prediction.
    
    This implementation maintains the core concept of feature-wise transformations
    but replaces complex splines with more stable neural network operations.
    
    Note: This is the original implementation kept for backward compatibility.
    The EnhancedKAN or SimpleEnhancedKAN classes provide more accurate KAN 
    implementations with proper B-spline basis functions.
    """
    def __init__(self, n_input, n_output, hidden_width=32, num_layers=3, 
                 pressure_activation="tanh", spline_degree=None, num_basis=None):
        super(KAN, self).__init__()
        self.n_input = n_input
        self.n_output = n_output
        self.pressure_activation_type = pressure_activation
        
        # Initial projection layer
        self.input_layer = nn.Linear(n_input, hidden_width)
        
        # Feature-wise transformation layers (replaces spline compositions)
        self.feature_transforms = nn.ModuleList()
        for _ in range(num_layers):
            # Each layer has feature-wise transformations with residual connections
            self.feature_transforms.append(nn.Sequential(
                nn.Linear(hidden_width, hidden_width),
                nn.SiLU(),
                nn.Linear(hidden_width, hidden_width)
            ))
        
        # Output layer
        self.output_layer = nn.Linear(hidden_width, n_output)
        
        # Activation functions for physics constraints
        if pressure_activation == "tanh":
            self.pressure_activation = nn.Tanh()
        elif pressure_activation == "silu":
            self.pressure_activation = nn.SiLU()
        else:
            self.pressure_activation = nn.Identity()
            
        self.massflow_activation = nn.Softplus()  # Always positive
            
    def forward(self, x):
        """
        Forward pass through the KAN model.
        
        Args:
            x (Tensor): Input tensor of shape [batch_size, n_input]
            
        Returns:
            Tensor: Network output of shape [batch_size, n_output]
        """
        # Initial projection
        h = F.silu(self.input_layer(x))
        
        # Apply feature-wise transformations with residual connections
        for transform in self.feature_transforms:
            h = h + transform(h)
        
        # Output layer
        outputs = self.output_layer(h)
        
        # Apply different activations to maintain physics constraints
        if self.n_output > 1:
            # Process pressure output (first element)
            pressure = self.pressure_activation(outputs[:, 0]).unsqueeze(1)
            
            # Process mass flow outputs (remaining elements)
            massflow = self.massflow_activation(outputs[:, 1:])
            
            # Combine outputs
            outputs = torch.cat([pressure, massflow], dim=1)
        else:
            # If only predicting pressure
            outputs = self.pressure_activation(outputs)
            
        return outputs
    
    def get_activation_types(self):
        """
        Return the activation types used for each output.
        
        Returns:
            dict: Dictionary of activation types for each output
        """
        return {
            "pressure": self.pressure_activation_type,
            "mass_flow": "softplus"  # Always use softplus for mass flow
        }