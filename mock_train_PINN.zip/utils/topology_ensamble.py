
from .cluster_by_junctions import detect_junctions_from_nodes

def build_flows_from_sources_and_junctions(input_data, topology_data, sink_coord, sources_branch, 
                                           tol_primary=1e-6, round_decimals=8, max_iterations=50):

    """Assign FlowrateLiquidInsitu / Watercut by a fast, queue-based propagation:
        1. Map sources (clusters) to their BranchEquipment using source_map.csv and assign uniform flow+watercut.
        2. Precompute branch endpoints and coordinate -> (starting branches, ending branches) mapping (O(N)).
        3. Use a queue of coordinates (potential junction or linear continuation points). Each coordinate is processed once;
           if it has ≥1 flowed incoming (ending) branches and exactly one zero-flow outgoing (starting) branch, propagate
           summed flow + mixed watercut to that outgoing branch and enqueue its end coordinate.
           - Skips ambiguous splits (multiple zero-flow outgoing branches) without repeated full scans.
        4. Fallback linear pass: fill remaining zero-flow branches whose first node matches the last node of exactly one
           flowed branch (simple continuation, not a branching junction). Repeats until stable or iteration cap.
        5. Sink designation: any node whose (long, lat) matches a coordinate in sink_coord is labeled node_type = -1.


    Returns:
        network_topology (DataFrame)
        diagnostics (dict)
        cluster_flows (dict)
        cluster_wcs (dict)
        unexplained_unfilled (list[str])        # BranchEquipment IDs not explained by OFF/absent clusters
        unexplained_unfilled_dbg (list[tuple])  # (BranchEquipment, Troncal) for deeper debugging
    """

    # --- 0. Active wells & cluster aggregation ---
    active_wells = input_data[input_data['STATUS_OPT_OUTPUT'] == 1].copy() if 'STATUS_OPT_OUTPUT' in input_data.columns else input_data.copy()
    
    # Filter out wells with "FREE" status in TRONCAL column
    if 'TRONCAL' in active_wells.columns:
        free_mask = active_wells['TRONCAL'].astype(str).str.upper() == 'FREE'
        free_count = free_mask.sum()
        if free_count > 0:
            print(f"INFO: Filtering out {free_count} wells with TRONCAL='FREE'")
            active_wells = active_wells[~free_mask].copy()
    
    required_prod_cols = ['FLUID_PRED', 'WATER_PRED']
    for c in required_prod_cols:
        if c not in active_wells.columns:
            raise ValueError(f"Missing required production column {c}")

    # Identify OFF clusters (all wells STATUS_OPT_OUTPUT==0) and unmapped sources
    if 'CLUSTER' in input_data.columns and 'STATUS_OPT_OUTPUT' in input_data.columns:
        cluster_status = (input_data.groupby('CLUSTER')['STATUS_OPT_OUTPUT']
                                      .agg(['count','sum'])
                                      .rename(columns={'count':'well_count','sum':'active_well_count'}))
        clusters_off = cluster_status[cluster_status['active_well_count'] == 0].index.tolist()
    else:
        clusters_off = []

    # Sources in mapping not present in input data (possible stale entries)
    if 'CLUSTER' in input_data.columns:
        input_clusters = set(input_data['CLUSTER'].unique())
    else:
        input_clusters = set()
    mapping_sources = set(sources_branch['source'].unique()) if 'source' in sources_branch.columns else set()
    mapping_sources_not_in_input = sorted(list(mapping_sources - input_clusters))

    if clusters_off:
        print(f"INFO: OFF clusters (all wells off, excluded from active aggregation): {clusters_off} (count={len(clusters_off)})")
    else:
        print("INFO: No fully OFF clusters detected or insufficient columns to determine.")
    if mapping_sources_not_in_input:
        print(f"INFO: Source mapping entries absent in input_data.CLUSTER: {mapping_sources_not_in_input} (count={len(mapping_sources_not_in_input)})")
    else:
        print("INFO: All mapped sources found in input_data (or insufficient columns).")

    cluster_grp = active_wells.groupby('CLUSTER').agg({'FLUID_PRED':'sum','WATER_PRED':'sum'})
    cluster_grp['watercut_ratio'] = 0.0
    nz = cluster_grp['FLUID_PRED'] > 0
    cluster_grp.loc[nz,'watercut_ratio'] = cluster_grp.loc[nz,'WATER_PRED'] / cluster_grp.loc[nz,'FLUID_PRED']
    cluster_flows = cluster_grp['FLUID_PRED'].to_dict()
    cluster_wcs = cluster_grp['watercut_ratio'].to_dict()

    # --- Notice about clusters intentionally treated as FREE / not injected ---
    print("#" * 60)
    free_clusters = ["RUBI_CLUSTER 54", "RUBI_CLUSTER 19", "RUBI_CLUSTER 006"]
    print("INFO: The following clusters are currently NOT considered in flow propagation and are treated as FREE:", free_clusters)
    # (Only messaging per user request; no removal from cluster_flows performed here.)

    # --- 1. Prepare topology frame ---
    nt = topology_data.copy()
    if 'TotalDistance' not in nt.columns:
        raise ValueError("Topology missing 'TotalDistance'")
    nt['node_type'] = 0
    nt['FlowrateLiquidInsitu'] = 0.0
    nt['Watercut'] = 0.0
    nt['node_id'] = nt.index.astype(str)

    # --- 1a. Sink node designation (match every coordinate in sink_coord) ---
    if 'long' not in nt.columns or 'lat' not in nt.columns:
        raise ValueError("Topology must contain 'long' and 'lat' columns for sink mapping")
    if 'long' not in sink_coord.columns or 'lat' not in sink_coord.columns:
        raise ValueError("sink_coord must contain 'long' and 'lat' columns")

    # Build rounded coordinate sets for efficient matching
    def rcoord(lon, lat):
        return (round(float(lon), round_decimals), round(float(lat), round_decimals))

    sink_set = {rcoord(lon, lat) for lon, lat in zip(sink_coord['long'], sink_coord['lat'])}
    nt_coords = nt[['long','lat']].apply(lambda r: rcoord(r['long'], r['lat']), axis=1)
    sink_mask = nt_coords.isin(sink_set)
    sink_count = int(sink_mask.sum())
    if sink_count > 0:
        nt.loc[sink_mask, 'node_type'] = -1  # mark sinks now (sources later may override if same coord; prevent that below)

    # --- 2. Map clusters to BranchEquipment via sources_branch ---
    sb = sources_branch[['source','BranchEquipment']].drop_duplicates()
    cluster_to_branch = {}
    for _, row in sb.iterrows():
        cl = row['source']
        be = row['BranchEquipment']
        if cl in cluster_flows:
            cluster_to_branch.setdefault(be, {'flow':0.0,'water_vol':0.0})
            cluster_to_branch[be]['flow'] += cluster_flows[cl]
            cluster_to_branch[be]['water_vol'] += cluster_flows[cl] * cluster_wcs.get(cl,0.0)

    # --- 3. Assign flows to source branches (avoid overwriting sink node_type) ---
    for be, agg in cluster_to_branch.items():
        total_flow = agg['flow']
        wc = (agg['water_vol']/total_flow) if total_flow>0 else 0.0
        mask = (nt['BranchEquipment'] == be)
        if mask.any():
            branch_nodes = nt[mask].sort_values('TotalDistance')
            if not branch_nodes.empty:
                first_idx = branch_nodes.index[0]
                # Only set to source if not already marked as sink
                if nt.loc[first_idx, 'node_type'] != -1:
                    nt.loc[first_idx,'node_type'] = 1
            nt.loc[mask,'FlowrateLiquidInsitu'] = total_flow
            nt.loc[mask,'Watercut'] = wc

    # --- 4. Precompute endpoints & coordinate mapping ---
    branch_endpoints = {}
    from collections import defaultdict as _dd
    coord_starts = _dd(list)  # coord -> branches starting there
    coord_ends = _dd(list)    # coord -> branches ending there

    for be, bdf in nt.groupby('BranchEquipment'):
        bsorted = bdf.sort_values('TotalDistance')
        first = rcoord(bsorted.iloc[0]['long'], bsorted.iloc[0]['lat'])
        last = rcoord(bsorted.iloc[-1]['long'], bsorted.iloc[-1]['lat'])
        branch_endpoints[be] = {'first': first, 'last': last}
        coord_starts[first].append(be)
        coord_ends[last].append(be)

    # Detect junctions (for diagnostics) using existing utility (optional cost, but kept)
    junctions = detect_junctions_from_nodes(nt, node_id_col='node_id', x_col='long', y_col='lat', round_decimals=round_decimals)

    # Accessors
    def branch_flow(be):
        b = nt[nt['BranchEquipment']==be]
        return float(b['FlowrateLiquidInsitu'].iloc[0]) if not b.empty else 0.0
    def branch_wc(be):
        b = nt[nt['BranchEquipment']==be]
        return float(b['Watercut'].iloc[0]) if not b.empty else 0.0

    # --- 5. Queue-based propagation (skip propagation from sink-only coordinates) ---
    from collections import deque
    queue = deque()
    enqueued = set()

    for coord in set(list(coord_starts.keys()) + list(coord_ends.keys())):
        # If coord is a pure sink (all nodes already sink and no zero-flow starter) we ignore
        if any(branch_flow(b) > 0 for b in coord_ends.get(coord, [])) and any(branch_flow(b) == 0 for b in coord_starts.get(coord, [])):
            queue.append(coord)
            enqueued.add(coord)

    junction_propagations = 0
    skipped_multi_out = 0

    while queue and junction_propagations + skipped_multi_out < 100000:  # safety cap
        coord = queue.popleft()
        start_branches = coord_starts.get(coord, [])
        end_branches = coord_ends.get(coord, [])
        incoming = [b for b in end_branches if branch_flow(b) > 0]
        outgoing_zero = [b for b in start_branches if branch_flow(b) == 0]
        if not incoming or not outgoing_zero:
            continue
        if len(outgoing_zero) > 1:
            skipped_multi_out += 1
            continue
        target = outgoing_zero[0]
        total_in = sum(branch_flow(b) for b in incoming)
        if total_in <= 0:
            continue
        water_vol = sum(branch_flow(b) * branch_wc(b) for b in incoming)
        mixed_wc = water_vol / total_in if total_in > 0 else 0.0
        nt.loc[nt['BranchEquipment']==target,'FlowrateLiquidInsitu'] = total_in
        nt.loc[nt['BranchEquipment']==target,'Watercut'] = mixed_wc
        junction_propagations += 1
        down_coord = branch_endpoints[target]['last']
        if down_coord not in enqueued:
            if any(branch_flow(b) == 0 for b in coord_starts.get(down_coord, [])):
                queue.append(down_coord)
                enqueued.add(down_coord)

    # --- 6. Fallback linear continuation pass ---
    linear_events = 0
    lin_iter = 0
    while lin_iter < max_iterations:
        lin_iter += 1
        changes = 0
        zero_branches = [be for be in nt['BranchEquipment'].unique() if branch_flow(be) == 0.0]
        if not zero_branches:
            break
        for be in zero_branches:
            first_coord = branch_endpoints[be]['first']
            upstream = [ub for ub in coord_ends.get(first_coord, []) if branch_flow(ub) > 0]
            if len(upstream) == 1:
                up = upstream[0]
                nt.loc[nt['BranchEquipment']==be,'FlowrateLiquidInsitu'] = branch_flow(up)
                nt.loc[nt['BranchEquipment']==be,'Watercut'] = branch_wc(up)
                linear_events += 1
                changes += 1
        if changes == 0:
            break

    # --- 7. Diagnostics ---
    unfilled_branches = [be for be in nt['BranchEquipment'].unique() if branch_flow(be)==0.0]

    # Map OFF / absent clusters to their (potentially) unfilled branches
    off_or_absent_clusters = set(clusters_off) | set(mapping_sources_not_in_input)
    cluster_to_branches_map = {}
    # Pre-build branch->Troncal map (first occurrence) if Troncal column exists
    branch_troncal_map = nt.groupby('BranchEquipment')['Troncal'].first().to_dict() if 'Troncal' in nt.columns else {}
    if 'source' in sources_branch.columns:
        # Build mapping cluster -> list of mapped branches that remain unfilled
        for cl in sorted(off_or_absent_clusters):
            mapped_b = sources_branch.loc[sources_branch['source']==cl, 'BranchEquipment'].unique().tolist()
            unfilled_for_cl = [b for b in mapped_b if b in unfilled_branches]
            if unfilled_for_cl:
                # Store list of (BranchEquipment, Troncal)
                cluster_to_branches_map[cl] = [(b, branch_troncal_map.get(b)) for b in unfilled_for_cl]
    if cluster_to_branches_map:
        print("#" * 60)
        print("INFO: OFF/Absent CLUSTER -> Unfilled BranchEquipment mapping:")
        for cl, blist in cluster_to_branches_map.items():
            print(f"  {cl} -> {blist}")  # each entry is (BranchEquipment, Troncal)
    else:
        print("INFO: No unfilled branches associated with OFF/absent clusters (or no mapping found).")
    # Unfilled branches explained by off/absent clusters (flatten mapped lists)
    explained_unfilled = set()
    for lst in cluster_to_branches_map.values():
        for b, _t in lst:
            explained_unfilled.add(b)
    unexplained_unfilled = [b for b in unfilled_branches if b not in explained_unfilled]
    unexplained_unfilled_dbg = [(b, nt.loc[nt['BranchEquipment']==b,'Troncal'].iloc[0] if 'Troncal' in nt.columns and not nt.loc[nt['BranchEquipment']==b].empty else None) for b in unexplained_unfilled]

    if unexplained_unfilled:  
        print("#" * 60)
        print("INFO: Unfilled branches NOT explained by OFF/absent clusters:")
        print("  ", unexplained_unfilled[:15], '...' if len(unexplained_unfilled)>15 else '')
    else:
        print("INFO: All unfilled branches are explained by OFF/absent clusters (or none unfilled).")

    diagnostics = {
        'junction_count': len(junctions),
        'junction_propagations': junction_propagations,
        'skipped_multi_out': skipped_multi_out,
        'linear_iterations': lin_iter,
        'linear_connection_events': linear_events,
        'unfilled_branch_count': len(unfilled_branches),
        'unfilled_branches_sample': unfilled_branches[:-1],
        'sink_nodes_marked': sink_count,
        'off_or_absent_cluster_unfilled_map': cluster_to_branches_map
    }
    print("#" * 60)
    print(
        f"Topology ensamble done., "
        f"skipped multi-out={skipped_multi_out}, remaining unfilled={diagnostics['unfilled_branch_count']}, sinks marked={sink_count}"
    )
    if diagnostics['unfilled_branch_count']>0:
        print("#" * 60)
        print(f"Sample unfilled: {diagnostics['unfilled_branches_sample']}")

    return nt, diagnostics, cluster_flows, cluster_wcs, unexplained_unfilled_dbg
