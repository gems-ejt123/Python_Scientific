from collections import defaultdict
import networkx as nx
import numpy as np
from sklearn.cluster import  KMeans
import matplotlib.pyplot as plt



def detect_junctions_from_nodes(nodes_df, node_id_col="node_id", x_col="long", y_col="lat",
                                branch_col="BranchEquipment", round_decimals=8):
    """
    Detect junction points where multiple flowlines meet.
    
    Parameters:
        nodes_df (pd.DataFrame): DataFrame with node data
        node_id_col (str): Column name for node identifiers
        x_col, y_col (str): Column names for spatial coordinates
        round_decimals (int): Precision for coordinate rounding to identify coincident points
        
    Returns:
        list: List of junction dictionaries, each with coords, node_ids, count, and id
    """
    df = nodes_df.copy()
   
    # Round coordinates to identify coincident points
    df["x_round"] = df[x_col].round(round_decimals)
    df["y_round"] = df[y_col].round(round_decimals)
   
    # Group by rounded coordinates to find junctions
    grouped = df.groupby(["x_round", "y_round"])
    junctions = []
   
    for i, ((x_r, y_r), group) in enumerate(grouped):
        if len(group) > 1:  # A junction has multiple nodes at the same location
            junctions.append({
                "id": f"J{i}",              # Add a unique ID for each junction
                "coords": (x_r, y_r),
                "node_ids": group[node_id_col].tolist(),
                "flowline": group[branch_col].unique().tolist(),
                "count": len(group)
            })
           
    return junctions

def classify_flowline_direction(flowline_id, junction_coords, df, x_col="long", y_col="lat",
                             distance_col='TotalDistance', tol=1e-6):
    """
    Determine if a flowline is incoming to or outgoing from a junction.
    
    Parameters:
        flowline_id (str): ID of the flowline to classify
        junction_coords (tuple): Coordinates of the junction (x, y)
        df (pd.DataFrame): DataFrame with pipeline data
        x_col, y_col (str): Column names for spatial coordinates
        distance_col (str): Column name for distance measurement
        tol (float): Tolerance for coordinate matching
        
    Returns:
        str: "incoming", "outgoing", or "unknown"
    """
    # Get nodes for the specified flowline
    flowline_df = df[df["BranchEquipment"] == flowline_id].copy()
    if flowline_df.empty:
        return "unknown"
   
    # Sort by distance to get first and last node
    flowline_df.sort_values(by=distance_col, inplace=True)
    flowline_df.reset_index(drop=True, inplace=True)
   
    # Get coordinates of first and last node
    first_node = flowline_df.iloc[0]
    last_node = flowline_df.iloc[-1]
    first_coords = np.array([first_node[x_col], first_node[y_col]])
    last_coords = np.array([last_node[x_col], last_node[y_col]])
   
    # Calculate distances to junction
    junction_coords = np.array(junction_coords)
    dist_first = np.linalg.norm(first_coords - junction_coords)
    dist_last = np.linalg.norm(last_coords - junction_coords)
   
    # Classify direction
    if dist_first < tol:
        return "outgoing"  # Flowline starts at junction, so it's outgoing
    elif dist_last < tol:
        return "incoming"  # Flowline ends at junction, so it's incoming
    else:
        return "unknown"   # Flowline doesn't touch the junction
