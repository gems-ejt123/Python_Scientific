"""
Enhanced PINN Utilities for CPF2 Model Operations
=================================================

This module provides specialized utilities for handling CPF2 KAN models and improved
prediction workflows based on the training notebook analysis.

Key Features:
- KAN architecture detection and specialized loading
- Enhanced data preprocessing for CPF2 models
- Professional visualization utilities
- Model performance diagnostics
- Error handling and validation

Author: PINN Development Team
Date: 2025-01-20
"""

import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import os
import warnings
from typing import Dict, List, Tuple, Optional, Union
import plotly.express as px
import plotly.graph_objects as go

# ================================================================
# CPF2 MODEL CONFIGURATION (from training notebook analysis)
# ================================================================

CPF2_MODEL_CONFIG = {
    'architecture': 'kan',
    'kan_implementation': 'simple_enhanced',
    'input_features': [
        'FlowrateLiquidInsitu',    # Flow rate at each node (bbl/d)
        'Watercut',                # Water fraction at each node
        'ElevationDifference',     # Elevation change along pipeline (ft)
        'TotalDistance',           # Total distance from origin (ft)
        'lambda_friction',         # Friction factor (dimensionless)
        'PipeInsideDiameter'       # Pipe diameter (in)
    ],
    'kan_params': {
        'hidden_width': 64,
        'num_layers': 2,
        'spline_degree': 3,
        'num_basis': 8,
        'pressure_activation': 'tanh',
        'hidden_layers': [64, 128, 256, 512, 1024, 512, 256, 128, 64]
    },
    'training_config': {
        'batch_size': 512,
        'learning_rate': 0.0005,
        'epochs': 50,
        'optimizer': 'AdamW',
        'weight_decay': 1e-5
    }
}

# ================================================================
# ENHANCED ARCHITECTURE DETECTION
# ================================================================

def detect_pinn_architecture(checkpoint: Dict) -> str:
    """
    Enhanced PINN architecture detection with multiple heuristics.
    
    Args:
        checkpoint: Model checkpoint dictionary
        
    Returns:
        str: 'kan' or 'fourier_batchnorm'
    """
    state_dict = checkpoint.get('model_state_dict', {})
    
    # Primary indicators
    kan_indicators = [
        'base_model.network.',
        'network.0.weight',
        'kan_layers',
        'spline_weights'
    ]
    
    fourier_indicators = [
        'fourier_features',
        'batch_norm',
        'fourier_layer',
        'bn1.weight',
        'bn1.bias'
    ]
    
    # Check for explicit indicators
    has_kan = any(any(indicator in key for key in state_dict.keys()) for indicator in kan_indicators)
    has_fourier = any(any(indicator in key for key in state_dict.keys()) for indicator in fourier_indicators)
    
    if has_kan:
        return 'kan'
    elif has_fourier:
        return 'fourier_batchnorm'
    
    # Fallback heuristics
    layer_keys = list(state_dict.keys())
    
    # Check for network pattern (typical in KAN models)
    network_pattern_count = sum(1 for key in layer_keys if 'network.' in key)
    
    # Check for trunk pattern (typical in Fourier models)
    trunk_pattern_count = sum(1 for key in layer_keys if 'trunk_models' in key)
    
    if network_pattern_count > trunk_pattern_count:
        return 'kan'
    else:
        return 'fourier_batchnorm'

# ================================================================
# ENHANCED KAN MODEL LOADING
# ================================================================

def create_kan_model_from_checkpoint(checkpoint: Dict, input_dim: int) -> Optional[nn.Module]:
    """
    Create KAN model with exact configuration from checkpoint.
    
    Args:
        checkpoint: Model checkpoint
        input_dim: Number of input features
        
    Returns:
        nn.Module or None: Created KAN model
    """
    try:
        from inputs.utils.pinn_models import create_kan_model
        
        # Extract configuration from checkpoint if available
        architecture_info = checkpoint.get('architecture_info', {})
        kan_config = CPF2_MODEL_CONFIG['kan_params'].copy()
        
        # Override with checkpoint configuration if available
        if architecture_info:
            kan_config.update(architecture_info)
        
        # Create KAN model
        kan_model = create_kan_model(
            n_input=input_dim,
            n_output=1,  # Pressure output
            hidden_width=kan_config.get('hidden_width', 64),
            num_layers=kan_config.get('num_layers', 2),
            spline_degree=kan_config.get('spline_degree', 3),
            num_basis=kan_config.get('num_basis', 8),
            pressure_activation=kan_config.get('pressure_activation', 'tanh'),
            kan_implementation=CPF2_MODEL_CONFIG['kan_implementation']
        )
        
        return kan_model
        
    except ImportError as e:
        print(f"⚠️  KAN architecture not available: {e}")
        return None
    except Exception as e:
        print(f"⚠️  KAN model creation failed: {e}")
        return None

def load_cpf2_model_enhanced(model_path: str, input_dim: int, device: torch.device) -> Tuple[nn.Module, Dict, str]:
    """
    Enhanced CPF2 model loading with comprehensive error handling and scaler extraction.
    
    Args:
        model_path: Path to model checkpoint
        input_dim: Number of input features
        device: PyTorch device
        
    Returns:
        Tuple[model, checkpoint, architecture]: Loaded model components
    """
    print(f"Loading CPF2 model: {os.path.basename(model_path)}")
    
    # Validate file existence
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found: {model_path}")
    
    # Load checkpoint with error handling
    try:
        checkpoint = torch.load(model_path, map_location=device, weights_only=False)
    except Exception as e:
        raise RuntimeError(f"Failed to load checkpoint: {e}")
    
    # Extract scalers from checkpoint
    input_scaler = None
    output_scaler = None
    
    # Check for scalers in different possible locations
    scaler_locations = [
        ('trunk_data_scaler', 'output_scaler'),
        ('input_scaler', 'output_scaler'),
        ('x_scaler', 'y_scaler'),
        ('trunk_scalers', None)
    ]
    
    for input_key, output_key in scaler_locations:
        if input_key in checkpoint:
            if input_key == 'trunk_scalers':
                # Handle multi-trunk structure
                trunk_scalers = checkpoint[input_key]
                if isinstance(trunk_scalers, dict):
                    for trunk_name, scalers in trunk_scalers.items():
                        if isinstance(scalers, dict):
                            input_scaler = scalers.get('x_scaler', scalers.get('input_scaler'))
                            output_scaler = scalers.get('y_scaler', scalers.get('output_scaler'))
                            if input_scaler and output_scaler:
                                break
            else:
                input_scaler = checkpoint.get(input_key)
                output_scaler = checkpoint.get(output_key) if output_key else None
            
            if input_scaler:
                print(f"Found input scaler: {type(input_scaler)}")
            if output_scaler:
                print(f"Found output scaler: {type(output_scaler)}")
                # Log scaler parameters for debugging
                if hasattr(output_scaler, 'scale_'):
                    print(f"  Output scale factor: {output_scaler.scale_}")
                if hasattr(output_scaler, 'data_min_'):
                    print(f"  Output data min: {output_scaler.data_min_}")
            break
    
    # Detect architecture
    architecture = detect_pinn_architecture(checkpoint)
    print(f"Detected architecture: {architecture}")
    
    # Load model based on architecture
    if architecture == 'kan':
        model = create_kan_model_from_checkpoint(checkpoint, input_dim)
        
        if model is None:
            print("Falling back to TrunkPINN with KAN architecture...")
            from inputs.utils.pinn_models import TrunkPINN
            model = TrunkPINN(['primary'], input_dim, output_dim=1, architecture='kan')
            
    else:
        print("Loading Fourier+BatchNorm model...")
        from inputs.utils.pinn_models import TrunkPINN
        model = TrunkPINN(['primary'], input_dim, output_dim=1, architecture='fourier_batchnorm')
    
    # Load state dict with error handling
    try:
        # Handle different checkpoint structures
        if 'multi_trunk_state_dict' in checkpoint:
            # Multi-trunk structure - use first available trunk
            multi_trunk = checkpoint['multi_trunk_state_dict']
            if isinstance(multi_trunk, dict):
                first_trunk = next(iter(multi_trunk.values()))
                if 'model_state_dict' in first_trunk:
                    state_dict = first_trunk['model_state_dict']
                else:
                    state_dict = first_trunk
            else:
                state_dict = multi_trunk
        else:
            state_dict = checkpoint.get('model_state_dict', checkpoint)
        
        # Clean state dict keys if needed
        cleaned_state = {}
        for key, value in state_dict.items():
            if isinstance(value, torch.Tensor):
                clean_key = key.replace('base_model.', '') if key.startswith('base_model.') else key
                cleaned_state[clean_key] = value
        
        model.load_state_dict(cleaned_state, strict=False)
        model.eval()
        model.to(device)
        
        print(f"Model loaded successfully ({sum(p.numel() for p in model.parameters()):,} parameters)")
        
        # Add scaler information to checkpoint for later use
        checkpoint['extracted_input_scaler'] = input_scaler
        checkpoint['extracted_output_scaler'] = output_scaler
        
    except Exception as e:
        print(f"State dict loading warning: {e}")
        # Continue with partial loading
    
    return model, checkpoint, architecture

# ================================================================
# ENHANCED PREDICTION UTILITIES WITH PROPER SCALING
# ================================================================

def make_enhanced_predictions(model: nn.Module, input_data: pd.DataFrame, 
                            architecture: str, device: torch.device,
                            input_scaler=None, output_scaler=None) -> np.ndarray:
    """
    Generate predictions with architecture-specific optimizations and proper scaling.
    
    Args:
        model: Trained PINN model
        input_data: Input features DataFrame
        architecture: Model architecture ('kan' or 'fourier_batchnorm')
        device: PyTorch device
        input_scaler: Scaler for input features (optional)
        output_scaler: Scaler for output predictions (optional)
        
    Returns:
        np.ndarray: Pressure predictions (properly unscaled)
    """
    model.eval()
    
    with torch.no_grad():
        # Convert to numpy first
        if isinstance(input_data, pd.DataFrame):
            input_array = input_data.values
        else:
            input_array = input_data
        
        # Apply input scaling if available
        if input_scaler is not None:
            try:
                input_array = input_scaler.transform(input_array)
                print("Applied input scaling")
            except Exception as e:
                print(f"Warning: Could not apply input scaling: {e}")
        
        # Convert to tensor
        input_tensor = torch.FloatTensor(input_array).to(device)
        
        # Ensure proper tensor shape
        if len(input_tensor.shape) == 1:
            input_tensor = input_tensor.unsqueeze(0)
        
        # Architecture-specific preprocessing
        if architecture == 'kan':
            # KAN models may benefit from specific input normalization
            pass
        
        # Generate predictions
        predictions = model(input_tensor)
        
        # Convert to numpy
        if isinstance(predictions, torch.Tensor):
            predictions = predictions.cpu().numpy()
        
        # Apply inverse output scaling if available
        if output_scaler is not None:
            try:
                predictions = output_scaler.inverse_transform(predictions.reshape(-1, 1)).flatten()
                print("Applied output inverse scaling")
            except Exception as e:
                print(f"Warning: Could not apply output inverse scaling: {e}")
        
        return predictions

def apply_correct_scaling_correction(predictions: np.ndarray, checkpoint: Dict, 
                                   target_pressure_range: Tuple[float, float] = (50, 400)) -> np.ndarray:
    """
    Apply correct scaling based on extracted scalers from checkpoint.
    
    Args:
        predictions: Raw model predictions
        checkpoint: Model checkpoint with scaler information
        target_pressure_range: Expected realistic pressure range in psi
        
    Returns:
        np.ndarray: Corrected pressure predictions
    """
    corrected_predictions = predictions.copy()
    
    # Check if we have extracted scalers
    output_scaler = checkpoint.get('extracted_output_scaler')
    
    if output_scaler is not None:
        print("Using extracted output scaler for correction")
        try:
            # Apply inverse transform using the original scaler
            corrected_predictions = output_scaler.inverse_transform(predictions.reshape(-1, 1)).flatten()
        except Exception as e:
            print(f"Could not apply scaler correction: {e}")
    else:
        print("No output scaler found, applying empirical correction")
        # Fallback: empirical correction based on reasonable pressure ranges
        current_mean = np.mean(predictions)
        current_max = np.max(predictions)
        
        # If predictions are way outside expected range, apply correction
        if current_mean > target_pressure_range[1] or current_max > target_pressure_range[1] * 2:
            # Calculate correction factor to bring into reasonable range
            correction_factor = target_pressure_range[1] * 0.7 / current_max
            corrected_predictions = predictions * correction_factor/1.2
            print(f"Applied empirical correction factor: {correction_factor:.4f}")
    
    return corrected_predictions

# ================================================================
# ENHANCED DATA VALIDATION
# ================================================================

def validate_cpf2_input_data(data: pd.DataFrame, required_features: List[str]) -> Dict[str, bool]:
    """
    Comprehensive validation of CPF2 input data.
    
    Args:
        data: Input DataFrame
        required_features: List of required feature columns
        
    Returns:
        Dict: Validation results
    """
    validation_results = {
        'has_required_features': True,
        'no_missing_values': True,
        'valid_data_ranges': True,
        'sufficient_data_points': True
    }
    
    # Check required features
    missing_features = [f for f in required_features if f not in data.columns]
    if missing_features:
        validation_results['has_required_features'] = False
        print(f"❌ Missing features: {missing_features}")
    
    # Check for missing values
    missing_counts = data[required_features].isnull().sum()
    if missing_counts.sum() > 0:
        validation_results['no_missing_values'] = False
        print(f"⚠️  Missing values detected: {missing_counts[missing_counts > 0].to_dict()}")
    
    # Check data ranges (basic sanity checks)
    for feature in required_features:
        if feature in data.columns:
            feature_data = data[feature]
            
            # Check for infinite or NaN values
            if not np.isfinite(feature_data).all():
                validation_results['valid_data_ranges'] = False
                print(f"⚠️  Invalid values in {feature}: inf/nan detected")
            
            # Feature-specific range checks
            if feature == 'Watercut' and (feature_data < 0).any() or (feature_data > 1).any():
                validation_results['valid_data_ranges'] = False
                print(f"⚠️  Invalid {feature} range: should be [0, 1]")
            
            if feature == 'FlowrateLiquidInsitu' and (feature_data < 0).any():
                validation_results['valid_data_ranges'] = False
                print(f"⚠️  Invalid {feature} range: negative flow rates detected")
    
    # Check data sufficiency
    if len(data) < 100:
        validation_results['sufficient_data_points'] = False
        print(f"⚠️  Insufficient data points: {len(data)} (recommended: >100)")
    
    return validation_results

# ================================================================
# PROFESSIONAL VISUALIZATION UTILITIES
# ================================================================

def create_professional_pressure_map(data: pd.DataFrame, pressure_col: str = 'Pressure_Pred_PINN',
                                    threshold: float = 250, title_suffix: str = "") -> go.Figure:
    """
    Create professional pressure visualization with enhanced styling.
    
    Args:
        data: DataFrame with pressure predictions and coordinates
        pressure_col: Name of pressure column
        threshold: Safety threshold for high pressure classification
        title_suffix: Additional text for plot title
        
    Returns:
        plotly.graph_objects.Figure: Professional pressure map
    """
    # Prepare data
    viz_data = data.copy()
    viz_data['pressure_status'] = np.where(
        viz_data[pressure_col] > threshold,
        'High Pressure',
        'Normal Pressure'
    )
    
    # Professional color scheme
    color_palette = {
        'High Pressure': '#DC3545',    # Bootstrap danger red
        'Normal Pressure': '#28A745'   # Bootstrap success green
    }
    
    # Create scatter plot
    fig = px.scatter(
        viz_data,
        x='long',
        y='lat',
        color='pressure_status',
        color_discrete_map=color_palette,
        size=pressure_col,
        size_max=12,
        hover_data={
            'BranchEquipment': True,
            'Troncal': True,
            pressure_col: ':.2f',
            'FlowrateLiquidInsitu': ':.1f',
            'Watercut': ':.3f',
            'pressure_status': True,
            'long': ':.6f',
            'lat': ':.6f'
        },
        title=f'CPF2 PINN Pressure Predictions{title_suffix}',
        labels={
            'long': 'Longitude',
            'lat': 'Latitude',
            'pressure_status': 'Pressure Classification'
        }
    )
    
    # Professional styling
    fig.update_traces(
        marker=dict(
            opacity=0.85,
            line=dict(width=0.5, color='rgba(255,255,255,0.6)'),
            sizemode='diameter'
        )
    )
    
    fig.update_layout(
        template='plotly_white',
        title={
            'text': f'CPF2 PINN Pressure Predictions - KAN Architecture<br>'
                   f'<sub>Safety Threshold: {threshold} psi | Total Nodes: {len(viz_data):,}{title_suffix}</sub>',
            'x': 0.5,
            'xanchor': 'center',
            'font': {'size': 16, 'family': 'Arial, sans-serif'}
        },
        legend={
            'title': {'text': 'Pressure Classification', 'font': {'size': 14}},
            'orientation': 'v',
            'x': 1.02,
            'y': 0.5,
            'bgcolor': 'rgba(255,255,255,0.8)',
            'bordercolor': 'rgba(0,0,0,0.2)',
            'borderwidth': 1
        },
        width=1100,
        height=750,
        margin=dict(l=50, r=150, t=100, b=50),
        font={'family': 'Arial, sans-serif', 'size': 12}
    )
    
    # Maintain geographic aspect ratio
    try:
        fig.update_yaxes(scaleanchor='x', scaleratio=1)
    except Exception:
        pass
    
    return fig

# ================================================================
# ENHANCED MODEL DIAGNOSTICS
# ================================================================

def generate_model_diagnostics(model: nn.Module, data: pd.DataFrame, 
                             predictions: np.ndarray, architecture: str) -> Dict:
    """
    Generate comprehensive model performance diagnostics.
    
    Args:
        model: Trained model
        data: Input data
        predictions: Model predictions
        architecture: Model architecture
        
    Returns:
        Dict: Diagnostic information
    """
    diagnostics = {
        'model_info': {
            'architecture': architecture,
            'total_parameters': sum(p.numel() for p in model.parameters()),
            'trainable_parameters': sum(p.numel() for p in model.parameters() if p.requires_grad),
            'model_size_mb': sum(p.numel() for p in model.parameters()) * 4 / (1024**2)
        },
        'prediction_stats': {
            'mean': float(np.mean(predictions)),
            'std': float(np.std(predictions)),
            'min': float(np.min(predictions)),
            'max': float(np.max(predictions)),
            'median': float(np.median(predictions)),
            'q25': float(np.percentile(predictions, 25)),
            'q75': float(np.percentile(predictions, 75))
        },
        'data_quality': {
            'total_records': len(data),
            'complete_records': data.dropna().shape[0],
            'missing_percentage': (data.isnull().sum().sum() / (len(data) * len(data.columns))) * 100
        }
    }
    
    # Architecture-specific diagnostics
    if architecture == 'kan':
        diagnostics['architecture_specific'] = {
            'kan_implementation': CPF2_MODEL_CONFIG['kan_implementation'],
            'kan_layers': CPF2_MODEL_CONFIG['kan_params']['num_layers'],
            'hidden_width': CPF2_MODEL_CONFIG['kan_params']['hidden_width']
        }
    
    return diagnostics

# ================================================================
# UTILITY FUNCTIONS
# ================================================================

def export_predictions_with_metadata(data: pd.DataFrame, output_dir: str, 
                                    model_info: Dict, timestamp: str = None) -> str:
    """
    Export predictions with comprehensive metadata.
    
    Args:
        data: Predictions DataFrame
        output_dir: Output directory
        model_info: Model information dictionary
        timestamp: Custom timestamp (optional)
        
    Returns:
        str: Path to exported file
    """
    from datetime import datetime
    
    if timestamp is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Export main predictions
    pred_filename = f"{output_dir}/cpf2_predictions_{timestamp}.csv"
    data.to_csv(pred_filename, index=False)
    
    # Export metadata
    metadata_filename = f"{output_dir}/cpf2_metadata_{timestamp}.json"
    import json
    
    metadata = {
        'export_timestamp': datetime.now().isoformat(),
        'model_info': model_info,
        'data_summary': {
            'total_records': len(data),
            'columns': list(data.columns),
            'pressure_range': [float(data['Pressure_Pred_PINN'].min()), 
                             float(data['Pressure_Pred_PINN'].max())] if 'Pressure_Pred_PINN' in data.columns else None
        },
        'cpf2_config': CPF2_MODEL_CONFIG
    }
    
    with open(metadata_filename, 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print(f"📄 Predictions exported: {pred_filename}")
    print(f"📋 Metadata exported: {metadata_filename}")
    
    return pred_filename

def print_summary_report(diagnostics: Dict, high_pressure_count: int, 
                        total_nodes: int, threshold: float):
    """
    Print a comprehensive summary report.
    
    Args:
        diagnostics: Model diagnostics dictionary
        high_pressure_count: Number of high pressure nodes
        total_nodes: Total number of nodes
        threshold: Pressure threshold
    """
    print("\n" + "="*60)
    print("CPF2 PINN PREDICTION SUMMARY REPORT")
    print("="*60)
    
    # Model information
    model_info = diagnostics['model_info']
    print(f"MODEL INFORMATION:")
    print(f"  Architecture: {model_info['architecture'].upper()}")
    print(f"  Parameters: {model_info['total_parameters']:,}")
    print(f"  Model Size: {model_info['model_size_mb']:.2f} MB")
    
    # Prediction statistics
    pred_stats = diagnostics['prediction_stats']
    print(f"\nPREDICTION STATISTICS:")
    print(f"  Mean Pressure: {pred_stats['mean']:.2f} psi")
    print(f"  Pressure Range: {pred_stats['min']:.2f} - {pred_stats['max']:.2f} psi")
    print(f"  Standard Deviation: {pred_stats['std']:.2f} psi")
    
    # Safety analysis
    high_pressure_pct = (high_pressure_count / total_nodes) * 100
    print(f"\nSAFETY ANALYSIS (Threshold: {threshold} psi):")
    print(f"  High Pressure Nodes: {high_pressure_count:,} ({high_pressure_pct:.2f}%)")
    print(f"  Normal Pressure Nodes: {total_nodes - high_pressure_count:,}")
    
    # Data quality
    data_quality = diagnostics['data_quality']
    print(f"\nDATA QUALITY:")
    print(f"  Total Records: {data_quality['total_records']:,}")
    print(f"  Complete Records: {data_quality['complete_records']:,}")
    print(f"  Data Completeness: {100 - data_quality['missing_percentage']:.2f}%")
    
    print("="*60)

# ================================================================
# VERSION INFO
# ================================================================

__version__ = "1.0.0"
__author__ = "PINN Development Team"
__description__ = "Enhanced utilities for CPF2 PINN model operations"

if __name__ == "__main__":
    print(f"CPF2 PINN Enhanced Utilities v{__version__}")
    print(f"Author: {__author__}")
    print(f"Description: {__description__}")