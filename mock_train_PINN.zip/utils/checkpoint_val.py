
import torch
import numpy as np
def inspect_multi_trunk_state_dict(checkpoint):
    if 'multi_trunk_state_dict' in checkpoint:
        mtsd = checkpoint['multi_trunk_state_dict']
        try:
            print(f"multi_trunk_state_dict key count: {len(mtsd)}")
        except Exception:
            print("multi_trunk_state_dict present but not a standard mapping type")
        # Peek at first few entries
        preview_keys = list(mtsd.keys())[:10] if hasattr(mtsd, 'keys') else []
        if preview_keys:
            print(f"First keys: {preview_keys}")
            first_key = preview_keys[0]
            first_val = mtsd[first_key]
            if isinstance(first_val, dict):
                print("Detected nested trunk structure (values are dicts). Showing first trunk param sample:")
                sample_keys = list(first_val.keys())[:8]
                for k in sample_keys:
                    v = first_val[k]
                    shape = tuple(v.shape) if hasattr(v, 'shape') else 'NA'
                    print(f"  {k} -> {shape}")
            elif isinstance(first_val, (torch.Tensor, np.ndarray)):
                print("Detected flat parameter mapping (values are tensors). Showing first 8 (key, shape):")
                for k in preview_keys[:8]:
                    v = mtsd[k]
                    shape = tuple(v.shape) if hasattr(v, 'shape') else 'NA'
                    print(f"  {k} -> {shape}")
                # Heuristic: count how many look like layer weights
                weight_like = [k for k in mtsd.keys() if k.endswith('.weight')]
                print(f"Total tensor entries: {len(list(mtsd.keys()))}; weight-like entries: {len(weight_like)}")
            else:
                print(f"Unknown entry type: {type(first_val)}. Cannot descend.")
        else:
            print("multi_trunk_state_dict has no .keys() method or is empty")
    else:
        print("multi_trunk_state_dict not present; using flat state dict")