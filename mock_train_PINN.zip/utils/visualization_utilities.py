"""
General Visualization Utilities for PINN Pipeline Pressure Analysis

This module contains visualization functions that work for both CPF1 and CPF2 configurations.
All visualization functions are architecture-agnostic and receive the CPF name as a parameter.
"""

import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from typing import Dict, List, Optional, Union

def create_pressure_map(predictions: pd.DataFrame, cpf_name: str, pressure_col: str = 'Pressure_Pred_PINN', 
                       threshold: float = 250) -> go.Figure:
    """
    Create professional pressure visualization for any CPF configuration.
    
    Args:
        predictions: DataFrame with pressure predictions and coordinates
        cpf_name: Name of the CPF (e.g., 'CPF1', 'CPF2')
        pressure_col: Name of pressure column
        threshold: Safety threshold for high pressure classification
        
    Returns:
        plotly.graph_objects.Figure: Professional pressure map
    """
    # Prepare data
    viz_data = predictions.copy()
    viz_data['pressure_status'] = np.where(
        viz_data[pressure_col] > threshold,
        'High Pressure',
        'Normal Pressure'
    )
    
    # Professional color scheme
    color_palette = {
        'High Pressure': '#DC3545',    # Bootstrap danger red
        'Normal Pressure': '#28A745'   # Bootstrap success green
    }
    
    # Create scatter plot
    fig = px.scatter(
        viz_data,
        x='long',
        y='lat',
        color='pressure_status',
        color_discrete_map=color_palette,
        size=pressure_col,
        size_max=12,
        hover_data={
            'BranchEquipment': True,
            'Troncal': True,
            pressure_col: ':.2f',
            'FlowrateLiquidInsitu': ':.1f',
            'Watercut': ':.3f',
            'pressure_status': True,
            'long': ':.6f',
            'lat': ':.6f'
        },
        title=f'{cpf_name} PINN Pressure Predictions',
        labels={
            'long': 'Longitude',
            'lat': 'Latitude',
            'pressure_status': 'Pressure Classification'
        }
    )
    
    # Professional styling
    fig.update_traces(
        marker=dict(
            opacity=0.85,
            line=dict(width=0.5, color='rgba(255,255,255,0.6)'),
            sizemode='diameter'
        )
    )
    
    fig.update_layout(
        template='plotly_white',
        title={
            'text': f'{cpf_name} PINN Pressure Predictions<br>'
                   f'<sub>Safety Threshold: {threshold} psi | Total Nodes: {len(viz_data):,}</sub>',
            'x': 0.5,
            'xanchor': 'center',
            'font': {'size': 16, 'family': 'Arial, sans-serif'}
        },
        legend={
            'title': {'text': 'Pressure Classification', 'font': {'size': 14}},
            'orientation': 'v',
            'x': 1.02,
            'y': 0.5,
            'bgcolor': 'rgba(255,255,255,0.8)',
            'bordercolor': 'rgba(0,0,0,0.2)',
            'borderwidth': 1
        },
        width=1100,
        height=750,
        margin=dict(l=50, r=150, t=100, b=50),
        font={'family': 'Arial, sans-serif', 'size': 12}
    )
    
    # Maintain geographic aspect ratio
    try:
        fig.update_yaxes(scaleanchor='x', scaleratio=1)
    except Exception:
        pass
    
    return fig


def create_pressure_comparison_plot(cpf1_predictions: pd.DataFrame, cpf2_predictions: pd.DataFrame,
                                   pressure_col: str = 'Pressure_Pred_PINN') -> go.Figure:
    """
    Create a comparison plot between CPF1 and CPF2 pressure predictions.
    
    Args:
        cpf1_predictions: DataFrame with CPF1 pressure predictions
        cpf2_predictions: DataFrame with CPF2 pressure predictions  
        pressure_col: Name of pressure column
        
    Returns:
        plotly.graph_objects.Figure: Comparison plot
    """
    fig = go.Figure()
    
    # Add CPF1 histogram
    fig.add_trace(go.Histogram(
        x=cpf1_predictions[pressure_col],
        name='CPF1',
        opacity=0.7,
        marker_color='#1f77b4',
        nbinsx=50
    ))
    
    # Add CPF2 histogram
    fig.add_trace(go.Histogram(
        x=cpf2_predictions[pressure_col],
        name='CPF2',
        opacity=0.7,
        marker_color='#ff7f0e',
        nbinsx=50
    ))
    
    fig.update_layout(
        title='CPF1 vs CPF2 Pressure Distribution Comparison',
        xaxis_title='Pressure (psi)',
        yaxis_title='Frequency',
        barmode='overlay',
        template='plotly_white',
        font={'family': 'Arial, sans-serif', 'size': 12}
    )
    
    return fig


def print_pressure_summary(predictions: pd.DataFrame, cpf_name: str, 
                          pressure_col: str = 'Pressure_Pred_PINN', threshold: float = 250) -> Dict:
    """
    Print and return pressure summary statistics.
    
    Args:
        predictions: DataFrame with pressure predictions
        cpf_name: Name of the CPF
        pressure_col: Name of pressure column
        threshold: Safety threshold for high pressure classification
        
    Returns:
        Dict: Summary statistics
    """
    stats = predictions[pressure_col].describe()
    high_pressure_count = (predictions[pressure_col] > threshold).sum()
    
    summary = {
        'cpf_name': cpf_name,
        'mean': stats['mean'],
        'max': stats['max'],
        'min': stats['min'],
        'std': stats['std'],
        'high_pressure_nodes': high_pressure_count,
        'total_nodes': len(predictions),
        'high_pressure_percentage': (high_pressure_count / len(predictions)) * 100
    }
    
    print(f"=== {cpf_name} Pressure Summary ===")
    print(f"Mean: {summary['mean']:.2f} psi")
    print(f"Max: {summary['max']:.2f} psi")
    print(f"Min: {summary['min']:.2f} psi")
    print(f"Std: {summary['std']:.2f} psi")
    print(f"Nodes above {threshold} psi: {summary['high_pressure_nodes']} ({summary['high_pressure_percentage']:.1f}%)")
    print(f"Total nodes: {summary['total_nodes']}")
    print()
    
    return summary