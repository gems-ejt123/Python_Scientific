"""Utility helpers for validating propagated flowrates and watercuts.

These helpers operate on the enriched network topology DataFrame produced by
`propagate_flowrates` or `build_flows_from_sources_and_junctions`. They provide
summary tables that help verify:

1. Source branch assignments match the aggregated well production data.
2. Junctions conserve volumetric flow and mix watercut correctly.
3. Each Troncal conserves total flow between its sources and sinks.

All public functions expect pandas DataFrames and return DataFrames so they can
be displayed or further filtered inside notebooks.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd


@dataclass
class _ClusterAggregate:
    flow: float
    water_volume: float

    @property
    def watercut(self) -> float:
        if self.flow <= 0:
            return 0.0
        return self.water_volume / self.flow


def _round_coord(lon: float, lat: float, decimals: int) -> Tuple[float, float]:
    """Helper to round coordinates consistently."""
    return (round(float(lon), decimals), round(float(lat), decimals))


def _aggregate_clusters(input_df: pd.DataFrame) -> Dict[str, _ClusterAggregate]:
    """Aggregate active well production by cluster.

    Parameters
    ----------
    input_df : DataFrame
        Must contain CLUSTER, FLUID_PRED, WATER_PRED and STATUS_OPT_OUTPUT.
    """
    required_cols = {"CLUSTER", "FLUID_PRED", "WATER_PRED", "STATUS_OPT_OUTPUT"}
    missing = required_cols - set(input_df.columns)
    if missing:
        raise ValueError(f"input_df is missing required columns: {sorted(missing)}")

    active = input_df[input_df["STATUS_OPT_OUTPUT"] == 1]
    grouped = (
        active.groupby("CLUSTER")[["FLUID_PRED", "WATER_PRED"]]
        .sum(min_count=1)
        .fillna(0.0)
    )

    aggregates: Dict[str, _ClusterAggregate] = {}
    for cluster, row in grouped.iterrows():
        flow = float(row["FLUID_PRED"])
        water_volume = float(row["WATER_PRED"])
        aggregates[cluster] = _ClusterAggregate(flow=flow, water_volume=water_volume)
    return aggregates


def summarize_source_flow_mapping(
    input_df: pd.DataFrame,
    sources_branch_df: pd.DataFrame,
    topology_df: pd.DataFrame,
) -> pd.DataFrame:
    """Compare source branch assignments versus cluster production.

    Returns a table with one row per BranchEquipment that is mapped as a source.
    Columns include:
        - mapped_clusters: list of clusters attached to the branch
        - input_flow / input_watercut: volumetric flow & mixed WC from production
        - topology_flow / topology_watercut: values assigned in the topology
        - flow_residual / watercut_residual: absolute difference metrics
    """
    if not {"source", "BranchEquipment"}.issubset(sources_branch_df.columns):
        raise ValueError("sources_branch_df must contain 'source' and 'BranchEquipment'")

    agg_by_cluster = _aggregate_clusters(input_df)

    # Build mapping: BranchEquipment -> clusters
    branch_to_clusters: Dict[str, List[str]] = (
        sources_branch_df.groupby("BranchEquipment")["source"].apply(list).to_dict()
    )

    # Topology source values (take first row per branch where node_type == 1)
    if {"BranchEquipment", "node_type", "FlowrateLiquidInsitu", "Watercut"}.issubset(
        topology_df.columns
    ):
        topo_sources = (
            topology_df[topology_df["node_type"] == 1]
            .sort_values(["BranchEquipment", "TotalDistance"], na_position="last")
            .groupby("BranchEquipment")[["FlowrateLiquidInsitu", "Watercut"]]
            .first()
        )
    else:
        raise ValueError(
            "topology_df must contain BranchEquipment, node_type, FlowrateLiquidInsitu and Watercut"
        )

    records: List[Dict[str, object]] = []
    for branch, clusters in branch_to_clusters.items():
        cluster_aggregates = [agg_by_cluster[c] for c in clusters if c in agg_by_cluster]
        input_flow = float(sum(c.flow for c in cluster_aggregates))
        input_water_volume = float(sum(c.water_volume for c in cluster_aggregates))
        input_watercut = 0.0 if input_flow <= 0 else input_water_volume / input_flow

        topo_flow = float(topo_sources.loc[branch, "FlowrateLiquidInsitu"]) if branch in topo_sources.index else 0.0
        topo_wc = float(topo_sources.loc[branch, "Watercut"]) if branch in topo_sources.index else 0.0

        records.append(
            {
                "BranchEquipment": branch,
                "mapped_clusters": clusters,
                "input_flow": input_flow,
                "input_watercut": input_watercut,
                "topology_flow": topo_flow,
                "topology_watercut": topo_wc,
                "flow_residual": topo_flow - input_flow,
                "watercut_residual": topo_wc - input_watercut,
            }
        )

    summary = pd.DataFrame.from_records(records)
    if not summary.empty:
        summary["abs_flow_residual_pct"] = np.where(
            summary["input_flow"].abs() > 0,
            summary["flow_residual"].abs() / summary["input_flow"].replace(0, np.nan) * 100,
            np.nan,
        )
    return summary.sort_values("BranchEquipment").reset_index(drop=True)


def analyze_connections(
    topology_df: pd.DataFrame,
    round_decimals: int = 8,
    min_flow_threshold: float = 0.0,
) -> pd.DataFrame:
    """Inspect every coordinate where branches meet to verify conservation.

    Each row represents a unique coordinate with metadata:
        - incoming / outgoing branch lists
        - sum_in_flow / sum_out_flow
        - flow_balance (sum_out - sum_in)
        - classification: source, sink, continuation, junction, isolated

    Parameters
    ----------
    topology_df : DataFrame
        Must contain BranchEquipment, TotalDistance, long, lat, FlowrateLiquidInsitu.
    round_decimals : int
        Decimal precision for coordinate grouping.
    min_flow_threshold : float
        Branches with absolute flow below this value are ignored when counting
        incoming/outgoing participants.
    """
    required = {"BranchEquipment", "TotalDistance", "long", "lat", "FlowrateLiquidInsitu"}
    missing = required - set(topology_df.columns)
    if missing:
        raise ValueError(f"topology_df missing required columns: {sorted(missing)}")

    df = topology_df.copy()
    df = df.sort_values(["BranchEquipment", "TotalDistance"])

    branch_first_last: Dict[str, Tuple[Tuple[float, float], Tuple[float, float]]] = {}
    start_map: Dict[Tuple[float, float], List[str]] = {}
    end_map: Dict[Tuple[float, float], List[str]] = {}

    for branch, bdf in df.groupby("BranchEquipment"):
        first = _round_coord(bdf.iloc[0]["long"], bdf.iloc[0]["lat"], round_decimals)
        last = _round_coord(bdf.iloc[-1]["long"], bdf.iloc[-1]["lat"], round_decimals)
        branch_first_last[branch] = (first, last)
        start_map.setdefault(first, []).append(branch)
        end_map.setdefault(last, []).append(branch)

    def branch_flow(branch: str) -> float:
        sub = df[df["BranchEquipment"] == branch]
        return float(sub["FlowrateLiquidInsitu"].iloc[0]) if not sub.empty else 0.0

    records: List[Dict[str, object]] = []
    coords = set(start_map.keys()) | set(end_map.keys())

    for coord in coords:
        incoming_branches = [b for b in end_map.get(coord, []) if abs(branch_flow(b)) > min_flow_threshold]
        outgoing_branches = [b for b in start_map.get(coord, []) if abs(branch_flow(b)) > min_flow_threshold]

        sum_in = sum(branch_flow(b) for b in incoming_branches)
        sum_out = sum(branch_flow(b) for b in outgoing_branches)
        balance = sum_out - sum_in

        if not incoming_branches and not outgoing_branches:
            classification = "isolated"
        elif incoming_branches and not outgoing_branches:
            classification = "sink"
        elif not incoming_branches and outgoing_branches:
            classification = "source"
        else:
            if len(incoming_branches) == 1 and len(outgoing_branches) == 1:
                classification = "continuation"
            else:
                classification = "junction"

        records.append(
            {
                "coord": coord,
                "incoming_branches": incoming_branches,
                "outgoing_branches": outgoing_branches,
                "incoming_branch_count": len(incoming_branches),
                "outgoing_branch_count": len(outgoing_branches),
                "sum_in_flow": sum_in,
                "sum_out_flow": sum_out,
                "flow_balance": balance,
                "classification": classification,
            }
        )

    result = pd.DataFrame.from_records(records)
    if not result.empty:
        result["abs_balance_pct"] = np.where(
            result["sum_in_flow"].abs() > 0,
            result["flow_balance"].abs() / result["sum_in_flow"].replace(0, np.nan) * 100,
            np.nan,
        )
    return result.sort_values("classification").reset_index(drop=True)


def troncal_balance(topology_df: pd.DataFrame) -> pd.DataFrame:
    """Compute mass-balance between sources and sinks for every Troncal."""
    required = {"Troncal", "BranchEquipment", "node_type", "FlowrateLiquidInsitu"}
    missing = required - set(topology_df.columns)
    if missing:
        raise ValueError(f"topology_df missing required columns: {sorted(missing)}")

    df = topology_df.copy()

    # Flow entering each true source branch (node_type == 1)
    source_flows = (
        df[df["node_type"] == 1]
        .groupby("BranchEquipment")["FlowrateLiquidInsitu"]
        .first()
    )

    # Flow exiting branches that contain at least one sink node (node_type == -1)
    sink_flows = (
        df[df["node_type"] == -1]
        .groupby("BranchEquipment")["FlowrateLiquidInsitu"]
        .first()
    )

    troncal_rows: List[Dict[str, object]] = []
    for troncal, tdf in df.groupby("Troncal"):
        branch_list = tdf["BranchEquipment"].unique().tolist()
        source_sum = 0.0
        sink_sum = 0.0
        if not source_flows.empty and branch_list:
            source_sum = float(source_flows.reindex(branch_list).fillna(0.0).sum())
        if not sink_flows.empty and branch_list:
            sink_sum = float(sink_flows.reindex(branch_list).fillna(0.0).sum())
        residual = sink_sum - source_sum
        residual_pct = np.nan
        if abs(source_sum) > 0:
            residual_pct = abs(residual) / abs(source_sum) * 100.0

        troncal_rows.append(
            {
                "Troncal": troncal,
                "source_flow": source_sum,
                "sink_flow": sink_sum,
                "flow_residual": residual,
                "abs_residual_pct": residual_pct,
            }
        )

    return pd.DataFrame.from_records(troncal_rows).sort_values("abs_residual_pct", ascending=False).reset_index(drop=True)


def _identify_off_clusters(
    input_df: pd.DataFrame,
    sources_branch_df: pd.DataFrame,
) -> Tuple[Dict[str, str], Dict[str, List[str]]]:
    """Identify clusters considered OFF or missing.

    Returns
    -------
    cluster_status : Dict[str, str]
        Mapping of cluster -> status string ("off", "missing_in_input").
    branch_to_clusters : Dict[str, List[str]]
        Mapping of BranchEquipment -> list of clusters from sources_branch_df.
    """

    if not {"source", "BranchEquipment"}.issubset(sources_branch_df.columns):
        raise ValueError("sources_branch_df must contain 'source' and 'BranchEquipment'")

    branch_to_clusters: Dict[str, List[str]] = (
        sources_branch_df.groupby("BranchEquipment")["source"].apply(list).to_dict()
    )

    cluster_status: Dict[str, str] = {}
    if {"CLUSTER", "STATUS_OPT_OUTPUT"}.issubset(input_df.columns):
        cluster_group = (
            input_df.groupby("CLUSTER")["STATUS_OPT_OUTPUT"].agg(["count", "sum"])
        )
        off_mask = cluster_group["sum"].fillna(0) == 0
        for cluster in cluster_group.index[off_mask]:
            cluster_status[str(cluster)] = "off"
    else:
        cluster_group = pd.DataFrame()

    clusters_in_input = set(cluster_group.index) if not cluster_group.empty else set(
        input_df["CLUSTER"].unique()
    ) if "CLUSTER" in input_df.columns else set()
    mapped_clusters = set(sources_branch_df["source"].unique())
    missing_clusters = mapped_clusters - clusters_in_input
    for cluster in missing_clusters:
        cluster_status[str(cluster)] = "missing_in_input"

    return cluster_status, branch_to_clusters


def check_off_clusters_flow(
    input_df: pd.DataFrame,
    sources_branch_df: pd.DataFrame,
    topology_df: pd.DataFrame,
    zero_tolerance: float = 1e-6,
) -> pd.DataFrame:
    """Validate that OFF or missing clusters feed zero flow to their branches."""

    required_topology = {"BranchEquipment", "FlowrateLiquidInsitu"}
    missing_topology = required_topology - set(topology_df.columns)
    if missing_topology:
        raise ValueError(
            f"topology_df missing required columns: {sorted(missing_topology)}"
        )

    cluster_status, branch_to_clusters = _identify_off_clusters(input_df, sources_branch_df)

    topo_branch_flows = (
        topology_df.groupby("BranchEquipment")["FlowrateLiquidInsitu"].first()
    )

    records: List[Dict[str, object]] = []
    for branch, clusters in branch_to_clusters.items():
        off_clusters = [c for c in clusters if c in cluster_status]
        has_off_cluster = len(off_clusters) > 0
        branch_flow = float(topo_branch_flows.get(branch, 0.0))
        expected_zero = has_off_cluster
        status = "OK"
        if expected_zero and abs(branch_flow) > zero_tolerance:
            status = "Mismatch"

        records.append(
            {
                "BranchEquipment": branch,
                "mapped_clusters": clusters,
                "off_or_missing_clusters": off_clusters,
                "branch_flow": branch_flow,
                "expected_zero": expected_zero,
                "status": status,
            }
        )

    result = pd.DataFrame.from_records(records)
    if not result.empty:
        result = result.sort_values(["status", "BranchEquipment"]).reset_index(drop=True)
    return result


__all__ = [
    "summarize_source_flow_mapping",
    "analyze_connections",
    "troncal_balance",
    "check_off_clusters_flow",
]
