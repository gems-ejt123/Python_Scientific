"""
physics_decoder.py — Boundary-Anchored Differentiable Integrator (BADI).

A *physics-as-architecture* alternative to the soft junction/momentum PENALTY
terms. Instead of predicting a free per-node pressure residual and nudging it
with a soft loss, the network predicts a per-SEGMENT correction field ``delta``
and node pressures are reconstructed by integrating those segment drops along
the directed sink -> node path, anchored at the KNOWN sink pressure:

    P_node = P_sink + sum_{seg on sink->node path} ( dP_backbone_seg + delta_seg )
           = P_backbone_node + ( A @ delta )_node

where ``A`` (node x segment, {0,1}) is the *path-incidence matrix*. Because the
topology of a trunk is identical across all its scenarios, ``A`` and the static
segment geometry are built ONCE from a representative scenario and reused.

Why this differs from the existing soft-physics phase (see junction_loss.py /
momentum_loss.py), and why it should help the documented failure modes:

  * HARD sink boundary. The sink node's path is empty, so P_sink is reproduced
    exactly for every scenario, every epoch. No soft term can violate it. This
    is the fix for the "physics is level-blind" diagnosis: the integrator pins
    the absolute level, not just the shape.
  * CONSERVATIVE residual. r_node = (A @ delta) is the integral of a segment
    field, so it is path-consistent by construction. A node shared by several
    flowlines (a junction) receives a single pressure automatically -> junction
    continuity becomes STRUCTURAL, not a variance penalty.
  * LEVEL-AWARE physics. The optional momentum closure compares each segment's
    *integrated* drop P[up]-P[down] against the discretised two-phase momentum
    balance evaluated with a network-predicted mixture density. Because the
    drops integrate to the anchored level, this constraint informs the absolute
    pressure, unlike the drop-only soft terms.
  * TAIL control. A far-upstream (high-P) node is a cumulative sum of bounded
    segment drops from the sink, so it cannot free-float upward; over-prediction
    must come from accumulated segment error, which the closure penalises.

Sign / orientation conventions (match backbone_reconstruction.py):
  * TotalDistance increases source -> sink along a flowline, so within a
    flowline the LARGER-distance node is the DOWNSTREAM (sink-ward) endpoint.
  * For a segment, ``up`` = source-ward node, ``down`` = sink-ward node, and the
    physical drop P[up] - P[down] >= 0 in the friction/uphill regime.
  * Gravity/friction unit conventions: psi = 144, gc = 32.174, i.e.
        dP_grav = rho_mix * dz / 144
        dP_fric = lambda * rho_mix * v^2 * dl / (2 d) / (gc * 144)

The heavy torch pieces are import-light: only ``integrate_pressure`` and
``momentum_closure_residual`` touch torch, and they import it lazily so the
pure-numpy topology builder can be imported and unit-tested without a GPU stack.
"""
from __future__ import annotations

import numpy as np

GC = 32.174
PSI = 144.0

FL_COL = "BranchEquipment"
DIST_COL = "TotalDistance"
ELEV_COL = "Elevation"
DIAM_COL = "PipeInsideDiameter"
X_COL, Y_COL = "long", "lat"


# ===========================================================================
#  TOPOLOGY  (numpy only, built once per trunk)
# ===========================================================================
class SegmentTopology:
    """Fixed per-trunk integrator structure.

    Attributes
    ----------
    node_key   : (N,2) float array of (BranchEquipment-code, TotalDistance) used
                 only as an ordering/alignment fingerprint; canonical node order
                 is 0..N-1 = topology_df sorted by [FL_COL, DIST_COL].
    seg_up     : (S,) int, source-ward node position of each segment.
    seg_down   : (S,) int, sink-ward node position of each segment.
    A          : (N,S) float32 path-incidence; P = P_sink + A @ delta.
    seg_dl     : (S,) float32 segment length (ft).
    seg_dz     : (S,) float32 elevation gain up->down? see note (z_down - z_up).
    seg_dmean  : (S,) float32 mean diameter (ft).
    sink_pos   : int position of the sink node (path is empty).
    n_nodes, n_seg : ints.
    """

    __slots__ = ("seg_up", "seg_down", "A", "seg_dl", "seg_dz", "seg_dmean",
                 "sink_pos", "n_nodes", "n_seg", "flowline_of_node")

    def __init__(self, seg_up, seg_down, A, seg_dl, seg_dz, seg_dmean,
                 sink_pos, flowline_of_node):
        self.seg_up = seg_up
        self.seg_down = seg_down
        self.A = A
        self.seg_dl = seg_dl
        self.seg_dz = seg_dz
        self.seg_dmean = seg_dmean
        self.sink_pos = sink_pos
        self.flowline_of_node = flowline_of_node
        self.n_nodes = A.shape[0]
        self.n_seg = A.shape[1]


def _sorted_topology(topology_df):
    """Canonical node order: sort by (flowline, distance). Returns the sorted
    frame with a stable RangeIndex 0..N-1 giving node POSITIONS."""
    d = topology_df.sort_values([FL_COL, DIST_COL]).reset_index(drop=True)
    return d


def build_segment_topology(topology_df, junction_graph, flowline_order, sink_fl,
                           node_type_col="node_type"):
    """Build the differentiable-integrator structures from ONE representative
    scenario (topology is identical across a trunk's scenarios).

    Mirrors backbone_reconstruction.backbone_channels: it walks flowlines in
    REVERSED topological order and carries a junction value downstream. Here the
    carried value is the LIST OF SEGMENTS on the sink->(flowline start) path
    instead of an accumulated H/B scalar, which yields the path-incidence A.

    Returns a SegmentTopology.
    """
    d = _sorted_topology(topology_df)
    N = len(d)

    # position of each row within its flowline, and global position 0..N-1
    d = d.assign(_pos=np.arange(N))
    # group positions per flowline (already sorted by distance within flowline)
    fl_positions = {}
    for fl, g in d.groupby(FL_COL, sort=False):
        fl_positions[fl] = g["_pos"].to_numpy()

    z = d[ELEV_COL].to_numpy(float) if ELEV_COL in d.columns else np.zeros(N)
    dist = d[DIST_COL].to_numpy(float)
    diam = (d[DIAM_COL].to_numpy(float) / 12.0) if DIAM_COL in d.columns else np.ones(N)

    seg_up, seg_down = [], []
    seg_dl, seg_dz, seg_dmean = [], [], []
    # per-flowline list of *its own* segment ids, ordered start(source) -> end(sink)
    fl_own_segments = {}

    for fl, pos in fl_positions.items():
        own = []
        for k in range(len(pos) - 1):
            up = int(pos[k])       # smaller distance -> source-ward
            dn = int(pos[k + 1])   # larger distance  -> sink-ward
            sid = len(seg_up)
            seg_up.append(up)
            seg_down.append(dn)
            dl = dist[dn] - dist[up]
            seg_dl.append(dl)
            seg_dz.append(z[dn] - z[up])
            seg_dmean.append(0.5 * (diam[up] + diam[dn]))
            own.append(sid)
        fl_own_segments[fl] = own  # ordered source->sink

    S = len(seg_up)
    seg_up = np.asarray(seg_up, np.int64)
    seg_down = np.asarray(seg_down, np.int64)
    seg_dl = np.asarray(seg_dl, np.float32)
    seg_dz = np.asarray(seg_dz, np.float32)
    seg_dmean = np.asarray(seg_dmean, np.float32)

    # ---- junction carry: for a flowline, the segments on sink->(flowline END) ----
    out_junc, in_junc = {}, {}
    for jc, info in junction_graph.items():
        for fl in info["outgoing"]:
            out_junc[fl] = jc     # junction sits at this flowline's START
        for fl in info["incoming"]:
            in_junc[fl] = jc      # junction sits at this flowline's END
    junc_start_path = {}          # jc -> segment list sink -> that junction

    A = np.zeros((N, S), dtype=np.float32)

    for fl in reversed(flowline_order):
        if fl not in fl_own_segments:
            continue
        own = fl_own_segments[fl]           # source->sink order
        pos = fl_positions[fl]              # source->sink order (by distance)
        # segments on sink -> (this flowline's END/sink-ward node)
        if fl == sink_fl:
            base_end = []                    # end connects directly to P_sink
        elif fl in in_junc and in_junc[fl] in junc_start_path:
            base_end = junc_start_path[in_junc[fl]]
        else:
            base_end = []                    # unreached -> anchor at sink (safe)

        # node k on this flowline: path = base_end + own[k:]  (segments k..end)
        for k, node_pos in enumerate(pos):
            path_segs = base_end + own[k:]
            if path_segs:
                A[int(node_pos), path_segs] = 1.0

        # sink -> (this flowline's START) = base_end + all own segments
        start_path = base_end + own
        if fl in out_junc:
            junc_start_path[out_junc[fl]] = start_path

    # sink node = the max-distance node of the sink flowline (empty path row)
    sink_pos = int(A.sum(axis=1).argmin())

    flowline_of_node = d[FL_COL].to_numpy()
    return SegmentTopology(seg_up, seg_down, A, seg_dl, seg_dz, seg_dmean,
                           sink_pos, flowline_of_node)


def align_scenario_frame(scenario_df):
    """Return the scenario frame in canonical node order (positions 0..N-1)."""
    return scenario_df.sort_values([FL_COL, DIST_COL]).reset_index(drop=True)


def scenario_segment_features(scen_df_sorted, topo: "SegmentTopology", input_cols):
    """Per-segment feature matrix (S, len(input_cols)+2).

    Feature = endpoint-averaged INPUT_COLS  ++  [seg_dz, seg_dl]. Endpoint values
    are read at the (up, down) node positions, so this is aligned to A / seg_up /
    seg_down purely by position (no per-scenario re-derivation of segment ids).
    """
    X = scen_df_sorted[input_cols].to_numpy(np.float32)          # (N, F0)
    up = X[topo.seg_up]                                          # (S, F0)
    dn = X[topo.seg_down]
    mid = 0.5 * (up + dn)
    geom = np.stack([topo.seg_dz, topo.seg_dl], axis=1)          # (S, 2)
    return np.concatenate([mid, geom], axis=1).astype(np.float32)


def scenario_pressure_target(scen_df_sorted, pressure_col="Pressure"):
    """Node pressure target (N,) in canonical order."""
    return scen_df_sorted[pressure_col].to_numpy(np.float32)


# ===========================================================================
#  DIFFERENTIABLE INTEGRATION  (torch)
# ===========================================================================
def integrate_pressure(P_backbone_nodes_t, A_t, delta_seg_t):
    """P_pred = P_backbone + A @ delta.  All torch tensors.

    P_backbone_nodes_t : (N,)   backbone pressure in canonical node order.
    A_t                : (N,S)  path-incidence (float).
    delta_seg_t        : (S,)   per-segment correction (psi).
    Returns (N,) predicted node pressure. Sink row of A is all-zero -> anchored.
    """
    return P_backbone_nodes_t + A_t @ delta_seg_t


def segment_drop_from_nodes(P_nodes_t, seg_up_t, seg_down_t):
    """Integrated per-segment drop P[up] - P[down] (torch), for the closure."""
    return P_nodes_t[seg_up_t] - P_nodes_t[seg_down_t]


def _xp_log(x):
    """Backend-agnostic natural log (torch tensor or numpy/float)."""
    try:
        import torch
        if torch.is_tensor(x):
            return torch.log(x)
    except Exception:
        pass
    return np.log(x)


def _xp_abs(x):
    """Backend-agnostic absolute value (torch tensor or numpy/float)."""
    try:
        import torch
        if torch.is_tensor(x):
            return torch.abs(x)
    except Exception:
        pass
    return np.abs(x)


def _xp_exp(x):
    """Backend-agnostic exp (torch tensor or numpy/float)."""
    try:
        import torch
        if torch.is_tensor(x):
            return torch.exp(x)
    except Exception:
        pass
    return np.exp(x)


def _xp_maximum(a, b):
    """Backend-agnostic elementwise maximum (torch tensor or numpy/float)."""
    try:
        import torch
        if torch.is_tensor(a) or torch.is_tensor(b):
            a_t = a if torch.is_tensor(a) else torch.as_tensor(a)
            b_t = b if torch.is_tensor(b) else torch.as_tensor(b)
            return torch.maximum(a_t, b_t)
    except Exception:
        pass
    return np.maximum(a, b)


def friction_factor_churchill(Re, eps_over_D):
    """Darcy friction factor via the Churchill (1977) all-regime correlation.

    Valid across laminar, transitional AND turbulent flow in one explicit
    expression: reduces to f = 64/Re as Re -> 0 and to Colebrook-White at high
    Re. Backend-agnostic (numpy or torch). `eps_over_D` is the relative pipe
    roughness (absolute roughness / diameter, both in the same length unit).

    This is the DEPLOYMENT-PORTABLE friction model: it depends only on Reynolds
    number (Re = rho*v*D/mu) and relative roughness -- physical fluid/pipe
    properties -- NOT on the per-flowline PIPESIM `lambda_friction` calibration,
    which does not exist on an unseen network. On this field the flow is mostly
    laminar/transitional (Re ~ 1e3), so Churchill behaves like 64/Re here while
    remaining correct if a new network runs at higher rates.

    NUMERICAL NOTE (float32 / NaN fix): the textbook form builds
    A=(...)**16 and B=(37530/Re)**16 explicitly, then 1/(A+B)**1.5. At the low
    Reynolds numbers of this field (Re~10-1e3) B ~ (37530/Re)**16 ~ 1e56, which
    OVERFLOWS float32 (max 3.4e38) -> inf in the forward pass and NaN gradients
    in backprop -> NaN train/val loss. This implementation is algebraically
    identical but computes the 1/(A+B)**1.5 term in LOG-space (log-sum-exp), so no
    huge intermediate is ever formed; it stays finite and differentiable in
    float32. Re is floored at 1.0 (physical here; also guards v=0 -> Re=0).
    """
    if hasattr(Re, "clamp_min"):
        Re_safe = Re.clamp_min(1.0)
    else:
        Re_safe = np.maximum(Re, 1.0)

    # Laminar/transitional term (bounded once Re is floored at 1): -> 64/Re.
    term1 = (8.0 / Re_safe) ** 12

    # Turbulent/roughness term 1/(A+B)**1.5 via log-sum-exp to avoid overflow.
    inner = (7.0 / Re_safe) ** 0.9 + 0.27 * eps_over_D
    # log A: the core 2.457*ln(1/inner) can be negative for Re<~7, but it is
    # raised to the even 16th power, so take |.| before logging; +1e-30 floors
    # log(0) (occurs only where inner==1 exactly).
    a_core = _xp_abs(2.457 * _xp_log(1.0 / inner))
    logA = 16.0 * _xp_log(a_core + 1e-30)
    logB = 16.0 * (np.log(37530.0) - _xp_log(Re_safe))
    m = _xp_maximum(logA, logB)
    log_ApB = m + _xp_log(_xp_exp(logA - m) + _xp_exp(logB - m))
    term2 = _xp_exp(-1.5 * log_ApB)

    return 8.0 * (term1 + term2) ** (1.0 / 12.0)


def momentum_closure_residual(dP_seg_pred_t, *, rho_liq_seg_t, vel_seg_t,
                              lam_seg_t, seg_dl_t, seg_dz_t, seg_dmean_t,
                              holdup_seg_t=None, rho_gas_seg_t=None,
                              friction_f0=1.0, mu_eff=None, eps_ft=None):
    """Discretised two-phase momentum residual per segment (torch).

    physics_dP = rho_mix * dz / 144                              (gravity head)
               + f0*lambda * rho_mix * v^2 * dl/(2 d)/(gc*144)   (friction)

    UNITS / SCALE -- IMPORTANT:
    `lam_seg_t` (lambda_friction) is the PIPESIM *calibration multiplier*, NOT the
    Darcy friction factor f. The physical friction factor is  f = f0 * lambda,
    where `friction_f0` is the base Darcy factor for the field (dimensionless,
    ~0.02-0.03 for turbulent flow in these trunks). Passing friction_f0=1.0 (the
    default) treats lambda AS f and OVER-predicts the friction drop by ~1/f0
    (~15-40x here). Callers MUST set friction_f0 to the field base Darcy factor
    (fit ~0.027 on this dataset) for the closure to be in physical psi.

    rho_mix = HL*rho_liq + (1-HL)*rho_gas ; if holdup/rho_gas are None it falls
    back to single-phase liquid (HL = 1). Returns (dP_pred - physics_dP), whose
    MSE is the label-free closure loss. Because dP_pred comes from the anchored
    integration, driving this to zero informs the absolute pressure level.
    """
    if holdup_seg_t is None or rho_gas_seg_t is None:
        rho_mix = rho_liq_seg_t
    else:
        rho_mix = holdup_seg_t * rho_liq_seg_t + (1.0 - holdup_seg_t) * rho_gas_seg_t
    grav = rho_mix * seg_dz_t / PSI
    if mu_eff is not None:
        # DEPLOYABLE physics: Darcy factor from Churchill(Re, eps/D); no lambda.
        Re = rho_liq_seg_t * vel_seg_t * seg_dmean_t / mu_eff
        eps_over_D = (0.0 if eps_ft is None else eps_ft) / seg_dmean_t
        f = friction_factor_churchill(Re, eps_over_D)
    else:
        # CALIBRATION physics: f = friction_f0 * lambda (training-network only).
        f = friction_f0 * lam_seg_t
    fric = f * rho_mix * vel_seg_t * vel_seg_t * seg_dl_t \
        / (2.0 * seg_dmean_t) / (GC * PSI)
    physics_dP = grav + fric
    return dP_seg_pred_t - physics_dP

# ===========================================================================
#  DEPLOYMENT-ALIGNED LIQUID DENSITY  (reconstructed from watercut)
# ===========================================================================
def liquid_density_from_watercut(wc, rho_oil, rho_water, P=None, c_l=None,
                                 p_ref=0.0):
    """In-situ liquid density from watercut (gas-free oil+water mixture).

    Volumetric (no-slip) mixing rule:  rho_liq = wc*rho_water + (1-wc)*rho_oil,
    where wc is the IN-SITU volumetric watercut (= PIPESIM Watercut column) and
    rho_oil / rho_water are in-situ phase densities from the field PVT / black-oil
    fluid model. They CANNOT be regressed when watercut is ~constant (no leverage).

    Optional pressure (compressibility) term: rho_liq *= 1 + c_l*(P - p_ref),
    applied only when both P and c_l are given. c_l is the TRUE isothermal liquid
    compressibility (~5e-6 1/psi), NOT the absolute lb/ft3-per-psi slope; p_ref is
    the reference pressure at which rho_oil/rho_water are quoted.

    Backend-agnostic: works on floats, numpy arrays, or torch tensors (uses only
    +, -, * so autograd flows through wc and P).
    """
    rho = wc * rho_water + (1.0 - wc) * rho_oil
    if P is not None and c_l is not None:
        rho = rho * (1.0 + c_l * (P - p_ref))
    return rho


# ===========================================================================
#  TAIL WEIGHT  (node-level, psi domain) -- mirrors tail_weighting intent
# ===========================================================================
def tail_weights(P_true_np, p0_psi=250.0, alpha=0.5, scale=100.0, wmax=3.0):
    """Per-node tail emphasis in raw-psi node space. Returns (N,)."""
    p = np.asarray(P_true_np, np.float32)
    w = 1.0 + alpha * np.clip((p - p0_psi) / scale, 0.0, None)
    return np.minimum(w, wmax).astype(np.float32)


__all__ = [
    "friction_factor_churchill",
    "SegmentTopology", "build_segment_topology", "align_scenario_frame",
    "scenario_segment_features", "scenario_pressure_target",
    "integrate_pressure", "segment_drop_from_nodes",
    "momentum_closure_residual", "liquid_density_from_watercut", "tail_weights",
]

