import os
import gc
import torch

def set_cuda_env_vars():
    """Set CUDA environment variables for better error reporting"""
    os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
    os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:1024'

def get_device(force_cuda=False, requested_device=None):
    """Get the appropriate device for tensor computations"""
    if requested_device is not None:
        return torch.device(requested_device)
    
    if force_cuda and torch.cuda.is_available():
        device = torch.device('cuda')
        # Print CUDA device info
        print(f"Using CUDA device: {torch.cuda.get_device_name(0)}")
        print(f"CUDA memory allocated: {torch.cuda.memory_allocated(0) / 1e9:.2f} GB")
        print(f"CUDA memory reserved: {torch.cuda.memory_reserved(0) / 1e9:.2f} GB")
        return device
    
    if torch.cuda.is_available():
        return torch.device('cuda')
    else:
        return torch.device('cpu')

def clear_memory():
    """Clear GPU memory cache and run garbage collection"""
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()