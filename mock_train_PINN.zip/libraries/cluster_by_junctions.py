from collections import defaultdict
import networkx as nx
import numpy as np
from sklearn.cluster import  KMeans
import matplotlib.pyplot as plt



def detect_junctions_from_nodes(nodes_df, node_id_col="node_id", x_col="long", y_col="lat",
                                branch_col="BranchEquipment", round_decimals=8):
    """
    Detect junction points where multiple flowlines meet.
    
    Parameters:
        nodes_df (pd.DataFrame): DataFrame with node data
        node_id_col (str): Column name for node identifiers
        x_col, y_col (str): Column names for spatial coordinates
        round_decimals (int): Precision for coordinate rounding to identify coincident points
        
    Returns:
        list: List of junction dictionaries, each with coords, node_ids, count, and id
    """
    df = nodes_df.copy()
   
    # Round coordinates to identify coincident points
    df["x_round"] = df[x_col].round(round_decimals)
    df["y_round"] = df[y_col].round(round_decimals)
   
    # Group by rounded coordinates to find junctions
    grouped = df.groupby(["x_round", "y_round"])
    junctions = []
   
    for i, ((x_r, y_r), group) in enumerate(grouped):
        if len(group) > 1:  # A junction has multiple nodes at the same location
            junctions.append({
                "id": f"J{i}",              # Add a unique ID for each junction
                "coords": (x_r, y_r),
                "node_ids": group[node_id_col].tolist(),
                "flowline": group[branch_col].unique().tolist(),
                "count": len(group)
            })
           
    return junctions

def classify_flowline_direction(flowline_id, junction_coords, df, x_col="long", y_col="lat",
                             distance_col='measuredDistance meters', tol=1e-6):
    """
    Determine if a flowline is incoming to or outgoing from a junction.
    
    Parameters:
        flowline_id (str): ID of the flowline to classify
        junction_coords (tuple): Coordinates of the junction (x, y)
        df (pd.DataFrame): DataFrame with pipeline data
        x_col, y_col (str): Column names for spatial coordinates
        distance_col (str): Column name for distance measurement
        tol (float): Tolerance for coordinate matching
        
    Returns:
        str: "incoming", "outgoing", or "unknown"
    """
    # Get nodes for the specified flowline
    flowline_df = df[df["BranchEquipment"] == flowline_id].copy()
    if flowline_df.empty:
        return "unknown"
   
    # Sort by distance to get first and last node
    flowline_df.sort_values(by=distance_col, inplace=True)
    flowline_df.reset_index(drop=True, inplace=True)
   
    # Get coordinates of first and last node
    first_node = flowline_df.iloc[0]
    last_node = flowline_df.iloc[-1]
    first_coords = np.array([first_node[x_col], first_node[y_col]])
    last_coords = np.array([last_node[x_col], last_node[y_col]])
   
    # Calculate distances to junction
    junction_coords = np.array(junction_coords)
    dist_first = np.linalg.norm(first_coords - junction_coords)
    dist_last = np.linalg.norm(last_coords - junction_coords)
   
    # Classify direction
    if dist_first < tol:
        return "outgoing"  # Flowline starts at junction, so it's outgoing
    elif dist_last < tol:
        return "incoming"  # Flowline ends at junction, so it's incoming
    else:
        return "unknown"   # Flowline doesn't touch the junction
    
def apply_branch_aware_clustering(data, num_clusters=15, distance_threshold=0.00005, n_jobs=-1):
    """
    Optimized clustering that leverages branch information and produces balanced clusters.
    Uses detect_junctions_from_nodes to identify junction points properly.
    
    Parameters:
    -----------
    data : pandas DataFrame
        Pipeline data with long, lat, BranchEquipment and scenario columns
    num_clusters : int
        Target number of clusters to create
    distance_threshold : float
        Distance threshold for identifying junction points
    n_jobs : int
        Number of parallel jobs (-1 for using all cores)
    
    Returns:
    --------
    clustered_data : pandas DataFrame
        Original data with added junction_cluster column
    junction_graph : networkx.Graph
        Graph representing junction connectivity
    junctions : list
        List of junction coordinates
    junction_clusters : dict
        Mapping of junction clusters
    """
    print(f"Processing {len(data['BranchEquipment'].unique())} unique flowline branches")
    
    # Make a copy to avoid modifying the original
    df = data.copy()
    
    # 1. Extract reference data from scenario 0 for network structure
    scenario_0 = df[df['scenario'] == 0].copy()
    
    # 2. Use detect_junctions_from_nodes to properly identify junctions
    # Add a unique node_id if it doesn't exist
    if 'node_id' not in scenario_0.columns:
        scenario_0['node_id'] = scenario_0['BranchEquipment'] + "_" + scenario_0['NodeNumber'].astype(str)
    
    # Detect junctions using the specialized function
    junction_data = detect_junctions_from_nodes(
        scenario_0, 
        node_id_col='node_id',
        x_col='long', 
        y_col='lat',
        round_decimals=8
    )
    
    # Extract junction coordinates and create a mapping
    junctions = [np.array(j['coords']) for j in junction_data]
    
    # Create a mapping from coordinates to junction IDs
    endpoint_to_junction = {}
    for i, junction in enumerate(junction_data):
        coords = junction['coords']
        endpoint_to_junction[coords] = i
    
    # 3. Extract branch endpoints for connectivity
    branches = scenario_0['BranchEquipment'].unique()
    branch_to_endpoints = {}
    
    for branch in branches:
        branch_data = scenario_0[scenario_0['BranchEquipment'] == branch]
        # Get first and last points of each branch
        start_point = (branch_data['long'].iloc[0], branch_data['lat'].iloc[0])
        end_point = (branch_data['long'].iloc[-1], branch_data['lat'].iloc[-1])
        
        branch_to_endpoints[branch] = (start_point, end_point)
    
    # 4. Build branch connectivity graph based on shared junctions
    G = nx.Graph()
    
    # Add all branches as nodes
    for branch in branches:
        # Use midpoint as position for visualization
        branch_data = scenario_0[scenario_0['BranchEquipment'] == branch]
        midpoint = branch_data[['long', 'lat']].mean().values
        G.add_node(branch, pos=midpoint)
    
    # Map rounded coordinates back to actual junction IDs for consistency
    rounded_to_junction = {}
    for junction in junction_data:
        coords = junction['coords']
        rounded_to_junction[coords] = endpoint_to_junction[coords]
    
    # Connect branches that share junctions
    for branch, (start, end) in branch_to_endpoints.items():
        # Find if endpoints match any junction (with rounding)
        start_junction = -1
        end_junction = -1
        
        for coords, junction_id in rounded_to_junction.items():
            # Check if start or end point is close to this junction
            if abs(start[0] - coords[0]) < 1e-8 and abs(start[1] - coords[1]) < 1e-8:
                start_junction = junction_id
            if abs(end[0] - coords[0]) < 1e-8 and abs(end[1] - coords[1]) < 1e-8:
                end_junction = junction_id
        
        # Connect branches that share junctions
        for other_branch, (other_start, other_end) in branch_to_endpoints.items():
            if branch == other_branch:
                continue
                
            # Find junction IDs for other branch
            other_start_junction = -1
            other_end_junction = -1
            
            for coords, junction_id in rounded_to_junction.items():
                if abs(other_start[0] - coords[0]) < 1e-8 and abs(other_start[1] - coords[1]) < 1e-8:
                    other_start_junction = junction_id
                if abs(other_end[0] - coords[0]) < 1e-8 and abs(other_end[1] - coords[1]) < 1e-8:
                    other_end_junction = junction_id
            
            # If they share any junction, connect them
            if (start_junction >= 0 and 
                (start_junction == other_start_junction or 
                 start_junction == other_end_junction)):
                G.add_edge(branch, other_branch)
                
            elif (end_junction >= 0 and 
                 (end_junction == other_start_junction or 
                  end_junction == other_end_junction)):
                G.add_edge(branch, other_branch)
    
    # 5. Get connected components and divide them to achieve target clusters
    components = list(nx.connected_components(G))
    
    # Calculate how many clusters to allocate to each component based on size
    total_nodes = sum(len(comp) for comp in components)
    target_clusters = min(num_clusters, total_nodes)
    
    # Proportionally allocate clusters to components
    component_clusters = {}
    branch_to_cluster = {}
    
    if len(components) >= target_clusters:
        # Too many components - merge some if needed
        for i, comp in enumerate(components[:target_clusters]):
            for branch in comp:
                branch_to_cluster[branch] = i
                
        # Assign remaining components to nearest cluster
        if len(components) > target_clusters:
            for i, comp in enumerate(components[target_clusters:]):
                nearest_comp_idx = i % target_clusters  # simple round-robin assignment
                for branch in comp:
                    branch_to_cluster[branch] = nearest_comp_idx
    else:
        # Need to subdivide some components
        cluster_id = 0
        
        for comp in sorted(components, key=len, reverse=True):
            # Calculate clusters for this component proportionally to its size
            comp_size = len(comp)
            comp_clusters = max(1, int(round(comp_size / total_nodes * target_clusters)))
            
            if comp_size <= comp_clusters or comp_clusters == 1:
                # Small component, just assign to one cluster
                for branch in comp:
                    branch_to_cluster[branch] = cluster_id
                cluster_id += 1
            else:
                # Large component, subdivide using KMeans on spatial coordinates
                subgraph = G.subgraph(comp).copy()
                
                # Get branch positions for clustering
                branch_positions = []
                branch_list = []
                
                for branch in subgraph.nodes():
                    branch_data = scenario_0[scenario_0['BranchEquipment'] == branch]
                    midpoint = branch_data[['long', 'lat']].mean().values
                    branch_positions.append(midpoint)
                    branch_list.append(branch)
                
                # Apply KMeans to the branch positions
                branch_positions = np.array(branch_positions)
                kmeans = KMeans(n_clusters=min(comp_clusters, len(branch_positions)), 
                                random_state=42).fit(branch_positions)
                
                # Assign branches to clusters
                for branch, label in zip(branch_list, kmeans.labels_):
                    branch_to_cluster[branch] = cluster_id + label
                
                cluster_id += comp_clusters
    
    # 6. Apply cluster assignments to all scenarios in the dataframe
    df['junction_cluster'] = -1
    
    for branch, cluster_id in branch_to_cluster.items():
        df.loc[df['BranchEquipment'] == branch, 'junction_cluster'] = cluster_id
    
    # Create a mapping of junctions to clusters for visualization
    junction_clusters = defaultdict(list)
    
    # Map junctions to clusters based on connected branches
    for junction_id, junction in enumerate(junction_data):
        coords = junction['coords']
        node_ids = junction['node_ids']
        
        # Find branches connected to this junction
        connected_branches = []
        for node_id in node_ids:
            branch = node_id.split('_')[0] if '_' in node_id else None
            if branch and branch in branch_to_cluster:
                connected_branches.append(branch)
        
        # If junction connects branches, use the first branch's cluster
        if connected_branches:
            cluster_id = branch_to_cluster[connected_branches[0]]
            junction_clusters[cluster_id].append(junction_id)
    
    # Convert junction coordinates to array format for compatibility
    junction_coords = np.array([np.array([j['coords'][0], j['coords'][1]]) for j in junction_data])
    
    # Convert to expected format for visualization
    junction_dict = {}
    for cluster_id, junction_ids in junction_clusters.items():
        junction_dict[cluster_id] = junction_ids
    
    return df, G, junction_coords, junction_dict

def visualize_branch_clusters(df, scenario_id=0, branch_graph=None, junctions=None, junction_clusters=None,
                             cluster_col='junction_cluster', x_col='long', y_col='lat',
                             flowline_col='BranchEquipment', scenario_col='scenario',
                             highlight_boundaries=True, show_junction_groups=True):
    """
    Visualize the branch-based clustering results.
    
    Parameters:
    -----------
    df : pandas DataFrame
        The clustered data with flowline and coordinate information
    scenario_id : int
        Scenario ID to visualize
    branch_graph : networkx.Graph, optional
        Graph of branch connectivity (not used in this implementation)
    junctions : list, optional
        List of junction coordinates to display as markers
    junction_clusters : dict, optional
        Mapping of cluster IDs to junction indices
    cluster_col : str
        Column name for cluster IDs
    x_col, y_col : str
        Column names for coordinates (longitude, latitude)
    flowline_col : str
        Column name for flowline identifiers
    scenario_col : str
        Column name for scenario ID
    highlight_boundaries : bool
        Whether to highlight cluster boundaries (not implemented)
    show_junction_groups : bool
        Whether to show junction points on the visualization
        
    Returns:
    --------
    fig, ax : matplotlib figure and axes
        The created visualization
    """
    
    # Filter for the specific scenario
    scenario_data = df[df[scenario_col] == scenario_id].copy()
    
    # Get unique clusters
    clusters = sorted(scenario_data[cluster_col].unique())
    
    # Create figure
    figsize = (12, 10)
    fig, ax = plt.subplots(figsize=figsize)
    
    # Color palette for clusters
    colors = plt.cm.tab10(np.linspace(0, 1, len(clusters)))
    
    # Plot flowlines with cluster colors
    for i, cluster_id in enumerate(clusters):
        if cluster_id < 0:
            continue  # Skip unclustered points
            
        cluster_data = scenario_data[scenario_data[cluster_col] == cluster_id]
        
        # Plot each branch in this cluster
        for branch in cluster_data[flowline_col].unique():
            branch_data = cluster_data[cluster_data[flowline_col] == branch]
            
            # Sort by distance if available
            if 'measuredDistance meters' in branch_data.columns:
                branch_data = branch_data.sort_values('measuredDistance meters')
            
            # Plot the branch line
            ax.plot(branch_data[x_col], branch_data[y_col], '-', color=colors[i % len(colors)], 
                   linewidth=1.5, alpha=0.7)
            
            # Plot points
            ax.scatter(branch_data[x_col], branch_data[y_col], 
                      color=colors[i % len(colors)], s=15, alpha=0.5)
    
    # Plot junction points if available
    if junctions is not None and show_junction_groups:
        junction_points = np.array(junctions)
        ax.scatter(junction_points[:, 0], junction_points[:, 1], 
                  color='black', marker='*', s=80, alpha=0.7,
                  label='Junctions')
                  
        # Add numeric labels for junctions
        for i, junction in enumerate(junction_points):
            ax.annotate(str(i), (junction[0], junction[1]), 
                       fontsize=8, ha='center', va='center',
                       bbox=dict(boxstyle="circle", fc="white", ec="black", alpha=0.7))
    
    # Set labels and title
    ax.set_xlabel('Longitude')
    ax.set_ylabel('Latitude')
    ax.set_title(f'Branch-Based Clustering - Scenario {scenario_id}')
    
    # Add legend for clusters
    for i, cluster_id in enumerate(clusters):
        if cluster_id >= 0:  # Skip unclustered points
            plt.plot([], [], '-', color=colors[i % len(colors)], 
                    label=f'Cluster {cluster_id}')
    
    ax.legend(loc='upper right')
    
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    return fig, ax