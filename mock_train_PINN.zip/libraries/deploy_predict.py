"""
deploy_predict.py — save the trained per-trunk BADI surrogate and run inference on
UNSEEN scenarios from ONLY the 5 deployment inputs.

The 5 deployment inputs (Configuration.INPUT_COLS):
    FlowrateLiquidInsitu, Watercut, ElevationDifference, TotalDistance, PipeInsideDiameter

Of these, three (ElevationDifference, TotalDistance, PipeInsideDiameter) are STATIC
trunk geometry baked into the saved topology template; the operating point is the
remaining two (FlowrateLiquidInsitu, Watercut) at the source node(s). Everything a
scenario needs is reconstructed from those:

    source (flow, watercut)
      --reconstruct_source_only(split_priors)-->  per-node flow & watercut
      --velocity_from_flow(flow, diameter)     -->  VelocityLiquid           (deployable)
      --liquid_density_from_watercut(wc)       -->  DensityLiquidInSitu      (deployable)
      lambda_friction := 1.0                    -->  absorbed by per-flowline f0 (deployable)
      --backbone_pressure(coeffs)              -->  P_backbone (level, ~99%)
      --PI-KAN(segment features) * scale       -->  per-segment delta
      --integrate_pressure(P_bb, A, delta)     -->  P_node = P_bb + A@delta  (sink-anchored)

WHY lambda=1: the training `lambda_friction` column is PIPESIM's per-flowline
CALIBRATION multiplier and does not exist on an unseen network. The backbone is fit
with lambda==1 so its ridge-regularised per-flowline f0 absorbs the mean calibration;
inference then reproduces exactly the same friction integral the model was trained on.
For this to hold, the notebook MUST also fit/apply the backbone with lambda==1 and the
derived velocity (see `deployable_backbone_columns` — it is the single source of truth
for both training and inference).

Nothing here needs the PIPESIM Pressure/VelocityLiquid/lambda_friction columns at
inference time.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .backbone_reconstruction import velocity_from_flow, backbone_pressure
from . import physics_decoder as pdc
from . import multitrunk as mt


# ===========================================================================
#  SINGLE SOURCE OF TRUTH: make a frame's backbone columns deployable
# ===========================================================================
def deployable_backbone_columns(df, *, rho_oil, rho_water,
                                flow_col="FlowrateLiquidInsitu",
                                wc_col="Watercut",
                                diam_col="PipeInsideDiameter",
                                vel_col="VelocityLiquid",
                                rho_col="DensityLiquidInSitu",
                                lam_col="lambda_friction"):
    """Overwrite (in place, on a copy) the three backbone driver columns with values
    reconstructible from the 5 inputs, so the backbone is identical in training and
    deployment:

        VelocityLiquid       <- velocity_from_flow(flow, diameter)   (superficial)
        DensityLiquidInSitu  <- liquid_density_from_watercut(wc)
        lambda_friction      <- 1.0   (per-flowline f0 absorbs the calibration)

    Call this on the TRAIN frame before fit_backbone AND on every inference frame,
    with the same rho_oil/rho_water, so train==deploy. Returns the modified copy.
    """
    d = df.copy()
    d[vel_col] = velocity_from_flow(d[flow_col].to_numpy(float),
                                    d[diam_col].to_numpy(float))
    d[rho_col] = pdc.liquid_density_from_watercut(
        d[wc_col].to_numpy(float), rho_oil, rho_water)
    d[lam_col] = 1.0
    return d


# ===========================================================================
#  SAVE  /  LOAD
# ===========================================================================
def _topo_to_dict(topo: "pdc.SegmentTopology"):
    return {
        "seg_up": topo.seg_up, "seg_down": topo.seg_down, "A": topo.A,
        "seg_dl": topo.seg_dl, "seg_dz": topo.seg_dz, "seg_dmean": topo.seg_dmean,
        "sink_pos": topo.sink_pos, "flowline_of_node": topo.flowline_of_node,
    }


def _topo_from_dict(d):
    return pdc.SegmentTopology(
        d["seg_up"], d["seg_down"], d["A"], d["seg_dl"], d["seg_dz"],
        d["seg_dmean"], d["sink_pos"], d["flowline_of_node"])


def save_trunk_artifacts(path, *, trunk, model, seg_scaler, backbone_coeffs, topo,
                         topology_template, split_priors, trunk_structure, config):
    """Persist everything needed to predict a trunk from 5 inputs, into one file.

    Parameters
    ----------
    path              : output file (e.g. f"badi_{trunk}.pt").
    model             : trained PI-KAN (its state_dict is saved).
    seg_scaler        : fitted MinMaxScaler over segment features (scale_/min_ saved).
    backbone_coeffs   : dict from fit_backbone (must have been fit with lambda==1).
    topo              : SegmentTopology for this trunk.
    topology_template : static per-trunk node frame (canonical geometry + node_type +
                        coords). Must carry: BranchEquipment, TotalDistance, Elevation,
                        ElevationDifference, PipeInsideDiameter, long, lat, node_type,
                        node_id, gsid.
    split_priors      : junction split priors for reconstruct_source_only.
    trunk_structure   : (junction_graph, flowline_order, source_flowlines).
    config            : dict of the constants used (INPUT_COLS, PER_SEG_DELTA_SCALE,
                        N_OUT, KAN_HIDDEN_WIDTH, KAN_NUM_LAYERS, pressure_activation,
                        RHO_OIL_INSITU, RHO_WATER_INSITU, SINK_PRESSURE_PSI, ...).
    """
    import torch
    bundle = {
        "format": "badi_trunk_v1",
        "trunk": trunk,
        "model_state_dict": model.state_dict(),
        "model_build": {
            "n_input": len(config["INPUT_COLS"]) + 2,
            "n_output": config["N_OUT"],
            "hidden_width": config["KAN_HIDDEN_WIDTH"],
            "num_layers": config["KAN_NUM_LAYERS"],
            "pressure_activation": config.get("pressure_activation", "tanh"),
        },
        "seg_scaler": {"scale_": np.asarray(seg_scaler.scale_, np.float64),
                       "min_": np.asarray(seg_scaler.min_, np.float64)},
        "backbone_coeffs": backbone_coeffs,
        "topo": _topo_to_dict(topo),
        "topology_template": topology_template.reset_index(drop=True),
        "split_priors": split_priors,
        "trunk_structure": trunk_structure,
        "config": config,
    }
    torch.save(bundle, path)
    return path


def load_trunk_artifacts(path, device=None):
    """Load a bundle and rebuild the live model. Returns a dict with a ready model,
    the SegmentTopology, and all inference inputs."""
    import torch
    from .pikan_trainer import build_pikan
    b = torch.load(path, map_location=device or "cpu", weights_only=False)
    mb = b["model_build"]
    model = build_pikan(mb["n_input"], mb["n_output"],
                        hidden_width=mb["hidden_width"], num_layers=mb["num_layers"],
                        pressure_activation=mb["pressure_activation"],
                        device=device, verbose=False)
    model.load_state_dict(b["model_state_dict"])
    model.eval()
    return {
        "trunk": b["trunk"], "model": model,
        "seg_scaler": b["seg_scaler"],
        "backbone_coeffs": b["backbone_coeffs"],
        "topo": _topo_from_dict(b["topo"]),
        "topology_template": b["topology_template"],
        "split_priors": b["split_priors"],
        "trunk_structure": b["trunk_structure"],
        "config": b["config"], "device": device,
    }


def _apply_scaler(X, scaler_dict):
    """MinMaxScaler.transform without sklearn: X_scaled = X*scale_ + min_."""
    return X * scaler_dict["scale_"][None, :] + scaler_dict["min_"][None, :]


# ===========================================================================
#  PER-CPF BUNDLE  (one file per CPF, holding all its trunks)
# ===========================================================================
def _trunk_artifact_to_dict(*, model, seg_scaler, backbone_coeffs, topo,
                            topology_template, split_priors, trunk_structure, config):
    """Serialize one trunk's artifacts (without top-level format/config wrapping)."""
    return {
        "model_state_dict": model.state_dict(),
        "model_build": {
            "n_input": len(config["INPUT_COLS"]) + 2,
            "n_output": config["N_OUT"],
            "hidden_width": config["KAN_HIDDEN_WIDTH"],
            "num_layers": config["KAN_NUM_LAYERS"],
            "pressure_activation": config.get("pressure_activation", "tanh"),
        },
        "seg_scaler": {"scale_": np.asarray(seg_scaler.scale_, np.float64),
                       "min_": np.asarray(seg_scaler.min_, np.float64)},
        "backbone_coeffs": backbone_coeffs,
        "topo": _topo_to_dict(topo),
        "topology_template": topology_template.reset_index(drop=True),
        "split_priors": split_priors,
        "trunk_structure": trunk_structure,
    }


def save_cpf_bundle(path, *, cpf, trunks, config):
    """Persist ALL trunks of one CPF into a single file — the deployment analogue of
    the old per-CPF multi-trunk `.pth`.

    Parameters
    ----------
    path   : output file, e.g. f"badi_{cpf}.pt".
    cpf    : CPF label ("CPF1"/"CPF2").
    trunks : {trunk_name: dict(model, seg_scaler, backbone_coeffs, topo,
              topology_template, split_priors, trunk_structure)}. Each backbone_coeffs
              MUST have been fit with lambda==1 (see deployable_backbone_columns) so
              inference reproduces the training friction integral.
    config : shared training constants (INPUT_COLS, N_OUT, KAN_HIDDEN_WIDTH,
             KAN_NUM_LAYERS, PER_SEG_DELTA_SCALE, RHO_OIL_INSITU, RHO_WATER_INSITU,
             SINK_PRESSURE_PSI, pressure_activation, ...).
    """
    import torch
    bundle = {"format": "badi_cpf_v1", "cpf": cpf, "config": config, "trunks": {}}
    for tr, a in trunks.items():
        bundle["trunks"][tr] = _trunk_artifact_to_dict(config=config, **a)
    torch.save(bundle, path)
    return path


def load_cpf_bundle(path, device=None):
    """Load a per-CPF bundle and rebuild every trunk's live model. Returns
        {"cpf", "config", "trunks": {trunk_name: <ready artifacts dict>}}
    where each trunk artifacts dict is directly usable by predict_frame/predict_network.
    """
    import torch
    from .pikan_trainer import build_pikan
    b = torch.load(path, map_location=device or "cpu", weights_only=False)
    cfg = b["config"]
    trunks = {}
    for tr, t in b["trunks"].items():
        mb = t["model_build"]
        model = build_pikan(mb["n_input"], mb["n_output"],
                            hidden_width=mb["hidden_width"], num_layers=mb["num_layers"],
                            pressure_activation=mb["pressure_activation"],
                            device=device, verbose=False)
        model.load_state_dict(t["model_state_dict"])
        model.eval()
        trunks[tr] = {
            "trunk": tr, "model": model,
            "seg_scaler": t["seg_scaler"],
            "backbone_coeffs": t["backbone_coeffs"],
            "topo": _topo_from_dict(t["topo"]),
            "topology_template": t["topology_template"],
            "split_priors": t["split_priors"],
            "trunk_structure": t["trunk_structure"],
            "config": cfg, "device": device,
        }
    return {"cpf": b["cpf"], "config": cfg, "trunks": trunks}


def predict_network(cpf_bundle, network_topology, *, trunk_col="Troncal",
                    node_id_col="node_id", pressure_col_out="Pressure_Pred_PINN",
                    verbose=True):
    """Predict per-node pressure for a whole CPF network in one call.

    `network_topology` is the assembled per-node frame from
    build_flows_from_sources_and_junctions: each node already carries
    FlowrateLiquidInsitu, Watercut and static geometry. This groups nodes by trunk,
    runs each trunk's BADI model, and writes predictions back onto a copy of the
    input frame (original row order preserved). Trunks with no matching model get NaN.

    Returns (predictions_df, report_dict).
    """
    trunks = cpf_bundle["trunks"]
    out = network_topology.copy().reset_index(drop=True)
    out[pressure_col_out] = np.nan
    out["P_backbone"] = np.nan

    report = {"trunks_predicted": [], "trunks_skipped": [], "n_nodes": {}}
    for tr, sub in out.groupby(trunk_col, sort=False):
        art = trunks.get(tr)
        if art is None:
            report["trunks_skipped"].append(tr)
            if verbose:
                print(f"  [skip] no model for trunk '{tr}' ({len(sub)} nodes)")
            continue
        try:
            pred = _predict_core(art, sub)
        except Exception as e:  # geometry/node-count mismatch etc. — report, don't crash
            report["trunks_skipped"].append(tr)
            if verbose:
                print(f"  [skip] trunk '{tr}': {e}")
            continue
        # map predictions back onto `out` by node_id when present, else by (branch, dist)
        if node_id_col in sub.columns and node_id_col in pred.columns:
            key = pred.set_index(node_id_col)
            for col in ("P_backbone", "P_pred"):
                out.loc[out[trunk_col] == tr, {"P_pred": pressure_col_out}.get(col, col)] = (
                    out.loc[out[trunk_col] == tr, node_id_col].map(key[col]).values)
        else:
            keyed = pred.set_index(["BranchEquipment", "TotalDistance"])
            m = out[trunk_col] == tr
            idx = list(zip(out.loc[m, "BranchEquipment"], out.loc[m, "TotalDistance"]))
            out.loc[m, "P_backbone"] = [keyed["P_backbone"].get(k, np.nan) for k in idx]
            out.loc[m, pressure_col_out] = [keyed["P_pred"].get(k, np.nan) for k in idx]
        report["trunks_predicted"].append(tr)
        report["n_nodes"][tr] = len(sub)
        if verbose:
            print(f"  [ok]   trunk '{tr}': {len(sub)} nodes")
    return out, report


# ===========================================================================
#  INFERENCE FROM 5 INPUTS
# ===========================================================================
def build_scenario_frame(artifacts, source_spec):
    """Assemble a full per-node scenario frame for an unseen operating point.

    source_spec: either
        - a scalar/2-tuple giving (flow, watercut) applied to ALL source flowlines
          when the trunk has a single source, or a float flow (watercut defaults 0.9);
        - a dict {source_flowline_name: (flow, watercut)} for multi-source trunks;
        - a full DataFrame already carrying FlowrateLiquidInsitu & Watercut per node
          (only the source-node values must be correct; the rest are reconstructed).

    Returns a frame in the trunk's node order with FlowrateLiquidInsitu & Watercut
    source-propagated across the whole trunk.
    """
    tmpl = artifacts["topology_template"].copy()
    jg, order, source_fls = artifacts["trunk_structure"]

    if isinstance(source_spec, pd.DataFrame):
        base = source_spec.copy()
    else:
        base = tmpl.copy()
        if "FlowrateLiquidInsitu" not in base.columns:
            base["FlowrateLiquidInsitu"] = np.nan
        if "Watercut" not in base.columns:
            base["Watercut"] = np.nan
        if isinstance(source_spec, dict):
            spec = source_spec
        else:
            # scalar/tuple -> apply to every source flowline
            if np.isscalar(source_spec):
                flow, wc = float(source_spec), 0.9
            else:
                flow, wc = float(source_spec[0]), float(source_spec[1])
            spec = {fl: (flow, wc) for fl in source_fls}
        for fl, (flow, wc) in spec.items():
            m = (base["BranchEquipment"] == fl)
            base.loc[m, "FlowrateLiquidInsitu"] = flow
            base.loc[m, "Watercut"] = wc

    # propagate source flow/watercut across the trunk (deployment-aligned inputs)
    rec = mt._reconstruct_source_only_for_scenario(
        base, split_priors=artifacts["split_priors"],
        structure=(jg, order, source_fls))
    base.loc[rec.index, ["FlowrateLiquidInsitu", "Watercut"]] = \
        rec[["FlowrateLiquidInsitu", "Watercut"]].values
    return base


def _predict_core(artifacts, frame):
    """Core inference for ONE trunk from a per-node frame that already carries the 5
    inputs (per-node FlowrateLiquidInsitu + Watercut + static geometry). Shared by
    predict_scenario (source_spec path) and predict_frame (pre-assembled ensamble
    path). Returns the canonical-order frame with P_backbone and P_pred added.
    """
    import torch
    cfg = artifacts["config"]
    device = artifacts["device"] or "cpu"
    topo = artifacts["topo"]
    co = artifacts["backbone_coeffs"]
    INPUT_COLS = cfg["INPUT_COLS"]
    rho_oil = cfg["RHO_OIL_INSITU"]; rho_water = cfg["RHO_WATER_INSITU"]

    # 1) make backbone drivers deployable (velocity/density/lambda) — SAME as training
    frame = deployable_backbone_columns(frame, rho_oil=rho_oil, rho_water=rho_water)

    # 2) backbone pressure (level) from the deployable columns
    frame = _backbone_single(frame, co)

    # 3) canonical order + segment features + scaling
    sd = pdc.align_scenario_frame(frame)
    if len(sd) != topo.n_nodes:
        raise ValueError(f"scenario has {len(sd)} nodes but topology expects "
                         f"{topo.n_nodes}; template/geometry mismatch.")
    feat = pdc.scenario_segment_features(sd, topo, INPUT_COLS)
    Xs = _apply_scaler(feat, artifacts["seg_scaler"]).astype(np.float32)

    # 4) PI-KAN -> per-segment delta -> integrate from the anchored backbone
    P_bb = sd["P_backbone"].to_numpy(np.float32)
    with torch.no_grad():
        X_t = torch.tensor(Xs, dtype=torch.float32, device=device)
        out = artifacts["model"](X_t)
        delta = out[:, 0] * float(cfg["PER_SEG_DELTA_SCALE"])
        A_t = torch.tensor(topo.A, dtype=torch.float32, device=device)
        P_bb_t = torch.tensor(P_bb, dtype=torch.float32, device=device)
        P_pred = pdc.integrate_pressure(P_bb_t, A_t, delta).cpu().numpy()

    sd = sd.copy()
    sd["P_backbone"] = P_bb
    sd["P_pred"] = P_pred
    return sd


def predict_scenario(artifacts, source_spec):
    """Predict node pressure (psi) for one unseen scenario from the 5 inputs, where
    only the SOURCE operating point is given and the rest of the trunk is
    reconstructed via split priors.

    Returns a DataFrame in canonical node order with columns:
        node_id, BranchEquipment, TotalDistance, P_backbone, P_pred.
    """
    frame = build_scenario_frame(artifacts, source_spec)
    sd = _predict_core(artifacts, frame)
    return pd.DataFrame({
        "node_id": sd["node_id"] if "node_id" in sd.columns
                   else pd.Series(np.arange(len(sd))),
        "BranchEquipment": sd["BranchEquipment"].values,
        "TotalDistance": sd["TotalDistance"].values,
        "P_backbone": sd["P_backbone"].values,
        "P_pred": sd["P_pred"].values,
    })


def predict_frame(artifacts, node_frame, *, pressure_col_out="Pressure_Pred_PINN"):
    """Predict node pressure for ONE trunk from a per-node frame that is ALREADY
    assembled (e.g. the output of build_flows_from_sources_and_junctions), i.e. flow
    and watercut are already present at every node — no source reconstruction needed.

    Returns a copy of node_frame (canonical order) with `P_backbone` and
    `pressure_col_out` columns added.
    """
    sd = _predict_core(artifacts, node_frame)
    return sd.rename(columns={"P_pred": pressure_col_out})


def _backbone_single(frame, co):
    """add P_backbone to a single-scenario frame (no scen grouping)."""
    idx, pbb = backbone_pressure(frame, co)
    frame = frame.copy()
    frame["P_backbone"] = np.nan
    frame.loc[idx, "P_backbone"] = pbb
    if frame["P_backbone"].isna().any():
        # fall back: unreached nodes anchor to sink pressure
        frame["P_backbone"] = frame["P_backbone"].fillna(co["sink_pressure"])
    return frame
