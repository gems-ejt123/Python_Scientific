
import torch
import numpy as np

def scale_data(data_tensor):
    """
    Scale data to range [0, 1] for each feature.
    
    Parameters:
        data_tensor: Tensor with data to scale
        
    Returns:
        scaled_tensor, min_vals, max_vals
    """
    min_vals = torch.min(data_tensor, dim=0)[0]
    max_vals = torch.max(data_tensor, dim=0)[0]
    
    # Handle cases where min and max are the same (constant features)
    range_vals = max_vals - min_vals
    range_vals[range_vals == 0] = 1.0  # Avoid division by zero
    
    scaled_tensor = (data_tensor - min_vals) / range_vals
    
    return scaled_tensor, min_vals, max_vals

def scale_features(features, min_vals, max_vals):
    """
    Scale features to range [0, 1] using provided min/max values.
    
    Args:
        features: 2D array of feature values
        min_vals: Minimum values for each feature
        max_vals: Maximum values for each feature
        
    Returns:
        Scaled features
    """
    # Convert to numpy arrays if needed
    min_vals = np.array(min_vals)
    max_vals = np.array(max_vals)
    
    # Handle cases where min and max are the same (constant features)
    range_vals = max_vals - min_vals
    range_vals[range_vals == 0] = 1.0  # Avoid division by zero
    
    # Scale to [0, 1] range
    scaled_features = (features - min_vals) / range_vals
    
    return scaled_features

def inverse_scale_features(scaled_features, min_vals, max_vals):
    """
    Inverse scale features from [0, 1] range back to original range.
    
    Args:
        scaled_features: 2D array of scaled feature values in [0, 1] range
        min_vals: Minimum values for each feature
        max_vals: Maximum values for each feature
        
    Returns:
        Features in original scale
    """
    # Convert to numpy arrays if needed
    min_vals = np.array(min_vals)
    max_vals = np.array(max_vals)
    
    # Inverse scale from [0, 1] to original range
    original_features = scaled_features * (max_vals - min_vals) + min_vals
    
    return original_features

def calculate_elevation_differences(df, elevation_col="Elevation", 
                                  distance_col="TotalDistance", 
                                  flowline_col="BranchEquipment",
                                  node_type_col="node_type",
                                  source_node_type=1):
    """
    Calculate elevation differences between nodes and source nodes using vectorized operations.
    
    Parameters:
        df: DataFrame with pipeline data
        elevation_col: Column name for elevation
        distance_col: Column name for distance
        flowline_col: Column name for flowline identifiers
        node_type_col: Column name for node type
        source_node_type: Node type identifier for sources
        
    Returns:
        DataFrame with added 'ElevationDifference' column
    """
    import pandas as pd
    
    # Create a copy with reset index for consistency
    result_df = df.copy().reset_index(drop=True)
    
    # Create source reference mapping using vectorized operations
    # Find all source nodes first
    source_mask = result_df[node_type_col] == source_node_type
    source_df = result_df[source_mask].copy()
    
    if source_df.empty:
        # If no sources found, use first node of each flowline as reference
        reference_df = result_df.groupby(flowline_col)[elevation_col].first().reset_index()
        reference_df.columns = [flowline_col, 'reference_elevation']
    else:
        # Group sources by flowline and take first source per flowline
        reference_df = (source_df.groupby(flowline_col)[elevation_col]
                       .first()
                       .reset_index())
        reference_df.columns = [flowline_col, 'reference_elevation']
        
        # For flowlines without sources, use the first node as reference
        all_flowlines = set(result_df[flowline_col].unique())
        flowlines_with_sources = set(reference_df[flowline_col].unique())
        flowlines_without_sources = all_flowlines - flowlines_with_sources
        
        if flowlines_without_sources:
            no_source_ref = (result_df[result_df[flowline_col].isin(flowlines_without_sources)]
                           .groupby(flowline_col)[elevation_col]
                           .first()
                           .reset_index())
            no_source_ref.columns = [flowline_col, 'reference_elevation']
            reference_df = pd.concat([reference_df, no_source_ref], ignore_index=True)
    
    # Merge reference elevations with the main dataframe
    result_df = result_df.merge(reference_df, on=flowline_col, how='left')
    
    # Calculate elevation difference vectorized
    result_df['ElevationDifference'] = result_df[elevation_col] - result_df['reference_elevation']
    
    # Drop the temporary reference column
    result_df.drop('reference_elevation', axis=1, inplace=True)
    
    return result_df

def add_source_pressure(df, source_node_type=1, scenario_ids=None):
    """
    Add source pressure as a feature for each node.
    
    Parameters:
        df: DataFrame with pipeline data
        source_node_type: Node type identifier for sources
        scenario_ids: List of scenario IDs to process (None = all scenarios)
        
    Returns:
        DataFrame with added 'SourcePressure' column
    """
    result_df = df.copy()
    result_df['SourcePressure'] = 0.0
    
    # Get scenarios to process
    if scenario_ids is None:
        scenarios = df['scenario'].unique()
    else:
        scenarios = scenario_ids
    
    # Process each scenario
    for scenario in scenarios:
        scenario_df = df[df['scenario'] == scenario]
        
        # Process each flowline
        for flowline in scenario_df['BranchEquipment'].unique():
            flowline_df = scenario_df[scenario_df['BranchEquipment'] == flowline]
            
            # Find source nodes
            source_nodes = flowline_df[flowline_df['node_type'] == source_node_type]
            
            if not source_nodes.empty:
                # Use pressure from first source node
                source_pressure = source_nodes.iloc[0]['Pressure']
                
                # Update all nodes in this flowline
                node_indices = flowline_df.index
                result_df.loc[node_indices, 'SourcePressure'] = source_pressure
    
    return result_df

def prepare_source_based_dataset(df, source_input_cols, source_node_type=1, scenario_ids=None):
    """
    Prepare dataset with source-based inputs using vectorized operations.
    
    Parameters:
        df: DataFrame with pipeline data
        source_input_cols: List of columns to get from source nodes
        source_node_type: Node type identifier for sources
        scenario_ids: List of scenario IDs to process (None = all scenarios)
        
    Returns:
        DataFrame with source-based inputs
    """
    import pandas as pd
    
    result_df = df.copy()
    
    # Get scenarios to process
    if scenario_ids is None:
        scenarios = df['scenario'].unique()
    else:
        scenarios = scenario_ids
    
    # Filter data to only process specified scenarios
    scenario_mask = result_df['scenario'].isin(scenarios)
    process_df = result_df[scenario_mask].copy()
    
    # Create source reference mapping for all scenarios at once
    source_mask = process_df['node_type'] == source_node_type
    source_df = process_df[source_mask].copy()
    
    if not source_df.empty:
        # Group sources by scenario and flowline, take first source per combination
        source_reference = (source_df.groupby(['scenario', 'BranchEquipment'])[source_input_cols]
                          .first()
                          .reset_index())
        
        # Create a temporary key for merging
        process_df['merge_key'] = process_df['scenario'].astype(str) + '_' + process_df['BranchEquipment'].astype(str)
        source_reference['merge_key'] = source_reference['scenario'].astype(str) + '_' + source_reference['BranchEquipment'].astype(str)
        
        # Merge source values with all nodes
        merged_df = process_df.merge(source_reference[['merge_key'] + source_input_cols], 
                                   on='merge_key', how='left', suffixes=('', '_source'))
        
        # Update the columns with source values where available
        for col in source_input_cols:
            source_col = f"{col}_source"
            if source_col in merged_df.columns:
                # Update non-null values
                mask = merged_df[source_col].notna()
                merged_df.loc[mask, col] = merged_df.loc[mask, source_col]
                # Drop temporary column
                merged_df.drop(source_col, axis=1, inplace=True)
        
        # Drop temporary merge key
        merged_df.drop('merge_key', axis=1, inplace=True)
        
        # Update the result dataframe
        result_df.loc[scenario_mask] = merged_df
    
    return result_df