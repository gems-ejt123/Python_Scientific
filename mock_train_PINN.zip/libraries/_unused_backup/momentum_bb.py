"""
Corrected Beggs & Brill momentum loss for the trunk PINN.

Fixes the physics term that never helped. Two changes matter:

1. `lambda_friction` in the data is the PIPESIM friction-factor CALIBRATION
   multiplier (per-flowline, default 1.0), not the Darcy friction factor. The
   old loss plugged it straight into the `f` slot of f*rho*v^2/(2d), giving a
   friction drop ~22x too steep. The physical Darcy factor is
   `f_eff = f0 * lambda_friction`, with a single base `f0` fitted from data
   (see `fit_base_friction`; ~0.028 for this trunk). That puts f_eff in
   [0.0004, 0.21], matching the Beggs & Brill paper's lambda range.

2. Per-segment pressure drop (~0.3 psi) is noise. The momentum constraint only
   carries signal at the CUMULATIVE flowline scale (held-out R^2 ~0.75). So the
   residual compares the model's end-to-end pressure drop along each flowline to
   the drop integrated from the calibrated closure, not segment by segment.

Single-phase liquid: HL = 1, gas terms drop out, and the Beggs & Brill velocity
correction bracket -> 1, so Eq. 6 reduces to gravity + Darcy friction.

Gradients flow through the model's predicted pressures. Everything else (density,
velocity, elevation, lambda) comes from data columns and is treated as constant.
"""

from __future__ import annotations

import numpy as np

# torch is imported lazily inside compute_momentum_bb_loss so the pure-data
# calibration helpers (fit_base_friction, _segment_physics_drop) run without it.

G = 32.174           # ft/s^2
GC = 32.174          # lbm-ft/(lbf-s^2)
PSI = 144.0          # lbf/ft^2 per psi


def _segment_physics_drop(g, f0, flowline_dist, elev_col, single_phase=True):
    """Integrated pressure drop (psi) along one flowline from the calibrated
    closure. Data-only, returned as a float (no gradient)."""
    P = g["Pressure"].to_numpy(np.float64)          # only for shape / fallback
    L = g[flowline_dist].to_numpy(np.float64)
    z = g[elev_col].to_numpy(np.float64)
    v = g["VelocityLiquid"].to_numpy(np.float64)
    rho = g["DensityLiquidInSitu"].to_numpy(np.float64)
    d = g["PipeInsideDiameter"].to_numpy(np.float64) / 12.0
    lam = g["lambda_friction"].to_numpy(np.float64)

    drop = 0.0
    for i in range(len(g) - 1):
        dl = L[i + 1] - L[i]
        if dl <= 0:
            continue
        vv = 0.5 * (v[i] + v[i + 1])
        rr = 0.5 * (rho[i] + rho[i + 1])
        dd = 0.5 * (d[i] + d[i + 1])
        gravity = rr * (z[i] - z[i + 1]) / PSI
        friction = f0 * lam[i] * rr * vv * vv * dl / (2.0 * dd) / (GC * PSI)
        drop += gravity + friction
    return drop


def compute_momentum_bb_loss(model, batch_data, input_cols, output_cols,
                             input_min, input_max, output_min, output_max,
                             f0, flowline_col="BranchEquipment",
                             distance_col="TotalDistance", elev_col="Elevation",
                             single_phase=True, device=None, pressure_inverse=None):
    """Cumulative Beggs & Brill momentum loss.

    For each flowline: the model's end-to-end predicted drop must match the drop
    integrated from `f0 * lambda_friction` + hydrostatic gravity. Returns a scalar
    loss with gradient through the model's pressure output.

    `pressure_inverse`: optional callable mapping scaled model output [-1, 1] to
    psi (e.g. `QuantileWarp.inverse_torch`). If None, linear MinMax is used.
    """
    import torch
    import torch.nn.functional as F
    from libraries.memory_utils import get_device

    if device is None:
        device = get_device(force_cuda=True)

    p_idx = output_cols.index("Pressure")
    imin = torch.tensor(input_min, dtype=torch.float32, device=device)
    imax = torch.tensor(input_max, dtype=torch.float32, device=device)
    scale_in = (imax - imin).clamp_min(1e-8)
    p_min = float(output_min[p_idx])
    p_max = float(output_max[p_idx])
    p_range = max(p_max - p_min, 1e-6)

    endpoint_inputs = []   # first & last node inputs, interleaved
    targets = []           # physics drop per flowline (psi)

    for scenario_data in batch_data:
        sdf = scenario_data.reset_index(drop=True)
        for _fl, g in sdf.groupby(flowline_col, sort=False):
            g = g.sort_values(distance_col)
            if len(g) < 2:
                continue
            target = _segment_physics_drop(g, f0, distance_col, elev_col,
                                           single_phase=single_phase)
            first = g.iloc[0][input_cols].to_numpy(np.float64)
            last = g.iloc[-1][input_cols].to_numpy(np.float64)
            endpoint_inputs.append(first)
            endpoint_inputs.append(last)
            targets.append(target)

    if not targets:
        return next(model.parameters()) * 0.0

    x = torch.tensor(np.stack(endpoint_inputs), dtype=torch.float32, device=device)
    x_scaled = 2.0 * (x - imin) / scale_in - 1.0
    preds = model(x_scaled)
    p_scaled = preds[:, p_idx] if preds.dim() > 1 else preds
    if pressure_inverse is not None:
        p_phys = pressure_inverse(p_scaled)               # e.g. quantile warp
    else:
        p_phys = (p_scaled + 1.0) * 0.5 * p_range + p_min  # linear MinMax

    p_first = p_phys[0::2]
    p_last = p_phys[1::2]
    model_drop = p_first - p_last
    target = torch.tensor(targets, dtype=torch.float32, device=device)

    residual = (model_drop - target) / p_range             # dimensionless
    return F.smooth_l1_loss(residual, torch.zeros_like(residual))


def fit_base_friction(batch_data, flowline_col="BranchEquipment",
                      distance_col="TotalDistance", elev_col="Elevation"):
    """Least-squares fit of the single base friction `f0` so that
    `gravity + f0 * lambda * DarcyBase` reproduces the observed flowline drop.

    Returns (f0, r2). Run once on the training scenarios; pass f0 to the loss.
    """
    num = 0.0
    den = 0.0
    base_list, fric_list = [], []
    for scenario_data in batch_data:
        sdf = scenario_data.reset_index(drop=True)
        for _fl, g in sdf.groupby(flowline_col, sort=False):
            g = g.sort_values(distance_col)
            if len(g) < 2:
                continue
            L = g[distance_col].to_numpy(np.float64)
            z = g[elev_col].to_numpy(np.float64)
            v = g["VelocityLiquid"].to_numpy(np.float64)
            rho = g["DensityLiquidInSitu"].to_numpy(np.float64)
            d = g["PipeInsideDiameter"].to_numpy(np.float64) / 12.0
            lam = g["lambda_friction"].to_numpy(np.float64)
            P = g["Pressure"].to_numpy(np.float64)
            base = 0.0
            grav = 0.0
            for i in range(len(g) - 1):
                dl = L[i + 1] - L[i]
                if dl <= 0:
                    continue
                vv = 0.5 * (v[i] + v[i + 1])
                rr = 0.5 * (rho[i] + rho[i + 1])
                dd = 0.5 * (d[i] + d[i + 1])
                base += lam[i] * rr * vv * vv * dl / (2.0 * dd) / (GC * PSI)
                grav += rr * (z[i] - z[i + 1]) / PSI
            fric_obs = (P[0] - P[-1]) - grav
            num += base * fric_obs
            den += base * base
            base_list.append(base)
            fric_list.append(fric_obs)

    f0 = num / den if den > 0 else 0.0
    base_arr = np.array(base_list)
    fric_arr = np.array(fric_list)
    pred = f0 * base_arr
    ss = ((fric_arr - pred) ** 2).sum()
    st = ((fric_arr - fric_arr.mean()) ** 2).sum()
    r2 = 1.0 - ss / st if st > 0 else 0.0
    return float(f0), float(r2)
