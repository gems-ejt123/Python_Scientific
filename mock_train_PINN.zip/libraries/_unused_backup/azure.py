"""
###########################################################
LIBRERIA SALVAR Y LEER ARCHIVOS DESDE BLOB STORAGE DE AZURE
###########################################################
Requisitos:
- El blob storage debe tener una url base
- se debe pasar la ruta relativa desde la raiz del blob storage, para que se guarde

Ejemplo de uso
    uri_base = "https://saaeuecpdevhubupstprdyp.blob.core.windows.net/rubiales-on-off"
    ruta_relativa = "Datos Modelos Surrogados RUBIALES/BW.csv"

    full_blob_url = azure.urljoin(uri_base + "/", archivo_escribir_csv)

    # Leer archivo
    df = read_blob_file(full_blob_url)
    print(df.head())

    # Escribir archivo en formato CSV
    msg = write_blob_file(full_blob_url, df, 'csv', ";")
    print(msg)

    # Escribir archivo en formato Excel
    msg = write_blob_file(full_blob_url, df, 'excel')
    print(msg)

    # Salvar un modelo de torch
    msg = save_torch_model_to_blob(full_blob_url, model, in_min, in_max, out_min, out_max, INPUT_COLS, OUTPUT_COLS, activation_types, train_scenarios, val_scenarios, history, save_to_log, log_file)
    print(msg)

GET (c) 2025

"""


from azure.storage.blob import BlobClient, ContainerClient
# from azure.identity import DefaultAzureCredential USADO EN NUBE o COMPUTER INSTANCES EN AZURE ML
from azure.identity import AzureCliCredential  #USADO EN LOCAL

import pandas as pd
import io
import zipfile
from urllib.parse import urlparse, urljoin
from typing import List
import torch
import os




def listar_archivos_por_patron(blob_directory_url: str, patron: str) -> List[str]:
    """
    Lista archivos desde una carpeta en Azure Blob Storage que coincidan con un patrón específico.

    Args:
    blob_directory_url (str): URL completa del directorio en Azure Blob Storage.
    patron (str): Patrón de nombre de archivo, por ejemplo 'cl_escenario*.csv'.

    Returns:
    List[str]: Lista con los nombres de los archivos encontrados que coinciden con el patrón.
    """
    parsed = urlparse(blob_directory_url)
    account_url = f"https://{parsed.netloc}"
    path_parts = parsed.path.strip("/").split("/")
    container_name = path_parts[0]
    prefix = "/".join(path_parts[1:])

    credential = AzureCliCredential()
    container_client = ContainerClient(account_url=account_url,
                                       container_name=container_name,
                                       credential=credential)

    archivos = []
    try:
        blobs = container_client.list_blobs(name_starts_with=prefix)
        base_patron, extension = patron.split("*")
        for blob in blobs:
            filename = blob.name.split("/")[-1]
            if filename.startswith(base_patron) and filename.endswith(extension):
                full_url = urljoin(blob_directory_url, filename) #concat full URL to direct access to resource. otherwise, it will be relative to the container
                archivos.append(full_url)
    except Exception as e:
        print("Error al listar blobs:", e)

    return sorted(archivos)


def validar_ruta_blob(full_blob_url: str) -> bool:
    """
    Valida si una ruta (archivo o carpeta) existe en Azure Blob Storage.

    Args:
    full_blob_url (str): Ruta absoluta del blob (archivo o carpeta).
    
    Returns:
    bool: True si la ruta existe, False en caso contrario.
    """
    parsed = urlparse(full_blob_url)
    account_url = f"https://{parsed.netloc}"
    path_parts = parsed.path.strip("/").split("/")
    container_name = path_parts[0]
    blob_path = "/".join(path_parts[1:])

    credential = AzureCliCredential()

    # Primero intentamos como archivo
    blob_client = BlobClient(account_url=account_url,
                             container_name=container_name,
                             blob_name=blob_path,
                             credential=credential)
    try:
        blob_client.get_blob_properties()
        return True
    except Exception:
        pass  # Si no es archivo, intentamos como carpeta

    # Intentamos como carpeta (prefijo)
    container_client = ContainerClient(account_url=account_url,
                                       container_name=container_name,
                                       credential=credential)
    blob_list = container_client.list_blobs(name_starts_with=blob_path)
    try:
        return any(True for _ in blob_list)
    except Exception:
        return False


def read_blob_file(full_blob_url: str, file_format="csv", separator=",", read_zip=False) -> pd.DataFrame:
    """
    Lee un archivo desde Azure Blob Storage y devuelve un DataFrame.
    
    Args:
    full_blob_url (str): Ruta absoluta del blob (archivo o carpeta).
    file_format (str): Formato en el que se desea leer el archivo ('csv' o 'excel').
    separator (str): Separador a emplear si y solo si es csv. Por defecto es ",".
    read_zip (bool): Si el archivo CSV está comprimido en un ZIP. Por defecto es False.
    
    Returns:
    pd.DataFrame: DataFrame con los datos del archivo leído. Si hay un error, devuelve un DataFrame vacío.
    """
    parsed = urlparse(full_blob_url)
    account_url = f"https://{parsed.netloc}"
    container_name = parsed.path.strip("/").split("/")[0]
    blob_path = "/".join(parsed.path.strip("/").split("/")[1:])

    credential = AzureCliCredential()
    blob_client = BlobClient(account_url=account_url,
                             container_name=container_name,
                             blob_name=blob_path,
                             credential=credential)

    try:
        download_stream = blob_client.download_blob()
        blob_bytes = io.BytesIO(download_stream.readall())

        if file_format == 'csv':
            if read_zip:
                with zipfile.ZipFile(blob_bytes) as z:
                    csv_filename = z.namelist()[0]
                    with z.open(csv_filename) as f:
                        df = pd.read_csv(f, sep=separator)
            else:
                df = pd.read_csv(blob_bytes, sep=separator)
            return df

        elif file_format == 'excel':
            df = pd.read_excel(blob_bytes)
            return df

        else:
            print("Formato de archivo no compatible. Se admiten 'csv' y 'excel'.")
            return pd.DataFrame()

    except Exception as e:
        print("Error al leer el blob:", e)
        return pd.DataFrame()



def write_blob_file(full_blob_url: str, df: pd.DataFrame, file_format: str, index=False, compression= True, compression_type="zip") -> str:
    """
    Escribe un DataFrame en un archivo en Azure Blob Storage en el formato especificado y devuelve un mensaje de confirmación. Siempre Sobreescribe!
    
    Args:
    full_blob_url (str): Ruta absoluta del blob (archivo o carpeta).
    df (pd.DataFrame): DataFrame a escribir en el archivo.
    file_format (str): Formato en el que se desea guardar el archivo ('csv' o 'excel').
    index (Bool): Si desea o no guardar el indice del df
    compression (Bool): Si desea o no compresion
    compression_type (str): tipos admitidos en pandas. Solo aplica para csv, y solo si "compression" es True
    
    Returns:
    str: Mensaje de confirmación de escritura.
    """
    
    parsed = urlparse(full_blob_url)
    account_url = f"https://{parsed.netloc}"
    container_name = parsed.path.strip("/").split("/")[0]
    blob_path = "/".join(parsed.path.strip("/").split("/")[1:])

    credential = AzureCliCredential()
    blob_client = BlobClient(account_url=account_url,
                             container_name=container_name,
                             blob_name=blob_path,
                             credential=credential)

    try:


        if file_format == 'csv':
            if compression:
                # Crear un archivo CSV comprimido en memoria, para binarizar y efectivamente quede comprimido en el blob storage
                buffer = io.BytesIO()
                with zipfile.ZipFile(buffer, mode='w', compression=zipfile.ZIP_DEFLATED) as zf:
                    with zf.open('data.csv', mode='w') as f:
                        f.write(df.to_csv(index=index).encode('utf-8'))
                buffer.seek(0)
                blob_client.upload_blob(buffer.read(), overwrite=True)            
            else:
                blob_client.upload_blob(df.to_csv(index=index), overwrite=True)
        elif file_format == 'excel':
            # Crear un objeto BytesIO para escribir el DataFrame en formato Excel
            excel_writer = io.BytesIO()
            df.to_excel(excel_writer, index=index)
            excel_writer.seek(0)
            blob_client.upload_blob(excel_writer.read(), overwrite=True)
        else:
            return "Formato de archivo no compatible. Se admiten 'csv' y 'excel'."
        
        return f"OK: Archivo escrito exitosamente en Azure Blob Storage: {full_blob_url}"
    except Exception as e:
        print("Error al escribir en el blob:", e)
        return "Error al escribir en el blob"

def delete_blob_file(full_blob_url: str) -> str:
    """
    Borra un archivo en Azure Blob Storage y devuelve un mensaje de confirmación.
    
    Args:
    full_blob_url (str): Ruta absoluta del blob (archivo o carpeta).
    
    Returns:
    str: Mensaje de confirmación de borrado.
    """
    
    parsed = urlparse(full_blob_url)
    account_url = f"https://{parsed.netloc}"
    container_name = parsed.path.strip("/").split("/")[0]
    blob_path = "/".join(parsed.path.strip("/").split("/")[1:])

    credential = AzureCliCredential()
    blob_client = BlobClient(account_url=account_url,
                             container_name=container_name,
                             blob_name=blob_path,
                             credential=credential)

    try:
        blob_client.delete_blob()
        return f"Archivo {blob_path} borrado correctamente del Azure Blob Storage."
    except Exception as e:
        print("Error al borrar el archivo en Azure Blob Storage:", e)
        return "Error al borrar el archivo en Azure Blob Storage"
    

from urllib.parse import urlparse
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobClient
import torch
import os

def save_torch_model_to_blob(full_blob_url: str, save_dict: dict, save_to_log=False, log_file=None) -> str:
    """
    Guarda un modelo de PyTorch (y metadatos) en un archivo en Azure Blob Storage y elimina el archivo local temporal.

    Args:
    full_blob_url (str): Ruta absoluta del blob (incluyendo el nombre del archivo).
    save_dict (dict): Diccionario con el estado del modelo y metadatos.
    save_to_log (bool): Si se debe guardar información en un archivo de log.
    log_file (str): Ruta del archivo de log.

    Returns:
    str: Mensaje de confirmación de guardado.
    """
    try:
        # Salvar localmente el modelo en un archivo temporal. esto es necesario porque el blob storage no permite guardar un diccionario directamente
        temp_model_filename = "temp_torch_model.pth"
        if os.path.exists(temp_model_filename):
            os.remove(temp_model_filename)
        torch.save(save_dict, temp_model_filename)        

        parsed = urlparse(full_blob_url)
        account_url = f"https://{parsed.netloc}"
        path_parts = parsed.path.strip("/").split("/")
        container_name = path_parts[0]
        blob_path = "/".join(path_parts[1:])  # Incluye el nombre del archivo

        credential = AzureCliCredential()
        blob_client = BlobClient(account_url=account_url,
                                 container_name=container_name,
                                 blob_name=blob_path,
                                 credential=credential)

        with open(temp_model_filename, "rb") as data:
            blob_client.upload_blob(data, overwrite=True)

        os.remove(temp_model_filename)

        if save_to_log and log_file:
            with open(log_file, "a") as log:
                log.write(f"Modelo guardado en: {full_blob_url}\n")

        return f"Modelo guardado exitosamente en Azure Blob Storage: {full_blob_url}"

    except Exception as e:
        raise RuntimeError(f"Error al guardar el modelo en Azure Blob Storage: {e}")






