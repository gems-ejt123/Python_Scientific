#Neural networks
import torch
import torch.nn as nn
import torch.optim as optim

from livelossplot import PlotLosses

import random
import numpy as np
import pandas as pd


def set_seed(seed):
    """
    Use this to set ALL the random seeds to a fixed value and remove randomness.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False  
    torch.backends.cudnn.enabled = False
    return True





# -------------------------------------------
# PINN Architecture Definition
# -------------------------------------------
class Surrogate_PINN_MultiActivation(nn.Module):
    def __init__(self, N_INPUT, N_OUTPUT, hidden_layers=[64, 128, 256, 128, 64], 
                 hidden_activation="relu", pressure_activation="tanh",
                 weight_norm=False, dropout_rate=0.0):
        """
        Physics-Informed Neural Network for surrogate modeling of multiphase flow
        
        Args:
            N_INPUT: Number of input features
            N_OUTPUT: Number of output variables
            hidden_layers: List defining the size of each hidden layer
            hidden_activation: Activation function for hidden layers; supported ReLU, Tanh, SiLU (Swish) y LeakyReLU
            pressure_activation: Activation function for pressure output; supported SiLU, lineal y tanh
            weight_norm: Whether to apply weight normalization
            dropout_rate: Dropout rate for regularization
        """
        super(Surrogate_PINN_MultiActivation, self).__init__()
        self.N_OUTPUT = N_OUTPUT
        self.pressure_activation_type = pressure_activation
        self.hidden_activation_type = hidden_activation
        self.dropout_rate = dropout_rate
        
        # Set activation function
        if hidden_activation == "relu":
            self.hidden_activation = nn.ReLU()
        elif hidden_activation == "tanh":
            self.hidden_activation = nn.Tanh()
        elif hidden_activation == "silu":
            self.hidden_activation = nn.SiLU()
        elif hidden_activation == "leaky_relu":
            self.hidden_activation = nn.LeakyReLU(0.1)
        else:
            raise ValueError(f"Unsupported hidden activation: {hidden_activation}")
            
        # Input layer
        self.input_layer = nn.Linear(N_INPUT, hidden_layers[0])
        if weight_norm:
            self.input_layer = nn.utils.weight_norm(self.input_layer)
            
        # Hidden layers
        self.hidden_layers = nn.ModuleList()
        for i in range(len(hidden_layers)-1):
            layer_sequence = []
            
            # Add activation
            layer_sequence.append(self.hidden_activation)
            
            # Add dropout if specified
            if dropout_rate > 0:
                layer_sequence.append(nn.Dropout(dropout_rate))
                
            # Add linear layer
            linear = nn.Linear(hidden_layers[i], hidden_layers[i+1])
            if weight_norm:
                linear = nn.utils.weight_norm(linear)
            layer_sequence.append(linear)
            
            # Add to sequence
            self.hidden_layers.append(nn.Sequential(*layer_sequence))
            
        # Feature extraction layer (final activation)
        self.feature_layer = self.hidden_activation
        
        # Output layers with different activations for different outputs
        if N_OUTPUT >= 2:
            # Pressure output
            if pressure_activation == "silu":
                self.pressure_output = nn.Sequential(
                    nn.Linear(hidden_layers[-1], 1),
                    nn.SiLU()
                )
            elif pressure_activation == "linear":
                self.pressure_output = nn.Linear(hidden_layers[-1], 1)
            elif pressure_activation == "tanh":
                self.pressure_output = nn.Sequential(
                    nn.Linear(hidden_layers[-1], 1),
                    nn.Tanh()
                )
            else:
                raise ValueError(f"Unsupported pressure activation: {pressure_activation}")
                
            # Mass flow output always uses tanh
            self.mass_flow_output = nn.Sequential(
                nn.Linear(hidden_layers[-1], 1),
                nn.Tanh()
            )
            
            # Temperature output if needed
            if N_OUTPUT >= 3:
                self.temperature_output = nn.Sequential(
                    nn.Linear(hidden_layers[-1], 1),
                    nn.Tanh()
                )
                
            # Other outputs if needed
            if N_OUTPUT > 3:
                self.other_outputs = nn.Sequential(
                    nn.Linear(hidden_layers[-1], N_OUTPUT - 3),
                    nn.Tanh()
                )
        else:
            # Single output case
            self.output_layer = nn.Sequential(
                nn.Linear(hidden_layers[-1], N_OUTPUT),
                nn.Tanh()
            )
    
    def forward(self, x):
        """Forward pass through the network"""
        # Input layer
        x = self.input_layer(x)
        
        # Hidden layers
        for layer in self.hidden_layers:
            x = layer(x)
            
        # Feature extraction
        features = self.feature_layer(x)
        
        # Output layers
        if self.N_OUTPUT >= 2:
            pressure = self.pressure_output(features)
            mass_flow = self.mass_flow_output(features)
            
            if self.N_OUTPUT >= 3:
                temperature = self.temperature_output(features)
                
                if self.N_OUTPUT > 3:
                    other = self.other_outputs(features)
                    outputs = torch.cat([pressure, mass_flow, temperature, other], dim=1)
                else:
                    outputs = torch.cat([pressure, mass_flow, temperature], dim=1)
            else:
                outputs = torch.cat([pressure, mass_flow], dim=1)
        else:
            outputs = self.output_layer(features)
            
        return outputs

    def get_activation_types(self):
        """Return dictionary of activation types for each output"""
        activation_dict = {
            "hidden": self.hidden_activation_type,
            "pressure": self.pressure_activation_type,
            "mass_flow": "tanh"
        }
        if self.N_OUTPUT >= 3:
            activation_dict["temperature"] = "tanh"
        return activation_dict


# -------------------------------------------
# Simplified Batch Loss Computation - Data Loss Only
# -------------------------------------------
# Fixed version of the compute_batch_loss function to correctly handle source data
def compute_batch_loss(model, batch_data, INPUT_COLS, OUTPUT_COLS, 
                     input_min, input_max, output_min, output_max,
                     source_node_type=1, device=torch.device("cpu")):
    """
    Compute data loss for a batch of scenarios using only source node inputs and elevation differences
    
    Args:
        model: Neural network model
        batch_data: List of dataframes, one per scenario
        INPUT_COLS: List of input column names
        OUTPUT_COLS: List of output column names
        input_min, input_max: Min/max values for input scaling
        output_min, output_max: Min/max values for output scaling
        source_node_type: Node type identifier for sources
        device: Computation device
    
    Returns:
        Total loss (data loss only) and loss components dictionary
    """
    batch_size = len(batch_data)
    
    if batch_size == 0:
        return torch.tensor(0.0, device=device), {'data_loss': 0.0}
    
    # Create tensors for scaling
    min_vals_tensor = torch.tensor(output_min, device=device, dtype=torch.float32)
    max_vals_tensor = torch.tensor(output_max, device=device, dtype=torch.float32)
    
    # Get activation types
    activation_types = model.get_activation_types() if hasattr(model, 'get_activation_types') else {
        "pressure": "tanh", 
        "mass_flow": "tanh"
    }
    
    # Initialize loss values
    total_batch_loss = 0.0
    batch_data_loss = 0.0
    
    # Process each scenario in the batch
    for scenario_data in batch_data:
        scenario_data = scenario_data.reset_index(drop=True)
        
        # Find source nodes for each flowline and use their input values
        flowline_source_map = {}
        
        # Find source nodes for each flowline
        for flowline_id in scenario_data['BranchEquipment'].unique():
            flowline_data = scenario_data[scenario_data['BranchEquipment'] == flowline_id]
            source_nodes = flowline_data[flowline_data['node_type'] == source_node_type].sort_values(by='TotalDistance')
            
            if not source_nodes.empty:
                # Use the first source node
                source_node = source_nodes.iloc[0]
                # Get source node values for all input columns
                source_values = []
                for col in INPUT_COLS:
                    # For non-node-specific features like DistanceFromSource and ElevationDifference, 
                    # we'll get the actual node values later
                    if col in ['DistanceFromSource', 'ElevationDifference', 'TotalDistance']:
                        source_values.append(0.0)  # Placeholder
                    else:
                        source_values.append(float(source_node[col]))
                flowline_source_map[flowline_id] = np.array(source_values)
            else:
                # Handle flowlines without source nodes (those starting at junctions)
                # Use the first node in the flowline as a reference
                if not flowline_data.empty:
                    first_node = flowline_data.sort_values(by='TotalDistance').iloc[0]
                    source_values = []
                    for col in INPUT_COLS:
                        if col in ['DistanceFromSource', 'ElevationDifference', 'TotalDistance']:
                            source_values.append(0.0)  # Placeholder
                        else:
                            source_values.append(float(first_node[col]))
                    flowline_source_map[flowline_id] = np.array(source_values)
        
        # Prepare inputs using source node values
        all_inputs = []
        all_indices = []
        
        for idx, node in scenario_data.iterrows():
            flowline_id = node['BranchEquipment']
            if flowline_id in flowline_source_map:
                # Use source node input values but override node-specific features
                source_values = flowline_source_map[flowline_id].copy()
                
                # Override with actual node-specific values
                for i, col in enumerate(INPUT_COLS):
                    if col == 'DistanceFromSource':
                        source_values[i] = node['DistanceFromSource']
                    elif col == 'TotalDistance':
                        source_values[i] = node['TotalDistance']
                    elif col == 'ElevationDifference':
                        source_values[i] = node['ElevationDifference']
                
                all_inputs.append(source_values)
                all_indices.append(idx)
            else:
                # Fallback: use this node's values (should be rare)
                node_values = []
                for col in INPUT_COLS:
                    node_values.append(float(node[col]))
                all_inputs.append(np.array(node_values))
                all_indices.append(idx)
        
        # Convert to tensor and scale to [0,1] range
        if all_inputs:
            inputs_tensor = torch.tensor(all_inputs, dtype=torch.float32, device=device)
            input_min_tensor = torch.tensor(input_min, dtype=torch.float32, device=device)
            input_max_tensor = torch.tensor(input_max, dtype=torch.float32, device=device)
            scaled_inputs = (inputs_tensor - input_min_tensor) / (input_max_tensor - input_min_tensor + 1e-8)
            
            # Get predictions
            preds = model(scaled_inputs)
            
            # Get ground truth values for the nodes we're predicting
            true_vals = []
            for idx in all_indices:
                node_outputs = []
                for col in OUTPUT_COLS:
                    node_outputs.append(float(scenario_data.loc[idx, col]))
                true_vals.append(node_outputs)
            
            true_vals_tensor = torch.tensor(true_vals, dtype=torch.float32, device=device)
            
            # Unscale predictions for physical comparison
            if all(act_type == "tanh" for act_type in activation_types.values()):
                # Use standard unscaling for tanh
                physical_preds = ((preds + 1) / 2) * (max_vals_tensor - min_vals_tensor) + min_vals_tensor
            else:
                # Use custom unscaling for mixed activations
                physical_preds = torch.zeros_like(preds)
                for i, col in enumerate(OUTPUT_COLS):
                    act_type = "tanh"  # Default
                    if col == "Pressure" and "pressure" in activation_types:
                        act_type = activation_types["pressure"]
                    
                    if act_type == "tanh":
                        normalized = (preds[:, i] + 1) / 2
                        physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
                    elif act_type == "silu":
                        normalized = torch.clamp(preds[:, i], 0.0, 1.0)
                        physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
                    elif act_type == "linear":
                        # For linear, apply sigmoid to constrain to [0,1]
                        normalized = torch.sigmoid(preds[:, i])
                        physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
            
            # Scale ground truth to [0,1] range for comparing with model outputs
            true_scaled = torch.zeros_like(true_vals_tensor)
            for i, col in enumerate(OUTPUT_COLS):
                uses_tanh = True
                if col == "Pressure" and activation_types.get("pressure") != "tanh":
                    uses_tanh = False
                    
                if uses_tanh:
                    true_scaled[:, i] = (true_vals_tensor[:, i] - min_vals_tensor[i]) / (max_vals_tensor[i] - min_vals_tensor[i] + 1e-8)
                    # Convert to [-1, 1] range for tanh
                    true_scaled[:, i] = 2 * true_scaled[:, i] - 1
            
            # Calculate loss for each output column
            data_loss = torch.tensor(0.0, device=device)
            for i, col in enumerate(OUTPUT_COLS):
                if col == "Pressure" and activation_types.get("pressure") != "tanh":
                    # For non-tanh activation, compare unscaled values
                    pressure_loss = torch.mean((physical_preds[:, i] - true_vals_tensor[:, i]) ** 2)
                    data_loss += pressure_loss
                else:
                    # For tanh activation, compare scaled values
                    col_loss = torch.mean((preds[:, i] - true_scaled[:, i]) ** 2)
                    data_loss += col_loss
            
            # Average across all outputs
            data_loss = data_loss / len(OUTPUT_COLS)
            
            # Add to batch total
            batch_data_loss += data_loss
    
    # Average across batch
    batch_data_loss /= batch_size
    
    # Total loss is just the data loss now
    total_batch_loss = batch_data_loss
    
    # Create result dictionary
    batch_loss_components = {
        'data_loss': batch_data_loss.item(),
        'total_loss': total_batch_loss.item()
    }
    
    return total_batch_loss, batch_loss_components


# Helper function for unscaling with multiple activation types
def unscale_mixed_outputs(preds, min_vals, max_vals, activation_types, output_cols):
    """
    Unscale predictions, handling different activation functions
    """
    # If all activations are tanh, use standard unscaling
    if all(act_type == "tanh" for act_type in activation_types.values()):
        return input_preprocessing.unscale_data(preds, min_vals, max_vals)
    
    unscaled = torch.zeros_like(preds)
    for i, col in enumerate(output_cols):
        # Determine activation type for this column
        act_type = "tanh"  # Default activation
        if col == "Pressure" and "pressure" in activation_types:
            act_type = activation_types["pressure"]
        elif col == output_cols[1] and "mass_flow" in activation_types:
            act_type = activation_types["mass_flow"]
            
        # Unscale based on activation type
        if act_type == "tanh":
            # For tanh, we need to convert from [-1,1] to [0,1] first
            normalized = (preds[:, i] + 1) / 2
            unscaled[:, i] = normalized * (max_vals[i] - min_vals[i]) + min_vals[i]
        elif act_type == "silu":
            # SiLU (Sigmoid Linear Unit) already gives positive values
            normalized = torch.clamp(preds[:, i], 0.0, 1.0)
            unscaled[:, i] = normalized * (max_vals[i] - min_vals[i]) + min_vals[i]
        elif act_type == "linear":
            # For linear activation, apply sigmoid to constrain to [0,1]
            normalized = torch.sigmoid(preds[:, i])
            unscaled[:, i] = normalized * (max_vals[i] - min_vals[i]) + min_vals[i]
        else:
            # Fallback unscaling - assume output is already in [0,1]
            normalized = torch.clamp(preds[:, i], 0.0, 1.0)
            unscaled[:, i] = normalized * (max_vals[i] - min_vals[i]) + min_vals[i]
            
    return unscaled

# -------------------------------------------
# Training Function - Simplified for Data Loss Only
# -------------------------------------------
def train_model(model, data, INPUT_COLS, OUTPUT_COLS, input_min, input_max,
                output_min, output_max, num_epochs=100, learning_rate=1e-4, 
                batch_size=4, num_scenarios=None, early_stopping_patience=15,
                lr_scheduler_patience=10, lr_scheduler_factor=0.75,
                source_node_type=1, device=torch.device("cpu")):
    """
    Train the PINN model with source-only inputs and elevation differences
    using only data loss
    
    Args:
        model: Neural network model
        data: DataFrame with training data
        INPUT_COLS: List of input column names (including ElevationDifference)
        OUTPUT_COLS: List of output column names
        input_min, input_max: Min/max values for input scaling
        output_min, output_max: Min/max values for output scaling
        num_epochs: Maximum number of epochs to train
        learning_rate: Initial learning rate
        batch_size: Number of scenarios per batch
        num_scenarios: Maximum number of scenarios to use (None = use all)
        early_stopping_patience: Number of epochs with no improvement before stopping
        lr_scheduler_patience: Patience for learning rate scheduler
        lr_scheduler_factor: Factor for learning rate reduction
        source_node_type: Node type identifier for sources
        device: Computation device
    
    Returns:
        Trained model and training history
    """
    # Move model to device
    model.to(device)
    
    # Create optimizer
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    
    # Create learning rate scheduler
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, 'min', factor=lr_scheduler_factor, patience=lr_scheduler_patience
    )
    
    # Get all scenarios
    all_scenarios = sorted(data["scenario"].unique())
    if num_scenarios is not None:
        all_scenarios = all_scenarios[:num_scenarios]
    
    # Split into train and validation sets
    train_cutoff = int(0.7 * len(all_scenarios))
    train_scenarios = all_scenarios[:train_cutoff]
    val_scenarios = all_scenarios[train_cutoff:]
    
    print(f"Training on {len(train_scenarios)} scenarios, validating on {len(val_scenarios)} scenarios")
    print(f"Model using activation types: {model.get_activation_types() if hasattr(model, 'get_activation_types') else 'default'}")
    
    # Create live loss plotter
    liveloss = PlotLosses()
    
    # Initialize histories
    train_loss_history = []
    val_loss_history = []
    
    # Initialize early stopping
    best_val_loss = float('inf')
    patience_counter = 0
    best_model_state = None
    
    # Training loop
    for epoch in range(num_epochs):
        # Training phase
        model.train()
        epoch_loss = 0.0
        
        # Shuffle scenarios
        random.shuffle(train_scenarios)
        
        # Create batches
        train_batches = [train_scenarios[i:i+batch_size] for i in range(0, len(train_scenarios), batch_size)]
        
        # Process each batch
        for batch_idx, batch_scenario_ids in enumerate(train_batches):
            # Get batch data
            batch_data = [data[data["scenario"] == sc_id].copy() for sc_id in batch_scenario_ids]
            
            # Compute loss - now only data loss
            batch_loss, batch_components = compute_batch_loss(
                model, batch_data, INPUT_COLS, OUTPUT_COLS,
                input_min, input_max, output_min, output_max,
                source_node_type, device
            )
            
            # Backpropagation
            optimizer.zero_grad()
            batch_loss.backward()
            
            # Update weights
            optimizer.step()
            
            # Update epoch statistics
            epoch_loss += batch_loss.item()
            
            # Print progress
            if (batch_idx + 1) % 10 == 0:
                print(f"  Batch {batch_idx + 1}/{len(train_batches)} - Loss: {batch_loss.item():.4f}")
        
        # Average epoch statistics
        num_batches = len(train_batches)
        epoch_loss /= num_batches
        train_loss_history.append(epoch_loss)
        
        # Validation phase
        model.eval()
        val_loss = 0.0
        
        # Create validation batches
        val_batches = [val_scenarios[i:i+batch_size] for i in range(0, len(val_scenarios), batch_size)]
        
        with torch.no_grad():
            # Process each validation batch
            for batch_scenario_ids in val_batches:
                # Get batch data
                batch_data = [data[data["scenario"] == sc_id].copy() for sc_id in batch_scenario_ids]
                
                # Compute loss
                batch_val_loss, _ = compute_batch_loss(
                    model, batch_data, INPUT_COLS, OUTPUT_COLS,
                    input_min, input_max, output_min, output_max,
                    source_node_type, device
                )
                
                # Update validation statistics
                val_loss += batch_val_loss.item()

        # Average validation statistics
        num_val_batches = len(val_batches)
        val_loss /= num_val_batches
        val_loss_history.append(val_loss)
        
        # Update learning rate
        scheduler.step(val_loss)
        
        # Create logs for live plotting
        logs = {
            'loss': epoch_loss, 
            'val_loss': val_loss,
        }
        
        # Update live plot
        liveloss.update(logs)
        liveloss.draw()
        
        # Print epoch summary
        print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {epoch_loss:.4f}, Val Loss: {val_loss:.4f}')
        
        # Check for improvement
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_model_state = model.state_dict().copy()
            print(f"  New best model saved! (Val Loss: {best_val_loss:.4f})")
        else:
            patience_counter += 1
            print(f"  No improvement for {patience_counter} epochs. Best Val Loss: {best_val_loss:.4f}")
            
            # Early stopping
            if patience_counter >= early_stopping_patience:
                print(f"Early stopping triggered after {epoch+1} epochs")
                model.load_state_dict(best_model_state)
                break
    
    # Restore best model if found
    if best_model_state is not None:
        model.load_state_dict(best_model_state)
        print(f"Restored best model with validation loss: {best_val_loss:.4f}")
        
    # Return model and history
    return model, {
        'train_loss': train_loss_history,
        'val_loss': val_loss_history
    }

# -------------------------------------------
# Prediction Function (Source-Only Version)
# -------------------------------------------
def predict_with_model(model, test_data, INPUT_COLS, OUTPUT_COLS,
                     input_min, input_max, output_min, output_max,
                     batch_size=16, source_node_type=1, device=torch.device("cpu")):
    """
    Make predictions with a trained model using source-only inputs
    
    Args:
        model: Trained neural network model
        test_data: DataFrame with test data
        INPUT_COLS: List of input column names (including ElevationDifference)
        OUTPUT_COLS: List of output column names
        input_min, input_max: Min/max values for input scaling
        output_min, output_max: Min/max values for output scaling
        batch_size: Batch size for prediction
        source_node_type: Node type identifier for sources
        device: Computation device
    
    Returns:
        DataFrame with original data and predictions
    """
    model.to(device)
    model.eval()
    
    # Get activation types
    activation_types = model.get_activation_types() if hasattr(model, 'get_activation_types') else {
        "pressure": "tanh", 
        "mass_flow": "tanh"
    }
    
    # Create tensors for scaling
    min_vals_tensor = torch.tensor(output_min, device=device, dtype=torch.float32)
    max_vals_tensor = torch.tensor(output_max, device=device, dtype=torch.float32)
    
    # Get all scenarios
    all_scenarios = sorted(test_data["scenario"].unique())
    
    # Initialize results
    all_predictions = []
    
    with torch.no_grad():
        # Process each scenario
        for scenario_id in all_scenarios:
            # Get scenario data
            scenario_data = test_data[test_data["scenario"] == scenario_id].copy()
            
            # Create tensors for scaling
            input_min_tensor = torch.tensor(input_min, dtype=torch.float32, device=device)
            input_max_tensor = torch.tensor(input_max, dtype=torch.float32, device=device)
            
            # Process flowlines with source nodes
            flowline_source_map = {}
            scenario_predictions = []
            
            # First identify all source nodes for each flowline
            for flowline_id in scenario_data['BranchEquipment'].unique():
                flowline_data = scenario_data[scenario_data['BranchEquipment'] == flowline_id]
                source_nodes = flowline_data[flowline_data['node_type'] == source_node_type]
                
                if not source_nodes.empty:
                    # Use the first source node's input values
                    source_node = source_nodes.iloc[0]
                    source_values = []
                    
                    for col in INPUT_COLS:
                        if col in ['DistanceFromSource', 'ElevationDifference', 'TotalDistance']:
                            # These will be overridden with node-specific values
                            source_values.append(0.0)
                        else:
                            source_values.append(float(source_node[col]))
                    
                    flowline_source_map[flowline_id] = np.array(source_values)
                else:
                    # Handle flowlines without source nodes (those starting at junctions)
                    # Use the first node in the flowline as a reference
                    if not flowline_data.empty:
                        first_node = flowline_data.sort_values(by='TotalDistance').iloc[0]
                        source_values = []
                        for col in INPUT_COLS:
                            if col in ['DistanceFromSource', 'ElevationDifference', 'TotalDistance']:
                                source_values.append(0.0)  # Will be overridden
                            else:
                                source_values.append(float(first_node[col]))
                        flowline_source_map[flowline_id] = np.array(source_values)
            
            # Process each node, making predictions
            for _, node in scenario_data.iterrows():
                flowline_id = node['BranchEquipment']
                
                # If we have source data for this flowline, use it
                if flowline_id in flowline_source_map:
                    source_values = flowline_source_map[flowline_id].copy()
                    
                    # Override with node-specific values
                    for i, col in enumerate(INPUT_COLS):
                        if col == 'ElevationDifference':
                            source_values[i] = node['ElevationDifference']
                        elif col == 'TotalDistance':
                            source_values[i] = node['TotalDistance']
                        elif col == 'DistanceFromSource':
                            source_values[i] = node['DistanceFromSource']
                        
                    input_values = source_values
                else:
                    # Fallback: use this node's values (should be rare)
                    input_values = []
                    for col in INPUT_COLS:
                        input_values.append(float(node[col]))
                
                # Convert to tensor and scale to [0,1] range
                input_tensor = torch.tensor(input_values, dtype=torch.float32, device=device).reshape(1, -1)
                scaled_input = (input_tensor - input_min_tensor) / (input_max_tensor - input_min_tensor + 1e-8)
                
                # Get prediction
                preds = model(scaled_input)
                
                # Unscale predictions
                if all(act_type == "tanh" for act_type in activation_types.values()):
                    # Standard unscaling for tanh activations
                    physical_preds = ((preds + 1) / 2) * (max_vals_tensor - min_vals_tensor) + min_vals_tensor
                else:
                    # Custom unscaling for mixed activations
                    physical_preds = torch.zeros_like(preds)
                    for i, col in enumerate(OUTPUT_COLS):
                        act_type = "tanh"  # Default
                        if col == "Pressure" and "pressure" in activation_types:
                            act_type = activation_types["pressure"]
                        
                        if act_type == "tanh":
                            normalized = (preds[:, i] + 1) / 2
                            physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
                        elif act_type == "silu":
                            normalized = torch.clamp(preds[:, i], 0.0, 1.0)
                            physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
                        elif act_type == "linear":
                            # For linear activation, apply sigmoid to constrain output
                            normalized = torch.sigmoid(preds[:, i])
                            physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
                
                # Store node with predictions
                node_data = node.copy()
                for i, col in enumerate(OUTPUT_COLS):
                    node_data[f"{col}_pred"] = physical_preds[0, i].cpu().item()
                scenario_predictions.append(node_data)
            
            # Create DataFrame for this scenario's predictions
            if scenario_predictions:
                scenario_with_preds = pd.concat(scenario_predictions, axis=1).T if isinstance(scenario_predictions[0], pd.Series) else pd.DataFrame(scenario_predictions)
                all_predictions.append(scenario_with_preds)
    
    # Combine all predictions
    if all_predictions:
        result_df = pd.concat(all_predictions, ignore_index=True)
        return result_df
    else:
        print("Warning: No predictions were made.")
        return None

# -------------------------------------------
# Compare cluster prediction Function 
# -------------------------------------------		
def compare_cluster_predictions(predictions_df, output_cols, scenario_id=None, 
                               sort_by='TotalDistance', group_by='BranchEquipment'):
    """
    Compare predictions with ground truth across multiple flowlines in a cluster
    
    Args:
        predictions_df: DataFrame with predictions and ground truth
        output_cols: List of output column names
        scenario_id: Specific scenario to plot (None = use all scenarios)
        sort_by: Column to sort nodes within each flowline
        group_by: Column to group flowlines
    """
    # Filter to specific scenario if provided
    if scenario_id is not None:
        df = predictions_df[predictions_df["scenario"] == scenario_id].copy()
    else:
        df = predictions_df.copy()
    
    # Get unique flowlines
    flowlines = df[group_by].unique()
    num_flowlines = len(flowlines)
    
    # Create a plot for each output column
    for col in output_cols:
        # Calculate figure size based on number of flowlines
        fig_height = max(6, num_flowlines * 1.5)
        fig, axes = plt.subplots(num_flowlines, 1, figsize=(12, fig_height), sharex=True)
        
        # Handle single flowline case
        if num_flowlines == 1:
            axes = [axes]
        
        # Plot each flowline
        for i, flowline in enumerate(flowlines):
            flowline_data = df[df[group_by] == flowline].sort_values(by=sort_by)
            
            # Create x values (node index or distance)
            x = flowline_data[sort_by].values
            
            # Plot true and predicted values
            axes[i].scatter(x, flowline_data[col], label=f'True {col}', alpha=0.7)
            axes[i].scatter(x, flowline_data[f'{col}_pred'], label=f'Predicted {col}', alpha=0.7)
            
            # Add labels and legend
            axes[i].set_title(f'Flowline: {flowline}')
            axes[i].set_ylabel(col)
            axes[i].legend()
            axes[i].grid(True)
        
        # Add overall title and x-label
        plt.suptitle(f'{col} Comparison - Scenario {scenario_id}')
        plt.xlabel(sort_by)
        plt.tight_layout()
        plt.subplots_adjust(top=0.95)
        plt.show()



