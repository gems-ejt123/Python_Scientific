"""
Pressure target transform to fix the >250 psi under-prediction.

Root cause: global MinMax maps P=250 to scaled +0.013, so the upper half of the
[-1, 1] output range holds only ~6% of the data. A network minimizing mean loss
underfits that half no matter how the tail is weighted.

`QuantileWarp` maps pressure through its own empirical CDF, so every slice of the
output range holds an equal share of samples. The sparse high-pressure tail then
occupies as much of the range as the dense low-pressure body, and the model
spends capacity there. The map is monotone and invertible, so physical pressure
is recovered exactly for the physics loss and evaluation.

Use it in place of the pressure column's MinMax scaling: fit on the TRAIN
pressures, `transform` the target before training, `inverse` the model output
back to psi. Pass `inverse_torch` to the momentum loss so it unscales the same way.
"""

from __future__ import annotations

import numpy as np

# torch is imported lazily inside inverse_torch so fit/transform/inverse (numpy)
# run without a torch install.


class QuantileWarp:
    def __init__(self, n_knots=256, eps=1e-4):
        self.n_knots = n_knots
        self.eps = eps
        self.knots_p = None      # pressure values at uniform quantiles
        self.grid_u = None       # uniform grid in [0, 1]

    def fit(self, pressures):
        p = np.asarray(pressures, dtype=np.float64).ravel()
        p = p[np.isfinite(p)]
        qs = np.linspace(0.0, 1.0, self.n_knots)
        knots = np.quantile(p, qs)
        # Enforce strict monotonicity so interpolation stays invertible.
        for i in range(1, len(knots)):
            if knots[i] <= knots[i - 1]:
                knots[i] = knots[i - 1] + self.eps
        self.knots_p = knots
        self.grid_u = qs
        return self

    def transform(self, pressures):
        """psi -> scaled [-1, 1]."""
        p = np.asarray(pressures, dtype=np.float64)
        u = np.interp(p, self.knots_p, self.grid_u)
        return (2.0 * u - 1.0).astype(np.float32)

    def inverse(self, scaled):
        """scaled [-1, 1] -> psi (numpy)."""
        y = np.asarray(scaled, dtype=np.float64)
        u = np.clip((y + 1.0) * 0.5, 0.0, 1.0)
        return np.interp(u, self.grid_u, self.knots_p)

    def inverse_torch(self, scaled):
        """scaled [-1, 1] -> psi (torch, differentiable, piecewise-linear)."""
        import torch
        knots_p = torch.as_tensor(self.knots_p, dtype=scaled.dtype,
                                  device=scaled.device)
        grid_u = torch.as_tensor(self.grid_u, dtype=scaled.dtype,
                                 device=scaled.device)
        u = torch.clamp((scaled + 1.0) * 0.5, 0.0, 1.0)
        idx = torch.searchsorted(grid_u, u.contiguous()).clamp(1, len(grid_u) - 1)
        u0 = grid_u[idx - 1]
        u1 = grid_u[idx]
        p0 = knots_p[idx - 1]
        p1 = knots_p[idx]
        w = (u - u0) / (u1 - u0).clamp_min(1e-12)
        return p0 + w * (p1 - p0)


class HybridOutputScaler:
    """Drop-in replacement for a MinMaxScaler(feature_range=(-1, 1)) on the
    multi-output target, warping ONLY the pressure column through its empirical
    CDF while every other output stays linear MinMax.

    It mirrors the sklearn API the notebook already relies on (`fit`,
    `transform`, `inverse_transform`, `data_min_`, `data_max_`), so no
    downstream inverse-transform call site has to change. The pressure column is
    the one the network underfits above ~250 psi; equalizing its output-range
    density (QuantileWarp) is the fix, and keeping the aux columns linear avoids
    disturbing mass/holdup/lambda supervision.

    `data_min_`/`data_max_` report the true physical min/max for every column
    (the pressure entries are the raw psi range, used only for reporting and for
    the linear fallback in the momentum loss). The momentum loss should instead
    be passed `pressure_inverse=scaler.pressure_inverse_torch` so it unscales
    pressure through the same warp.
    """

    def __init__(self, pressure_index, feature_range=(-1, 1), n_knots=256):
        self.pressure_index = pressure_index
        self.feature_range = feature_range
        self.n_knots = n_knots
        self.warp = QuantileWarp(n_knots=n_knots)
        self.data_min_ = None
        self.data_max_ = None
        self._lo, self._hi = feature_range

    def fit(self, Y):
        Y = np.asarray(Y, dtype=np.float64)
        self.data_min_ = Y.min(axis=0)
        self.data_max_ = Y.max(axis=0)
        self._span = np.clip(self.data_max_ - self.data_min_, 1e-12, None)
        self.warp.fit(Y[:, self.pressure_index])
        return self

    def transform(self, Y):
        Y = np.asarray(Y, dtype=np.float64)
        u = (Y - self.data_min_) / self._span            # linear -> [0, 1]
        S = u * (self._hi - self._lo) + self._lo         # -> feature_range
        S[:, self.pressure_index] = self.warp.transform(Y[:, self.pressure_index])
        return S.astype(np.float32)

    def fit_transform(self, Y):
        return self.fit(Y).transform(Y)

    def inverse_transform(self, S):
        S = np.asarray(S, dtype=np.float64)
        u = (S - self._lo) / (self._hi - self._lo)       # -> [0, 1]
        Y = u * self._span + self.data_min_              # linear cols
        Y[:, self.pressure_index] = self.warp.inverse(S[:, self.pressure_index])
        return Y

    def pressure_inverse_torch(self, scaled_pressure):
        """scaled pressure [-1, 1] -> psi (torch, differentiable). Pass this to
        the momentum loss as `pressure_inverse`."""
        return self.warp.inverse_torch(scaled_pressure)


def scenario_sink_pressure(scenario_df, node_type_col="node_type",
                           pressure_col="Pressure", sink_value=-1):
    """Known sink (delivery) pressure for a scenario. The trunk holds it fixed,
    so it is the natural anchor for a departure-from-sink target."""
    sink = scenario_df[scenario_df[node_type_col] == sink_value]
    if len(sink) == 0:
        return float(scenario_df[pressure_col].min())
    return float(sink[pressure_col].mean())
