import numpy as np
import pandas as pd
from datetime import datetime
import os
import plotly.graph_objects as go

def count_branches(data):
    
    return data['BranchEquipment'].value_counts()

def long_lat_col(data):

    data['long'], data['lat'] = np.round(0.0, 8), np.round(0.0, 8)

    return data

def drop_duplicated_branches(data, columns):

    return data.drop_duplicates(subset = columns)

def count_branches(data):
    
    return data['BranchEquipment'].value_counts()

def get_long_lat(df_coordinates, data):
    
    #Rename the column Unnamed as Nodo
    data = data.rename(columns={"index": "Nodo"})
    
    #Sort the dataframe containing coordinates by flowline
    df_coordinates = df_coordinates.sort_values(by = ['flowline',"measuredDistance meters"], ascending=True, ignore_index=True)
    
    #Sort the dataframe containing flowlines by Branch and Nodo
    data = data.sort_values(by = ['BranchEquipment', "Nodo"], ascending=True, ignore_index=True)

    
    #Labels from dataframe containing flow line data
    labels_fl_df = data.BranchEquipment.unique()

    #mask related to coordinates of the flowline
    mask_coord = df_coordinates['flowline'].isin(labels_fl_df)

    #filter df by the mask
    df_coordinates = df_coordinates[mask_coord]

    long = df_coordinates.long.values
    lat = df_coordinates.lat.values

    #assign long and lt to data
    data['long'] = long
    data['lat'] = lat
    
    return data

def get_elevation(df_coordinates, data):
    
    #Rename the column Unnamed as Nodo
    data = data.rename(columns={"index": "Nodo"})
    
    #Sort the dataframe containing coordinates by flowline
    df_coordinates = df_coordinates.sort_values(by = ['flowline',"measuredDistance meters"], ascending=True, ignore_index=True)
    
    #Sort the dataframe containing flowlines by Branch and Nodo
    data = data.sort_values(by = ['BranchEquipment', "Nodo"], ascending=True, ignore_index=True)

    
    #Labels from dataframe containing flow line data
    labels_fl_df = data.BranchEquipment.unique()

    #mask related to coordinates of the flowline
    mask_coord = df_coordinates['flowline'].isin(labels_fl_df)

    #filter df by the mask
    df_coordinates = df_coordinates[mask_coord]

    elevation = df_coordinates['elevation meters'].values

    #assign elevation to data
    data['Elevation'] = elevation

    return data

def get_distances(df_coordinates, data):

    """
    Function to get the distances (horizontalDistance meters and measuredDistance meters) from the coordinates dataframe 
    and assign them to the data dataframe.
    
    Parameters:
    df_coordinates (DataFrame): DataFrame containing the coordinates and distances
    data (DataFrame): DataFrame containing the flowline data
    Returns:
    DataFrame: The input data DataFrame with the distances added
    """

    #Rename the column Unnamed as Nodo
    data = data.rename(columns={"index": "Nodo"})
    
    #Sort the dataframe containing coordinates by flowline
    df_coordinates = df_coordinates.sort_values(by = ['flowline',"measuredDistance meters"], ascending=True, ignore_index=True)
    
    #Sort the dataframe containing flowlines by Branch and Nodo
    data = data.sort_values(by = ['BranchEquipment', "Nodo"], ascending=True, ignore_index=True)

    
    #Labels from dataframe containing flow line data
    labels_fl_df = data.BranchEquipment.unique()

    #mask related to coordinates of the flowline
    mask_coord = df_coordinates['flowline'].isin(labels_fl_df)

    #filter df by the mask
    df_coordinates = df_coordinates[mask_coord]

    horizontal_distance = df_coordinates['horizontalDistance meters'].values
    measured_distance = df_coordinates['measuredDistance meters'].values

    #assign distances to data
    data['horizontalDistance meters'] = horizontal_distance
    data['measuredDistance meters'] = measured_distance

    return data

def add_scenario(data):
    return [df.assign(scenario=idx) for idx, df in enumerate(data)]

def create_df_pipe_nodes(data):
    
    labels_fl = data[0].BranchEquipment.unique()

    long_init, lat_init, long_end, lat_end = [], [], [], []

    for fl in labels_fl:
        
        flow_line = data[0][data[0]['BranchEquipment'].isin([fl])]
        
        long_init.append((flow_line.long.iloc[0])) 
        lat_init.append((flow_line.lat.iloc[0]))
        long_end.append((flow_line.long.iloc[-1])) 
        lat_end.append((flow_line.lat.iloc[-1]))

    df_pipe_nodes = pd.DataFrame(columns=['pipeline_id', 'start_x', 'start_y', 'end_x', 'end_y'])

    df_pipe_nodes.pipeline_id =  labels_fl
    df_pipe_nodes.start_x = long_init
    df_pipe_nodes.start_y = lat_init
    df_pipe_nodes.end_x = long_end
    df_pipe_nodes.end_y = lat_end

    return df_pipe_nodes

def get_corrected_clusters_id(data, dict_change_id = {2: 0, 0: 1, 3: 2, 4: 3, 1: 4}, column_cluster="cluster_id"):
    """
    Function to correct the cluster id in the dataframe. The function replaces the cluster id with the new one
    defined in the dictionary dict_change_id.
    """
    #Create a mask using the cluster_id

    data[column_cluster] = data[column_cluster].replace(to_replace = dict_change_id)
    
    return data

def include_cluster_id(data, data_with_cluster):

    cluster_id = data_with_cluster.cluster_id.unique()

    data["cluster_id"] = ''

    for cluster in cluster_id:

        #Create mask using the cluster_id
        mask_cluster_id = data_with_cluster["cluster_id"].isin([cluster])
      
        #Get pipelines based on the mask_cluster_id
        pipelines = data_with_cluster[mask_cluster_id].pipeline_id.unique()

        #Create a mask for flowline dataframe
        mask_data = data["BranchEquipment"].isin(pipelines)
   
        cluster_val = data_with_cluster[mask_cluster_id]["cluster_id"].values
        
        index = data[mask_data].index
      
        data.loc[index, "cluster_id"] = cluster_val[0]
    
    return data

def convert_tuple_long_lat(data):

    data['coordinates'] = data[["long", "lat"]].apply(tuple, axis=1)
    data = data.drop(columns = ["long", "lat"])
    
    return  data

def add_actual_sources(data, df_sources):

    data['node_type'] = 0
    
    #Labels from dataframe containing flow line data
    actual_sources_long = df_sources['long deg'].values

    for long in actual_sources_long:
        
        mask_sources_true = (data['long'].isin([long]))

        data.loc[mask_sources_true, 'node_type'] = 1

    return data

def add_actual_sink(data, df_sink):

    actual_sink_long = df_sink.long.values

    for long in actual_sink_long:

        mask_sink_true = (data['long'].isin([long]))

        data.loc[mask_sink_true, 'node_type'] = -1
    
    return data

def handle_NaN(data):
    
    return data.fillna(0)

def get_subNN(data, cluster):
    """
    Cluster: int. Is the cluster id
    
    """
    mask_cluster = data["cluster_id"].isin([cluster])

    data = data[mask_cluster]

    return data

def concat_cluster(data):

    return pd.concat(data)

def get_sources(data):

    sources = data[(data["node_type"] == 1) & (data["Nodo"] == 0)]
    
    return sources

def get_nodes(data):
     
    nodes = data[(data["node_type"] != 1)]

    return nodes

def get_sink(data):
    
    if -1 in data.is_a_source.unique():
        sink = data[data["is_a_source"] == -1]
        
        return sink

    else:

        print("No sinks were found, please check your dataframe")

        return None
    
def get_friction_factor(data, friction_df):
    """
    Optimized version of get_friction_factor that avoids loops and uses vectorized operations
    
    Parameters:
    data (DataFrame): DataFrame containing the BranchEquipment column
    friction_df (DataFrame): DataFrame containing flowline and lambda_friction columns
    
    Returns:
    DataFrame: Input DataFrame with lambda_friction column added
    """
    # Create a copy of the input data to avoid modifying the original
    result = data.copy()
    
    # Create a mapping dictionary from flowline to lambda_friction
    friction_map = dict(zip(friction_df['flowline'], friction_df['lambda_friction']))
    
    # Use map function to apply the mapping to BranchEquipment column
    result['lambda_friction'] = result['BranchEquipment'].map(friction_map)
    
    return result

def rename_branch_equipment(data, old_name, new_name):
    """
    Function to rename a BranchEquipment from old_name to new_name in the dataframe.
    
    Parameters:
    data (DataFrame): DataFrame containing the BranchEquipment column
    old_name (str): Current name of the BranchEquipment to be changed
    new_name (str): New name for the BranchEquipment
    
    Returns:
    DataFrame: DataFrame with the BranchEquipment name updated
    """
    # Create a copy to avoid modifying the original dataframe
    result = data.copy()
    
    # Replace the old_name with new_name in the BranchEquipment column
    result['BranchEquipment'] = result['BranchEquipment'].replace(old_name, new_name)
    
    return result

def message(msg, save_to_log, log_file, title=False):
    """
    Print a formatted message with optional title banners and file logging.
    
    Args:
        msg (str): The message to display and optionally log
        save_to_log (bool): If True, save in a file
        log_file (str): name of the log file. must be in "logs" folder
        title (bool): If True, adds decorative lines before and after the message
        
    """
    # Create formatted message
    prefix  = "[" + datetime.now().strftime("%H:%M:%S") + "]  "
    suffix  ="\n"
    banner = "=" * 60
    formatted_msg = f"\n{banner}\n{msg}\n{banner}\n".upper() if title else  prefix + msg + suffix
    
    # Print to console
    print(formatted_msg)
    
    # Handle logging if logfile is specified
    if save_to_log:
     
        # Write to log file if exists 
        if not os.path.exists("logs"):
            open_file = "w"
        else:
            open_file = "a"

        with open(log_file, open_file) as f:
            f.write(formatted_msg)

def visualize_pipeline_network(full_data_training, scenario=0, cpf_to_process='CPF1'):
    """
    Create a comprehensive pipeline network visualization showing Troncales in different colors
    with node-by-node discretization.
    
    Parameters:
    full_data_training (DataFrame): Complete pipeline data
    scenario (int): Scenario number to visualize (default: 0)
    cpf_to_process (str): CPF facility name (default: 'CPF1')
    
    Returns:
    plotly.graph_objects.Figure: Interactive pipeline network visualization
    """
    
    # Filter data for the specified scenario
    network_data = full_data_training[full_data_training["scenario"] == scenario].copy()
    
    print(f"🔍 NETWORK ANALYSIS FOR SCENARIO {scenario}")
    print(f"Total nodes: {len(network_data):,}")
    print(f"Unique Troncales: {len(network_data['Troncal'].dropna().unique())}")
    print(f"Unique pipelines (BranchEquipment): {len(network_data['BranchEquipment'].unique())}")
    print(f"Unique node_ids: {len(network_data['node_id'].unique())}")

    # Analyze Troncal composition
    print(f"\n📊 TRONCAL COMPOSITION:")
    troncal_stats = network_data.groupby('Troncal').agg({
        'node_id': 'count',
        'BranchEquipment': 'nunique',
        'node_type': lambda x: list(x.unique())
    }).round(2)
    troncal_stats.columns = ['Total_Nodes', 'Pipelines', 'Node_Types']
    print(troncal_stats)

    # Check sink nodes (-1) per Troncal
    print(f"\n🎯 SINK NODES (-1) PER TRONCAL:")
    sink_analysis = network_data[network_data['node_type'] == -1].groupby('Troncal').size()
    print(sink_analysis if not sink_analysis.empty else "No sink nodes found")

    # Highly distinct color palette for Troncales
    unique_troncales = sorted(network_data["Troncal"].fillna("UNKNOWN").unique())
    troncal_colors = {
        'RUBIALES_TRONCAL_1-11': '#FF0000',      # Bright Red
        'RUBIALES_TRONCAL_3-3A': '#00FF00',      # Bright Green  
        'RUBIALES_TRONCAL_5-12': '#0000FF',      # Bright Blue
        'RUBIALES_TRONCAL_6': '#FFFF00',         # Bright Yellow
        'RUBIALES_TRONCAL_8-8A': '#FF00FF',      # Bright Magenta
        'RUBIALES_TRONCAL_LINEA-12': '#00FFFF',  # Bright Cyan
        'RUBIALES_TRONCAL_TRUNK-LINE': '#FF8000', # Bright Orange
        'UNKNOWN': '#808080'                      # Gray for unknown
    }

    print(f"\n🎨 COLOR MAPPING:")
    for troncal, color in troncal_colors.items():
        if troncal in unique_troncales:
            node_count = len(network_data[network_data['Troncal'] == troncal])
            print(f"   {troncal}: {color} ({node_count:,} nodes)")

    print(f"\n" + "="*80)
    
    # Create the interactive visualization
    fig = go.Figure()

    # Plot each Troncal as a separate trace with distinct color
    for troncal in unique_troncales:
        if troncal == 'UNKNOWN':
            continue
            
        # Filter data for this specific Troncal
        troncal_data = network_data[network_data['Troncal'] == troncal].copy()
        
        if troncal_data.empty:
            continue
        
        # Get color for this Troncal
        color = troncal_colors.get(troncal, '#808080')
        
        # Group by pipeline (BranchEquipment) within this Troncal
        pipeline_groups = troncal_data.groupby('BranchEquipment')
        
        # Plot each pipeline as connected line segments
        for pipeline_name, pipeline_data in pipeline_groups:
            # Sort by distance to ensure proper line connectivity
            pipeline_sorted = pipeline_data.sort_values('TotalDistance')
            
            # Create detailed hover information
            hover_text = (
                f"<b>Troncal:</b> {troncal}<br>" +
                f"<b>Pipeline:</b> {pipeline_name}<br>" +
                f"<b>Node ID:</b> " + pipeline_sorted["node_id"].astype(str) + "<br>" +
                f"<b>Node Type:</b> " + pipeline_sorted["node_type"].astype(str) + "<br>" +
                f"<b>Pressure:</b> " + pipeline_sorted["Pressure"].round(2).astype(str) + " psia<br>" +
                f"<b>Flow:</b> " + pipeline_sorted["FlowrateLiquidInsitu"].round(1).astype(str) + " bbl/d<br>" +
                f"<b>Elevation:</b> " + pipeline_sorted["Elevation"].round(1).astype(str) + " ft<br>" +
                f"<b>Distance:</b> " + pipeline_sorted["TotalDistance"].round(1).astype(str) + " ft"
            )
            
            # Add pipeline trace
            fig.add_trace(go.Scatter(
                x=pipeline_sorted["long"],
                y=pipeline_sorted["lat"],
                mode="lines+markers",
                line=dict(color=color, width=4),
                marker=dict(size=5, color=color, opacity=0.8),
                name=pipeline_name,
                legendgroup=troncal,  # Group by Troncal in legend
                hoverinfo="text",
                hovertext=hover_text,
                showlegend=False  # We'll add separate legend entries
            ))

    # Add legend entries for each Troncal
    for troncal in unique_troncales:
        if troncal == 'UNKNOWN':
            continue
        color = troncal_colors.get(troncal, '#808080')
        node_count = len(network_data[network_data['Troncal'] == troncal])
        
        fig.add_trace(go.Scatter(
            x=[None], y=[None],
            mode="markers",
            marker=dict(size=15, color=color, symbol="square"),
            name=f"{troncal} ({node_count:,} nodes)",
            showlegend=True
        ))

    # Highlight special nodes
    # Sources (node_type = 0 or 1)
    sources = network_data[network_data["node_type"].isin([0, 1])]
    if not sources.empty:
        fig.add_trace(go.Scatter(
            x=sources["long"],
            y=sources["lat"],
            mode="markers",
            marker=dict(
                symbol="diamond",
                color="gold",
                size=0.05,
                line=dict(color="black", width=2)
            ),
            name=f"Sources/Wells ({len(sources):,})",
            hoverinfo="text",
            hovertext=(
                "<b>🔸 SOURCE NODE</b><br>" +
                "<b>Node ID:</b> " + sources["node_id"].astype(str) + "<br>" +
                "<b>Troncal:</b> " + sources["Troncal"].astype(str) + "<br>" +
                "<b>Pipeline:</b> " + sources["BranchEquipment"].astype(str) + "<br>" +
                "<b>Node Type:</b> " + sources["node_type"].astype(str) + "<br>" +
                "<b>Pressure:</b> " + sources["Pressure"].round(2).astype(str) + " psia<br>" +
                "<b>Flow:</b> " + sources["FlowrateLiquidInsitu"].round(1).astype(str) + " bbl/d"
            )
        ))

    # Sinks (node_type = -1)
    sinks = network_data[network_data["node_type"] == -1]
    if not sinks.empty:
        fig.add_trace(go.Scatter(
            x=sinks["long"],
            y=sinks["lat"],
            mode="markers",
            marker=dict(
                symbol="star",
                color="red",
                size=15,
                line=dict(color="darkred", width=2)
            ),
            name=f"Sinks/CPF ({len(sinks):,})",
            hoverinfo="text",
            hovertext=(
                "<b>⭐ SINK NODE</b><br>" +
                "<b>Node ID:</b> " + sinks["node_id"].astype(str) + "<br>" +
                "<b>Troncal:</b> " + sinks["Troncal"].astype(str) + "<br>" +
                "<b>Pipeline:</b> " + sinks["BranchEquipment"].astype(str) + "<br>" +
                "<b>Pressure:</b> " + sinks["Pressure"].round(2).astype(str) + " psia"
            )
        ))

    # Enhanced layout
    fig.update_layout(
        title={
            'text': f"🛢️ RUBIALES PIPELINE NETWORK - {cpf_to_process}<br><sub>Scenario {scenario} | Node-by-Node Discretization | Colored by Troncal</sub>",
            'x': 0.5,
            'xanchor': 'center',
            'font': {'size': 18, 'color': 'darkblue'}
        },
        xaxis_title="Longitude (°)",
        yaxis_title="Latitude (°)",
        hovermode="closest",
        height=1000,
        width=1400,
        legend=dict(
            orientation="v",
            yanchor="top",
            y=1,
            xanchor="left",
            x=1.02,
            itemsizing="constant",
            font=dict(size=11),
            bgcolor="rgba(255,255,255,0.8)",
            bordercolor="black",
            borderwidth=1
        ),
        margin=dict(l=60, r=200, t=100, b=60),
        showlegend=True,
        plot_bgcolor='rgba(240,240,240,0.3)'
    )

    # Add grid and styling
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor='rgba(128,128,128,0.3)')
    fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor='rgba(128,128,128,0.3)')

    # Print final summary
    print("\n" + "🎯 VISUALIZATION SUMMARY")
    print("="*80)
    print(f"✅ Network successfully visualized for scenario {scenario}")
    print(f"✅ {len(unique_troncales)-1 if 'UNKNOWN' in unique_troncales else len(unique_troncales)} Troncales plotted with distinct colors")
    print(f"✅ {len(network_data['BranchEquipment'].unique())} pipelines discretized by nodes")
    print(f"✅ {len(network_data):,} total nodes plotted")
    print(f"✅ Special nodes highlighted: Sources ({len(sources):,}), Sinks ({len(sinks):,})")
    print("="*80)
    
    return fig
