import matplotlib.pyplot as plt


# -------------------------------------------
# Visualization Functions NEURAL NETWORK
# -------------------------------------------
def plot_training_history_PINN(history, title="Training History"):
    """Plot training and validation loss"""
    plt.figure(figsize=(10, 6))
    plt.plot(history['train_loss'], label='Training Loss')
    plt.plot(history['val_loss'], label='Validation Loss')
    plt.title(title)
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    plt.show()

def plot_error_distribution(prediction_df, output_cols, scenario_id=None):
    """Plot error distribution for each output column"""
    if scenario_id is not None:
        df = prediction_df[prediction_df["scenario"] == scenario_id].copy()
    else:
        df = prediction_df.copy()
    
    num_cols = len(output_cols)
    plt.figure(figsize=(15, 5 * num_cols))
    
    for i, col in enumerate(output_cols):
        plt.subplot(num_cols, 1, i+1)
        
        # Calculate absolute and relative errors
        df[f'{col}_abs_error'] = abs(df[col] - df[f'{col}_pred'])
        df[f'{col}_rel_error'] = 100 * df[f'{col}_abs_error'] / (abs(df[col]) + 1e-8)
        
        # Plot histogram of relative errors
        plt.hist(df[f'{col}_rel_error'], bins=50)
        plt.title(f'{col} Relative Error Distribution (%)')
        plt.xlabel('Relative Error (%)')
        plt.ylabel('Count')
        plt.grid(True)
        
        # Print statistics
        mean_rel_error = df[f'{col}_rel_error'].mean()
        median_rel_error = df[f'{col}_rel_error'].median()
        max_rel_error = df[f'{col}_rel_error'].max()
        
        print(f"{col} Error Statistics:")
        print(f"  Mean Relative Error: {mean_rel_error:.2f}%")
        print(f"  Median Relative Error: {median_rel_error:.2f}%")
        print(f"  Max Relative Error: {max_rel_error:.2f}%")
        
    plt.tight_layout()
    plt.show()
# -------------------------------------------




def compare_cluster_predictions_with_elevation(predictions_df, output_cols, scenario_id=None, 
                                              sort_by='TotalDistance', group_by='BranchEquipment',
                                              elevation_col='Elevation', invert_elevation=True):
    """
    Compare predictions with ground truth across multiple flowlines in a cluster
    and show elevation profile on a secondary y-axis
    
    Args:
        predictions_df: DataFrame with predictions and ground truth
        output_cols: List of output column names
        scenario_id: Specific scenario to plot (None = use all scenarios)
        sort_by: Column to sort nodes within each flowline
        group_by: Column to group flowlines
        elevation_col: Column name for elevation data
        invert_elevation: Whether to invert the elevation axis (to show depth)
    """
    # Filter to specific scenario if provided
    if scenario_id is not None:
        df = predictions_df[predictions_df["scenario"] == scenario_id].copy()
    else:
        df = predictions_df.copy()
    
    # Get unique flowlines
    flowlines = df[group_by].unique()
    num_flowlines = len(flowlines)
    
    # Create a plot for each output column
    for col in output_cols:
        # Calculate figure size based on number of flowlines
        fig_height = max(6, num_flowlines * 2)  # Increased height for clarity
        fig, axes = plt.subplots(num_flowlines, 1, figsize=(12, fig_height), sharex=True)
        
        # Handle single flowline case
        if num_flowlines == 1:
            axes = [axes]
        
        # Plot each flowline
        for i, flowline in enumerate(flowlines):
            flowline_data = df[df[group_by] == flowline].sort_values(by=sort_by)
            
            # Create x values (node index or distance)
            x = flowline_data[sort_by].values
            
            # Create primary y-axis for output values
            ax1 = axes[i]
            
            # Plot true and predicted values on primary y-axis
            line1 = ax1.scatter(x, flowline_data[col], label=f'True {col}', color='blue', marker='o', alpha=0.7)
            line2 = ax1.scatter(x, flowline_data[f'{col}_pred'], label=f'Predicted {col}', color='red', marker='x', alpha=0.7)
            
            # Set y-axis label for primary axis
            ax1.set_ylabel(col, color='black')
            ax1.tick_params(axis='y', labelcolor='black')
            
            # Create secondary y-axis for elevation
            ax2 = ax1.twinx()
            
            # Plot elevation on secondary y-axis if available
            if elevation_col in flowline_data.columns:
                # Prepare elevation data - invert if requested
                if invert_elevation:
                    # Get elevation values and invert them 
                    elevation_values = flowline_data[elevation_col].values
                    ylabel = 'Elevation (ft)'
                else:
                    elevation_values = flowline_data[elevation_col].values 
                    ylabel = 'Elevation (ft)'
                
                line3 = ax2.plot(x, elevation_values, label='Elevation', color='green', 
                                linestyle='-', linewidth=2, alpha=0.5)
                ax2.set_ylabel(ylabel, color='green')
                ax2.tick_params(axis='y', labelcolor='green')
                
                # If inverted, also invert the y-axis direction so depth increases downward
                if invert_elevation:
                    ax2.invert_yaxis()
                
                # Add elevation to legend
                # Combine legends from both axes
                lines = [line1, line2, line3[0]]
                labels = [f'True {col}', f'Predicted {col}', 'Depth' if invert_elevation else 'Elevation']
                ax1.legend(lines, labels, loc='best')
            else:
                ax1.legend(loc='best')
            
            # Add flowline title
            ax1.set_title(f'Flowline: {flowline}')
            ax1.grid(True)
        
        # Add overall title and x-label
        title_elevation = "Depth Profile" if invert_elevation else "Elevation Profile"
        plt.suptitle(f'{col} Comparison with {title_elevation} - Scenario {scenario_id}')
        plt.xlabel(sort_by)
        plt.tight_layout()
        plt.subplots_adjust(top=0.95)
        plt.show()

def plot_pressure_profile_with_elevation(predictions_df, scenario_id=None, 
                                       sort_by='TotalDistance', group_by='BranchEquipment',
                                       elevation_col='Elevation', pressure_col='Pressure',
                                       flowrate_col='MassFlowrate', invert_elevation=True):
    """
    Create a comprehensive visualization showing pressure, elevation, and flow rate
    for a better understanding of flow behavior
    
    Args:
        predictions_df: DataFrame with predictions and ground truth
        scenario_id: Specific scenario to plot
        sort_by: Column to sort nodes within each flowline
        group_by: Column to group flowlines
        elevation_col: Column name for elevation data
        pressure_col: Column name for pressure data
        flowrate_col: Column name for flow rate data
        invert_elevation: Whether to invert the elevation axis (to show depth)
    """
    # Filter to specific scenario if provided
    if scenario_id is not None:
        df = predictions_df[predictions_df["scenario"] == scenario_id].copy()
    else:
        df = predictions_df.copy()
    
    # Get unique flowlines
    flowlines = df[group_by].unique()
    num_flowlines = len(flowlines)
    
    # Create a figure with two subplots for each flowline (pressure+elevation and flow rate)
    fig_height = max(8, num_flowlines * 4)  # Increased height for double plots
    fig, axes = plt.subplots(num_flowlines, 2, figsize=(15, fig_height))
    
    # Handle single flowline case
    if num_flowlines == 1:
        axes = axes.reshape(1, 2)
    
    # Plot each flowline
    for i, flowline in enumerate(flowlines):
        flowline_data = df[df[group_by] == flowline].sort_values(by=sort_by)
        
        # Create x values (node index or distance)
        x = flowline_data[sort_by].values
        
        # ---------- Left subplot: Pressure with Elevation ----------
        ax1 = axes[i, 0]
        
        # Plot actual and predicted pressure on primary y-axis
        line1 = ax1.scatter(x, flowline_data[pressure_col], label=f'True {pressure_col}', 
                          color='blue', marker='o', alpha=0.7)
        
        if f'{pressure_col}_pred' in flowline_data.columns:
            line2 = ax1.scatter(x, flowline_data[f'{pressure_col}_pred'], 
                              label=f'Predicted {pressure_col}', 
                              color='red', marker='x', alpha=0.7)
        
        # Set pressure axis labels
        ax1.set_ylabel(f'{pressure_col} (kPa)', color='black')
        ax1.tick_params(axis='y', labelcolor='black')
        
        # Create secondary y-axis for elevation
        ax1_twin = ax1.twinx()
        
        # Plot elevation on secondary y-axis if available
        if elevation_col in flowline_data.columns:
            # Prepare elevation data - invert if requested
            if invert_elevation:
                # Get elevation values and invert them (multiply by F)
                elevation_values = flowline_data[elevation_col].values
                ylabel = 'Elevation (ft)'
            else:
                elevation_values = flowline_data[elevation_col].values
                ylabel = 'Elevation (ft)'
            
            line3 = ax1_twin.plot(x, elevation_values, label='Depth' if invert_elevation else 'Elevation', 
                                color='green', linestyle='-', linewidth=2, alpha=0.5)
            ax1_twin.set_ylabel(ylabel, color='green')
            ax1_twin.tick_params(axis='y', labelcolor='green')
            
            # If inverted, also invert the y-axis direction so depth increases downward
            if invert_elevation:
                ax1_twin.invert_yaxis()
            
            # Create combined legend
            lines1 = [line1]
            if f'{pressure_col}_pred' in flowline_data.columns:
                lines1.append(line2)
            lines1.append(line3[0])
            
            labels1 = [f'True {pressure_col}']
            if f'{pressure_col}_pred' in flowline_data.columns:
                labels1.append(f'Predicted {pressure_col}')
            labels1.append('Depth' if invert_elevation else 'Elevation')
            
            ax1.legend(lines1, labels1, loc='best')
        else:
            ax1.legend(loc='best')
        
        title_elevation = "Depth" if invert_elevation else "Elevation"
        ax1.set_title(f'Pressure and {title_elevation} - Flowline: {flowline}')
        ax1.grid(True)
        ax1.set_xlabel(sort_by)
        
        # ---------- Right subplot: Flow Rate ----------
        ax2 = axes[i, 1]
        
        # Plot actual and predicted flow rate
        ax2.scatter(x, flowline_data[flowrate_col], label=f'True {flowrate_col}', 
                  color='purple', marker='o', alpha=0.7)
        
        if f'{flowrate_col}_pred' in flowline_data.columns:
            ax2.scatter(x, flowline_data[f'{flowrate_col}_pred'], 
                      label=f'Predicted {flowrate_col}', 
                      color='orange', marker='x', alpha=0.7)
        
        ax2.set_ylabel(f'{flowrate_col}')
        ax2.set_title(f'Flow Rate - Flowline: {flowline}')
        ax2.legend(loc='best')
        ax2.grid(True)
        ax2.set_xlabel(sort_by)
    
    # Add overall title
    plt.suptitle(f'Flow Analysis - Scenario {scenario_id}', fontsize=16)
    plt.tight_layout()
    plt.subplots_adjust(top=0.95)
    plt.show()

def visualize_network_results(predictions_df, scenario_id, elevation_col='Elevation', 
                            pressure_col='Pressure', flowrate_col='MassFlowrate',
                            invert_elevation=True):
    """
    Create a comprehensive visualization of network results with multiple plots
    
    Args:
        predictions_df: DataFrame with predictions and ground truth
        scenario_id: Specific scenario to plot
        elevation_col: Column name for elevation data
        pressure_col: Column name for pressure data
        flowrate_col: Column name for flow rate data
        invert_elevation: Whether to invert the elevation axis (to show depth)
    """
    # Filter to the specified scenario
    df = predictions_df[predictions_df["scenario"] == scenario_id].copy()
    
    # 1. First create the standard pressure and flow comparison plots with elevation
    compare_cluster_predictions_with_elevation(
        df, 
        output_cols=[pressure_col, flowrate_col], 
        scenario_id=scenario_id,
        elevation_col=elevation_col,
        invert_elevation=invert_elevation
    )
    
    # 2. Then create the comprehensive profile visualization
    plot_pressure_profile_with_elevation(
        df,
        scenario_id=scenario_id,
        elevation_col=elevation_col,
        pressure_col=pressure_col,
        flowrate_col=flowrate_col,
        invert_elevation=invert_elevation
    )
    
    # 3. Calculate and print error statistics
    print(f"\nError Analysis for Scenario {scenario_id}:")
    
    for col in [pressure_col, flowrate_col]:
        if f'{col}_pred' in df.columns:
            # Calculate absolute and relative errors
            df[f'{col}_abs_error'] = abs(df[col] - df[f'{col}_pred'])
            df[f'{col}_rel_error'] = 100 * df[f'{col}_abs_error'] / (abs(df[col]) + 1e-8)
            
            # Print statistics
            mean_abs_error = df[f'{col}_abs_error'].mean()
            mean_rel_error = df[f'{col}_rel_error'].mean()
            median_rel_error = df[f'{col}_rel_error'].median()
            max_rel_error = df[f'{col}_rel_error'].max()
            
            print(f"\n{col} Error Statistics:")
            print(f"  Mean Absolute Error: {mean_abs_error:.4f}")
            print(f"  Mean Relative Error: {mean_rel_error:.2f}%")
            print(f"  Median Relative Error: {median_rel_error:.2f}%")
            print(f"  Max Relative Error: {max_rel_error:.2f}%")