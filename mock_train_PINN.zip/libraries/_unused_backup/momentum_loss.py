import torch
import numpy as np
import pandas as pd
from libraries.memory_utils import get_device

def compute_momentum_conservation_loss(model, batch_data, input_cols, output_cols,
                                      input_min, input_max, output_min, output_max,
                                      flowline_col="BranchEquipment", node_id_col="node_id",
                                      distance_col="TotalDistance", 
                                      single_phase=True, sampling_ratio=1.0,
                                      device=None):
    """
    Computes momentum conservation loss based on Equation 7 from the paper OIL-GAS MULTIPHASE FLOW SURROGATE MODEL EMBEDDED WITH MECHANISM
FORMULAS.
    
    This function implements the momentum conservation equation:
    (P_in - P_out)/L = [HL*ρL + (1-HL)*ρg] * g * sin(θ) + λ * (2ω*M)/(π*d³) * [1 - (2*(HL*ρL + (1-HL)*ρg)*ω*ωsg)/(P_in + P_out)]
    
    Where:
    - P_in, P_out: Inlet and outlet pressures (psi)
    - L: Segment length (ft)
    - HL: Liquid holdup (dimensionless)
    - ρL: Liquid density (lbm/ft³)
    - ρg: Gas density (lbm/ft³)
    - g: Gravitational acceleration (32.174 ft/s²)
    - θ: Pipe inclination angle (radians)
    - λ: Two-phase friction factor (dimensionless)
    - ω: Average velocity (ft/s)
    - M: Mass flow rate (lbm/s)
    - d: Pipe diameter (ft)
    - ωsg: Gas superficial velocity (ft/s)
    
    Parameters:
        model (torch.nn.Module): Neural network model to evaluate
        batch_data (list): List of dataframes, one per scenario
        input_cols (list): List of input column names
        output_cols (list): List of output column names
        input_min (numpy.ndarray): Minimum values for input scaling
        input_max (numpy.ndarray): Maximum values for input scaling
        output_min (numpy.ndarray): Minimum values for output scaling
        output_max (numpy.ndarray): Maximum values for output scaling
        flowline_col (str): Column name for flowline identifiers
        node_id_col (str): Column name for node identifiers
        distance_col (str): Column name for distance from source
        single_phase (bool): If True, treat as single-phase (liquid only) by setting 
                            gas density and superficial gas velocity to zero
        sampling_ratio (float): Fraction of nodes to sample for momentum calculation
                               to reduce computational load (0.0-1.0)
        device (torch.device): Computation device (CPU or GPU)
        
    Returns:
        torch.Tensor: Momentum conservation loss tensor with gradient
    
    Note:
        - Units expected: mass flow in lbm/s, density in lbm/ft³, diameter in inches
        - The function automatically handles unit conversions (inches to feet)
        - Set single_phase=True to simplify to liquid-only flow (ignores gas properties)
        - When single_phase=True, liquid holdup is set to 1.0
    """
    # Set device if not provided
    if device is None:
        device = get_device(force_cuda=True)
    
    # Initialize loss
    momentum_loss = torch.tensor(0.0, device=device, requires_grad=True)
    segment_count = 0
    
    # Define constants
    g = 32.174  # Gravitational acceleration (ft/s²)
    PI = 3.14159
    
    # Process each scenario
    for scenario_data in batch_data:
        scenario_data = scenario_data.reset_index(drop=True)
        
        # Sample only a subset of flowlines to reduce computational load
        if len(scenario_data[flowline_col].unique()) > 3:
            sampled_flowlines = np.random.choice(
                scenario_data[flowline_col].unique(), 
                size=3, 
                replace=False
            )
        else:
            sampled_flowlines = scenario_data[flowline_col].unique()
        
        # Process only sampled flowlines
        for flowline_id in sampled_flowlines:
            flowline_data = scenario_data[scenario_data[flowline_col] == flowline_id].copy()
            
            # Apply sampling to reduce data points
            if len(flowline_data) > 5 and sampling_ratio < 1.0:
                # Always include first and last points
                first_node = flowline_data.iloc[[0]]
                last_node = flowline_data.iloc[[-1]]
                
                # Sample middle points more aggressively
                if len(flowline_data) > 2:
                    middle_nodes = flowline_data.iloc[1:-1]
                    sample_size = max(2, int(len(middle_nodes) * sampling_ratio))
                    sampled_indices = np.random.choice(
                        range(len(middle_nodes)), 
                        size=min(sample_size, len(middle_nodes)), 
                        replace=False
                    )
                    middle_samples = middle_nodes.iloc[sampled_indices]
                    flowline_data = pd.concat([first_node, middle_samples, last_node]).reset_index(drop=True)
                    flowline_data = flowline_data.sort_values(by=distance_col).reset_index(drop=True)
            
            # Skip if too few points
            if len(flowline_data) < 2:
                continue
                
            # Make predictions for all nodes in the flowline
            with torch.set_grad_enabled(True):
                # Prepare inputs
                all_inputs = []
                for _, node in flowline_data.iterrows():
                    input_values = []
                    for col in input_cols:
                        input_values.append(float(node.get(col, 0.0)))
                    all_inputs.append(input_values)
                
                # Convert to tensor with float32 precision
                inputs_tensor = torch.tensor(all_inputs, dtype=torch.float32, device=device)
                scaled_inputs = (inputs_tensor - torch.tensor(input_min, dtype=torch.float32, device=device)) / \
                                (torch.tensor(input_max, dtype=torch.float32, device=device) - 
                                 torch.tensor(input_min, dtype=torch.float32, device=device) + 1e-8)
                
                # Get model predictions
                preds = model(scaled_inputs)
                
                # Unscale predictions to physical values
                unscaled_preds = torch.zeros_like(preds, device=device)
                for j, col in enumerate(output_cols):
                    if col in ["Pressure", "MassFlowrate"]:
                        # Convert from [-1,1] to physical values
                        unscaled_preds[:, j] = ((preds[:, j] + 1) / 2) * \
                                            (output_max[j] - output_min[j]) + output_min[j]
                
                # Calculate momentum conservation for consecutive node pairs
                for i in range(len(flowline_data) - 1):
                    try:
                        # Get node data
                        upstream_node = flowline_data.iloc[i]
                        downstream_node = flowline_data.iloc[i+1]
                        
                        # Get key parameters
                        segment_length = float(downstream_node[distance_col] - upstream_node[distance_col])
                        if segment_length <= 0:
                            continue  # Skip invalid segments
                        
                        
                        # Get pipe inclination angle (if available, otherwise assume horizontal)
                        inclination = 0.0  # Default: horizontal
                        if 'Inclination' in flowline_data.columns:
                            inclination = float(upstream_node['Inclination'])
                        elif 'ElevationDifference' in flowline_data.columns:
                            # Calculate inclination from elevation difference
                            elev_diff = float(downstream_node['ElevationDifference'] - upstream_node['ElevationDifference'])
                            inclination = np.arcsin(elev_diff / segment_length) if segment_length > 0 else 0.0
                        
                        # Get pressure values (psi)
                        p_in_idx = output_cols.index('Pressure')
                        p_out_idx = output_cols.index('Pressure')
                        p_in = unscaled_preds[i, p_in_idx].item()
                        p_out = unscaled_preds[i+1, p_out_idx].item()
                        p_avg = (p_in + p_out) / 2.0
                        
                        # Get mass flow rate (lbm/s)
                        mass_flow_idx = output_cols.index('MassFlowrate')
                        mass_flow = unscaled_preds[i, mass_flow_idx].item()
                        
                        # Get pipe diameter (inches -> feet)
                        diameter_in = 0.0
                        if 'PipeInsideDiameter' in flowline_data.columns:
                            diameter_in = float(upstream_node['PipeInsideDiameter'])
                        else:
                            # Use a default value if not available
                            diameter_in = 3.0  # Default 3 inches
                        diameter_ft = diameter_in / 12.0
                        
                        # Get liquid density (lbm/ft³)
                        liquid_density = 0.0
                        if 'DensityLiquidInSitu' in flowline_data.columns:
                            liquid_density = float(upstream_node['DensityLiquidInSitu'])
                        else:
                            # Use a default value for water
                            liquid_density = 62.4  # Default: water density
                        
                        # Get liquid holdup
                        liquid_holdup = 1.0  # Default: full liquid
                        if not single_phase and 'HoldupFractionLiquid' in flowline_data.columns:
                            liquid_holdup = float(upstream_node['HoldupFractionLiquid'])
                                                
                        # Get gas density (lbm/ft³)
                        gas_density = 0.0
                        if not single_phase and 'GasDensity' in flowline_data.columns:
                            gas_density = float(upstream_node['GasDensity'])
                        
                        # Get gas superficial velocity (ft/s)
                        gas_velocity = 0.0
                        if not single_phase and 'GasSuperficialVelocity' in flowline_data.columns:
                            gas_velocity = float(upstream_node['GasSuperficialVelocity'])
                        
                        # Get two-phase friction factor
                        friction_factor = 0.01  # Default friction factor
                        if 'lambda_friction' in flowline_data.columns:
                            friction_factor = float(upstream_node['lambda_friction'])
                                                  
                        # Calculate mixture properties
                        # Mixture density (lbm/ft³)
                        mixture_density = liquid_holdup * liquid_density
                        if not single_phase:
                            mixture_density += (1 - liquid_holdup) * gas_density
                        
                        # Calculate cross-sectional area (ft²)
                        area = PI * (diameter_ft ** 2) / 4
                        
                        # Calculate average velocity (ft/s)
                        avg_velocity = mass_flow / (mixture_density * area) if mixture_density * area > 0 else 0.0
                        
                        # Now implement Equation 7 from the paper
                        # (P_in - P_out) / L = [HL*ρL + (1-HL)*ρg] * g * sin(θ) + λ * (2ω*M)/(π*d³) * ...
                        
                        # First term: gravity term
                        gravity_term = mixture_density * g * np.sin(inclination)
                        
                        # Second term: friction term
                        friction_term = friction_factor * (2 * avg_velocity * mass_flow) / (PI * (diameter_ft ** 3))
                        
                        # Third term: momentum correction (from Eq. 7)
                        momentum_correction = 1.0
                        if not single_phase and avg_velocity > 0 and p_avg > 0:
                            momentum_correction = 1.0 - (2 * mixture_density * avg_velocity * gas_velocity) / p_avg
                        
                        # Apply the momentum correction to the friction term
                        friction_term = friction_term / momentum_correction if momentum_correction != 0 else friction_term
                        
                        # Calculate expected pressure gradient from physics
                        expected_dp_dl = gravity_term + friction_term
                        
                        # Calculate actual pressure gradient from predictions
                        actual_dp_dl = (p_in - p_out) / segment_length
                        
                        # Compute loss as squared difference between expected and actual
                        dp_error = (expected_dp_dl - actual_dp_dl)
                        
                        # Normalize error by average pressure to make it unitless
                        normalized_error = dp_error / max(1.0, p_avg)
                        
                        # Add to momentum loss
                        segment_loss = normalized_error ** 2
                        momentum_loss = momentum_loss + segment_loss
                        segment_count += 1
                        
                    except Exception as e:
                        print(f"Error in momentum calculation: {str(e)}")
                        continue
    
    # Return average loss
    if segment_count > 0:
        momentum_loss = momentum_loss / segment_count
    else:
        # Return a zero tensor with gradient
        dummy_param = next(model.parameters())
        momentum_loss = dummy_param * 0.0
        
    return momentum_loss

def compute_pressure_field_loss(model, batch_data, input_cols, output_cols,
                               input_min, input_max, output_min, output_max,
                               flowline_col="BranchEquipment", 
                               distance_col="TotalDistance",
                               interpolation_points=5,
                               device=None):
    """
    Computes the pressure field smoothness loss along flowlines.
    Penalizes rapid changes in pressure gradient (large second derivatives)
    to enforce physically plausible smooth pressure profiles.

    VECTORIZED: All interpolation points across all scenarios/flowlines are
    gathered into a single tensor and passed through the model in ONE forward
    call, avoiding the per-segment Python loop bottleneck.

    Parameters:
        model: Neural network model (expects inputs scaled to [-1, 1])
        batch_data: List of DataFrames, one per scenario
        interpolation_points: Number of interior points between each node pair
        device: torch device

    Returns:
        torch.Tensor: Smoothness loss with gradient
    """
    if device is None:
        device = get_device(force_cuda=True)

    input_min_t = torch.tensor(input_min, dtype=torch.float32, device=device)
    input_max_t = torch.tensor(input_max, dtype=torch.float32, device=device)
    output_min_t = torch.tensor(output_min, dtype=torch.float32, device=device)
    output_max_t = torch.tensor(output_max, dtype=torch.float32, device=device)
    scale_in = input_max_t - input_min_t + 1e-8

    p_idx = output_cols.index("Pressure")
    dist_idx = input_cols.index(distance_col)
    n_total = interpolation_points + 2  # node1 + interp + node2

    # ---- Phase 1: gather all interpolation inputs (numpy, no gradient) ----
    all_inputs = []       # list of numpy arrays, each (n_total, n_features)
    all_distances = []    # list of numpy arrays, each (n_total,)

    for scenario_data in batch_data:
        df = scenario_data.reset_index(drop=True)
        flowlines = df[flowline_col].unique()
        n_sample = min(3, len(flowlines))
        sampled_fls = np.random.choice(flowlines, size=n_sample, replace=False)

        for fl_id in sampled_fls:
            fl_df = df[df[flowline_col] == fl_id].sort_values(distance_col).reset_index(drop=True)
            if len(fl_df) < 2:
                continue

            features = fl_df[input_cols].values.astype(np.float64)
            distances = fl_df[distance_col].values.astype(np.float64)

            for i in range(len(fl_df) - 1):
                d1, d2 = distances[i], distances[i + 1]
                seg_len = d2 - d1
                if seg_len <= 0.1:
                    continue

                # Alphas for interior interpolation points (exclude endpoints)
                alphas = np.linspace(0.0, 1.0, n_total)  # includes 0 and 1
                # Interpolate all features linearly between node1 and node2
                f1 = features[i]    # (n_features,)
                f2 = features[i + 1]
                seg_inputs = f1[None, :] + alphas[:, None] * (f2[None, :] - f1[None, :])
                # Override the distance column with actual interpolated distances
                seg_inputs[:, dist_idx] = d1 + alphas * seg_len
                seg_dists = seg_inputs[:, dist_idx].copy()

                all_inputs.append(seg_inputs.astype(np.float32))
                all_distances.append(seg_dists.astype(np.float32))

    if not all_inputs:
        dummy_param = next(model.parameters())
        return dummy_param * 0.0

    n_segments = len(all_inputs)

    # ---- Phase 2: single batched model forward pass ----
    # Stack all segments into one big tensor: (n_segments * n_total, n_features)
    big_input = np.concatenate(all_inputs, axis=0)
    inp_t = torch.tensor(big_input, device=device)
    # Scale to [-1, 1] (FIXED: was [0,1] before)
    scaled = 2.0 * (inp_t - input_min_t) / scale_in - 1.0

    preds = model(scaled)  # (n_segments * n_total, n_outputs)

    # Unscale pressure to physical units
    p_norm = (preds[:, p_idx] + 1.0) / 2.0
    p_phys = p_norm * (output_max_t[p_idx] - output_min_t[p_idx]) + output_min_t[p_idx]

    # ---- Phase 3: compute second derivatives per segment (vectorized) ----
    # Reshape to (n_segments, n_total)
    p_seg = p_phys.view(n_segments, n_total)
    dist_np = np.stack(all_distances, axis=0)  # (n_segments, n_total)
    dist_t = torch.tensor(dist_np, device=device)

    # First derivatives: dp/dx between consecutive points
    dp = torch.diff(p_seg, dim=1)          # (n_segments, n_total-1)
    dx = torch.diff(dist_t, dim=1)         # (n_segments, n_total-1)
    dx = torch.clamp(dx, min=1e-6)
    first_deriv = dp / dx

    # Second derivatives: d²p/dx² between consecutive first derivatives
    d_first = torch.diff(first_deriv, dim=1)       # (n_segments, n_total-2)
    dx_mid = torch.diff(dist_t[:, :-1], dim=1)     # (n_segments, n_total-2)
    dx_mid = torch.clamp(dx_mid, min=1e-6)
    second_deriv = d_first / dx_mid

    # Smoothness loss: mean squared second derivative across all segments
    field_loss = (second_deriv ** 2).mean()

    return field_loss


def build_high_residual_flowline_weights(
    flowline_residual_tracker,
    quantile=0.75,
    min_observations=3,
    boost_factor=1.5,
    max_boost=2.0,
):
    """
    Build per-flowline momentum weights from residual history.

    Args:
        flowline_residual_tracker (dict): {flowline: [rmse_1, rmse_2, ...]}.
        quantile (float): Quantile threshold used to mark high-residual flowlines.
        min_observations (int): Minimum residual history required per flowline.
        boost_factor (float): Multiplicative factor for high-residual flowlines.
        max_boost (float): Hard cap for any per-flowline weight.

    Returns:
        tuple:
            - weight_map (dict): {flowline: weight}
            - summary (dict): threshold and bookkeeping stats
    """
    if not flowline_residual_tracker:
        return {}, {
            "threshold": None,
            "eligible_count": 0,
            "boosted_count": 0,
        }

    mean_rmse = {}
    for flowline, values in flowline_residual_tracker.items():
        if values is None or len(values) < min_observations:
            continue
        arr = np.asarray(values, dtype=np.float64)
        arr = arr[np.isfinite(arr)]
        if arr.size == 0:
            continue
        mean_rmse[flowline] = float(np.mean(arr))

    if not mean_rmse:
        return {}, {
            "threshold": None,
            "eligible_count": 0,
            "boosted_count": 0,
        }

    threshold = float(np.quantile(list(mean_rmse.values()), quantile))
    weight_map = {}
    boosted_count = 0
    for flowline, rmse_val in mean_rmse.items():
        if rmse_val >= threshold:
            weight_map[flowline] = float(min(boost_factor, max_boost))
            boosted_count += 1
        else:
            weight_map[flowline] = 1.0

    return weight_map, {
        "threshold": threshold,
        "eligible_count": len(mean_rmse),
        "boosted_count": boosted_count,
    }