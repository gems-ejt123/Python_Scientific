# Import this at the top of your notebook
import sys
import types

def apply_field_loss_patch():
    """
    This function patches the batch_loss or training modules to fix the 
    'BranchEquipment' string to float conversion error.
    """
    try:
        from libraries import training
        from libraries import batch_loss
        
        # Original function that likely has the issue
        original_compute_batch_loss = batch_loss.compute_batch_loss
        
        # Define patched function
        def patched_compute_batch_loss(model, batch_data, input_cols, output_cols, 
                                      input_min, input_max, output_min, output_max,
                                      data_weight=1.0, physics_weight=0.0, 
                                      junction_physics_weight=0.0,
                                      field_smoothness_weight=0.0,
                                      min_pressure_sink=30.0,
                                      pressure_continuity_weight=1.0, 
                                      mass_conservation_weight=1.0,
                                      junctions=None,
                                      use_pressure_gradient=False,
                                      pressure_gradient_weight=0.5,
                                      pressure_gradient_sample_rate=1.0,
                                      flowline_col="BranchEquipment",
                                      distance_col="TotalDistance",
                                      device='cpu'):
            """
            Patched version that ensures field_smoothness_weight is properly handled
            """
            # Make sure field_smoothness_weight is a float
            field_smoothness_weight = float(field_smoothness_weight)
            
            # The rest of the function would be the same as the original
            # but here we'll just call the original with our fixed parameters
            return original_compute_batch_loss(
                model, batch_data, input_cols, output_cols, 
                input_min, input_max, output_min, output_max,
                data_weight, physics_weight, 
                junction_physics_weight,
                field_smoothness_weight,
                min_pressure_sink,
                pressure_continuity_weight, 
                mass_conservation_weight,
                junctions,
                use_pressure_gradient,
                pressure_gradient_weight,
                pressure_gradient_sample_rate,
                flowline_col,
                distance_col,
                device
            )
            
        # Apply the patch
        batch_loss.compute_batch_loss = patched_compute_batch_loss
        
        print("Successfully applied field loss patch!")
        return True
    except Exception as e:
        print(f"Failed to apply patch: {e}")
        return False