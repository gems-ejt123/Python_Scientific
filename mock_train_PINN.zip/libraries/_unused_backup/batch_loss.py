import torch
from libraries.data_loss import compute_data_loss
from libraries.sink_boundary_loss import compute_sink_boundary_loss
from libraries.junction_loss import compute_junction_losses
from libraries.memory_utils import get_device
from libraries.momentum_loss import compute_pressure_field_loss 

def compute_batch_loss(model, batch_data, junctions, input_cols, output_cols, 
                     input_min, input_max, output_min, output_max,
                     data_weight=1.0, physics_weight=0.0, junction_physics_weight=0.0,
                     min_pressure_sink=36, sink_node_type=-1, source_node_type=1,
                     pressure_continuity_weight=1.0, mass_conservation_weight=1.0,
                     field_smoothness_weight=0.0,  # New parameter for pressure field smoothness
                     flowline_col="BranchEquipment", node_id_col="node_id",
                     x_col="long", y_col="lat", distance_col="TotalDistance", tol=1e-6,
                     epoch=0, total_epochs=100, use_pressure_gradient=False,
                     pressure_gradient_weight=1.0, pressure_gradient_sample_rate=1.0,
                     device=None):
    """
    Compute complete loss for a batch of scenarios (data loss + physics constraints)
    
    Parameters:
        model: Neural network model
        batch_data: List of dataframes, one per scenario
        junctions: List of junction dictionaries with coordinates and node IDs
        input_cols, output_cols: Lists of input and output column names
        input_min, input_max, output_min, output_max: Scaling parameters
        data_weight: Weight for data loss component
        physics_weight: Weight for physics loss component (sink boundary)
        junction_physics_weight: Weight for junction physics loss component
        min_pressure_sink: Minimum pressure required at sink nodes
        sink_node_type: Node type identifier for sinks
        source_node_type: Node type identifier for sources
        pressure_continuity_weight: Weight for pressure continuity at junctions
        mass_conservation_weight: Weight for mass conservation at junctions
        flowline_col, node_id_col, x_col, y_col, distance_col: Column names
        tol: Tolerance for coordinate matching
        epoch: Current training epoch (for curriculum learning)
        total_epochs: Total number of training epochs
        use_pressure_gradient: Whether to include pressure gradient in data loss
        pressure_gradient_weight: Weight for pressure gradient loss component
        pressure_gradient_sample_rate: Fraction of flowlines to process for gradient (0.0-1.0)
        device: Computation device
    
    Returns:
        total_loss, loss_components
    """
    # Initialize device if needed
    if device is None:
        device = get_device(force_cuda=True)
    
    # Ensure field_smoothness_weight is a float safely at the beginning
    try:
        _field_smoothness_weight = float(field_smoothness_weight)
    except (ValueError, TypeError):
        print(f"WARNING: Invalid field_smoothness_weight: {field_smoothness_weight}, using 0.0 instead")
        _field_smoothness_weight = 0.0
        
    # Compute data loss if needed
    if data_weight > 0:
        data_loss = compute_data_loss(
            model, batch_data, input_cols, output_cols,
            input_min, input_max, output_min, output_max,
            source_node_type=source_node_type, 
            use_pressure_gradient=use_pressure_gradient,
            pressure_gradient_weight=pressure_gradient_weight,
            pressure_gradient_sample_rate=pressure_gradient_sample_rate,
            device=device
        )
        weighted_data_loss = data_weight * data_loss
    else:
        data_loss = torch.tensor(0.0, device=device, requires_grad=True)
        weighted_data_loss = data_loss
    
    # Compute sink boundary physics loss if needed
    if physics_weight > 0:
        boundary_loss = compute_sink_boundary_loss(
            model, batch_data, input_cols, output_cols,
            input_min, input_max, output_min, output_max,
            sink_node_type, min_pressure_sink, device
        )
        
        weighted_boundary_loss = physics_weight * boundary_loss
    else:
        boundary_loss = torch.tensor(0.0, device=device, requires_grad=True)
        weighted_boundary_loss = boundary_loss
    
    # Compute junction physics losses if needed
    if junction_physics_weight > 0 and junctions:
        junction_loss, junction_components = compute_junction_losses(
            model, batch_data, junctions, input_cols, output_cols,
            input_min, input_max, output_min, output_max,
            flowline_col, node_id_col, x_col, y_col, distance_col,
            source_node_type, tol, pressure_continuity_weight, mass_conservation_weight,
            device,
            epoch=epoch, total_epochs=total_epochs  # Pass both parameters
        )
        
        weighted_junction_loss = junction_physics_weight * junction_loss
        pressure_continuity_loss = junction_components['pressure_continuity_loss']
        mass_conservation_loss = junction_components['mass_conservation_loss']
    else:
        junction_loss = torch.tensor(0.0, device=device, requires_grad=True)
        weighted_junction_loss = junction_loss
        pressure_continuity_loss = 0.0
        mass_conservation_loss = 0.0
    
    # Combine all weighted losses
    total_loss = weighted_data_loss + weighted_boundary_loss + weighted_junction_loss
    
    # Physics loss is the sum of all physics losses
    physics_loss = boundary_loss
    if junction_physics_weight > 0:
        physics_loss = physics_loss + junction_loss
    


    if _field_smoothness_weight > 0.0:
        pressure_field_loss = compute_pressure_field_loss(
            model, batch_data, input_cols, output_cols,
            input_min, input_max, output_min, output_max,
            flowline_col=flowline_col,
            distance_col=distance_col,
            interpolation_points=5,  # Use 5 interpolation points between actual nodes
            device=device
        )

        print(f"pressure_field_loss type: {type(pressure_field_loss)}, value: {pressure_field_loss}")
        
        weighted_field_loss = _field_smoothness_weight * pressure_field_loss
    else:
        pressure_field_loss = torch.tensor(0.0, device=device, requires_grad=True)
        weighted_field_loss = pressure_field_loss
    
    # Update total loss to include field loss
    total_loss = weighted_data_loss + weighted_boundary_loss + weighted_junction_loss + weighted_field_loss
    
    # Physics loss is the sum of all physics losses
    physics_loss = boundary_loss
    if junction_physics_weight > 0:
        physics_loss = physics_loss + junction_loss
    if _field_smoothness_weight > 0:  # Use the safe variable here too
        physics_loss = physics_loss + pressure_field_loss
    
    # Update loss components dictionary
    loss_components = {
        'data_loss': data_loss.item(),
        'physics_loss': physics_loss.item(),
        'boundary_loss': boundary_loss.item(),
        'pressure_continuity_loss': pressure_continuity_loss,
        'mass_conservation_loss': mass_conservation_loss,
        'pressure_field_loss': pressure_field_loss.item() if _field_smoothness_weight > 0 else 0.0,
        'total_loss': total_loss.item()
    }
    
    return total_loss, loss_components