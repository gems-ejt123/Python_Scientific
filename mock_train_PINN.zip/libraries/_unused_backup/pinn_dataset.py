import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd

class PINNDataset(Dataset):
    """Custom Dataset for Physics-Informed Neural Networks"""
    
    def __init__(self, dataframe, input_cols, output_cols, 
                 scenario_ids=None, source_node_type=1,
                 input_min=None, input_max=None, 
                 output_min=None, output_max=None):
        """
        Initialize the dataset.
        
        Args:
            dataframe: Pandas DataFrame containing the data
            input_cols: List of input column names
            output_cols: List of output column names
            scenario_ids: List of scenario IDs to include (optional)
            source_node_type: Node type identifier for sources
            input_min, input_max: Min/max values for input scaling (optional)
            output_min, output_max: Min/max values for output scaling (optional)
        """
        # Filter by scenarios if provided
        if scenario_ids is not None:
            self.df = dataframe[dataframe['scenario'].isin(scenario_ids)].copy()
        else:
            self.df = dataframe.copy()
            
        self.input_cols = input_cols
        self.output_cols = output_cols
        self.source_node_type = source_node_type
        
        # Group by scenario for batch access
        self.scenarios = self.df['scenario'].unique()
        self.scenario_data = {
            scenario: self.df[self.df['scenario'] == scenario].reset_index(drop=True)
            for scenario in self.scenarios
        }
        
        # Store scaling parameters
        self.input_min = input_min
        self.input_max = input_max
        self.output_min = output_min
        self.output_max = output_max
    
    def __len__(self):
        """Return the number of scenarios in the dataset"""
        return len(self.scenarios)
    
    def __getitem__(self, idx):
        """Get a scenario by index"""
        scenario_id = self.scenarios[idx]
        scenario_df = self.scenario_data[scenario_id]
        
        # Extract input and output values
        inputs = np.array([
            [float(row.get(col, 0.0)) for col in self.input_cols]
            for _, row in scenario_df.iterrows()
        ])
        
        outputs = np.array([
            [float(row.get(col, 0.0)) for col in self.output_cols]
            for _, row in scenario_df.iterrows()
        ])
        
        # Convert to tensors
        inputs_tensor = torch.tensor(inputs, dtype=torch.float32)
        outputs_tensor = torch.tensor(outputs, dtype=torch.float32)
        
        return {
            'scenario_id': scenario_id,
            'inputs': inputs_tensor, 
            'outputs': outputs_tensor,
            'scenario_df': scenario_df  # Keep DataFrame for physics calculations
        }
    
    def get_scaling_params(self):
        """Calculate or return scaling parameters"""
        if self.input_min is None or self.input_max is None or self.output_min is None or self.output_max is None:
            # Calculate scaling parameters if not provided
            all_inputs = []
            all_outputs = []
            
            for scenario_id in self.scenarios:
                scenario_df = self.scenario_data[scenario_id]
                
                for _, row in scenario_df.iterrows():
                    input_values = [float(row.get(col, 0.0)) for col in self.input_cols]
                    output_values = [float(row.get(col, 0.0)) for col in self.output_cols]
                    all_inputs.append(input_values)
                    all_outputs.append(output_values)
            
            # Convert to numpy arrays
            all_inputs = np.array(all_inputs)
            all_outputs = np.array(all_outputs)
            
            # Calculate min/max
            input_min = np.min(all_inputs, axis=0)
            input_max = np.max(all_inputs, axis=0)
            output_min = np.min(all_outputs, axis=0)
            output_max = np.max(all_outputs, axis=0)
            
            # Store for future use
            self.input_min = input_min
            self.input_max = input_max
            self.output_min = output_min
            self.output_max = output_max
        
        return self.input_min, self.input_max, self.output_min, self.output_max

# Custom collate function that properly handles DataFrames
def pinn_collate_fn(batch):
    """Custom collate function for the PINN dataset that handles DataFrames"""
    scenario_ids = [item['scenario_id'] for item in batch]
    inputs = torch.stack([item['inputs'] for item in batch])
    outputs = torch.stack([item['outputs'] for item in batch])
    
    # Keep DataFrames in a list (don't try to collate them)
    scenario_dfs = [item['scenario_df'] for item in batch]
    
    return {
        'scenario_ids': scenario_ids,
        'inputs': inputs,
        'outputs': outputs,
        'scenario_dfs': scenario_dfs
    }

def create_dataloaders(dataframe, input_cols, output_cols, train_scenarios, val_scenarios,
                      batch_size=64, num_workers=4, source_node_type=1,
                      input_min=None, input_max=None, output_min=None, output_max=None):
    """
    Create training and validation DataLoaders.
    
    Args:
        dataframe: Pandas DataFrame containing all data
        input_cols: List of input column names
        output_cols: List of output column names
        train_scenarios: List of scenario IDs for training
        val_scenarios: List of scenario IDs for validation
        batch_size: Batch size for DataLoader
        num_workers: Number of worker processes for DataLoader
        source_node_type: Node type identifier for sources
        input_min, input_max, output_min, output_max: Scaling parameters (optional)
        
    Returns:
        train_loader, val_loader, (input_min, input_max, output_min, output_max)
    """
    # Create training dataset
    train_dataset = PINNDataset(
        dataframe, input_cols, output_cols, 
        scenario_ids=train_scenarios,
        source_node_type=source_node_type,
        input_min=input_min, input_max=input_max,
        output_min=output_min, output_max=output_max
    )
    
    # Calculate scaling parameters if not provided
    if input_min is None or input_max is None or output_min is None or output_max is None:
        input_min, input_max, output_min, output_max = train_dataset.get_scaling_params()
    
    # Create validation dataset with the same scaling parameters
    val_dataset = PINNDataset(
        dataframe, input_cols, output_cols,
        scenario_ids=val_scenarios,
        source_node_type=source_node_type,
        input_min=input_min, input_max=input_max,
        output_min=output_min, output_max=output_max
    )
    
    # Create DataLoaders with custom collate function
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
        collate_fn=pinn_collate_fn,  # Use custom collate function
        persistent_workers=True if num_workers > 0 else False,
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
        collate_fn=pinn_collate_fn,  # Use custom collate function
        persistent_workers=True if num_workers > 0 else False
    )
    
    return train_loader, val_loader, (input_min, input_max, output_min, output_max)