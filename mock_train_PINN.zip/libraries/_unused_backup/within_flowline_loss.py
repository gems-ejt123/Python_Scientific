"""Within-flowline pressure-profile (shape) loss.

Motivation
----------
The FE-GNN-PINN reaches high GLOBAL pressure accuracy (R2 ~ 0.94, MAE ~ 8 psi)
but poor WITHIN-flowline accuracy: the pressure difference between flowlines is
right, yet the pressure profile *inside* a flowline is blurred (valid-bucket
within-flowline R2 median ~ -1.35, 77% negative). Because a single flowline's
internal pressure spread is only ~8-40 psi, an 8-11 psi node error erases the
profile shape. That is what produces the large residual outliers and threatens
overpressure ranking, which depends on resolving tens-of-psi gradients rather
than the 35-459 psi global scale the data loss is optimized on.

The momentum loss constrains the CUMULATIVE flowline drop through a friction
closure, so it cannot supervise the fine local gradient. This term does exactly
that, in a purely data-driven way: it matches predicted to actual pressure
DIFFERENCES between adjacent nodes along each flowline.

Design
------
It reuses the SAME graph the FE-GNN message-passes over. The in-pipe segment
edges (``is_junction_edge == False``) are, by construction, the adjacent-node
pairs within each flowline. Node index i therefore aligns across the graph, the
model output, and the scenario-graph batches (all use the identical
``sort_values(["BranchEquipment", "TotalDistance"])`` layout). No re-derivation,
no ordering assumptions beyond the one the pipeline already relies on.

The loss operates in the model's [-1, 1] scaled pressure space (linear MinMax),
so its magnitude stays comparable to the SmoothL1 data loss and it is directly
proportional to the psi-space gradient error.
"""

import torch
import torch.nn as nn


class WithinFlowlineShapeLoss:
    """SmoothL1 between predicted and actual adjacent-node pressure differences.

    Parameters
    ----------
    graph : PipelineGraph
        The fixed trunk graph (``build_pipeline_graph``). Its in-pipe segment
        edges define the adjacent-node pairs.
    pressure_index : int
        Column of the pressure output in the model's output vector.
    huber_beta : float
        SmoothL1 transition point (in scaled space). Small so most gradient
        residuals stay in the quadratic regime.
    device : torch.device or None
        Where to place the cached index tensors.

    Call
    ----
    ``loss(preds, target)`` where ``preds`` / ``target`` are ``[S * n_nodes,
    n_output]`` scaled tensors in canonical node order (one contiguous block of
    ``n_nodes`` rows per scenario). Returns a scalar tensor.
    """

    def __init__(self, graph, pressure_index=0, huber_beta=0.05, device=None):
        self.n_nodes = int(graph.n_nodes)
        self.p_idx = int(pressure_index)

        edge_index = graph.edge_index
        is_junc = graph.is_junction_edge.bool()

        # Keep only in-pipe segment edges, one direction per undirected pair
        # (src < dst) so each adjacent pair is counted once.
        src = edge_index[0]
        dst = edge_index[1]
        keep = (~is_junc) & (src < dst)
        self.src = src[keep].clone()
        self.dst = dst[keep].clone()
        if device is not None:
            self.src = self.src.to(device)
            self.dst = self.dst.to(device)

        self.n_pairs = int(self.src.numel())
        self._smooth_l1 = nn.SmoothL1Loss(reduction="mean", beta=float(huber_beta))

    def to(self, device):
        self.src = self.src.to(device)
        self.dst = self.dst.to(device)
        return self

    def __call__(self, preds, target):
        if self.n_pairs == 0:
            return preds.new_zeros(())

        total = preds.shape[0]
        n = self.n_nodes
        if total % n != 0:
            # Batch is not whole-scenario blocks (e.g. a row-shuffled loader);
            # the within-flowline pairing is undefined, so skip safely.
            return preds.new_zeros(())
        s = total // n

        # [S, N] scaled pressure for predictions and targets.
        p_pred = preds[:, self.p_idx].view(s, n)
        p_true = target[:, self.p_idx].view(s, n)

        # Adjacent-node differences along every flowline segment, per scenario.
        pred_d = p_pred[:, self.dst] - p_pred[:, self.src]   # [S, n_pairs]
        true_d = p_true[:, self.dst] - p_true[:, self.src]   # [S, n_pairs]

        return self._smooth_l1(pred_d, true_d)
