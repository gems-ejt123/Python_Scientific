import torch
from libraries.pinn_models import Surrogate_PINN
from libraries.memory_utils import get_device
from libraries.azure import save_torch_model_to_blob

def save_model(model, filename, input_cols, output_cols, 
              input_min, input_max, output_min, output_max, 
              history=None, additional_info=None, run_sandbox=False, save_to_log=False, log_file=""):
    """
    Save the trained model with all necessary information.
    
    Parameters:
        model: Trained neural network model
        filename: Output filename
        input_cols: List of input column names
        output_cols: List of output column names
        input_min, input_max: Min/max values for input scaling
        output_min, output_max: Min/max values for output scaling
        history: Training history dictionary
        additional_info: Additional information to save
    """
    # Get model architecture information
    hidden_layers = []
    if hasattr(model, 'hidden_layers'):
        for layer in model.hidden_layers:
            # Check if this is a PhysicsAwareLayer (new architecture)
            if hasattr(layer, 'linear'):
                # Extract size directly from the linear layer attribute
                hidden_layers.append(layer.linear.out_features)
            # Backward compatibility for older model types
            elif hasattr(layer, '__iter__'):
                for module in layer:
                    if isinstance(module, torch.nn.Linear):
                        hidden_layers.append(module.out_features)
    
    # Store model metadata
    model_metadata = {
        'architecture': {
            'hidden_layers': hidden_layers,
            'hidden_activation': model.hidden_activation_type if hasattr(model, 'hidden_activation_type') else 'relu',
            'pressure_activation': model.pressure_activation_type if hasattr(model, 'pressure_activation_type') else 'tanh'
        }
    }
    
    # Create save dictionary
    save_dict = {
        'model_state_dict': model.state_dict(),
        'input_min': input_min,
        'input_max': input_max,
        'output_min': output_min,
        'output_max': output_max,
        'input_cols': input_cols,
        'output_cols': output_cols,
        'activation_types': model.get_activation_types() if hasattr(model, 'get_activation_types') else None,
        'model_metadata': model_metadata
    }
    
    # Add training history if provided
    if history is not None:
        save_dict['history'] = history
        
    # Add additional information if provided
    if additional_info is not None:
        for key, value in additional_info.items():
            save_dict[key] = value
    
    # Save to file
    try:
        if run_sandbox:
            print("Saving model to Azure Blob Storage...")
            msg = save_torch_model_to_blob(full_blob_url=filename,
                              save_dict=save_dict,
                              save_to_log=save_to_log,
                              log_file=log_file)
            print(msg)
        else:
            torch.save(save_dict, filename)
            print(f"Model saved to {filename}")
    except Exception as e:
        print(f"Error saving model: {str(e)}")
        raise Exception(f"Failed to save model to {filename}") from e
    
def load_model(filename, device=None):
    """
    Load a trained model with all necessary information.
    
    Parameters:
        filename: Input filename
        device: Computation device (None = auto-detect)
        
    Returns:
        model, input_cols, output_cols, (input_min, input_max, output_min, output_max), additional_info
    """
    # Determine device
    if device is None:
        device = get_device(force_cuda=True)
    
    try:
        # Load saved information
        saved_info = torch.load(filename, map_location=device)
        
        # Extract model configuration
        input_cols = saved_info['input_cols']
        output_cols = saved_info['output_cols']
        
        # Get hidden layers architecture
        hidden_layers = [64, 256, 512, 1024, 512, 256, 64]  # Default architecture
        
        if 'model_metadata' in saved_info and 'architecture' in saved_info['model_metadata']:
            arch_info = saved_info['model_metadata']['architecture']
            if 'hidden_layers' in arch_info and len(arch_info['hidden_layers']) > 0:
                hidden_layers = arch_info['hidden_layers']
        
        # Get activation types
        activation_types = saved_info.get('activation_types', None)
        pressure_activation = "tanh"
        hidden_activation = "relu"
        
        if activation_types and "pressure" in activation_types:
            pressure_activation = activation_types["pressure"]
        
        if 'model_metadata' in saved_info and 'architecture' in saved_info['model_metadata']:
            arch_info = saved_info['model_metadata']['architecture']
            if 'hidden_activation' in arch_info:
                hidden_activation = arch_info['hidden_activation']
            if 'pressure_activation' in arch_info:
                pressure_activation = arch_info['pressure_activation']
        
        # Create model with the same architecture
        model = Surrogate_PINN(
            n_input=len(input_cols),
            n_output=len(output_cols),
            hidden_layers=hidden_layers,
            hidden_activation=hidden_activation,
            pressure_activation=pressure_activation,
            weight_norm=True,
            dropout_rate=0.0001
        )
        
        # Load weights
        model.load_state_dict(saved_info['model_state_dict'])
        model.to(device)
        model.eval()
        
        # Extract scaling parameters
        input_min = saved_info['input_min']
        input_max = saved_info['input_max']
        output_min = saved_info['output_min']
        output_max = saved_info['output_max']
        
        # Create a dictionary with all additional information
        additional_info = {k: v for k, v in saved_info.items() 
                          if k not in ['model_state_dict', 'input_min', 'input_max', 
                                     'output_min', 'output_max', 'input_cols', 'output_cols',
                                     'activation_types', 'model_metadata']}
        
        print(f"Model loaded from {filename}")
        print(f"Architecture: {len(hidden_layers)} hidden layers with sizes {hidden_layers}")
        print(f"Input columns ({len(input_cols)}): {input_cols}")
        print(f"Output columns ({len(output_cols)}): {output_cols}")
        
        return model, input_cols, output_cols, (input_min, input_max, output_min, output_max), additional_info
    
    except Exception as e:
        print(f"Error loading model: {str(e)}")
        return None, None, None, (None, None, None, None), None
