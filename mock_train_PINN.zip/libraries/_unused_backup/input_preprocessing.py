
import numpy as np
import torch
import pandas as pd
# -------------------------------------------
# Scaling Functions (0 to 1 normalization)
# -------------------------------------------
def scale_data(data_tensor, min_vals=None, max_vals=None):
    """
    Scale data tensor to range [0, 1] using min-max scaling.
    If min_vals and max_vals are provided, uses them for scaling,
    otherwise computes them from the data.
    
    Args:
        data_tensor: Input data tensor
        min_vals: Optional tensor of minimum values
        max_vals: Optional tensor of maximum values
    
    Returns:
        Scaled data tensor, min_vals, max_vals
    """
    if min_vals is None or max_vals is None:
        # Compute min and max values along first dimension (per feature)
        min_vals = torch.min(data_tensor, dim=0)[0]
        max_vals = torch.max(data_tensor, dim=0)[0]
    
    # Add small epsilon to prevent division by zero
    epsilon = 1e-8
    divisor = max_vals - min_vals + epsilon
    
    # Scale to [0, 1]
    scaled_data = (data_tensor - min_vals) / divisor
    
    return scaled_data, min_vals, max_vals

def unscale_data(scaled_tensor, min_vals, max_vals):
    """
    Convert scaled data (range [-1, 1] for tanh activation) back to original range.
    
    Args:
        scaled_tensor: Scaled data tensor in range [-1, 1]
        min_vals: Tensor of minimum values
        max_vals: Tensor of maximum values
    
    Returns:
        Unscaled data tensor in original range
    """
    # Convert from [-1, 1] to [0, 1] for tanh activation
    normalized = (scaled_tensor + 1) / 2
    
    # Unscale from [0, 1] to original range
    unscaled = normalized * (max_vals - min_vals) + min_vals
    
    return unscaled



# -------------------------------------------
# Calculate Distance From Source
# -------------------------------------------
def calculate_distance_from_source(data, distance_col="TotalDistance", 
                                flowline_col="BranchEquipment",
                                node_type_col="node_type",
                                source_node_type=1):
    """
    Calculate the distance of each node from its source node in each flowline.
    
    Args:
        data: DataFrame with pipeline network data
        distance_col: Column name containing total distance information
        flowline_col: Column name identifying different flowlines
        node_type_col: Column name identifying node types
        source_node_type: Node type identifier for sources
    
    Returns:
        DataFrame with additional column 'DistanceFromSource'
    """
    result_df = data.copy()
    result_df['DistanceFromSource'] = 0.0  # Default value
    
    # Process each scenario separately
    for scenario_id in data['scenario'].unique():
        scenario_data = data[data['scenario'] == scenario_id]
        
        # Process each flowline
        for flowline_id in scenario_data[flowline_col].unique():
            # Get data for this flowline
            flowline_data = scenario_data[scenario_data[flowline_col] == flowline_id].copy()
            
            # Find source nodes for this flowline
            source_nodes = flowline_data[flowline_data[node_type_col] == source_node_type]
            
            if source_nodes.empty:
                print(f"Warning: No source nodes found for flowline {flowline_id} in scenario {scenario_id}")
                continue
                
            # Get the first source node and its distance
            source_node = source_nodes.iloc[0]
            source_distance = source_node[distance_col]
            
            # Calculate distance from source for each node
            for idx, node in flowline_data.iterrows():
                # Distance from source is the absolute difference in total distance
                distance_from_source = abs(node[distance_col] - source_distance)
                result_df.loc[idx, 'DistanceFromSource'] = distance_from_source
    
    return result_df

# -------------------------------------------
# Include onlye pressure at sources
# -------------------------------------------

def prepare_source_based_dataset(data_df, source_input_cols, source_node_type=1, scenario_ids=None):
    """
    Creates a dataset where each node in each flowline has the same source node input values
    but keeps the correct source values for each individual scenario.
    
    Args:
        data_df: DataFrame containing the full dataset
        source_input_cols: List of columns to take from source nodes
        source_node_type: Value in node_type column that identifies source nodes
        scenario_ids: List of scenario IDs to process (None = use all in data_df)
    
    Returns:
        DataFrame with source node values propagated to all nodes in the same flowline
    """
    # Make a copy to avoid modifying the original
    result_df = data_df.copy()
    
    # Filter to specified scenarios if provided
    if scenario_ids is not None:
        result_df = result_df[result_df['scenario'].isin(scenario_ids)].copy()
    
    # Process each scenario separately to avoid cross-contamination
    all_scenarios = sorted(result_df['scenario'].unique())
    
    # Create a new DataFrame to hold the processed results
    processed_dfs = []
    
    for scenario_id in all_scenarios:
        # Get data for just this scenario
        scenario_df = result_df[result_df['scenario'] == scenario_id].copy()
        
        # Process each flowline in this scenario
        for flowline_id in scenario_df['BranchEquipment'].unique():
            # Get data for this flowline
            flowline_data = scenario_df[scenario_df['BranchEquipment'] == flowline_id]
            
            # Find source nodes in this flowline
            source_nodes = flowline_data[flowline_data['node_type'] == source_node_type]
            
            if not source_nodes.empty:
                # Take the first source node (in case there are multiple)
                source_node = source_nodes.iloc[0]
                
                # For each source input column, propagate the source value to all nodes in this flowline
                for col in source_input_cols:
                    if col in source_node:
                        scenario_df.loc[scenario_df['BranchEquipment'] == flowline_id, col] = source_node[col]
        
        # Add the processed scenario data to our results
        processed_dfs.append(scenario_df)
    
    # Combine all processed scenarios
    if processed_dfs:
        combined_df = pd.concat(processed_dfs, ignore_index=True)
        return combined_df
    else:
        print("Warning: No data was processed. Check your filtering criteria.")
        return result_df

def add_source_pressure(data_df, source_node_type=1, scenario_ids=None):
    """
    Adds source pressure as a feature to all nodes in each flowline
    while maintaining scenario-specific source pressure values.
    
    Args:
        data_df: DataFrame containing the full dataset
        source_node_type: Value in node_type column that identifies source nodes
        scenario_ids: List of scenario IDs to process (None = use all in data_df)
    
    Returns:
        DataFrame with a new SourcePressure column
    """
    # Make a copy to avoid modifying the original
    result_df = data_df.copy()
    
    # Filter to specified scenarios if provided
    if scenario_ids is not None:
        result_df = result_df[result_df['scenario'].isin(scenario_ids)].copy()
    
    # Initialize the SourcePressure column with NaN
    result_df['SourcePressure'] = float('nan')
    
    # Process each scenario separately
    all_scenarios = sorted(result_df['scenario'].unique())
    
    for scenario_id in all_scenarios:
        # Get data for just this scenario
        scenario_df = result_df[result_df['scenario'] == scenario_id]
        
        # Process each flowline in this scenario
        for flowline_id in scenario_df['BranchEquipment'].unique():
            # Get data for this flowline
            flowline_data = scenario_df[scenario_df['BranchEquipment'] == flowline_id]
            
            # Find source nodes in this flowline
            source_nodes = flowline_data[flowline_data['node_type'] == source_node_type]
            
            if not source_nodes.empty:
                # Take the first source node pressure (in case there are multiple)
                source_pressure = source_nodes['Pressure'].iloc[0]
                
                # Propagate the source pressure to all nodes in this flowline
                mask = (result_df['scenario'] == scenario_id) & (result_df['BranchEquipment'] == flowline_id)
                result_df.loc[mask, 'SourcePressure'] = source_pressure
    
    # Fill any remaining NaN values (flowlines without source nodes)
    # For these, we could use a fallback strategy like using junction node pressure
    # or propagating pressure from connected flowlines
    if result_df['SourcePressure'].isna().any():
        print(f"Warning: {result_df['SourcePressure'].isna().sum()} nodes couldn't be assigned a source pressure")
        
        # Fallback: For nodes without a source in their flowline, 
        # use their own pressure as SourcePressure
        result_df.loc[result_df['SourcePressure'].isna(), 'SourcePressure'] = \
            result_df.loc[result_df['SourcePressure'].isna(), 'Pressure']
    
    return result_df

def calculate_elevation_differences(data_df, elevation_col="Elevation", 
                                 distance_col="TotalDistance", flowline_col="BranchEquipment",
                                 node_type_col="node_type", source_node_type=1):
    """
    Calculate elevation differences for each node based on their distance from source.
    
    Args:
        data_df: DataFrame containing the pipeline network data
        elevation_col: Column name for elevation values
        distance_col: Column name for distance values (distance from source)
        flowline_col: Column name identifying different flowlines
        node_type_col: Column name identifying node types
        source_node_type: Value in node_type column that identifies source nodes
    
    Returns:
        DataFrame with a new ElevationDifference column
    """
    # Make a copy to avoid modifying the original
    result_df = data_df.copy()
    
    # Initialize elevation difference column
    result_df['ElevationDifference'] = 0.0
    
    # Process each scenario separately
    for scenario_id in result_df['scenario'].unique():
        scenario_data = result_df[result_df['scenario'] == scenario_id]
        
        # Process each flowline separately
        for flowline_id in scenario_data[flowline_col].unique():
            flowline_data = scenario_data[scenario_data[flowline_col] == flowline_id]
            
            # Find source nodes in this flowline
            source_nodes = flowline_data[flowline_data[node_type_col] == source_node_type]
            
            if not source_nodes.empty:
                # Get the source node with the smallest distance
                source_node = source_nodes.sort_values(by=distance_col).iloc[0]
                source_elevation = source_node[elevation_col]
                
                # Calculate elevation difference for each node in this flowline
                for idx, node in flowline_data.iterrows():
                    elev_diff = node[elevation_col] - source_elevation
                    result_df.loc[idx, 'ElevationDifference'] = elev_diff
            else:
                # No source node found in this flowline
                # Use the node with minimum distance as reference
                if not flowline_data.empty:
                    ref_node = flowline_data.sort_values(by=distance_col).iloc[0]
                    ref_elevation = ref_node[elevation_col]
                    
                    # Calculate elevation difference relative to reference node
                    for idx, node in flowline_data.iterrows():
                        elev_diff = node[elevation_col] - ref_elevation
                        result_df.loc[idx, 'ElevationDifference'] = elev_diff
    
    return result_df