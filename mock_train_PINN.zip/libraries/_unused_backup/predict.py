import torch
from libraries.memory_utils import get_device

def predict_pinn(model, data, input_cols, output_cols, 
                input_min, input_max, output_min, output_max, 
                device=None):
    """
    Make predictions using a trained PINN model
    
    Parameters:
        model: Trained neural network model
        data: DataFrame with input data
        input_cols, output_cols: Lists of input and output column names
        input_min, input_max, output_min, output_max: Scaling parameters
        device: Computation device (CPU or GPU)
        
    Returns:
        predictions: DataFrame with original data and predictions
    """
    if device is None:
        device = get_device()
    
    model = model.to(device)
    model.eval()
    
    # Make a copy of the data
    predictions = data.copy()
    
    # Get activation types - handle missing attribute safely
    activation_types = model.get_activation_types() if hasattr(model, 'get_activation_types') else {
        "pressure": "tanh", 
        "mass_flow": "tanh"
    }
    
    # Create tensors for scaling
    input_min_tensor = torch.tensor(input_min, dtype=torch.float32, device=device)
    input_max_tensor = torch.tensor(input_max, dtype=torch.float32, device=device)
    output_min_tensor = torch.tensor(output_min, dtype=torch.float32, device=device)
    output_max_tensor = torch.tensor(output_max, dtype=torch.float32, device=device)
    
    with torch.no_grad():
        # Prepare inputs
        inputs = []
        for _, row in data.iterrows():
            input_values = []
            for col in input_cols:
                input_values.append(float(row.get(col, 0.0)))
            inputs.append(input_values)
        
        if not inputs:
            return predictions
        
        # Convert to tensor and normalize
        inputs_tensor = torch.tensor(inputs, dtype=torch.float32, device=device)
        scaled_inputs = (inputs_tensor - input_min_tensor) / (input_max_tensor - input_min_tensor + 1e-8)
        
        # Get predictions
        outputs = model(scaled_inputs)
        
        # Unscale predictions for physical values
        physical_preds = torch.zeros_like(outputs, device=device)
        for i, col in enumerate(output_cols):
            act_type = "tanh"  # Default
            if col == "Pressure" and "pressure" in activation_types:
                act_type = activation_types["pressure"]
            
            if act_type == "tanh":
                normalized = (outputs[:, i] + 1) / 2
                physical_preds[:, i] = normalized * (output_max_tensor[i] - output_min_tensor[i]) + output_min_tensor[i]
            elif act_type == "silu":
                normalized = torch.clamp(outputs[:, i], 0.0, 1.0)
                physical_preds[:, i] = normalized * (output_max_tensor[i] - output_min_tensor[i]) + output_min_tensor[i]
            elif act_type == "linear":
                normalized = torch.sigmoid(outputs[:, i])
                physical_preds[:, i] = normalized * (output_max_tensor[i] - output_min_tensor[i]) + output_min_tensor[i]
        
        # Add predictions to the dataframe
        physical_preds = physical_preds.cpu().numpy()
        for i, col in enumerate(output_cols):
            predictions[f"{col}_pred"] = physical_preds[:, i]
    
    return predictions