import numpy as np

def create_physics_weight_scheduler(initial_weight=0.0, final_weight=1.0, warmup_epochs=10, mode='linear'):
    """
    Create a scheduler function that gradually increases the physics weight.
    
    Parameters:
        initial_weight: Starting weight for physics loss
        final_weight: Final weight for physics loss
        warmup_epochs: Number of epochs to reach final weight
        mode: 'linear', 'exponential', or 'step'
        
    Returns:
        Function that takes epoch number and returns physics weight
    """
    def scheduler(epoch):
        if epoch >= warmup_epochs:
            return final_weight
        
        if mode == 'linear':
            # Linear ramp-up
            return initial_weight + (final_weight - initial_weight) * (epoch / warmup_epochs)
        elif mode == 'exponential':
            # Exponential ramp-up
            return initial_weight + (final_weight - initial_weight) * (1 - np.exp(-5 * epoch / warmup_epochs))
        elif mode == 'step':
            # Step function (half-way)
            return initial_weight if epoch < warmup_epochs // 2 else final_weight
        else:
            return final_weight
            
    return scheduler