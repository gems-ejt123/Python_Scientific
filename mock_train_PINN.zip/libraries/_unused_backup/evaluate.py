import torch
import pandas as pd
import numpy as np
from libraries.plot_pinn import visualize_junction_performance
from libraries.memory_utils import get_device

def evaluate_model(model, test_data, input_cols, output_cols, 
                 input_min, input_max, output_min, output_max,
                 junctions=None, scenario_ids=None,
                 max_nodes_per_scenario=500, max_scenarios=5,
                 device=None):
    """
    Evaluate a trained model on test data with memory optimization.
    
    Parameters:
        model: Trained neural network model
        test_data: DataFrame with test data
        input_cols: List of input column names
        output_cols: List of output column names
        input_min, input_max: Min/max values for input scaling
        output_min, output_max: Min/max values for output scaling
        junctions: List of junction dictionaries (optional)
        scenario_ids: List of specific scenario IDs to evaluate (None = all)
        max_nodes_per_scenario: Maximum number of nodes to evaluate per scenario
        max_scenarios: Maximum number of scenarios to evaluate
        device: Computation device
        
    Returns:
        Dictionary with evaluation metrics and predictions
    """
    # Check if device is specified, otherwise use default
    if device is None:
        device = get_device(force_cuda=True)
    

    model.to(device)
    model.eval()
    
    # Filter scenarios if specified
    if scenario_ids is not None:
        scenarios_to_evaluate = scenario_ids
    else:
        scenarios_to_evaluate = test_data['scenario'].unique()
    
    # Limit number of scenarios for evaluation if needed
    if len(scenarios_to_evaluate) > max_scenarios:
        scenarios_to_evaluate = np.random.choice(
            scenarios_to_evaluate, size=max_scenarios, replace=False)
        print(f"Limiting evaluation to {max_scenarios} randomly selected scenarios")
    
    print(f"Evaluating model on {len(scenarios_to_evaluate)} scenarios")
    
    # Initialize list to store predictions
    all_predictions = []
    
    # Process each scenario separately to save memory
    for scenario_id in scenarios_to_evaluate:
        try:
            # Get data for this scenario
            scenario_data = test_data[test_data['scenario'] == scenario_id].copy()
            
            # Limit number of nodes if needed
            if len(scenario_data) > max_nodes_per_scenario:
                # Ensure we keep some points from each flowline
                all_flowlines = scenario_data['BranchEquipment'].unique()
                sampled_data = []
                
                for flowline in all_flowlines:
                    flowline_data = scenario_data[scenario_data['BranchEquipment'] == flowline]
                    # Take proportional sample from each flowline
                    sample_size = max(2, int(max_nodes_per_scenario * len(flowline_data) / len(scenario_data)))
                    
                    # Always include first and last points of the flowline
                    if len(flowline_data) > 1:
                        first_last = flowline_data.sort_values('TotalDistance').iloc[[0, -1]]
                        
                        # Sample middle points if needed
                        if len(flowline_data) > 2 and sample_size > 2:
                            middle = flowline_data.sort_values('TotalDistance').iloc[1:-1]
                            if len(middle) > sample_size - 2:
                                middle = middle.sample(sample_size - 2)
                            sampled_data.append(pd.concat([first_last, middle]))
                        else:
                            sampled_data.append(first_last)
                    else:
                        sampled_data.append(flowline_data)
                
                scenario_data = pd.concat(sampled_data).reset_index(drop=True)
                print(f"Scenario {scenario_id}: Sampled {len(scenario_data)} nodes from original dataset")
            
            # Create tensors for scaling
            input_min_tensor = torch.tensor(input_min, dtype=torch.float32, device=device)
            input_max_tensor = torch.tensor(input_max, dtype=torch.float32, device=device)
            output_min_tensor = torch.tensor(output_min, dtype=torch.float32, device=device)
            output_max_tensor = torch.tensor(output_max, dtype=torch.float32, device=device)
            
            # Make predictions in smaller batches to save memory
            batch_size = 100
            scenario_predictions = []
            
            for i in range(0, len(scenario_data), batch_size):
                batch_data = scenario_data.iloc[i:i+batch_size]
                
                # Prepare inputs
                batch_inputs = []
                for _, node in batch_data.iterrows():
                    input_values = []
                    for col in input_cols:
                        input_values.append(float(node.get(col, 0.0)))
                    batch_inputs.append(input_values)
                
                with torch.no_grad():
                    # Convert to tensor and scale
                    inputs_tensor = torch.tensor(batch_inputs, dtype=torch.float32, device=device)
                    scaled_inputs = (inputs_tensor - input_min_tensor) / (input_max_tensor - input_min_tensor + 1e-8)
                    
                    # Get predictions
                    preds = model(scaled_inputs)
                    
                    # Unscale predictions
                    unscaled_preds = torch.zeros_like(preds)
                    for j, col in enumerate(output_cols):
                        # Convert from [-1,1] to physical values
                        unscaled_preds[:, j] = ((preds[:, j] + 1) / 2) * (output_max_tensor[j] - output_min_tensor[j]) + output_min_tensor[j]
                
                # Store predictions with original data
                for idx, (_, node) in enumerate(batch_data.iterrows()):
                    node_result = node.copy()
                    for j, col in enumerate(output_cols):
                        node_result[f"{col}_pred"] = unscaled_preds[idx, j].item()
                    scenario_predictions.append(node_result)
            
            # Convert predictions to DataFrame and add to results
            if scenario_predictions:
                scenario_results = pd.DataFrame(scenario_predictions)
                all_predictions.append(scenario_results)
                
                # Print progress
                print(f"Completed evaluation for scenario {scenario_id} with {len(scenario_results)} nodes")
        
        except Exception as e:
            print(f"Error evaluating scenario {scenario_id}: {str(e)}")
            continue
    
    # Combine all predictions if any
    if not all_predictions:
        print("No predictions were made.")
        return None
    
    predictions = pd.concat(all_predictions, ignore_index=True)
    
    # Calculate error metrics
    metrics = {}
    for col in output_cols:
        # Ensure both true and predicted values exist
        if col in predictions.columns and f"{col}_pred" in predictions.columns:
            # Calculate error
            abs_error = abs(predictions[col] - predictions[f"{col}_pred"])
            rel_error = 100 * abs_error / (abs(predictions[col]) + 1e-8)
            
            # Store metrics
            metrics[f"{col}_mae"] = abs_error.mean()
            metrics[f"{col}_rmse"] = np.sqrt((abs_error**2).mean())
            metrics[f"{col}_mape"] = rel_error.mean()
            metrics[f"{col}_median_ape"] = rel_error.median()
            metrics[f"{col}_max_ape"] = rel_error.max()
            
            # Print metrics
            print(f"{col} Metrics:")
            print(f"  MAE: {metrics[f'{col}_mae']:.4f}")
            print(f"  RMSE: {metrics[f'{col}_rmse']:.4f}")
            print(f"  MAPE: {metrics[f'{col}_mape']:.2f}%")
            print(f"  Median APE: {metrics[f'{col}_median_ape']:.2f}%")
            print(f"  Max APE: {metrics[f'{col}_max_ape']:.2f}%")
    
    # Evaluate at junctions if provided
    if junctions is not None and len(junctions) > 0:
        print("\nEvaluating performance at junctions:")
        
        # Get the first few scenarios for junction visualization
        eval_scenarios = predictions['scenario'].unique()
        sample_scenarios = eval_scenarios[:min(3, len(eval_scenarios))]
        
        # Visualize junction performance for selected scenarios
        junction_data = []
        for scenario_id in sample_scenarios:
            print(f"\nJunction performance for scenario {scenario_id}:")
            try:
                scenario_junction_data = visualize_junction_performance(
                    predictions[predictions['scenario'] == scenario_id], 
                    junctions, 
                    scenario_id,
                    plot_pressure=True, 
                    plot_mass_flow=True
                )
                if scenario_junction_data:
                    junction_data.extend(scenario_junction_data)
            except Exception as e:
                print(f"Error visualizing junctions for scenario {scenario_id}: {str(e)}")
    
    # Return predictions and metrics
    return {
        'predictions': predictions,
        'metrics': metrics
    }