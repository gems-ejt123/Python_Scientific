
import numpy as np
import torch

# -------------------------------------------
# Gas Density Calculation for Momentum Conservation
# -------------------------------------------
def calculate_gas_density(P_in, P_out_pred, T_in, T_out_pred, max_iterations=20):
    """
    Calculate gas density using a compressibility factor Z approach.
    Modified to be compatible with PyTorch autograd for PINN training.
    
    Args:
        P_in: Inlet pressure (psi)
        P_out_pred: Predicted outlet pressure (psi)
        T_in: Inlet temperature (F)
        T_out_pred: Predicted outlet temperature (F)
        max_iterations: Maximum number of iterations for Z calculation
        
    Returns:
        Gas density (lb/ft³)
    """
    # Convert tensors to scalars if needed for this calculation
    if isinstance(P_in, torch.Tensor):
        P_in = P_in.item()
    
    if isinstance(P_out_pred, torch.Tensor):
        P_out_pred = P_out_pred.item()
    
    if isinstance(T_in, torch.Tensor):
        T_in = T_in.item()
    
    if isinstance(T_out_pred, torch.Tensor):
        T_out_pred = T_out_pred.item()
    
    # Constants for natural gas
    delta_rel_den_gas = 0.75  # relative density of natural gas
    
    # Pseudocritical properties
    T_c = (169.2 + 349.5 * delta_rel_den_gas - 74.0 * delta_rel_den_gas**2)  # Rankine
    P_c = 756.8 - 131.0 * delta_rel_den_gas - 3.6 * delta_rel_den_gas**2  # psi
    
    # Reduced pressure and temperature
    T_avg = ((T_in + T_out_pred)/2) + 460  # Average temperature, Rankine
    P_avg = (P_in + P_out_pred)/2  # Average pressure, psi
    Pr = P_avg/P_c
    Tr = T_avg/T_c
    
    # Factors for compressibility calculation
    A = 1.39 * (Tr - 0.92)**0.5 - 0.36*Tr - 0.101
    E = (0.62 - 0.23 * Tr) * Pr + ((0.066/(Tr - 0.86)) - 0.037) * Pr**2 + (0.32 / (10**(9 *(Tr-1)))) * Pr**6
    F = 0.132 - 0.32 * np.log(Tr)
    G = 10 **(0.3016 - 0.49*Tr + 0.1824*Tr**2)
    
    # Simpler iterative approach for Z calculation (instead of LBFGS)
    Z = 1.0  # Initial guess
    
    # Define the equation for Z
    def calc_Z(Z_val):
        return A + (1 - A) * np.exp(-E) + (F * Pr**G)
    
    # Iterative solution for Z
    for _ in range(max_iterations):
        Z_new = calc_Z(Z)
        if abs(Z_new - Z) < 1e-6:
            break
        Z = Z_new
    
    # Calculate density
    rho_st = 0.0573  # lb/ft³
    rho = rho_st * P_avg * ((15.5 * 1.8) + 492) / (Z * 14.5038 * T_avg)
    
    return rho

def gas_density_for_momentum_loss(P_in, P_out, T_in, T_out):
    """
    Wrapper function for gas density calculation to be used in momentum conservation loss.
    Handles unit conversions and data types.
    
    Args:
        P_in: Inlet pressure
        P_out: Outlet pressure
        T_in: Inlet temperature
        T_out: Outlet temperature
        
    Returns:
        Gas density in consistent units for the momentum equation
    """
    # Call the gas density calculation
    rho_g = calculate_gas_density(P_in, P_out, T_in, T_out)
    
    # Convert units if needed (e.g., from lb/ft³ to kg/m³)
    # For this example, we'll assume the momentum equation uses the same units
    
    return rho_g