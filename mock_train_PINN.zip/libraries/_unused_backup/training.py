import torch
import torch.optim as optim
from livelossplot import PlotLosses
from libraries.batch_loss import compute_batch_loss
from libraries.memory_utils import get_device
import gc
import time
import torch.nn.functional as F
# Import for mixed precision - fixed import for compatibility
try:
    from torch.cuda.amp import autocast, GradScaler
except ImportError:
    try:
        from torch.amp import autocast, GradScaler
    except ImportError:
        # Fallback for older PyTorch versions
        autocast = None
        GradScaler = None
        print("WARNING: Mixed precision not available. Training without mixed precision.")

def train_pinn_model(model, train_loader, val_loader, junctions, input_cols, output_cols, 
                   input_min, input_max, output_min, output_max, 
                   num_epochs=100, learning_rate=1e-4, num_scenarios=None, 
                   early_stopping_patience=25, lr_scheduler_patience=10, lr_scheduler_factor=0.75,
                   data_weight=1.0, physics_weight=0.0, junction_physics_weight=0.0,
                   min_pressure_sink=36, sink_node_type=-1, source_node_type=1,
                   pressure_continuity_weight=1.0, mass_conservation_weight=1.0,
                   field_smoothness_weight=0.0,
                   flowline_col="BranchEquipment", node_id_col="node_id",
                   x_col="long", y_col="lat", distance_col="TotalDistance", tol=1e-6,
                   physics_weight_schedule=None, junction_weight_schedule=None,
                   use_pressure_gradient=False, pressure_gradient_weight=1.0,
                   pressure_gradient_sample_rate=1.0, use_mixed_precision=False,
                   gradient_threshold=10.0,  # New parameter for gradient regulation
                   weight_decay=0.0,
                   device=None, train_validation_split=0.7):
    """
    Train a Physics-Informed Neural Network model using DataLoaders.
    
    Parameters:
        model (torch.nn.Module): The neural network model to train
        train_loader (DataLoader): DataLoader for training data
        val_loader (DataLoader): DataLoader for validation data
        junctions (list): List of junction dictionaries containing node information
        input_cols (list): List of input column names
        output_cols (list): List of output column names
        input_min, input_max (torch.Tensor): Scaling parameters for inputs
        output_min, output_max (torch.Tensor): Scaling parameters for outputs
        num_epochs (int): Maximum number of training epochs
    learning_rate (float): Learning rate for optimizer
    weight_decay (float): Weight decay (L2) applied by the optimizer (AdamW)
        early_stopping_patience (int): Number of epochs to wait for improvement before stopping
        lr_scheduler_patience (int): Number of epochs to wait before reducing learning rate
        lr_scheduler_factor (float): Factor by which to reduce learning rate
        data_weight (float): Weight for data-fitting loss component
        physics_weight (float): Weight for physics-based loss component
        junction_physics_weight (float): Weight for junction physics constraints
        min_pressure_sink (float): Minimum pressure value for sink nodes
        sink_node_type (int): Node type identifier for sink nodes
        source_node_type (int): Node type identifier for source nodes
        pressure_continuity_weight (float): Weight for pressure continuity at junctions
        mass_conservation_weight (float): Weight for mass conservation at junctions
        flowline_col (str): Column name for flowline identifiers
        node_id_col (str): Column name for node identifiers
        x_col, y_col (str): Column names for spatial coordinates
        distance_col (str): Column name for distance along flowlines
        tol (float): Tolerance for numerical stability
        physics_weight_schedule (callable): Function to adjust physics weight by epoch
        junction_weight_schedule (callable): Function to adjust junction weight by epoch
        use_pressure_gradient (bool): Whether to include pressure gradient in loss
        pressure_gradient_weight (float): Weight for pressure gradient loss
        pressure_gradient_sample_rate (float): Fraction of flowlines to sample for gradient
        use_mixed_precision (bool): Whether to use mixed precision training
        gradient_threshold (float): Maximum allowed gradient magnitude before scaling
        device (torch.device): Device to use for training
        train_validation_split (float): Fraction of data to use for training
        
    Returns:
        tuple: (trained model, training history dictionary)
    """
    # Initialize device if needed
    if device is None:
        device = get_device(force_cuda=True)
    
    # Create optimizer (use AdamW so weight_decay is applied consistently)
    try:
        optimizer = optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    except Exception:
        # Fallback to Adam if AdamW is not available in this environment
        optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    
    # Create learning rate scheduler
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, 'min', factor=lr_scheduler_factor, patience=lr_scheduler_patience
    )
    
    # Initialize mixed precision scaler if needed
    scaler = GradScaler() if use_mixed_precision and device.type == 'cuda' and GradScaler is not None else None
    
    # Initialize liveloss plot
    liveloss = PlotLosses()
    
    # Print physics weights
    physics_modes = []
    if data_weight > 0:
        physics_modes.append("data")
    if physics_weight > 0:
        physics_modes.append("boundary")
    if junction_physics_weight > 0:
        physics_modes.append("junction")
    if use_pressure_gradient:
        physics_modes.append("pressure_gradient")
    
    print(f"Training with: {', '.join(physics_modes)} physics")
    print(f"Initial weights: data={data_weight}, boundary={physics_weight}, "
          f"junction={junction_physics_weight}")
    print(f"Using gradient threshold of {gradient_threshold} for gradient regulation")  # New message
    
    if use_pressure_gradient:
        print(f"Using pressure gradient with weight={pressure_gradient_weight}, "
              f"sampling rate={pressure_gradient_sample_rate*100:.1f}%")
    
    # Initialize histories with new max_gradient tracking
    train_history = {
        'total_loss': [],
        'data_loss': [],
        'physics_loss': [],
        'boundary_loss': [],
        'pressure_continuity_loss': [],
        'mass_conservation_loss': [],
        'max_gradient': []  # New field to track maximum gradient magnitude
    }
    
    val_history = {
        'total_loss': [],
        'data_loss': [],
        'physics_loss': [],
        'boundary_loss': [],
        'pressure_continuity_loss': [],
        'mass_conservation_loss': []
    }
    
    # Initialize early stopping
    best_val_loss = float('inf')
    no_improvement_count = 0
    best_model_state = None
    
    # Main training loop
    for epoch in range(num_epochs):
        start_time = time.time()
        
        # Update physics weights based on scheduler
        current_physics_weight = physics_weight
        if physics_weight_schedule is not None:
            current_physics_weight = physics_weight_schedule(epoch)
        
        current_junction_weight = junction_physics_weight
        if junction_weight_schedule is not None:
            current_junction_weight = junction_weight_schedule(epoch)
        
        # Print current weights every 10 epochs
        if epoch % 10 == 0:
            print(f"Epoch {epoch}: physics_weight={current_physics_weight:.4f}, "
                  f"junction_weight={current_junction_weight:.4f}")
        
        # Update model's epoch information for progressive skip scaling
        # This is used by the PhysicsAwareLayer to dynamically adjust skip connection influence
        if hasattr(model, 'update_epoch_info'):
            model.update_epoch_info(epoch, num_epochs)
        
        # Training phase
        model.train()
        epoch_losses = {k: 0.0 for k in train_history.keys()}
        max_grad_magnitude = 0.0  # Track maximum gradient magnitude in this epoch
        
        # Process batches from DataLoader
        for batch_idx, batch in enumerate(train_loader):
            # Support two batch formats:
            # 1) Structured batch: dict-like with key 'scenario_dfs' (list of DataFrames)
            # 2) Supervised tuple: (X_batch, y_batch) tensors produced by TensorDataset
            is_structured = isinstance(batch, dict) and 'scenario_dfs' in batch

            # Skip empty structured batches
            if is_structured:
                batch_data = batch['scenario_dfs']
                if not batch_data:
                    continue
            else:
                # Expect a tuple/list (X_batch, y_batch)
                try:
                    X_batch, y_batch = batch
                except Exception:
                    # Unknown batch format: skip
                    print(f"Unexpected batch format at batch_idx={batch_idx}: {type(batch)} - skipping")
                    continue

            optimizer.zero_grad()

            # Supervised-only path for simple (X,y) batches
            if not is_structured:
                X_batch = X_batch.to(device)
                y_batch = y_batch.to(device)

                if use_mixed_precision and device.type == 'cuda' and autocast is not None:
                    with autocast():
                        preds = model(X_batch)
                        data_loss = F.mse_loss(preds, y_batch)
                        total_loss = data_weight * data_loss

                    if scaler is not None:
                        scaler.scale(total_loss).backward()
                        scaler.unscale_(optimizer)
                    else:
                        total_loss.backward()

                    # Gradient regulation
                    with torch.no_grad():
                        for name, param in model.named_parameters():
                            if param.grad is not None:
                                grad_mag = param.grad.abs().max().item()
                                max_grad_magnitude = max(max_grad_magnitude, grad_mag)
                                if grad_mag > gradient_threshold:
                                    scale_factor = gradient_threshold / (grad_mag + 1e-8)
                                    param.grad.mul_(scale_factor)

                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    if scaler is not None:
                        scaler.step(optimizer)
                        scaler.update()
                    else:
                        optimizer.step()

                else:
                    preds = model(X_batch)
                    data_loss = F.mse_loss(preds, y_batch)
                    total_loss = data_weight * data_loss

                    total_loss.backward()

                    with torch.no_grad():
                        for name, param in model.named_parameters():
                            if param.grad is not None:
                                grad_mag = param.grad.abs().max().item()
                                max_grad_magnitude = max(max_grad_magnitude, grad_mag)
                                if grad_mag > gradient_threshold:
                                    scale_factor = gradient_threshold / (grad_mag + 1e-8)
                                    param.grad.mul_(scale_factor)

                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    optimizer.step()

                # Build loss_components similar to compute_batch_loss for logging
                loss_components = {
                    'total_loss': total_loss.item() if isinstance(total_loss, torch.Tensor) else float(total_loss),
                    'data_loss': data_loss.item() if isinstance(data_loss, torch.Tensor) else float(data_loss),
                    'physics_loss': 0.0,
                    'boundary_loss': 0.0,
                    'pressure_continuity_loss': 0.0,
                    'mass_conservation_loss': 0.0
                }

            else:
                # Structured batch path (existing behavior)
                if use_mixed_precision and device.type == 'cuda' and autocast is not None:
                    with autocast():
                        batch_loss, loss_components = compute_batch_loss(
                                                    model=model, 
                                                    batch_data=batch_data, 
                                                    junctions=junctions, 
                                                    input_cols=input_cols, 
                                                    output_cols=output_cols,
                                                    input_min=input_min, 
                                                    input_max=input_max, 
                                                    output_min=output_min, 
                                                    output_max=output_max,
                                                    data_weight=data_weight,
                                                    physics_weight=current_physics_weight,
                                                    junction_physics_weight=current_junction_weight,
                                                    min_pressure_sink=min_pressure_sink,
                                                    sink_node_type=sink_node_type,
                                                    source_node_type=source_node_type,
                                                    pressure_continuity_weight=pressure_continuity_weight,
                                                    mass_conservation_weight=mass_conservation_weight,
                                                    field_smoothness_weight=field_smoothness_weight,  # Make sure this appears BEFORE flowline_col
                                                    flowline_col=flowline_col,
                                                    node_id_col=node_id_col,
                                                    x_col=x_col,
                                                    y_col=y_col,
                                                    distance_col=distance_col,
                                                    tol=tol,
                                                    epoch=epoch,
                                                    total_epochs=num_epochs,
                                                    use_pressure_gradient=use_pressure_gradient,
                                                    pressure_gradient_weight=pressure_gradient_weight,
                                                    pressure_gradient_sample_rate=pressure_gradient_sample_rate,
                                                    device=device
                                                )

                    if scaler is not None:
                        scaler.scale(batch_loss).backward()
                        scaler.unscale_(optimizer)
                    else:
                        batch_loss.backward()

                    # Advanced gradient regulation for mixed precision
                    with torch.no_grad():
                        for name, param in model.named_parameters():
                            if param.grad is not None:
                                grad_mag = param.grad.abs().max().item()
                                max_grad_magnitude = max(max_grad_magnitude, grad_mag)
                                if grad_mag > gradient_threshold:
                                    scale_factor = gradient_threshold / (grad_mag + 1e-8)
                                    param.grad.mul_(scale_factor)

                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    if scaler is not None:
                        scaler.step(optimizer)
                        scaler.update()
                    else:
                        optimizer.step()

                else:
                    batch_loss, loss_components = compute_batch_loss(
                                                    model=model, 
                                                    batch_data=batch_data, 
                                                    junctions=junctions, 
                                                    input_cols=input_cols, 
                                                    output_cols=output_cols,
                                                    input_min=input_min, 
                                                    input_max=input_max, 
                                                    output_min=output_min, 
                                                    output_max=output_max,
                                                    data_weight=data_weight,
                                                    physics_weight=current_physics_weight,
                                                    junction_physics_weight=current_junction_weight,
                                                    min_pressure_sink=min_pressure_sink,
                                                    sink_node_type=sink_node_type,
                                                    source_node_type=source_node_type,
                                                    pressure_continuity_weight=pressure_continuity_weight,
                                                    mass_conservation_weight=mass_conservation_weight,
                                                    field_smoothness_weight=field_smoothness_weight,  # Make sure this appears BEFORE flowline_col
                                                    flowline_col=flowline_col,
                                                    node_id_col=node_id_col,
                                                    x_col=x_col,
                                                    y_col=y_col,
                                                    distance_col=distance_col,
                                                    tol=tol,
                                                    epoch=epoch,
                                                    total_epochs=num_epochs,
                                                    use_pressure_gradient=use_pressure_gradient,
                                                    pressure_gradient_weight=pressure_gradient_weight,
                                                    pressure_gradient_sample_rate=pressure_gradient_sample_rate,
                                                    device=device
                                                )

                    batch_loss.backward()

                    # Advanced gradient regulation for standard precision
                    with torch.no_grad():
                        for name, param in model.named_parameters():
                            if param.grad is not None:
                                grad_mag = param.grad.abs().max().item()
                                max_grad_magnitude = max(max_grad_magnitude, grad_mag)
                                if grad_mag > gradient_threshold:
                                    scale_factor = gradient_threshold / (grad_mag + 1e-8)
                                    param.grad.mul_(scale_factor)

                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    optimizer.step()
            
            # Update epoch statistics
            for k, v in loss_components.items():
                if k in epoch_losses:
                    epoch_losses[k] += v
            
            # Print progress less frequently
            if (batch_idx + 1) % 10 == 0:
                _loss_val = loss_components.get('total_loss', None) if isinstance(loss_components, dict) else None
                if _loss_val is None:
                    print(f"  Batch {batch_idx + 1}/{len(train_loader)}")
                else:
                    # _loss_val may be tensor or float
                    try:
                        print(f"  Batch {batch_idx + 1}/{len(train_loader)} - Loss: {_loss_val:.4f}")
                    except Exception:
                        try:
                            print(f"  Batch {batch_idx + 1}/{len(train_loader)} - Loss: {float(_loss_val):.4f}")
                        except Exception:
                            print(f"  Batch {batch_idx + 1}/{len(train_loader)} - Loss: {_loss_val}")
            
            # Clear memory periodically
            if batch_idx % 5 == 0:
                clear_memory()
        
        # Record maximum gradient for this epoch
        epoch_losses['max_gradient'] = max_grad_magnitude
        train_history['max_gradient'].append(max_grad_magnitude)
        
        # Log the maximum gradient information
        print(f"  Maximum gradient magnitude: {max_grad_magnitude:.4f}" + 
              (f" (REGULATED from >{gradient_threshold})" if max_grad_magnitude >= gradient_threshold else ""))
        
        # Calculate average epoch statistics
        num_batches = len(train_loader)
        if num_batches > 0:
            for k in epoch_losses:
                if k != 'max_gradient':  # Don't average the max gradient
                    epoch_losses[k] /= num_batches
                    train_history[k].append(epoch_losses[k])
   
        # Validation phase
        model.eval()
        val_losses = {k: 0.0 for k in val_history.keys()}
        
        with torch.no_grad():
            # Process each validation batch
            for batch_idx, batch in enumerate(val_loader):
                # Support both structured and (X,y) tuple batches
                is_structured_val = isinstance(batch, dict) and 'scenario_dfs' in batch
                if is_structured_val:
                    batch_data = batch['scenario_dfs']
                    if not batch_data:
                        continue
                    val_batch_loss, val_loss_components = compute_batch_loss(
                        model, batch_data, junctions, input_cols, output_cols,
                        input_min, input_max, output_min, output_max,
                        data_weight, current_physics_weight, current_junction_weight,
                        min_pressure_sink, sink_node_type, source_node_type,
                        pressure_continuity_weight, mass_conservation_weight,
                        field_smoothness_weight,  # Add this missing parameter
                        flowline_col, node_id_col, x_col, y_col, distance_col, tol,
                        epoch=epoch, total_epochs=num_epochs,
                        use_pressure_gradient=use_pressure_gradient,
                        pressure_gradient_weight=pressure_gradient_weight,
                        pressure_gradient_sample_rate=pressure_gradient_sample_rate,
                        device=device
                    )
                else:
                    # Expect (X_batch, y_batch)
                    try:
                        X_batch, y_batch = batch
                    except Exception:
                        # Unknown format - skip
                        continue
                    X_batch = X_batch.to(device)
                    y_batch = y_batch.to(device)
                    preds = model(X_batch)
                    data_loss = F.mse_loss(preds, y_batch)
                    val_batch_loss = float(data_loss.item() if isinstance(data_loss, torch.Tensor) else data_loss)
                    val_loss_components = {
                        'total_loss': val_batch_loss,
                        'data_loss': val_batch_loss,
                        'physics_loss': 0.0,
                        'boundary_loss': 0.0,
                        'pressure_continuity_loss': 0.0,
                        'mass_conservation_loss': 0.0
                    }

                # Update validation statistics
                for k, v in val_loss_components.items():
                    if k in val_losses:
                        val_losses[k] += v
        
        # Average validation statistics
        num_val_batches = len(val_loader)
        if num_val_batches > 0:
            for k in val_losses:
                val_losses[k] /= num_val_batches
                val_history[k].append(val_losses[k])
        
        # Update learning rate based on total validation loss
        scheduler.step(val_losses['total_loss'])
        
        # Create logs for livelossplot
        logs = {
            'loss': epoch_losses['total_loss'], 
            'val_loss': val_losses['total_loss'],
            'data_loss': epoch_losses['data_loss'],
            'val_data_loss': val_losses['data_loss'],
            'physics_loss': epoch_losses['physics_loss'],
            'val_physics_loss': val_losses['physics_loss']
        }
        
        # Add junction losses to logs if used
        if current_junction_weight > 0:
            logs.update({
                'pressure_continuity': epoch_losses['pressure_continuity_loss'],
                'val_pressure_continuity': val_losses['pressure_continuity_loss'],
                'mass_conservation': epoch_losses['mass_conservation_loss'],
                'val_mass_conservation': val_losses['mass_conservation_loss']
            })
        
        # Add gradient information to logs
        logs.update({
            'max_gradient': max_grad_magnitude
        })
            
        # Update live plot
        liveloss.update(logs)
        liveloss.send()
        
        # Check for early stopping
        current_val_loss = val_losses['total_loss']
        
        if current_val_loss < best_val_loss:
            best_val_loss = current_val_loss
            no_improvement_count = 0
            # Save best model
            best_model_state = model.state_dict().copy()
            
            print(f"Epoch {epoch}: New best model with val_loss={best_val_loss:.6f}")
        else:
            no_improvement_count += 1
            
        # Apply early stopping
        if no_improvement_count >= early_stopping_patience:
            print(f"Early stopping at epoch {epoch} with best val_loss={best_val_loss:.6f}")
            # Load best model
            if best_model_state is not None:
                model.load_state_dict(best_model_state)
            break
        
        # Print epoch summary
        epoch_time = time.time() - start_time
        print(f"Epoch {epoch} completed in {epoch_time:.2f}s - "
              f"train_loss: {epoch_losses['total_loss']:.6f}, "
              f"val_loss: {val_losses['total_loss']:.6f}")
        
        # Clean up memory
        clear_memory()
    
    # Load best model if it exists and we didn't early stop
    if no_improvement_count < early_stopping_patience and best_model_state is not None:
        model.load_state_dict(best_model_state)
    
    return model, {'train': train_history, 'val': val_history}

def clear_memory():
    """
    Clear GPU memory and run garbage collection.
    
    This function helps reduce memory fragmentation during training
    by explicitly releasing unused memory and running the garbage collector.
    """
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()