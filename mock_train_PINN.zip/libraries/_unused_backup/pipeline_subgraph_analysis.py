# pipeline_subgraph_analysis.py
import math
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from networkx.algorithms.community import kernighan_lin_bisection
from sklearn.cluster import KMeans  # For K-means clustering

def build_graph(df, alpha=1.0):
    """
    Build a weighted NetworkX graph from the pipeline DataFrame.
    
    Each unique (start_x, start_y) and (end_x, end_y) is a node.
    Each row represents an edge.
    
    The edge weight is computed using an exponential function based on the absolute
    difference in latitude (start_y vs. end_y). If the nodes have similar latitudes,
    the weight is high (making it expensive to cut), thereby favoring clusters that are
    coherent in the north–south direction.
    
    Parameters:
      - df: DataFrame with columns "pipeline_id", "start_x", "start_y", "end_x", "end_y"
      - alpha: Controls how strongly the latitude difference affects the weight.
    
    Returns:
      - G: A weighted NetworkX graph.
    """
    G = nx.Graph()
    for _, row in df.iterrows():
        start_node = (row["start_x"], row["start_y"])
        end_node = (row["end_x"], row["end_y"])
        G.add_node(start_node)
        G.add_node(end_node)
        weight = math.exp(-alpha * abs(row["start_y"] - row["end_y"]))
        G.add_edge(start_node, end_node, pipeline_id=row["pipeline_id"], weight=weight)
    return G

def plot_connected_components(G, pos=None):
    """
    Plot the connected components of graph G.
    """
    connected_components = list(nx.connected_components(G))
    print(f"Connected Components Found: {len(connected_components)}")
    for i, component in enumerate(connected_components, start=1):
        print(f"Component {i} has {len(component)} nodes.")
        
    if pos is None:
        pos = nx.spring_layout(G, seed=42)
        
    plt.figure(figsize=(8, 6))
    colors = ['red', 'green', 'blue', 'orange', 'purple']
    for i, component in enumerate(connected_components):
        subG = G.subgraph(component)
        nx.draw_networkx_nodes(subG, pos,
                               node_color=colors[i % len(colors)],
                               label=f"Component {i+1}",
                               node_size=100)
    nx.draw_networkx_edges(G, pos, alpha=0.5)
    plt.title("Connected Components of Pipeline Network")
    plt.legend()
    plt.axis('off')
    plt.tight_layout()
    plt.show()

def plot_kernighan_lin_partition(G, pos=None):
    """
    Apply Kernighan–Lin bisection and plot the partitioned graph.
    """
    if not nx.is_connected(G):
        raise ValueError("Graph is not connected. Please apply partitioning on each connected component separately.")
    
    setA, setB = kernighan_lin_bisection(G)
    print("Kernighan–Lin Bisection:")
    print("Set A has", len(setA), "nodes.")
    print("Set B has", len(setB), "nodes.")
    
    if pos is None:
        pos = nx.spring_layout(G, seed=42)
    
    color_map = []
    for node in G.nodes():
        color_map.append('skyblue' if node in setA else 'lightcoral')
    
    plt.figure(figsize=(8, 6))
    nx.draw_networkx(G, pos, node_color=color_map, with_labels=True, node_size=100, edge_color='gray')
    plt.title("Graph Partitioning via Kernighan–Lin Bisection")
    plt.axis('off')
    plt.tight_layout()
    plt.show()

def recursive_kl_bisection(G, num_parts=2):
    """
    Recursively apply Kernighan–Lin bisection to partition graph G into num_parts subgroups.
    
    Parameters:
      - G: A connected NetworkX graph.
      - num_parts: The desired number of partitions (ideally a power of 2).
    
    Returns:
      - A list of sets, where each set contains the nodes of one partition.
    """
    if num_parts < 1:
        raise ValueError("num_parts must be at least 1.")
    if num_parts == 1:
        return [set(G.nodes())]
    
    partitions = [set(G.nodes())]
    while len(partitions) < num_parts:
        new_partitions = []
        for part in partitions:
            subG = G.subgraph(part)
            if subG.number_of_nodes() <= 1:
                new_partitions.append(part)
            else:
                try:
                    setA, setB = kernighan_lin_bisection(subG)
                    new_partitions.append(setA)
                    new_partitions.append(setB)
                except Exception as e:
                    print("Bisection failed for partition with nodes", part, ":", e)
                    new_partitions.append(part)
        partitions = new_partitions
    return partitions

def process_pipeline_df(df):
    """
    Given a pipeline DataFrame, build the graph and plot:
      1. Connected components.
      2. Kernighan–Lin bisection partition (if the graph is connected).
    Returns the built graph.
    """
    G = build_graph(df)
    print("Total nodes in graph:", G.number_of_nodes())
    print("Total edges in graph:", G.number_of_edges())
    pos = nx.spring_layout(G, seed=42)
    plot_connected_components(G, pos=pos)
    
    if nx.is_connected(G):
        plot_kernighan_lin_partition(G, pos=pos)
    else:
        print("Graph has multiple connected components; please partition each component separately.")
    return G

def add_cluster_ids(df, method="components", num_parts=2):
    """
    Builds the graph from the provided pipeline DataFrame and assigns a cluster_id
    to each pipeline (row) based on the selected method.
   
    Parameters:
      - df: DataFrame with columns "pipeline_id", "start_x", "start_y", "end_x", "end_y".
      - method: One of the following:
          "components"             : Uses connected components.
          "kernighan_lin"          : Uses a single bisection via Kernighan–Lin.
          "recursive_kernighan_lin": Uses recursive bisection for 'num_parts' partitions.
          "louvain"                : Uses Louvain community detection.
          "kmeans"                 : Uses K-means clustering on both longitude and latitude.
      - num_parts: Number of clusters for recursive bisection or K-means (if applicable).
   
    Returns:
      A copy of the DataFrame with an added "cluster_id" column.
    """
    # For graph-based methods, build the graph.
    if method in ["components", "kernighan_lin", "recursive_kernighan_lin", "louvain"]:
        G = build_graph(df)
   
    if method == "components":
        components = list(nx.connected_components(G))
        node_to_cluster = {}
        for cluster_id, comp in enumerate(components):
            for node in comp:
                node_to_cluster[node] = cluster_id
    elif method == "kernighan_lin":
        if not nx.is_connected(G):
            raise ValueError("Graph is not connected. Kernighan–Lin requires a connected graph.")
        setA, setB = kernighan_lin_bisection(G)
        node_to_cluster = {node: 0 for node in setA}
        node_to_cluster.update({node: 1 for node in setB})
    elif method == "recursive_kernighan_lin":
        if not nx.is_connected(G):
            raise ValueError("Graph is not connected. Recursive Kernighan–Lin requires a connected graph.")
        partitions = recursive_kl_bisection(G, num_parts=num_parts)
        node_to_cluster = {}
        for cluster_id, part in enumerate(partitions):
            for node in part:
                node_to_cluster[node] = cluster_id
    elif method == "louvain":
        try:
            import community as community_louvain
        except ImportError:
            raise ImportError("Please install python-louvain: pip install python-louvain")
        node_to_cluster = community_louvain.best_partition(G)
    elif method == "kmeans":
        # Modified to use both longitude and latitude for clustering
        df = df.copy()
        
        # Calculate the average longitude and latitude for each pipeline segment
        df["avg_long"] = (df["start_x"] + df["end_x"]) / 2.0
        df["avg_lat"] = (df["start_y"] + df["end_y"]) / 2.0
        
        # Use K-means clustering on both dimensions
        kmeans = KMeans(n_clusters=num_parts, random_state=42)
        df["cluster_id"] = kmeans.fit_predict(df[["avg_long", "avg_lat"]])
        
        return df.drop(columns=["avg_long", "avg_lat"])
    else:
        raise ValueError("Invalid method. Use 'components', 'kernighan_lin', 'recursive_kernighan_lin', 'louvain', or 'kmeans'.")
   
    df_copy = df.copy()
    df_copy["cluster_id"] = df_copy.apply(
        lambda row: node_to_cluster.get((row["start_x"], row["start_y"]), -1), axis=1
    )
    return df_copy

def plot_pipeline_clusters(df):
    """
    Plot pipeline segments from the DataFrame 'df' with each segment colored based on its 'cluster_id'.
    Assumes df has columns: 'start_x', 'start_y', 'end_x', 'end_y', and 'cluster_id'.
    """
    plt.figure(figsize=(8, 8))
    clusters = df["cluster_id"].unique()
    clusters.sort()  # sort for consistent color mapping
    cmap = plt.get_cmap("tab10")
    
    for i, cluster in enumerate(clusters):
        cluster_df = df[df["cluster_id"] == cluster]
        for idx, row in cluster_df.iterrows():
            plt.plot([row["start_x"], row["end_x"]],
                     [row["start_y"], row["end_y"]],
                     color=cmap(i % 10),
                     marker="o",
                     markersize=10,
                     label=f"Cluster {cluster}" if idx == cluster_df.index[0] else ""
                     )
    
    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.title("Pipeline Segments by Cluster")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()