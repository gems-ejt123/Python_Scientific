"""Pressure-tail-aware data loss.

Replaces the plain per-output SmoothL1 with a per-sample weight that grows with
the TARGET pressure, so the rare high-pressure tail (~7% of rows above 250 psi,
~2.6% above 300 psi) is not averaged away by the dense mid-range.

This version is SYMMETRIC. The earlier notebook stacked a one-directional
under-prediction penalty (``TAIL_UNDERPRED_BETA``) that was tuned to fight an old
under-prediction and then over-corrected the 250-300 band. That ratchet is gone.
To recover the sparse >300 band (which drifts back to under-prediction once the
ratchet is removed) an optional SECOND weight tier adds extra, even-handed
emphasis above a high threshold, penalizing over- and under-prediction equally.

The loss operates in [-1, 1] scaled space (linear MinMax), matching the model
output and the Phase-1 loss scale.
"""

import torch
import torch.nn as nn


def make_tail_aware_data_loss(
    output_cols,
    output_min,
    output_max,
    data_loss_weights,
    device,
    p0_psi=250.0,
    alpha=1.25,
    weight_scale=100.0,
    weight_max=6.0,
    p1_psi=300.0,
    alpha2=0.0,
    pressure_name="Pressure",
):
    """Build a pressure-weighted SmoothL1 data-loss closure.

    Parameters
    ----------
    output_cols : list[str]
        Model output column names (identifies the pressure column).
    output_min, output_max : array-like
        Per-output MinMax bounds (raw units) used to recover psi from scaled y.
    data_loss_weights : list[float]
        Per-output weights; normalized so pressure keeps effective weight 1.0.
    p0_psi, alpha, weight_scale, weight_max : float
        First tier: ``w = 1 + alpha * relu(P - p0)/scale``, capped at weight_max.
    p1_psi, alpha2 : float
        Optional second tier for the sparse extreme band:
        ``w += alpha2 * relu(P - p1)/scale``. Set ``alpha2 = 0`` to disable
        (reproduces the single-tier behavior).
    pressure_name : str
        Name of the pressure column in ``output_cols``.

    Returns
    -------
    callable ``loss(preds, target)`` -> scalar tensor. Both inputs are
    ``[batch, n_output]`` in [-1, 1] scaled space.
    """
    p_idx = list(output_cols).index(pressure_name)
    omin = torch.tensor(float(output_min[p_idx]), device=device)
    omax = torch.tensor(float(output_max[p_idx]), device=device)

    data_w = torch.tensor(data_loss_weights, dtype=torch.float32, device=device)
    data_w = data_w / data_w[p_idx]                      # pressure weight -> 1.0

    smooth_l1_none = nn.SmoothL1Loss(reduction="none")
    use_second_tier = alpha2 > 0.0 and p1_psi is not None

    def _scaled_to_psi(p_scaled):
        return (p_scaled + 1.0) * 0.5 * (omax - omin) + omin

    def loss(preds, target):
        per_elem = smooth_l1_none(preds, target)          # [batch, n_output]
        p_psi = _scaled_to_psi(target[:, p_idx])          # [batch] physical psi

        # First (and optional second) tier, both symmetric.
        w = 1.0 + alpha * torch.clamp(p_psi - p0_psi, min=0.0) / weight_scale
        if use_second_tier:
            w = w + alpha2 * torch.clamp(p_psi - p1_psi, min=0.0) / weight_scale
        w = torch.clamp(w, max=weight_max)

        pressure_term = (per_elem[:, p_idx] * w).sum() / w.sum()

        # Auxiliary outputs: plain weighted SmoothL1 (mean over batch).
        aux_term = preds.new_zeros(())
        if preds.shape[1] > 1:
            per_output = per_elem.mean(dim=0)             # [n_output]
            for i in range(preds.shape[1]):
                if i == p_idx:
                    continue
                aux_term = aux_term + data_w[i] * per_output[i]

        return pressure_term + aux_term

    return loss
