
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import numpy as np
import torch
from libraries.cluster_by_junctions import classify_flowline_direction
import pandas as pd

def plot_training_history(history, title="PINN Training History"):
    """Plot training and validation losses."""
    plt.figure(figsize=(15, 10))
    
    # Plot total loss
    plt.subplot(2, 2, 1)
    plt.plot(history['train']['total_loss'], label='Training Loss')
    plt.plot(history['val']['total_loss'], label='Validation Loss')
    plt.title('Total Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    
    # Plot data vs physics loss
    plt.subplot(2, 2, 2)
    plt.plot(history['train']['data_loss'], label='Data Loss')
    plt.plot(history['train']['physics_loss'], label='Physics Loss')
    plt.title('Data vs Physics Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    
    # Plot boundary loss
    plt.subplot(2, 2, 3)
    plt.plot(history['train']['boundary_loss'], label='Boundary Loss')
    
    # Check if junction losses are present
    has_junction_losses = ('pressure_continuity_loss' in history['train'] and 
                          'mass_conservation_loss' in history['train'] and
                          len(history['train']['pressure_continuity_loss']) > 0)
    
    if has_junction_losses:
        plt.plot(history['train']['pressure_continuity_loss'], label='Pressure Continuity')
        plt.plot(history['train']['mass_conservation_loss'], label='Mass Conservation')
    
    plt.title('Physics Loss Components')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    
    # Plot validation components
    plt.subplot(2, 2, 4)
    plt.plot(history['val']['data_loss'], label='Val Data Loss')
    plt.plot(history['val']['physics_loss'], label='Val Physics Loss')
    
    if has_junction_losses:
        plt.plot(history['val']['pressure_continuity_loss'], label='Val Pressure Continuity')
        plt.plot(history['val']['mass_conservation_loss'], label='Val Mass Conservation')
    
    plt.title('Validation Loss Components')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    
    plt.suptitle(title)
    plt.tight_layout()
    plt.subplots_adjust(top=0.9)
    plt.show()


def plot_network_results(prediction_df, scenario_id, pressure_col='Pressure', flowrate_col='MassFlowrate',
                        elevation_col='Elevation', invert_elevation=True, x_col="long", y_col="lat", 
                        flowline_col="BranchEquipment"):
    """
    Visualize pipeline network results with predictions.
    
    Parameters:
        prediction_df (pd.DataFrame): DataFrame with predictions
        scenario_id (int or str): ID of the scenario to visualize
        pressure_col (str): Column name for pressure
        flowrate_col (str): Column name for mass flow rate
        elevation_col (str): Column name for elevation
        invert_elevation (bool): Whether to invert elevation for depth visualization
        x_col, y_col (str): Column names for spatial coordinates
        flowline_col (str): Column name for flowline identifiers
    
    Returns:
        matplotlib.figure.Figure: The created figure
    """
    # Filter to the specified scenario
    scenario_df = prediction_df[prediction_df["scenario"] == scenario_id].copy()
    
    if len(scenario_df) == 0:
        print(f"Scenario {scenario_id} not found in the dataset")
        return None
    
    # Create figure with 3 subplots
    fig = plt.figure(figsize=(18, 12))
    
    # 1. Plot network with pressure prediction
    ax1 = fig.add_subplot(221)
    
    # Create colormap for pressure
    min_pred_pressure = scenario_df[f"{pressure_col}_pred"].min()
    max_pred_pressure = scenario_df[f"{pressure_col}_pred"].max()
    
    # Plot each flowline with pressure prediction
    for flowline_id in scenario_df[flowline_col].unique():
        flowline_data = scenario_df[scenario_df[flowline_col] == flowline_id]
        flowline_data = flowline_data.sort_values(by='TotalDistance')
        
        # Get coordinates and predicted pressure
        x_coords = flowline_data[x_col].values
        y_coords = flowline_data[y_col].values
        pressures = flowline_data[f"{pressure_col}_pred"].values.astype(float)
        
        # Plot flowline as a line with pressure as color
        points = np.array([x_coords, y_coords]).T.reshape(-1, 1, 2)
        segments = np.concatenate([points[:-1], points[1:]], axis=1)
        
        # Skip if we don't have enough points for segments
        if len(segments) == 0:
            continue
            
        norm = plt.Normalize(min_pred_pressure, max_pred_pressure)
        lc = LineCollection(segments, cmap='jet', norm=norm)
        
        # Ensure pressures array is the right length and type
        if len(pressures) > 1:
            pressure_values = pressures[:-1]  # We need one value per segment
            # Convert to float array and check for NaN values
            pressure_values = np.array(pressure_values, dtype=float)
            if not np.isnan(pressure_values).any():
                lc.set_array(pressure_values)
                lc.set_linewidth(3)
                line = ax1.add_collection(lc)
        
        # Mark source nodes with a circle
        source_nodes = flowline_data[flowline_data['node_type'] == 1]
        if not source_nodes.empty:
            ax1.plot(source_nodes[x_col], source_nodes[y_col], 'o', color='green', markersize=8)
            
        # Mark sink nodes with a square
        sink_nodes = flowline_data[flowline_data['node_type'] == -1]
        if not sink_nodes.empty:
            ax1.plot(sink_nodes[x_col], sink_nodes[y_col], 's', color='red', markersize=8)
    
    # Set axis limits based on data
    ax1.set_xlim(scenario_df[x_col].min() - 0.001, scenario_df[x_col].max() + 0.001)
    ax1.set_ylim(scenario_df[y_col].min() - 0.001, scenario_df[y_col].max() + 0.001)
    
    ax1.set_xlabel(x_col)
    ax1.set_ylabel(y_col)
    ax1.set_title(f'Network with Predicted Pressure - Scenario {scenario_id}')
    ax1.grid(True)
    
    # Add colorbar (if we have any valid line collections)
    if 'line' in locals():
        cbar = fig.colorbar(line, ax=ax1)
        cbar.set_label(f'Predicted {pressure_col}')
    
    # 2. Plot pressure profiles
    ax2 = fig.add_subplot(222)
    
    # Plot pressure vs distance for each flowline
    for flowline_id in scenario_df[flowline_col].unique():
        flowline_data = scenario_df[scenario_df[flowline_col] == flowline_id]
        flowline_data = flowline_data.sort_values(by='TotalDistance')
        
        # Get distance, true pressure, and predicted pressure
        distances = flowline_data['TotalDistance'].values
        true_pressures = flowline_data[pressure_col].values
        pred_pressures = flowline_data[f"{pressure_col}_pred"].values
        
        # Plot true and predicted pressure
        ax2.plot(distances, true_pressures, 'o-', linewidth=1, markersize=4, alpha=0.5, label=f'True (FL {flowline_id})')
        ax2.plot(distances, pred_pressures, 'x-', linewidth=2, markersize=6, label=f'Pred (FL {flowline_id})')
    
    ax2.set_xlabel('Distance (m)')
    ax2.set_ylabel('Pressure')
    ax2.set_title('Pressure vs Distance')
    ax2.grid(True)
    
    # Add minimum pressure threshold line if appropriate
    if min_pred_pressure < 40:
        ax2.axhline(y=36, color='r', linestyle='--', label='Min Pressure Threshold (36)')
    
    # Adjust legend to show only unique entries
    handles, labels = ax2.get_legend_handles_labels()
    by_label = dict(zip(labels, handles))
    ax2.legend(by_label.values(), by_label.keys(), loc='best')
    
    # 3. Plot elevation profile
    ax3 = fig.add_subplot(223)
    
    # Plot elevation vs distance for each flowline
    for flowline_id in scenario_df[flowline_col].unique():
        flowline_data = scenario_df[scenario_df[flowline_col] == flowline_id]
        flowline_data = flowline_data.sort_values(by='TotalDistance')
        
        # Get distance and elevation
        distances = flowline_data['TotalDistance'].values
        elevations = flowline_data[elevation_col].values
        
        # Invert elevation if requested (for depth visualization)
        if invert_elevation:
            elevations = -elevations
            
        # Plot elevation
        ax3.plot(distances, elevations, 'o-', linewidth=2, label=f'Flowline {flowline_id}')
    
    ax3.set_xlabel('Distance (m)')
    ax3.set_ylabel('Depth' if invert_elevation else 'Elevation')
    ax3.set_title('Elevation Profile')
    ax3.grid(True)
    ax3.legend()
    
    # 4. Plot flow rate profiles
    ax4 = fig.add_subplot(224)
    
    # Plot flow rate vs distance for each flowline
    for flowline_id in scenario_df[flowline_col].unique():
        flowline_data = scenario_df[scenario_df[flowline_col] == flowline_id]
        flowline_data = flowline_data.sort_values(by='TotalDistance')
        
        # Get distance, true flow, and predicted flow
        distances = flowline_data['TotalDistance'].values
        true_flows = flowline_data[flowrate_col].values
        pred_flows = flowline_data[f"{flowrate_col}_pred"].values
        
        # Plot true and predicted flow
        ax4.plot(distances, true_flows, 'o-', linewidth=1, markersize=4, alpha=0.5, label=f'True (FL {flowline_id})')
        ax4.plot(distances, pred_flows, 'x-', linewidth=2, markersize=6, label=f'Pred (FL {flowline_id})')
    
    ax4.set_xlabel('Distance (m)')
    ax4.set_ylabel('Mass Flow Rate')
    ax4.set_title('Flow Rate vs Distance')
    ax4.grid(True)
    
    # Adjust legend to show only unique entries
    handles, labels = ax4.get_legend_handles_labels()
    by_label = dict(zip(labels, handles))
    ax4.legend(by_label.values(), by_label.keys(), loc='best')
    
    plt.tight_layout()
    plt.suptitle(f'Pipeline Network Results - Scenario {scenario_id}', fontsize=16)
    plt.subplots_adjust(top=0.93)
    plt.show()
    
    return fig

def analyze_junction_performance(model, data, junctions, input_cols, output_cols,
                               input_min, input_max, output_min, output_max,
                               scenario_id, flowline_col="BranchEquipment", 
                               x_col="long", y_col="lat", tol=1e-6,
                               device=torch.device("cpu")):
    """
    Analyze how well the model satisfies physics constraints at junctions.
    
    Parameters:
        model (nn.Module): Trained neural network model
        data (pd.DataFrame): DataFrame with pipeline data
        junctions (list): List of junction dictionaries
        input_cols, output_cols (list): Lists of column names
        input_min, input_max, output_min, output_max (array): Scaling parameters
        scenario_id (int or str): ID of scenario to analyze
        flowline_col, x_col, y_col (str): Column names for data structure
        tol (float): Tolerance for coordinate matching
        device (torch.device): Computation device
    
    Returns:
        pd.DataFrame: DataFrame with junction analysis results
    """
    model.eval()
    
    # Get scenario data
    scenario_data = data[data["scenario"] == scenario_id].copy().reset_index(drop=True)
    
    # Create tensors for scaling
    input_min_tensor = torch.tensor(input_min, dtype=torch.float32, device=device)
    input_max_tensor = torch.tensor(input_max, dtype=torch.float32, device=device)
    output_min_tensor = torch.tensor(output_min, dtype=torch.float32, device=device)
    output_max_tensor = torch.tensor(output_max, dtype=torch.float32, device=device)
    
    # Results for each junction
    junction_results = []
    
    with torch.no_grad():
        for j_idx, junction in enumerate(junctions):
            junction_coords = junction["coords"]
            junction_nodes = []
            
            # Find all nodes at this junction
            for _, node in scenario_data.iterrows():
                node_coords = np.array([node[x_col], node[y_col]])
                junction_coords_arr = np.array(junction_coords)
                if np.linalg.norm(node_coords - junction_coords_arr) < tol:
                    junction_nodes.append(node)
            
            if len(junction_nodes) < 2:
                continue  # Skip junctions with insufficient nodes
            
            # Predict outputs for each node at the junction
            junction_node_predictions = []
            
            for node in junction_nodes:
                # Prepare input for prediction
                input_values = []
                for col in input_cols:
                    input_values.append(float(node.get(col, 0.0)))
                
                # Convert to tensor and scale
                input_tensor = torch.tensor([input_values], dtype=torch.float32, device=device)
                scaled_input = (input_tensor - input_min_tensor) / (input_max_tensor - input_min_tensor + 1e-8)
                
                # Get model prediction
                pred = model(scaled_input)
                
                # Unscale predicted values
                physical_preds = []
                for i, col in enumerate(output_cols):
                    # Convert from [-1,1] to [0,1] then unscale
                    pred_norm = (pred[0, i] + 1) / 2
                    physical_pred = pred_norm * (output_max_tensor[i] - output_min_tensor[i]) + output_min_tensor[i]
                    physical_preds.append(physical_pred.item())
                
                # Store predictions with node info
                node_pred = {
                    'node_id': node.get('node_id', f'node_{len(junction_node_predictions)}'),
                    'flowline': node[flowline_col],
                    'x': node[x_col],
                    'y': node[y_col]
                }
                
                for i, col in enumerate(output_cols):
                    node_pred[col] = physical_preds[i]
                    node_pred[f'{col}_true'] = float(node[col])
                
                junction_node_predictions.append(node_pred)
            
            # Calculate pressure continuity metrics
            pressures = [node['Pressure'] for node in junction_node_predictions]
            true_pressures = [node['Pressure_true'] for node in junction_node_predictions]
            
            mean_pressure = np.mean(pressures)
            pressure_std = np.std(pressures)
            pressure_variation = pressure_std / mean_pressure * 100 if mean_pressure > 0 else 0
            
            true_mean_pressure = np.mean(true_pressures)
            true_pressure_std = np.std(true_pressures)
            true_pressure_variation = true_pressure_std / true_mean_pressure * 100 if true_mean_pressure > 0 else 0
            
            # Classify flowlines as incoming or outgoing
            incoming_flowlines = []
            outgoing_flowlines = []
            
            for flowline_id in set(node['flowline'] for node in junction_node_predictions):
                direction = classify_flowline_direction(
                    flowline_id, junction_coords, scenario_data,
                    x_col, y_col, "TotalDistance", tol
                )
                
                if direction == "incoming":
                    incoming_flowlines.append(flowline_id)
                elif direction == "outgoing":
                    outgoing_flowlines.append(flowline_id)
            
            # Calculate mass conservation metrics
            incoming_mass = 0.0
            outgoing_mass = 0.0
            
            for flowline_id in incoming_flowlines:
                for node in junction_node_predictions:
                    if node['flowline'] == flowline_id:
                        incoming_mass += node['MassFlowrate']
                        break
            
            for flowline_id in outgoing_flowlines:
                for node in junction_node_predictions:
                    if node['flowline'] == flowline_id:
                        outgoing_mass += node['MassFlowrate']
                        break
            
            mass_conservation_error = 0.0
            if incoming_mass > 0:
                mass_conservation_error = abs(incoming_mass - outgoing_mass) / incoming_mass * 100
            
            # Store junction analysis results
            junction_result = {
                'junction_id': junction.get('id', f'J{j_idx}'),
                'x': junction_coords[0],
                'y': junction_coords[1],
                'node_count': len(junction_nodes),
                'pressure_mean': mean_pressure,
                'pressure_variation': pressure_variation,
                'true_pressure_variation': true_pressure_variation,
                'incoming_mass': incoming_mass,
                'outgoing_mass': outgoing_mass,
                'mass_conservation_error': mass_conservation_error,
                'incoming_flowlines': incoming_flowlines,
                'outgoing_flowlines': outgoing_flowlines
            }
            
            junction_results.append(junction_result)
    
    return pd.DataFrame(junction_results)

def visualize_junction_performance(prediction_df, junctions, scenario_id=None, 
                                 plot_pressure=True, plot_mass_flow=True,
                                 x_col="long", y_col="lat", pressure_col="Pressure", 
                                 mass_flow_col="MassFlowrate", tol=1e-6):
    """
    Visualize model performance at junctions.
    
    Parameters:
        prediction_df (pd.DataFrame): DataFrame with predictions
        junctions (list): List of junction dictionaries
        scenario_id (int or str): ID of the scenario to visualize (None = all scenarios)
        plot_pressure (bool): Whether to plot pressure performance
        plot_mass_flow (bool): Whether to plot mass flow performance
        x_col, y_col (str): Column names for spatial coordinates
        pressure_col (str): Column name for pressure
        mass_flow_col (str): Column name for mass flow
        tol (float): Tolerance for coordinate matching
        
    Returns:
        list: Junction analysis data
    """
    if scenario_id is not None:
        df = prediction_df[prediction_df["scenario"] == scenario_id].copy()
    else:
        df = prediction_df.copy()
    
    # Gather junction performance data
    junction_data = []
    
    for junction in junctions:
        junction_coords = np.array(junction["coords"])
        junction_nodes = []
        
        # Find all nodes at this junction
        for _, node in df.iterrows():
            node_coords = np.array([node[x_col], node[y_col]])
            if np.linalg.norm(node_coords - junction_coords) < tol:
                junction_nodes.append(node)
        
        if len(junction_nodes) < 2:
            continue  # Skip junctions with fewer than 2 nodes
            
        # Calculate pressure stats at junction
        if plot_pressure:
            true_pressures = [node[pressure_col] for node in junction_nodes]
            pred_pressures = [node[f"{pressure_col}_pred"] for node in junction_nodes]
            
            true_mean_pressure = np.mean(true_pressures)
            pred_mean_pressure = np.mean(pred_pressures)
            
            true_pressure_variation = np.std(true_pressures) / true_mean_pressure * 100 if true_mean_pressure > 0 else 0
            pred_pressure_variation = np.std(pred_pressures) / pred_mean_pressure * 100 if pred_mean_pressure > 0 else 0
            
            pressure_mae = np.mean(np.abs(np.array(true_pressures) - np.array(pred_pressures)))
            pressure_mape = np.mean(np.abs((np.array(true_pressures) - np.array(pred_pressures)) / np.array(true_pressures))) * 100
            
        # Calculate mass flow stats at junction
        if plot_mass_flow:
            true_flows = [node[mass_flow_col] for node in junction_nodes]
            pred_flows = [node[f"{mass_flow_col}_pred"] for node in junction_nodes]
            
            true_mean_flow = np.mean(true_flows)
            pred_mean_flow = np.mean(pred_flows)
            
            flow_mae = np.mean(np.abs(np.array(true_flows) - np.array(pred_flows)))
            flow_mape = np.mean(np.abs((np.array(true_flows) - np.array(pred_flows)) / np.array(true_flows))) * 100
            
        # Store junction stats
        junction_info = {
            'junction_id': junction["id"],
            'coords': junction["coords"],
            'node_count': len(junction_nodes)
        }
        
        if plot_pressure:
            junction_info.update({
                'true_mean_pressure': true_mean_pressure,
                'pred_mean_pressure': pred_mean_pressure,
                'true_pressure_variation': true_pressure_variation,
                'pred_pressure_variation': pred_pressure_variation,
                'pressure_mae': pressure_mae,
                'pressure_mape': pressure_mape
            })
            
        if plot_mass_flow:
            junction_info.update({
                'true_mean_flow': true_mean_flow,
                'pred_mean_flow': pred_mean_flow,
                'flow_mae': flow_mae,
                'flow_mape': flow_mape
            })
            
        junction_data.append(junction_info)
    
    # Create visualization
    if not junction_data:
        print("No junction data found for visualization")
        return []
        
    # Plot results
    if plot_pressure:
        # Create pressure performance plots
        plt.figure(figsize=(15, 10))
        
        # Plot 1: True vs. Predicted Pressure at Junctions
        plt.subplot(2, 2, 1)
        x = [j['true_mean_pressure'] for j in junction_data]
        y = [j['pred_mean_pressure'] for j in junction_data]
        plt.scatter(x, y)
        max_p = max(max(x), max(y)) * 1.1
        plt.plot([0, max_p], [0, max_p], 'r--')  # Perfect prediction line
        plt.xlabel('True Mean Pressure')
        plt.ylabel('Predicted Mean Pressure')
        plt.title('True vs. Predicted Pressure at Junctions')
        plt.grid(True)
        
        # Plot 2: Pressure Variation at Junctions
        plt.subplot(2, 2, 2)
        x = [j['true_pressure_variation'] for j in junction_data]
        y = [j['pred_pressure_variation'] for j in junction_data]
        plt.scatter(x, y)
        max_var = max(max(x), max(y)) * 1.1
        plt.plot([0, max_var], [0, max_var], 'r--')  # Equal variation line
        plt.xlabel('True Pressure Variation (%)')
        plt.ylabel('Predicted Pressure Variation (%)')
        plt.title('Pressure Variation at Junctions')
        plt.grid(True)
        
        # Plot 3: Pressure Error by Junction Size
        plt.subplot(2, 2, 3)
        x = [j['node_count'] for j in junction_data]
        y = [j['pressure_mape'] for j in junction_data]
        plt.scatter(x, y)
        plt.xlabel('Number of Nodes at Junction')
        plt.ylabel('Pressure MAPE (%)')
        plt.title('Pressure Error by Junction Size')
        plt.grid(True)
        
        # Plot 4: Histogram of Pressure MAPE
        plt.subplot(2, 2, 4)
        plt.hist([j['pressure_mape'] for j in junction_data], bins=20)
        plt.xlabel('Pressure MAPE (%)')
        plt.ylabel('Count')
        plt.title('Distribution of Pressure Error at Junctions')
        plt.grid(True)
        
        plt.tight_layout()
        plt.suptitle(f'Pressure Performance at Junctions (Scenario {scenario_id if scenario_id else "All"})')
        plt.subplots_adjust(top=0.9)
        plt.show()
    
    if plot_mass_flow:
        # Create mass flow performance plots
        plt.figure(figsize=(15, 10))
        
        # Plot 1: True vs. Predicted Flow at Junctions
        plt.subplot(2, 2, 1)
        x = [j['true_mean_flow'] for j in junction_data]
        y = [j['pred_mean_flow'] for j in junction_data]
        plt.scatter(x, y)
        max_f = max(max(x), max(y)) * 1.1
        plt.plot([0, max_f], [0, max_f], 'r--')  # Perfect prediction line
        plt.xlabel('True Mean Flow')
        plt.ylabel('Predicted Mean Flow')
        plt.title('True vs. Predicted Flow at Junctions')
        plt.grid(True)
        
        # Plot 2: Flow Error by Junction Size
        plt.subplot(2, 2, 2)
        x = [j['node_count'] for j in junction_data]
        y = [j['flow_mape'] for j in junction_data]
        plt.scatter(x, y)
        plt.xlabel('Number of Nodes at Junction')
        plt.ylabel('Flow MAPE (%)')
        plt.title('Flow Error by Junction Size')
        plt.grid(True)
        
        # Plot 3: Histogram of Flow MAPE
        plt.subplot(2, 2, 3)
        plt.hist([j['flow_mape'] for j in junction_data], bins=20)
        plt.xlabel('Flow MAPE (%)')
        plt.ylabel('Count')
        plt.title('Distribution of Flow Error at Junctions')
        plt.grid(True)
        
        plt.tight_layout()
        plt.suptitle(f'Mass Flow Performance at Junctions (Scenario {scenario_id if scenario_id else "All"})')
        plt.subplots_adjust(top=0.9)
        plt.show()
    
    # Print overall statistics
    print("Junction Performance Summary:")
    if plot_pressure:
        avg_pressure_mape = np.mean([j['pressure_mape'] for j in junction_data])
        print(f"  Average Pressure MAPE: {avg_pressure_mape:.2f}%")
        avg_pressure_variation_error = np.mean([abs(j['true_pressure_variation'] - j['pred_pressure_variation']) for j in junction_data])
        print(f"  Average Pressure Variation Error: {avg_pressure_variation_error:.2f}%")
    
    if plot_mass_flow:
        avg_flow_mape = np.mean([j['flow_mape'] for j in junction_data])
        print(f"  Average Flow MAPE: {avg_flow_mape:.2f}%")
        
    return junction_data

def plot_error_distribution(prediction_df, output_cols, scenario_id=None):
    """Plot error distribution for each output column"""
    if scenario_id is not None:
        df = prediction_df[prediction_df["scenario"] == scenario_id].copy()
    else:
        df = prediction_df.copy()
    
    num_cols = len(output_cols)
    plt.figure(figsize=(15, 5 * num_cols))
    
    for i, col in enumerate(output_cols):
        plt.subplot(num_cols, 1, i+1)
        
        # Calculate absolute and relative errors
        df[f'{col}_abs_error'] = abs(df[col] - df[f'{col}_pred'])
        df[f'{col}_rel_error'] = 100 * df[f'{col}_abs_error'] / (abs(df[col]) + 1e-8)
        
        # Plot histogram of relative errors
        plt.hist(df[f'{col}_rel_error'], bins=50)
        plt.title(f'{col} Relative Error Distribution (%)')
        plt.xlabel('Relative Error (%)')
        plt.ylabel('Count')
        plt.grid(True)
        
        # Print statistics
        mean_rel_error = df[f'{col}_rel_error'].mean()
        median_rel_error = df[f'{col}_rel_error'].median()
        max_rel_error = df[f'{col}_rel_error'].max()
        
        print(f"{col} Error Statistics:")
        print(f"  Mean Relative Error: {mean_rel_error:.2f}%")
        print(f"  Median Relative Error: {median_rel_error:.2f}%")
        print(f"  Max Relative Error: {max_rel_error:.2f}%")
        
    plt.tight_layout()
    plt.show()

def compare_cluster_predictions_with_elevation(predictions_df, output_cols, scenario_id=None, 
                                              sort_by='TotalDistance', group_by='BranchEquipment',
                                              elevation_col='Elevation', invert_elevation=True):
    """
    Compare predictions with ground truth across multiple flowlines in a cluster
    and show elevation profile on a secondary y-axis
    
    Args:
        predictions_df: DataFrame with predictions and ground truth
        output_cols: List of output column names
        scenario_id: Specific scenario to plot (None = use all scenarios)
        sort_by: Column to sort nodes within each flowline
        group_by: Column to group flowlines
        elevation_col: Column name for elevation data
        invert_elevation: Whether to invert the elevation axis (to show depth)
    """
    # Filter to specific scenario if provided
    if scenario_id is not None:
        df = predictions_df[predictions_df["scenario"] == scenario_id].copy()
    else:
        df = predictions_df.copy()
    
    # Get unique flowlines
    flowlines = df[group_by].unique()
    num_flowlines = len(flowlines)
    
    # Create a plot for each output column
    for col in output_cols:
        # Calculate figure size based on number of flowlines
        fig_height = max(6, num_flowlines * 2)  # Increased height for clarity
        fig, axes = plt.subplots(num_flowlines, 1, figsize=(12, fig_height), sharex=True)
        
        # Handle single flowline case
        if num_flowlines == 1:
            axes = [axes]
        
        # Plot each flowline
        for i, flowline in enumerate(flowlines):
            flowline_data = df[df[group_by] == flowline].sort_values(by=sort_by)
            
            # Create x values (node index or distance)
            x = flowline_data[sort_by].values
            
            # Create primary y-axis for output values
            ax1 = axes[i]
            
            # Plot true and predicted values on primary y-axis
            line1 = ax1.scatter(x, flowline_data[col], label=f'True {col}', color='blue', marker='o', alpha=0.7)
            line2 = ax1.scatter(x, flowline_data[f'{col}_pred'], label=f'Predicted {col}', color='red', marker='x', alpha=0.7)
            
            # Set y-axis label for primary axis
            ax1.set_ylabel(col, color='black')
            ax1.tick_params(axis='y', labelcolor='black')
            
            # Create secondary y-axis for elevation
            ax2 = ax1.twinx()
            
            # Plot elevation on secondary y-axis if available
            if elevation_col in flowline_data.columns:
                # Prepare elevation data - invert if requested
                if invert_elevation:
                    # Get elevation values and invert them 
                    elevation_values = flowline_data[elevation_col].values
                    ylabel = 'Elevation (ft)'
                else:
                    elevation_values = flowline_data[elevation_col].values 
                    ylabel = 'Elevation (ft)'
                
                line3 = ax2.plot(x, elevation_values, label='Elevation', color='green', 
                                linestyle='-', linewidth=2, alpha=0.5)
                ax2.set_ylabel(ylabel, color='green')
                ax2.tick_params(axis='y', labelcolor='green')
                
                # If inverted, also invert the y-axis direction so depth increases downward
                if invert_elevation:
                    ax2.invert_yaxis()
                
                # Add elevation to legend
                # Combine legends from both axes
                lines = [line1, line2, line3[0]]
                labels = [f'True {col}', f'Predicted {col}', 'Depth' if invert_elevation else 'Elevation']
                ax1.legend(lines, labels, loc='best')
            else:
                ax1.legend(loc='best')
            
            # Add flowline title
            ax1.set_title(f'Flowline: {flowline}')
            ax1.grid(True)
        
        # Add overall title and x-label
        title_elevation = "Depth Profile" if invert_elevation else "Elevation Profile"
        plt.suptitle(f'{col} Comparison with {title_elevation} - Scenario {scenario_id}')
        plt.xlabel(sort_by)
        plt.tight_layout()
        plt.subplots_adjust(top=0.95)
        plt.show()

def plot_pressure_profile_with_elevation(predictions_df, scenario_id=None, 
                                       sort_by='TotalDistance', group_by='BranchEquipment',
                                       elevation_col='Elevation', pressure_col='Pressure',
                                       flowrate_col='MassFlowrate', invert_elevation=True):
    """
    Create a comprehensive visualization showing pressure, elevation, and flow rate
    for a better understanding of flow behavior
    
    Args:
        predictions_df: DataFrame with predictions and ground truth
        scenario_id: Specific scenario to plot
        sort_by: Column to sort nodes within each flowline
        group_by: Column to group flowlines
        elevation_col: Column name for elevation data
        pressure_col: Column name for pressure data
        flowrate_col: Column name for flow rate data
        invert_elevation: Whether to invert the elevation axis (to show depth)
    """
    # Filter to specific scenario if provided
    if scenario_id is not None:
        df = predictions_df[predictions_df["scenario"] == scenario_id].copy()
    else:
        df = predictions_df.copy()
    
    # Get unique flowlines
    flowlines = df[group_by].unique()
    num_flowlines = len(flowlines)
    
    # Create a figure with two subplots for each flowline (pressure+elevation and flow rate)
    fig_height = max(8, num_flowlines * 4)  # Increased height for double plots
    fig, axes = plt.subplots(num_flowlines, 2, figsize=(15, fig_height))
    
    # Handle single flowline case
    if num_flowlines == 1:
        axes = axes.reshape(1, 2)
    
    # Plot each flowline
    for i, flowline in enumerate(flowlines):
        flowline_data = df[df[group_by] == flowline].sort_values(by=sort_by)
        
        # Create x values (node index or distance)
        x = flowline_data[sort_by].values
        
        # ---------- Left subplot: Pressure with Elevation ----------
        ax1 = axes[i, 0]
        
        # Plot actual and predicted pressure on primary y-axis
        line1 = ax1.scatter(x, flowline_data[pressure_col], label=f'True {pressure_col}', 
                          color='blue', marker='o', alpha=0.7)
        
        if f'{pressure_col}_pred' in flowline_data.columns:
            line2 = ax1.scatter(x, flowline_data[f'{pressure_col}_pred'], 
                              label=f'Predicted {pressure_col}', 
                              color='red', marker='x', alpha=0.7)
        
        # Set pressure axis labels
        ax1.set_ylabel(f'{pressure_col} (kPa)', color='black')
        ax1.tick_params(axis='y', labelcolor='black')
        
        # Create secondary y-axis for elevation
        ax1_twin = ax1.twinx()
        
        # Plot elevation on secondary y-axis if available
        if elevation_col in flowline_data.columns:
            # Prepare elevation data - invert if requested
            if invert_elevation:
                # Get elevation values and invert them (multiply by F)
                elevation_values = flowline_data[elevation_col].values
                ylabel = 'Elevation (ft)'
            else:
                elevation_values = flowline_data[elevation_col].values
                ylabel = 'Elevation (ft)'
            
            line3 = ax1_twin.plot(x, elevation_values, label='Depth' if invert_elevation else 'Elevation', 
                                color='green', linestyle='-', linewidth=2, alpha=0.5)
            ax1_twin.set_ylabel(ylabel, color='green')
            ax1_twin.tick_params(axis='y', labelcolor='green')
            
            # If inverted, also invert the y-axis direction so depth increases downward
            if invert_elevation:
                ax1_twin.invert_yaxis()
            
            # Create combined legend
            lines1 = [line1]
            if f'{pressure_col}_pred' in flowline_data.columns:
                lines1.append(line2)
            lines1.append(line3[0])
            
            labels1 = [f'True {pressure_col}']
            if f'{pressure_col}_pred' in flowline_data.columns:
                labels1.append(f'Predicted {pressure_col}')
            labels1.append('Depth' if invert_elevation else 'Elevation')
            
            ax1.legend(lines1, labels1, loc='best')
        else:
            ax1.legend(loc='best')
        
        title_elevation = "Depth" if invert_elevation else "Elevation"
        ax1.set_title(f'Pressure and {title_elevation} - Flowline: {flowline}')
        ax1.grid(True)
        ax1.set_xlabel(sort_by)
        
        # ---------- Right subplot: Flow Rate ----------
        ax2 = axes[i, 1]
        
        # Plot actual and predicted flow rate
        ax2.scatter(x, flowline_data[flowrate_col], label=f'True {flowrate_col}', 
                  color='purple', marker='o', alpha=0.7)
        
        if f'{flowrate_col}_pred' in flowline_data.columns:
            ax2.scatter(x, flowline_data[f'{flowrate_col}_pred'], 
                      label=f'Predicted {flowrate_col}', 
                      color='orange', marker='x', alpha=0.7)
        
        ax2.set_ylabel(f'{flowrate_col}')
        ax2.set_title(f'Flow Rate - Flowline: {flowline}')
        ax2.legend(loc='best')
        ax2.grid(True)
        ax2.set_xlabel(sort_by)
    
    # Add overall title
    plt.suptitle(f'Flow Analysis - Scenario {scenario_id}', fontsize=16)
    plt.tight_layout()
    plt.subplots_adjust(top=0.95)
    plt.show()