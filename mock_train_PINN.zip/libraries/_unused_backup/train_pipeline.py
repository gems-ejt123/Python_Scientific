import torch
import numpy as np
import random
import torch.nn as nn
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, TensorDataset
from libraries.pinn_models import Surrogate_PINN, create_pinn_model, create_kan_model
from libraries.memory_utils import get_device
from libraries.pinn_dataset import create_dataloaders

def set_seed(seed=42, device=None):
    """Set random seeds for reproducibility across all libraries."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_physics_weight(epoch, base_weight, warmup_epochs, mode='linear'):
    """Enhanced physics weight scheduling with validation."""
    if epoch < warmup_epochs:
        if mode == 'linear':
            return base_weight * (epoch / warmup_epochs)
        elif mode == 'exponential':
            return base_weight * (1 - np.exp(-5 * epoch / warmup_epochs))
        elif mode == 'cosine':
            return base_weight * (1 - np.cos(np.pi * epoch / warmup_epochs)) / 2
    return base_weight


class EnhancedPhysicsLoss:
    """Enhanced physics loss with improved validation and debugging."""
    
    def __init__(self, junctions, min_pressure_sink, pressure_continuity_weight,
                 mass_conservation_weight, device, input_scaler, output_scaler):
        self.junctions = junctions
        self.min_pressure_sink = min_pressure_sink
        self.pressure_continuity_weight = pressure_continuity_weight
        self.mass_conservation_weight = mass_conservation_weight
        self.device = device
        self.input_scaler = input_scaler
        self.output_scaler = output_scaler
        self.mse_loss = nn.MSELoss()
        # Optional mapping of training row indices -> node ids (set by pipeline)
        self.train_node_ids = None

        # Validate junctions
        if junctions is None or len(junctions) == 0:
            self.junction_validation_enabled = False
            print("WARNING: No junctions provided. Junction physics loss disabled.")
        else:
            self.junction_validation_enabled = True
            print(f"Junction physics loss enabled with {len(junctions)} junctions")
    
    def compute_enhanced_loss(self, model, X_batch, y_batch, y_pred, 
                            data_weight, physics_weight, junction_weight,
                            use_pressure_gradient, pressure_gradient_weight, 
                            pressure_gradient_sample_rate, epoch,
                            batch_row_indices=None):
        """Compute enhanced loss with physics validation and debugging."""
        
        # 1. Data loss
        data_loss = self.mse_loss(y_pred, y_batch)
        
        # 2. Physics loss (momentum conservation)
        physics_loss = self.compute_momentum_loss(model, X_batch)
        
        # 3. Junction physics loss
        junction_loss = torch.tensor(0.0, device=self.device)
        if self.junction_validation_enabled and junction_weight > 0:
            junction_loss = self.compute_junction_loss(model, X_batch, y_pred, batch_row_indices)
        
        # 4. Pressure gradient loss (optional)
        pressure_gradient_loss = torch.tensor(0.0, device=self.device)
        if use_pressure_gradient and pressure_gradient_weight > 0:
            pressure_gradient_loss = self.compute_pressure_gradient_loss(model, X_batch)
        
        # 5. Boundary conditions (minimum pressure at sink)
        boundary_loss = self.compute_boundary_loss(y_pred)
        
        # Total loss with validation
        total_loss = (
            data_weight * data_loss +
            physics_weight * physics_loss +
            junction_weight * junction_loss +
            pressure_gradient_weight * pressure_gradient_loss +
            0.1 * boundary_loss
        )
        
        # Validation: Check for NaN or infinite losses
        if torch.isnan(total_loss) or torch.isinf(total_loss):
            print(f"ERROR: Invalid loss detected at epoch {epoch}: total_loss={total_loss}")
            total_loss = data_loss  # Fallback to data loss only
        
        return {
            'total_loss': total_loss,
            'data_loss': data_loss,
            'physics_loss': physics_loss,
            'junction_loss': junction_loss,
            'pressure_gradient_loss': pressure_gradient_loss,
            'boundary_loss': boundary_loss
        }
    
    def compute_momentum_loss(self, model, X_batch):
        """
        Compute momentum conservation loss with elevation effects.
        
        Implements the momentum conservation equation for pipe flow:
        dP/dx = -friction_loss - ρg * sin(θ)
        
        Where sin(θ) ≈ dElevation/dx for small angles.
        
        INPUT_COLS order: ['FlowrateLiquidInsitu', 'Watercut', 'ElevationDifference', 'TotalDistance', 'SourcePressure']
        """
        try:
            X_batch.requires_grad_(True)
            y_pred = model(X_batch)
            
            # Correct indices based on INPUT_COLS order
            elevation_idx = 2  # ElevationDifference
            distance_idx = 3   # TotalDistance
            
            if X_batch.shape[1] > distance_idx:
                grad_outputs = torch.ones_like(y_pred)
                gradients = torch.autograd.grad(
                    outputs=y_pred,
                    inputs=X_batch,
                    grad_outputs=grad_outputs,
                    create_graph=True,
                    retain_graph=True,
                    only_inputs=True
                )[0]
                
                # Pressure gradient with respect to distance
                dp_dx = gradients[:, distance_idx:distance_idx+1]
                
                # Pressure gradient with respect to elevation difference
                dp_dh = gradients[:, elevation_idx:elevation_idx+1]
                
                # Physics constants
                g = 32.174  # ft/s² gravitational acceleration
                rho_liquid = 62.4  # lbm/ft³ typical liquid density (water)
                
                # Convert units: lbm/ft³ * ft/s² to psi/ft
                # 1 psi = 144 lbf/ft², 1 lbf = 32.174 lbm⋅ft/s²
                gravity_term = (rho_liquid * g) / 144.0  # psi/ft per unit elevation change
                
                # For momentum conservation, the pressure gradient should account for:
                # 1. Friction losses (captured by dp_dx)
                # 2. Gravitational effects (captured by dp_dh * gravity_term)
                
                # The physics-informed loss enforces that pressure changes 
                # should be consistent with both friction and elevation effects
                
                # Method 1: Ensure gradients are physically reasonable
                # Typical pressure drop is 1-10 psi per 1000 ft, so dp_dx should be small
                friction_loss = torch.mean(torch.abs(dp_dx))
                
                # Method 2: Elevation effect should follow hydrostatic principles
                # For upward flow, pressure should increase with elevation difference
                elevation_loss = torch.mean(torch.abs(dp_dh - gravity_term))
                
                # Combined momentum loss
                momentum_loss = friction_loss + 0.1 * elevation_loss
                
                if torch.isnan(momentum_loss) or torch.isinf(momentum_loss):
                    return torch.tensor(0.0, device=self.device)
                
                return momentum_loss
            else:
                return torch.tensor(0.0, device=self.device)
                
        except Exception as e:
            print(f"Error in momentum loss computation: {e}")
            return torch.tensor(0.0, device=self.device)
    
    def compute_junction_loss(self, model, X_batch, y_pred, batch_row_indices=None):
        """Compute junction physics loss (pressure continuity) using junction node ids.

        Expects self.junctions to be a list of dicts with either 'node_ids' or 'nodes'
        and self.train_node_ids to be a numpy array mapping training row -> node_id.
        batch_row_indices is a 1D tensor with positions in the training set for samples in X_batch.
        The loss enforces that predicted pressures for nodes that share a junction are equal
        (measured as mean absolute deviation from the junction mean).
        """
        if not self.junction_validation_enabled:
            return torch.tensor(0.0, device=self.device)

        # If we don't have node id mapping, fall back to batch variance
        if batch_row_indices is None or self.train_node_ids is None or not hasattr(self, 'full_to_train_pos'):
            try:
                return torch.mean(torch.abs(y_pred - torch.mean(y_pred)))
            except Exception:
                return torch.tensor(0.0, device=self.device)

        try:
            junction_loss = torch.tensor(0.0, device=self.device)
            valid_junctions = 0

            # Map batch original indices to train positions
            batch_idx_np = batch_row_indices.detach().cpu().numpy()
            train_pos = self.full_to_train_pos[batch_idx_np]
            # create mask for samples that are in the train set
            valid_mask = train_pos >= 0
            if not np.any(valid_mask):
                return torch.tensor(0.0, device=self.device)

            # filtered train positions and corresponding predictions
            train_pos_filtered = train_pos[valid_mask]
            # y_pred aligns with original batch order; filter to same mask
            valid_mask_t = torch.tensor(valid_mask, dtype=torch.bool, device=y_pred.device)
            y_pred_filtered = y_pred[valid_mask_t].view(-1)

            # node ids for filtered batch (aligned with y_pred_filtered)
            batch_node_ids = [str(self.train_node_ids[int(p)]) for p in train_pos_filtered]

            # For efficiency, precompute train-position predictions for any junctions
            # that don't have enough members in the batch. We'll collect required train positions
            # and run a single forward on those rows.
            train_positions_needed = set()
            junction_to_positions = {}

            # First pass: collect positions present in batch and only compute junctions
            # that have at least two members in the batch (fast path). Skip others.
            for j_idx, junction in enumerate(self.junctions):
                junction_node_ids = [str(x).strip() for x in junction.get('node_ids', junction.get('nodes', []))]
                if not junction_node_ids:
                    continue

                positions = [i for i, nid in enumerate(batch_node_ids) if nid in junction_node_ids]
                if len(positions) >= 2:
                    junction_to_positions[j_idx] = ('batch', positions)
                else:
                    # skip expensive train-set fallback during per-batch loss
                    continue

            # Compute train-position predictions in a single forward if needed
            train_preds_map = {}
            if train_positions_needed and self.train_X_tensor is not None:
                try:
                    train_pos_list_sorted = sorted(list(train_positions_needed))
                    x_sel = self.train_X_tensor[train_pos_list_sorted].to(self.device)
                    with torch.no_grad():
                        preds_sel = model(x_sel).view(-1)
                    # Map back to original train positions
                    for i, pos in enumerate(train_pos_list_sorted):
                        train_preds_map[pos] = preds_sel[i]
                except Exception:
                    train_preds_map = {}

            # Now compute junction loss using either batch preds or train_preds_map
            for j_idx, modepos in junction_to_positions.items():
                mode, positions = modepos
                if mode == 'batch':
                    preds = y_pred_filtered[positions].view(-1)
                else:
                    # assemble preds from train_preds_map
                    preds_list = [train_preds_map.get(p, None) for p in positions]
                    preds_list = [p for p in preds_list if p is not None]
                    if len(preds_list) < 2:
                        continue
                    preds = torch.stack(preds_list)

                if preds.numel() < 2:
                    continue

                try:
                    data_min = torch.tensor(self.output_scaler.data_min_, device=preds.device, dtype=preds.dtype)
                    data_max = torch.tensor(self.output_scaler.data_max_, device=preds.device, dtype=preds.dtype)
                    preds_unscaled = preds * (data_max - data_min) + data_min
                except Exception:
                    preds_unscaled = preds

                mean_pred = torch.mean(preds_unscaled)
                cont_loss = torch.mean(torch.abs(preds_unscaled - mean_pred))
                junction_loss = junction_loss + cont_loss
                valid_junctions += 1

            if valid_junctions > 0:
                junction_loss = junction_loss / valid_junctions

            if torch.isnan(junction_loss) or torch.isinf(junction_loss):
                return torch.tensor(0.0, device=self.device)

            return junction_loss

        except Exception as e:
            print(f"Error in junction loss computation: {e}")
            return torch.tensor(0.0, device=self.device)

    def compute_junction_breakdown(self, model):
        """Return a list of (junction_id, cont_loss) computed on the train set.

        Uses self.train_X_tensor and self.train_node_ids. Returns empty list if unavailable.
        """
        results = []
        if not hasattr(self, 'train_X_tensor') or self.train_X_tensor is None or self.train_node_ids is None:
            return results

        model.eval()
        with torch.no_grad():
            # If full dataset is available, compute model outputs once (no grad) for efficient breakdown
            preds_full = None
            if hasattr(self, 'full_X_tensor') and getattr(self, 'full_X_tensor') is not None:
                try:
                    # compute in chunks to avoid OOM
                    full_X = self.full_X_tensor
                    device = self.device
                    chunk = 4096
                    parts = []
                    for i in range(0, len(full_X), chunk):
                        xb = full_X[i:i+chunk].to(device)
                        parts.append(model(xb).view(-1))
                    if parts:
                        preds_full = torch.cat(parts, dim=0)
                except Exception:
                    preds_full = None

            for junction in self.junctions:
                junction_node_ids = [str(x).strip() for x in junction.get('node_ids', junction.get('nodes', []))]
                if not junction_node_ids:
                    continue

                # Prefer evaluating on train subset if available (faster for small junctions)
                train_positions = []
                if self.train_node_ids is not None:
                    train_positions = [i for i, nid in enumerate(self.train_node_ids) if nid in junction_node_ids]

                if len(train_positions) >= 2 and self.train_X_tensor is not None:
                    x_sel = self.train_X_tensor[train_positions].to(self.device)
                    preds = model(x_sel).view(-1)
                    try:
                        data_min = torch.tensor(self.output_scaler.data_min_, device=preds.device, dtype=preds.dtype)
                        data_max = torch.tensor(self.output_scaler.data_max_, device=preds.device, dtype=preds.dtype)
                        preds_unscaled = preds * (data_max - data_min) + data_min
                        cont_loss = float(torch.mean(torch.abs(preds_unscaled - torch.mean(preds_unscaled))).item())
                    except Exception:
                        cont_loss = float(torch.mean(torch.abs(preds - torch.mean(preds))).item())
                    results.append((junction.get('id', '?'), cont_loss))
                    continue

                # Fallback: use preds_full if available
                if preds_full is not None and getattr(self, 'full_node_ids', None) is not None:
                    full_positions = [i for i, nid in enumerate(self.full_node_ids) if nid in junction_node_ids]
                    if len(full_positions) >= 2:
                        preds = preds_full[full_positions]
                        try:
                            data_min = torch.tensor(self.output_scaler.data_min_, device=preds.device, dtype=preds.dtype)
                            data_max = torch.tensor(self.output_scaler.data_max_, device=preds.device, dtype=preds.dtype)
                            preds_unscaled = preds * (data_max - data_min) + data_min
                            cont_loss = float(torch.mean(torch.abs(preds_unscaled - torch.mean(preds_unscaled))).item())
                        except Exception:
                            cont_loss = float(torch.mean(torch.abs(preds - torch.mean(preds))).item())
                        results.append((junction.get('id', '?'), cont_loss))
                        continue
                # otherwise, skip this junction
        return results

    def compute_full_junction_loss(self, model):
        """Compute a differentiable junction continuity loss over the full dataset.

        Returns a torch scalar on self.device (0 if not available).
        """
        if not hasattr(self, 'full_X_tensor') or self.full_X_tensor is None or getattr(self, 'full_node_ids', None) is None:
            return torch.tensor(0.0, device=self.device)

        junction_loss = torch.tensor(0.0, device=self.device)
        valid_junctions = 0

        # Compute model outputs for the full dataset once (in chunks) to avoid N forward passes
        try:
            full_X = self.full_X_tensor
            device = self.device
            chunk = 4096
            preds_parts = []
            for i in range(0, len(full_X), chunk):
                xb = full_X[i:i+chunk].to(device)
                preds_parts.append(model(xb).view(-1))
            if not preds_parts:
                return torch.tensor(0.0, device=self.device)
            preds_all = torch.cat(preds_parts, dim=0)
        except Exception as e:
            # Fallback: if we can't compute preds_all, return zero
            print(f"Warning: compute_full_junction_loss failed to compute full predictions: {e}")
            return torch.tensor(0.0, device=self.device)

        for junction in self.junctions:
            junction_node_ids = [str(x).strip() for x in junction.get('node_ids', junction.get('nodes', []))]
            if not junction_node_ids:
                continue
            full_positions = [i for i, nid in enumerate(self.full_node_ids) if nid in junction_node_ids]
            if len(full_positions) < 2:
                continue
            preds = preds_all[full_positions]
            try:
                data_min = torch.tensor(self.output_scaler.data_min_, device=preds.device, dtype=preds.dtype)
                data_max = torch.tensor(self.output_scaler.data_max_, device=preds.device, dtype=preds.dtype)
                preds_unscaled = preds * (data_max - data_min) + data_min
                cont_loss = torch.mean(torch.abs(preds_unscaled - torch.mean(preds_unscaled)))
            except Exception:
                cont_loss = torch.mean(torch.abs(preds - torch.mean(preds)))

            junction_loss = junction_loss + cont_loss
            valid_junctions += 1

        if valid_junctions > 0:
            junction_loss = junction_loss / valid_junctions

        return junction_loss
    
    def compute_pressure_gradient_loss(self, model, X_batch):
        """Compute pressure gradient loss with validation."""
        try:
            X_batch.requires_grad_(True)
            
            # Sample a subset for gradient computation
            sample_size = max(1, int(len(X_batch) * 0.1))
            indices = torch.randperm(len(X_batch))[:sample_size]
            X_sample = X_batch[indices]
            
            y_sample = model(X_sample)
            
            grad_outputs = torch.ones_like(y_sample)
            first_grad = torch.autograd.grad(
                outputs=y_sample,
                inputs=X_sample,
                grad_outputs=grad_outputs,
                create_graph=True,
                retain_graph=True,
                only_inputs=True
            )[0]
            
            gradient_loss = torch.mean(torch.sum(first_grad**2, dim=1))
            
            if torch.isnan(gradient_loss) or torch.isinf(gradient_loss):
                return torch.tensor(0.0, device=self.device)
            
            return gradient_loss
            
        except Exception as e:
            print(f"Error in pressure gradient loss computation: {e}")
            return torch.tensor(0.0, device=self.device)
    
    def compute_boundary_loss(self, y_pred):
        """Compute boundary condition loss."""
        try:
            # Enforce minimum pressure constraint
            min_pressure_scaled = self.output_scaler.transform([[self.min_pressure_sink]])[0, 0]
            min_pressure_tensor = torch.tensor(min_pressure_scaled, device=self.device)
            
            boundary_loss = torch.mean(torch.relu(min_pressure_tensor - y_pred))
            return boundary_loss
            
        except Exception as e:
            print(f"Error in boundary loss computation: {e}")
            return torch.tensor(0.0, device=self.device)


def main_training_pipeline(data_df, input_cols, output_cols, 
                          junctions=None, data_weight=1.0, physics_weight=0.0, 
                          junction_physics_weight=0.0, min_pressure_sink=36.0,
                          pressure_continuity_weight=1.0, mass_conservation_weight=1.0,
                          num_epochs=50, hidden_layers=None, dropout_rate=0.1,
                          learning_rate=1e-3, lr_scheduler_patience=10, 
                          early_stopping=None, lr_scheduler_factor=0.5,
                          batch_size=64, pressure_activation="tanh",
                          field_smoothness_weight=0.0,
                          hidden_activation="silu", architecture_type="standard",
                          kan_implementation="simple_enhanced",
                          fourier_features=16, sigma=1.0, num_scenarios=None,
                          warmup_physics=10, warmup_junction=10,
                          mode_scheduler='linear', train_validation_split=0.75,
                          use_pressure_gradient=False, pressure_gradient_weight=0.5,
                          pressure_gradient_sample_rate=1.0, use_mixed_precision=True,
                          num_workers=0, device=None, seed=42, verbose_junctions=False,
                          full_junction_penalty_every_batches=0, full_junction_penalty_every_epochs=5):
                          
    """
    Enhanced main pipeline for training a physics-informed neural network
    with improved physics loss validation.
    """
    
    # Set seed for reproducibility
    set_seed(seed)
    
    # Validate physics weights
    if physics_weight <= 0:
        print("WARNING: physics_weight is zero or negative. Physics loss will not contribute to training.")
    if junction_physics_weight <= 0:
        print("WARNING: junction_physics_weight is zero or negative. Junction physics loss will not contribute to training.")
    
    # Get device
    if isinstance(device, str):
        device = torch.device(device)
    device = get_device(force_cuda=True, requested_device=device if isinstance(device, str) else None)
    print(f"Using device: {device}")
    
    # Get all scenarios
    all_scenarios = sorted(data_df["scenario"].unique())
    if num_scenarios is not None:
        all_scenarios = all_scenarios[:num_scenarios]
    
    # Split into training and validation sets
    train_cutoff = int(train_validation_split * len(all_scenarios))
    train_scenarios = all_scenarios[:train_cutoff]
    val_scenarios = all_scenarios[train_cutoff:]
    
    print(f"Training on {len(train_scenarios)} scenarios, validating on {len(val_scenarios)} scenarios")
    
    # Enhanced data preparation with proper scaling
    X = data_df[input_cols].values
    y = data_df[output_cols].values
    
    # Scaling - Use MinMaxScaler to get data_min_ and data_max_ attributes
    X_scaler = MinMaxScaler()
    y_scaler = MinMaxScaler()
    
    X_scaled = X_scaler.fit_transform(X)
    y_scaled = y_scaler.fit_transform(y)

    # Keep full tensors available for junction breakdown fallback (keep on CPU)
    try:
        full_X_tensor = torch.FloatTensor(X_scaled)
    except Exception:
        full_X_tensor = None
    
    # Train-validation split (preserve original row indices)
    row_indices = np.arange(len(data_df))
    X_train, X_val, y_train, y_val, idx_train, idx_val = train_test_split(
        X_scaled, y_scaled, row_indices, test_size=1-train_validation_split, random_state=seed
    )
    
    # Convert to tensors (include original row indices for junction mapping)
    # Keep dataset tensors on CPU so DataLoader workers don't trigger CUDA in subprocesses
    X_train_tensor = torch.FloatTensor(X_train)
    y_train_tensor = torch.FloatTensor(y_train)
    idx_train_tensor = torch.LongTensor(idx_train)
    X_val_tensor = torch.FloatTensor(X_val)
    y_val_tensor = torch.FloatTensor(y_val)
    idx_val_tensor = torch.LongTensor(idx_val)
    
    # Create data loaders
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor, idx_train_tensor)
    val_dataset = TensorDataset(X_val_tensor, y_val_tensor, idx_val_tensor)
    
    # Use pin_memory when using CUDA to speed host->device transfers
    try:
        pin_memory_flag = True if device.type == 'cuda' else False
    except Exception:
        pin_memory_flag = False
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers, pin_memory=pin_memory_flag)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers, pin_memory=pin_memory_flag)
    
    # Create model
    # Ensure sensible defaults for hidden_layers
    if hidden_layers is None:
        hidden_layers = [64, 64]

    if architecture_type == 'kan':
        model = create_kan_model(
            n_input=len(input_cols), 
            n_output=len(output_cols),
            hidden_width=hidden_layers[0] if hidden_layers else 32,
            num_layers=len(hidden_layers) if hidden_layers else 2,
            pressure_activation=pressure_activation,
            kan_implementation=kan_implementation
        )   
    elif architecture_type == 'default':
        model = Surrogate_PINN(
            n_input=len(input_cols),
            n_output=len(output_cols),
            hidden_layers=hidden_layers,
            hidden_activation=hidden_activation,
            pressure_activation=pressure_activation,
            weight_norm=False,
            dropout_rate=dropout_rate
        )
    else:
        model = create_pinn_model(
            architecture_type=architecture_type,
            input_dim=len(input_cols),
            output_dim=len(output_cols),
            hidden_layers=hidden_layers,
            dropout_rate=dropout_rate,
            pressure_activation=pressure_activation,
            hidden_activation=hidden_activation,
            fourier_features=fourier_features if 'fourier' in architecture_type.lower() else None,
            sigma=sigma if 'fourier' in architecture_type.lower() else None
        )
    
    model = model.to(device)
    print(f"Using architecture: {architecture_type}")
    
    # Enhanced physics loss with validation
    loss_fn = EnhancedPhysicsLoss(
        junctions=junctions,
        min_pressure_sink=min_pressure_sink,
        pressure_continuity_weight=pressure_continuity_weight,
        mass_conservation_weight=mass_conservation_weight,
        device=device,
        input_scaler=X_scaler,
        output_scaler=y_scaler
    )
    # Provide train_node_ids mapping from data_df so junction_loss can map batch rows -> node ids
    try:
        if 'node_id' in data_df.columns:
            node_ids = data_df['node_id'].astype(str).str.strip().values
        elif 'BranchEquipment' in data_df.columns and 'NodeNumber' in data_df.columns:
            node_ids = (data_df['BranchEquipment'].astype(str).str.strip() + '_' + data_df['NodeNumber'].astype(str)).values
        else:
            # Fallback to using row indices as node ids (stringified)
            node_ids = np.arange(len(data_df)).astype(str)

        # Store full node ids and also the train-only subset aligned with X_train_tensor
        full_to_train_pos = np.full(len(data_df), -1, dtype=int)
        for pos, orig_idx in enumerate(idx_train):
            full_to_train_pos[orig_idx] = pos

        node_ids_train = node_ids[idx_train]
        loss_fn.train_node_ids = node_ids_train
        # Build a fast mapping from train node_id -> list of train positions to avoid O(N) scans
        try:
            train_nodeid_to_positions = {}
            for pos, nid in enumerate(node_ids_train):
                train_nodeid_to_positions.setdefault(str(nid), []).append(pos)
            loss_fn.train_nodeid_to_positions = train_nodeid_to_positions
        except Exception:
            loss_fn.train_nodeid_to_positions = None
        # Prebuild junction node lists and node->junctions reverse map for fast lookup
        try:
            junction_node_ids_list = []
            nodeid_to_junctions = {}
            if junctions is not None:
                for j_idx, j in enumerate(junctions):
                    jnids = [str(x).strip() for x in j.get('node_ids', j.get('nodes', []))]
                    junction_node_ids_list.append(jnids)
                    for nid in jnids:
                        nodeid_to_junctions.setdefault(str(nid), set()).add(j_idx)
            loss_fn.junction_node_ids_list = junction_node_ids_list
            loss_fn.nodeid_to_junctions = nodeid_to_junctions
        except Exception:
            loss_fn.junction_node_ids_list = None
            loss_fn.nodeid_to_junctions = None
        loss_fn.full_to_train_pos = full_to_train_pos
        # attach full dataset tensors and node ids for breakdown fallback
        try:
            loss_fn.full_X_tensor = full_X_tensor
            loss_fn.full_node_ids = node_ids
        except Exception:
            loss_fn.full_X_tensor = None
            loss_fn.full_node_ids = None
    except Exception:
        loss_fn.train_node_ids = None
        loss_fn.full_to_train_pos = None

    # Store train inputs tensor so junction loss can evaluate model on specific nodes
    try:
        loss_fn.train_X_tensor = X_train_tensor
    except Exception:
        loss_fn.train_X_tensor = None
    
    # Optimizer and scheduler
    # Use AdamW by default; if mixed precision disabled keep Adam as a fallback
    if use_mixed_precision and torch.cuda.is_available():
        optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=1e-5)
        scaler = torch.cuda.amp.GradScaler()
    else:
        optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=1e-5)
        scaler = None
        if use_mixed_precision and not torch.cuda.is_available():
            print("⚠️  Mixed precision requested but CUDA not available - falling back to FP32")
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=lr_scheduler_factor, patience=lr_scheduler_patience, verbose=True
    )
    
    # Training history
    history = {
        'train_loss': [], 'val_loss': [], 'data_loss': [], 'physics_loss': [], 
        'junction_loss': [], 'pressure_gradient_loss': [], 'lr': []
    }
    
    best_val_loss = float('inf')
    patience_counter = 0
    
    print(f"Starting enhanced training for {num_epochs} epochs...")
    print(f"Physics weight: {physics_weight}, Junction weight: {junction_physics_weight}")
    
    for epoch in range(num_epochs):
        model.train()
        train_loss_epoch = 0
        data_loss_epoch = 0
        physics_loss_epoch = 0
        junction_loss_epoch = 0
        pressure_grad_loss_epoch = 0
        
        # Dynamic weight scheduling
        current_data_weight = data_weight
        current_physics_weight = get_physics_weight(epoch, physics_weight, warmup_physics, mode_scheduler)
        current_junction_weight = get_physics_weight(epoch, junction_physics_weight, warmup_junction, mode_scheduler)
        
        for batch_idx, (X_batch, y_batch, batch_idx_tensor) in enumerate(train_loader):
            optimizer.zero_grad()
            # Forward/backward pass with optional AMP
            # Move batch to device (tensors kept on CPU to allow num_workers>0)
            # Use non_blocking transfer when pin_memory is enabled
            X_batch = X_batch.to(device, non_blocking=True)
            y_batch = y_batch.to(device, non_blocking=True)

            if scaler is not None:
                with torch.amp.autocast('cuda'):
                    y_pred = model(X_batch)
                    loss_components = loss_fn.compute_enhanced_loss(
                        model, X_batch, y_batch, y_pred,
                        current_data_weight, current_physics_weight, current_junction_weight,
                        use_pressure_gradient, pressure_gradient_weight, pressure_gradient_sample_rate,
                        epoch,
                        batch_row_indices=batch_idx_tensor
                    )
                    total_loss = loss_components['total_loss']
                scaler.scale(total_loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                scaler.step(optimizer)
                scaler.update()
            else:
                # Forward pass
                y_pred = model(X_batch)

                # Compute enhanced physics loss with validation
                loss_components = loss_fn.compute_enhanced_loss(
                    model, X_batch, y_batch, y_pred,
                    current_data_weight, current_physics_weight, current_junction_weight,
                    use_pressure_gradient, pressure_gradient_weight, pressure_gradient_sample_rate,
                    epoch,
                    batch_row_indices=batch_idx_tensor
                )

                total_loss = loss_components['total_loss']

                # Backward pass
                total_loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
            # Periodic full-dataset junction penalty (every N batches)
            if full_junction_penalty_every_batches and full_junction_penalty_every_batches > 0:
                if (batch_idx + 1) % full_junction_penalty_every_batches == 0:
                    model.train()
                    full_junc_loss = loss_fn.compute_full_junction_loss(model)
                    if full_junc_loss is not None and full_junc_loss.item() > 0:
                        # Scale the full-dataset junction penalty and backpropagate
                        penalty = (junction_physics_weight * full_junc_loss)
                        if scaler is not None:
                            scaler.scale(penalty).backward()
                            scaler.unscale_(optimizer)
                            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                            scaler.step(optimizer)
                            scaler.update()
                        else:
                            penalty.backward()
                            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                            optimizer.step()
            
            # Accumulate losses
            train_loss_epoch += total_loss.item()
            data_loss_epoch += loss_components['data_loss'].item()
            physics_loss_epoch += loss_components['physics_loss'].item()
            junction_loss_epoch += loss_components['junction_loss'].item()
            if 'pressure_gradient_loss' in loss_components:
                pressure_grad_loss_epoch += loss_components['pressure_gradient_loss'].item()
        
        # Validation
        model.eval()
        val_loss_epoch = 0
        with torch.no_grad():
            for X_batch, y_batch, val_idx_tensor in val_loader:
                # move to device for evaluation
                Xb = X_batch.to(device)
                yb = y_batch.to(device)
                y_pred = model(Xb)
                val_loss = nn.MSELoss()(y_pred, yb)
                val_loss_epoch += val_loss.item()
        
        # Average losses
        train_loss_avg = train_loss_epoch / len(train_loader)
        val_loss_avg = val_loss_epoch / len(val_loader)
        data_loss_avg = data_loss_epoch / len(train_loader)
        physics_loss_avg = physics_loss_epoch / len(train_loader)
        # Compute epoch-level junction loss: prefer full-dataset breakdown average if available
        try:
            breakdown = loss_fn.compute_junction_breakdown(model)
            if breakdown:
                # breakdown is list of (junction_id, val)
                junction_vals = [v for (_jid, v) in breakdown]
                junction_loss_avg = float(np.mean(junction_vals))
            else:
                junction_loss_avg = junction_loss_epoch / len(train_loader)
        except Exception:
            junction_loss_avg = junction_loss_epoch / len(train_loader)
        pressure_grad_loss_avg = pressure_grad_loss_epoch / len(train_loader)
        
        # Update history
        history['train_loss'].append(train_loss_avg)
        history['val_loss'].append(val_loss_avg)
        history['data_loss'].append(data_loss_avg)
        history['physics_loss'].append(physics_loss_avg)
        history['junction_loss'].append(junction_loss_avg)
        history['pressure_gradient_loss'].append(pressure_grad_loss_avg)
        history['lr'].append(optimizer.param_groups[0]['lr'])
        
        # Scheduler step
        scheduler.step(val_loss_avg)
        
        # Early stopping
        if val_loss_avg < best_val_loss:
            best_val_loss = val_loss_avg
            patience_counter = 0
        else:
            patience_counter += 1
            
        if early_stopping and patience_counter >= early_stopping:
            print(f"Early stopping at epoch {epoch+1}")
            break
        
        # Logging
        if epoch % 10 == 0 or epoch < 10:
            log_msg = (
                f"Epoch {epoch+1}/{num_epochs} - "
                f"Train Loss: {train_loss_avg:.6f}, "
                f"Val Loss: {val_loss_avg:.6f}, "
                f"Data: {data_loss_avg:.6f}, "
                f"Physics: {physics_loss_avg:.6f}, "
                f"Junction: {junction_loss_avg:.6f}, "
                f"PressGrad: {pressure_grad_loss_avg:.6f}, "
                f"LR: {optimizer.param_groups[0]['lr']:.2e}"
            )
            print(log_msg)
            # Verbose per-junction breakdown (high-precision)
            if verbose_junctions:
                breakdown = loss_fn.compute_junction_breakdown(model)
                if breakdown:
                    print("Per-junction continuity residuals (train set):")
                    for jid, val in breakdown:
                        try:
                            print(f"  Junction {jid}: {val:.10f}")
                        except Exception:
                            print(f"  Junction {jid}: {val}")
                else:
                    print("Per-junction breakdown: no data available or insufficient nodes per junction.")

        # Periodic full-dataset junction penalty at epoch end
        if full_junction_penalty_every_epochs and full_junction_penalty_every_epochs > 0:
            if (epoch + 1) % full_junction_penalty_every_epochs == 0:
                model.train()
                full_junc_loss = loss_fn.compute_full_junction_loss(model)
                if full_junc_loss is not None and full_junc_loss.item() > 0:
                    penalty = (junction_physics_weight * full_junc_loss)
                    if scaler is not None:
                        scaler.scale(penalty).backward()
                        scaler.unscale_(optimizer)
                        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                        scaler.step(optimizer)
                        scaler.update()
                    else:
                        penalty.backward()
                        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                        optimizer.step()
    
    # Return the trained model, history, and scaling parameters  
    input_min = torch.tensor(X_scaler.data_min_, dtype=torch.float32)
    input_max = torch.tensor(X_scaler.data_max_, dtype=torch.float32)
    output_min = torch.tensor(y_scaler.data_min_, dtype=torch.float32)
    output_max = torch.tensor(y_scaler.data_max_, dtype=torch.float32)
    
    # Convert history to expected format for plotting
    formatted_history = {
        'train': {
            'total_loss': history['train_loss'],
            'data_loss': history['data_loss'],
            'physics_loss': history['physics_loss'],
            'boundary_loss': history['physics_loss'],  # Use physics_loss as boundary_loss
            'pressure_continuity_loss': history['junction_loss'],
            'mass_conservation_loss': history['junction_loss'],
        },
        'val': {
            'total_loss': history['val_loss'],
            'data_loss': history['data_loss'],  # Use same data_loss for val
            'physics_loss': history['physics_loss'],  # Use same physics_loss for val
            'pressure_continuity_loss': history['junction_loss'],
            'mass_conservation_loss': history['junction_loss'],
        }
    }
    
    return model, formatted_history, (input_min, input_max, output_min, output_max)