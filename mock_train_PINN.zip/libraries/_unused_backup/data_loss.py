import torch
import numpy as np
from libraries.memory_utils import get_device

def compute_data_loss(model, batch_data, input_cols, output_cols, 
                     input_min, input_max, output_min, output_max,
                     output_weights=None, use_huber_loss=True, huber_delta=1.0,
                     source_node_type=1, use_pressure_gradient=False,
                     pressure_gradient_weight=1.0, pressure_gradient_sample_rate=1.0,
                     device=None):
    """
    Compute the data-driven loss component - comparing model predictions with ground truth.
    
    Parameters:
        model (nn.Module): Neural network model
        batch_data (list): List of dataframes, one per scenario
        input_cols (list): List of input column names
        output_cols (list): List of output column names
        input_min, input_max (array): Min/max values for input scaling
        output_min, output_max (array): Min/max values for output scaling
        output_weights (dict or None): Dictionary mapping output column names to their weights
                                      (default: None = equal weights)
        use_huber_loss (bool): Whether to use Huber loss instead of MSE (default: True)
        huber_delta (float): Delta parameter for Huber loss (default: 1.0)
        source_node_type (int): Node type identifier for sources
        use_pressure_gradient (bool): Whether to include pressure gradient loss (default: False)
        pressure_gradient_weight (float): Weight for pressure gradient loss component (default: 1.0)
        pressure_gradient_sample_rate (float): Fraction of flowlines to process for gradient (0.0-1.0)
        device (torch.device): Computation device
        
    Returns:
        torch.Tensor: Data loss tensor
    """
    if device is None:
        device = get_device(force_cuda=True)
    batch_size = len(batch_data)
    
    if batch_size == 0:
        return torch.tensor(0.0, device=device)
    
    # Create tensors for scaling
    input_min_tensor = torch.tensor(input_min, dtype=torch.float32, device=device)
    input_max_tensor = torch.tensor(input_max, dtype=torch.float32, device=device)
    min_vals_tensor = torch.tensor(output_min, device=device, dtype=torch.float32)
    max_vals_tensor = torch.tensor(output_max, device=device, dtype=torch.float32)
    
    # Get activation types - handle missing attribute safely
    activation_types = model.get_activation_types() if hasattr(model, 'get_activation_types') else {
        "pressure": "tanh", 
        "mass_flow": "tanh"
    }
    
    # Set up output weights - ensure it's a dictionary
    if output_weights is None or not isinstance(output_weights, dict):
        # Create equal weights if None or not a dictionary
        output_weights = {col: 1.0 for col in output_cols}
    
    # Initialize loss values
    batch_data_loss = 0.0
    node_count = 0
    batch_gradient_loss = 0.0
    gradient_count = 0
    
    # Huber loss function
    def huber_loss(pred, target, delta=huber_delta):
        abs_diff = torch.abs(pred - target)
        quadratic = torch.min(abs_diff, torch.tensor(delta, device=pred.device))
        linear = abs_diff - quadratic
        return torch.mean(0.5 * quadratic**2 + delta * linear)
    
    # Process each scenario in the batch for data loss
    for scenario_data in batch_data:
        scenario_data = scenario_data.reset_index(drop=True)
        
        # Prepare inputs and indices for each node
        all_inputs = []
        all_indices = []
        
        for idx, node in scenario_data.iterrows():
            input_values = [float(node.get(col, 0.0)) for col in input_cols]
            all_inputs.append(input_values)
            all_indices.append(idx)
            node_count += 1
        
        # Convert to tensor and scale to [0,1]
        if all_inputs:
            inputs_tensor = torch.tensor(all_inputs, dtype=torch.float32, device=device)
            scaled_inputs = (inputs_tensor - input_min_tensor) / (input_max_tensor - input_min_tensor + 1e-8)
            
            # Get predictions
            preds = model(scaled_inputs)
            
            # Get ground truth values for nodes
            true_vals = []
            for idx in all_indices:
                node_outputs = [float(scenario_data.loc[idx, col]) for col in output_cols]
                true_vals.append(node_outputs)
            true_vals_tensor = torch.tensor(true_vals, dtype=torch.float32, device=device)
            
            # Unscale predictions for physical comparison
            if all(act_type == "tanh" for act_type in activation_types.values()):
                physical_preds = ((preds + 1) / 2) * (max_vals_tensor - min_vals_tensor) + min_vals_tensor
            else:
                physical_preds = torch.zeros_like(preds)
                for i, col in enumerate(output_cols):
                    act_type = activation_types.get("pressure", "tanh") if col == "Pressure" else "tanh"
                    if act_type == "tanh":
                        normalized = (preds[:, i] + 1) / 2
                        physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
                    elif act_type == "silu":
                        normalized = torch.clamp(preds[:, i], 0.0, 1.0)
                        physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
                    elif act_type == "linear":
                        normalized = torch.sigmoid(preds[:, i])
                        physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
            
            # Scale ground truth for tanh comparison
            true_scaled = torch.zeros_like(true_vals_tensor)
            for i, col in enumerate(output_cols):
                uses_tanh = True
                if col == "Pressure" and activation_types.get("pressure") != "tanh":
                    uses_tanh = False
                if uses_tanh:
                    true_scaled[:, i] = (true_vals_tensor[:, i] - min_vals_tensor[i]) / (max_vals_tensor[i] - min_vals_tensor[i] + 1e-8)
                    true_scaled[:, i] = 2 * true_scaled[:, i] - 1
            # Calculate loss for each output column with weights
            data_loss = torch.tensor(0.0, device=device)
            total_weight = 0.0
            
            for i, col in enumerate(output_cols):
                col_weight = output_weights.get(col, 1.0)
                total_weight += col_weight
                if col == "Pressure" and activation_types.get("pressure") != "tanh":
                    if use_huber_loss:
                        col_loss = huber_loss(physical_preds[:, i], true_vals_tensor[:, i])
                    else:
                        col_loss = torch.mean((physical_preds[:, i] - true_vals_tensor[:, i]) ** 2)
                    data_loss += col_weight * col_loss
                else:
                    if use_huber_loss:
                        col_loss = huber_loss(preds[:, i], true_scaled[:, i])
                    else:
                        col_loss = torch.mean((preds[:, i] - true_scaled[:, i]) ** 2)
                    data_loss += col_weight * col_loss
            
            if total_weight > 0:
                data_loss /= total_weight
            batch_data_loss += data_loss
        
        # If pressure gradient loss is enabled and Pressure is in outputs
        if use_pressure_gradient and "Pressure" in output_cols:
            pressure_idx = output_cols.index("Pressure")
            
            all_flowlines = scenario_data["BranchEquipment"].unique()
            num_flowlines_to_process = max(1, int(len(all_flowlines) * pressure_gradient_sample_rate))
            if len(all_flowlines) > num_flowlines_to_process:
                sampled_flowlines = np.random.choice(all_flowlines, size=num_flowlines_to_process, replace=False)
            else:
                sampled_flowlines = all_flowlines
            
            # Process each selected flowline
            for flowline_id in sampled_flowlines:
                flowline_data = scenario_data[scenario_data["BranchEquipment"] == flowline_id]
                if len(flowline_data) < 2:
                    continue
                flowline_data = flowline_data.sort_values(by="TotalDistance")
                
                fl_inputs = []
                fl_indices = []
                for idx, node in flowline_data.iterrows():
                    input_values = [float(node.get(col, 0.0)) for col in input_cols]
                    fl_inputs.append(input_values)
                    fl_indices.append(idx)
                
                if not fl_inputs:
                    continue
                inputs_tensor = torch.tensor(fl_inputs, dtype=torch.float32, device=device)
                scaled_inputs = (inputs_tensor - input_min_tensor) / (input_max_tensor - input_min_tensor + 1e-8)
                
                fl_preds = model(scaled_inputs)
                fl_physical_preds = torch.zeros_like(fl_preds, device=device)
                for i, col in enumerate(output_cols):
                    act_type = "tanh"  # Default activation
                    if col == "Pressure" and "pressure" in activation_types:
                        act_type = activation_types["pressure"]
                    if act_type == "tanh":
                        normalized = (fl_preds[:, i] + 1) / 2
                        fl_physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
                    elif act_type == "silu":
                        normalized = torch.clamp(fl_preds[:, i], 0.0, 1.0)
                        fl_physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
                    elif act_type == "linear":
                        normalized = torch.sigmoid(fl_preds[:, i])
                        fl_physical_preds[:, i] = normalized * (max_vals_tensor[i] - min_vals_tensor[i]) + min_vals_tensor[i]
                
                true_pressures = []
                distances = []
                for idx in fl_indices:
                    true_pressures.append(float(scenario_data.loc[idx, "Pressure"]))
                    distances.append(float(scenario_data.loc[idx, "TotalDistance"]))
                if len(true_pressures) < 2:
                    continue
                
                # Vectorized gradient computation
                true_pressures_tensor = torch.tensor(true_pressures, dtype=torch.float32, device=device)
                distances_tensor = torch.tensor(distances, dtype=torch.float32, device=device)
                dist_diffs = distances_tensor[1:] - distances_tensor[:-1]
                mask = dist_diffs > 0.1
                if mask.sum() > 0:
                    true_gradients_tensor = (true_pressures_tensor[1:] - true_pressures_tensor[:-1])[mask] / dist_diffs[mask]
                    pred_pressures = fl_physical_preds[:, pressure_idx]
                    pred_gradients_tensor = (pred_pressures[1:] - pred_pressures[:-1])[mask] / dist_diffs[mask]
                    
                    if use_huber_loss:
                        gradient_loss = huber_loss(pred_gradients_tensor, true_gradients_tensor, huber_delta)
                    else:
                        gradient_loss = torch.mean((pred_gradients_tensor - true_gradients_tensor) ** 2)
                    
                    batch_gradient_loss += gradient_loss
                    gradient_count += 1
    
    if batch_size > 0:
        batch_data_loss /= batch_size
    
    if gradient_count > 0 and use_pressure_gradient:
        avg_gradient_loss = batch_gradient_loss / gradient_count
        batch_data_loss = batch_data_loss + pressure_gradient_weight * avg_gradient_loss
    
    return batch_data_loss