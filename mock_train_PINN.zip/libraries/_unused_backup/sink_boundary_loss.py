import torch
import torch.nn.functional as F_loss
import numpy as np
from libraries.memory_utils import get_device


def compute_sink_boundary_loss(model, batch_data, input_cols, output_cols, 
                              input_min, input_max, output_min, output_max,
                              sink_node_type=-1, min_pressure_sink=36, 
                              device=None, return_details=False):
    """
    Target-anchored boundary constraint at sink nodes.
    
    Two components:
    1. **Target anchor** (SmoothL1): drives predicted sink pressure toward the
       actual measured sink pressure from the scenario data.  This is the primary
       term and directly fixes overestimation.
    2. **Floor penalty** (softplus): one-sided penalty if predicted pressure
       drops below `min_pressure_sink`.  Acts as a safety net only.
    
    The target anchor uses the 'Pressure' column from the scenario DataFrame for
    each sink node as ground truth.  SmoothL1 (Huber) is used for robustness to
    occasional outlier scenarios while maintaining strong gradients near the target.
    
    Combined loss = anchor_loss + 0.1 * floor_penalty
    """
    if device is None:
        device = get_device(force_cuda=True)
        
    # Initialize loss
    boundary_loss = torch.tensor(0.0, device=device, requires_grad=True)
    anchor_sum = torch.tensor(0.0, device=device)
    floor_sum = torch.tensor(0.0, device=device)
    sink_count = 0
    sink_violations = 0
    
    # Get activation types
    activation_types = model.get_activation_types() if hasattr(model, 'get_activation_types') else {
        "pressure": "tanh", 
        "mass_flow": "tanh"
    }
    
    # Create tensors for scaling
    input_min_tensor = torch.tensor(input_min, dtype=torch.float32, device=device)
    input_max_tensor = torch.tensor(input_max, dtype=torch.float32, device=device)
    output_min_tensor = torch.tensor(output_min, dtype=torch.float32, device=device)
    output_max_tensor = torch.tensor(output_max, dtype=torch.float32, device=device)

    # Pressure range for normalization
    pressure_idx = output_cols.index('Pressure')
    p_range = output_max_tensor[pressure_idx] - output_min_tensor[pressure_idx] + 1e-8
    # Floor target in normalized [0,1] space
    min_pressure_norm = (min_pressure_sink - output_min_tensor[pressure_idx].item()) / p_range.item()

    # Sharpness for the floor softplus penalty
    SHARPNESS = 20.0
    # Relative weight of floor penalty vs anchor loss
    FLOOR_WEIGHT = 0.1
    
    # Process each scenario in the batch — vectorized over all sink nodes per scenario
    for scenario_idx, scenario_data in enumerate(batch_data):
        # Explicitly filter for sink nodes
        sink_nodes = scenario_data[scenario_data['node_type'] == sink_node_type]
        n_sinks = len(sink_nodes)
        sink_count += n_sinks
        
        if n_sinks == 0:
            print(f"WARNING: No sink nodes found in batch scenario {scenario_idx}!")
            continue

        # Vectorized: build (n_sinks, n_features) tensor in one go
        input_np = sink_nodes[input_cols].values.astype(np.float32)
        input_tensor = torch.tensor(input_np, device=device)
        scaled_input = 2.0 * (input_tensor - input_min_tensor) / (input_max_tensor - input_min_tensor + 1e-8) - 1.0

        # Batch prediction
        pred = model(scaled_input)            # (n_sinks, n_outputs)

        # Unscale to [0,1] normalized space
        act_type = activation_types.get("pressure", "tanh")
        if act_type == "tanh":
            pred_norm = (pred[:, pressure_idx] + 1) / 2          # [0, 1]
        elif act_type == "silu":
            pred_norm = torch.clamp(pred[:, pressure_idx], 0.0, 1.0)
        elif act_type == "linear":
            pred_norm = torch.sigmoid(pred[:, pressure_idx])
        else:
            pred_norm = (pred[:, pressure_idx] + 1) / 2

        # --- Component 1: Target anchor (SmoothL1 toward measured sink pressure) ---
        # Read actual measured pressure from the scenario DataFrame
        actual_pressure = sink_nodes['Pressure'].values.astype(np.float32)
        actual_norm = torch.tensor(
            (actual_pressure - output_min_tensor[pressure_idx].item()) / p_range.item(),
            device=device
        )
        anchor_loss = F_loss.smooth_l1_loss(pred_norm, actual_norm, reduction='sum')

        # --- Component 2: Floor penalty (softplus, safety net only) ---
        gap = min_pressure_norm - pred_norm
        floor_penalty = torch.nn.functional.softplus(gap * SHARPNESS) / SHARPNESS

        floor_component = floor_penalty.sum()
        sink_violations += int((gap > 0).sum().item())

        anchor_sum = anchor_sum + anchor_loss
        floor_sum = floor_sum + floor_component
        boundary_loss = boundary_loss + anchor_loss + FLOOR_WEIGHT * floor_component
    
    # Print diagnostics
    anchor_avg = torch.tensor(0.0, device=device)
    floor_avg = torch.tensor(0.0, device=device)

    if sink_count > 0:
        print(f"Found {sink_count} sink nodes, {sink_violations} with pressure below minimum")
        boundary_loss = boundary_loss / sink_count
        anchor_avg = anchor_sum / sink_count
        floor_avg = floor_sum / sink_count
    else:
        print("WARNING: No sink nodes found in entire batch!")

    if return_details:
        details = {
            "anchor_loss": float(anchor_avg.item()),
            "floor_penalty_loss": float(floor_avg.item()),
            "sink_violations": int(sink_violations),
            "sink_count": int(sink_count),
        }
        return boundary_loss, details

    return boundary_loss


def compute_source_boundary_loss(model, batch_data, input_cols, output_cols,
                                 input_min, input_max, output_min, output_max,
                                 source_node_type=1, device=None):
    """
    Target-anchored boundary constraint at source nodes.

    Drives predicted source pressure toward the actual measured source pressure
    from the scenario data using SmoothL1 loss in [0,1] normalized space.
    Analogous to compute_sink_boundary_loss but without a floor penalty
    (source pressures are typically high, no minimum constraint needed).
    """
    if device is None:
        device = get_device(force_cuda=True)

    boundary_loss = torch.tensor(0.0, device=device, requires_grad=True)
    source_count = 0

    # Get activation types
    activation_types = model.get_activation_types() if hasattr(model, 'get_activation_types') else {
        "pressure": "tanh",
        "mass_flow": "tanh"
    }

    # Create tensors for scaling
    input_min_tensor = torch.tensor(input_min, dtype=torch.float32, device=device)
    input_max_tensor = torch.tensor(input_max, dtype=torch.float32, device=device)
    output_min_tensor = torch.tensor(output_min, dtype=torch.float32, device=device)
    output_max_tensor = torch.tensor(output_max, dtype=torch.float32, device=device)

    pressure_idx = output_cols.index('Pressure')
    p_range = output_max_tensor[pressure_idx] - output_min_tensor[pressure_idx] + 1e-8

    for scenario_idx, scenario_data in enumerate(batch_data):
        source_nodes = scenario_data[scenario_data['node_type'] == source_node_type]
        n_sources = len(source_nodes)
        source_count += n_sources

        if n_sources == 0:
            continue

        # Vectorized: build (n_sources, n_features) tensor
        input_np = source_nodes[input_cols].values.astype(np.float32)
        input_tensor = torch.tensor(input_np, device=device)
        scaled_input = 2.0 * (input_tensor - input_min_tensor) / (input_max_tensor - input_min_tensor + 1e-8) - 1.0

        pred = model(scaled_input)

        # Unscale to [0,1] normalized space
        act_type = activation_types.get("pressure", "tanh")
        if act_type == "tanh":
            pred_norm = (pred[:, pressure_idx] + 1) / 2
        elif act_type == "silu":
            pred_norm = torch.clamp(pred[:, pressure_idx], 0.0, 1.0)
        else:
            pred_norm = (pred[:, pressure_idx] + 1) / 2

        # Target anchor: SmoothL1 toward measured source pressure
        actual_pressure = source_nodes['Pressure'].values.astype(np.float32)
        actual_norm = torch.tensor(
            (actual_pressure - output_min_tensor[pressure_idx].item()) / p_range.item(),
            device=device
        )
        anchor_loss = F_loss.smooth_l1_loss(pred_norm, actual_norm, reduction='sum')
        boundary_loss = boundary_loss + anchor_loss

    if source_count > 0:
        print(f"Found {source_count} source nodes")
        boundary_loss = boundary_loss / source_count
    else:
        print("WARNING: No source nodes found in entire batch!")

    return boundary_loss