"""
pikan_trainer.py — training + evaluation for the multi-trunk PI-KAN pressure surrogate.

Extracted from PINN_MultiTrunk_PI-KAN_2026.ipynb so the notebook stays a thin
orchestration layer. Scope is the ACTIVE pipeline only: a sink-anchored physics
backbone (hydrostatic + per-flowline friction) plus a PI-KAN that learns the
residual, trained data-only. The Phase-2 physics and Phase-3 L-BFGS stages were
empirically flat / no-op on this data and are intentionally NOT reproduced here.

Prediction convention used everywhere in this module:

    P_pred[psi] = output_scaler.inverse_transform(model(X))[:, pressure_index] + pbb

where `pbb` is the per-trunk backbone pressure aligned to the same rows as X.

Heavy third-party deps (torch, matplotlib, sklearn) are imported lazily inside the
functions that need them, so the pure-numpy reporting helpers can be imported and
used (and unit-tested) without a GPU/torch stack present.
"""
from __future__ import annotations

import numpy as np

# Pressure bins (psi) used by the absolute-accuracy table. Operationally the model
# locates overpressure, so the high bins are what matter; bias>0 = overprediction
# (false-alarm side), bias<0 = MISSED overpressure (the unsafe direction).
PRESSURE_BINS = [(0, 100), (100, 150), (150, 200), (200, 250), (250, 300), (300, 1e9)]


# ===========================================================================
#  MODEL
# ===========================================================================
def build_pikan(n_input, n_output, *, hidden_width=128, num_layers=4,
                pressure_activation="tanh", device=None, verbose=True):
    """Build the active PI-KAN (simple_enhanced KAN backbone) and move to device.

    Thin wrapper over libraries.pinn_models.create_kan_model so the notebook does
    not carry the inactive surrogate / FEKAN / FE-GNN branches. All outputs are
    MinMax[-1,1]-scaled, hence tanh on the pressure (and aux) heads.
    """
    try:
        from .pinn_models import create_kan_model
    except Exception:  # notebook adds LIB_DIR to sys.path -> `libraries` is a package
        from libraries.pinn_models import create_kan_model

    model = create_kan_model(
        n_input=n_input,
        n_output=n_output,
        hidden_width=hidden_width,
        num_layers=num_layers,
        pressure_activation=pressure_activation,
        kan_implementation="simple_enhanced",
    )
    if device is not None:
        model = model.to(device)
    if verbose:
        total = sum(p.numel() for p in model.parameters())
        trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f"PI-KAN built | width={hidden_width} x {num_layers} layers | "
              f"params={total:,} ({trainable:,} trainable) | in={n_input} out={n_output}")
    return model


# ===========================================================================
#  TRAINING  (Phase 1 — data only)
# ===========================================================================
def _recon_ratio(epoch, mode, start, end, ramp_epochs):
    """Two-stream curriculum: fraction of batches drawn from the reconstructed
    (deployment-aligned) input stream at a given epoch."""
    if mode == "actual":
        return 0.0
    if mode == "reconstructed":
        return 1.0
    denom = max(ramp_epochs - 1, 1)
    p = min(max(epoch / denom, 0.0), 1.0)
    return start + p * (end - start)


def train_data_phase(model, train_loader, X_val_t, y_val_t, *, loss_fn, device,
                     epochs=60, lr=1e-3, max_lr_mult=3.0, weight_decay=1e-4,
                     grad_clip=1.0, patience=30, seed=42,
                     training_input_mode="two_stream",
                     recon_ratio_start=0.5, recon_ratio_end=0.9,
                     recon_ramp_epochs=None, log_every=10, restore_best=True):
    """Data-only training with OneCycleLR (per-batch) + early stopping.

    `train_loader` must yield (X_actual, X_recon, y). Under "two_stream" the batch
    input is drawn from the reconstructed stream with probability `_recon_ratio`,
    which ramps start->end over `recon_ramp_epochs`. Validation uses X_val_t/y_val_t
    (already in the configured VAL_INPUT_MODE). The tail-aware `loss_fn` operates in
    scaled space on the residual target, exactly as in Phase 1 of the notebook.

    Restores the best-by-val weights into `model` before returning (this is done
    explicitly here; the old notebook relied on the removed L-BFGS cell to reload
    them). Returns {"history", "best_val_loss", "best_epoch"}.
    """
    import torch

    if recon_ramp_epochs is None:
        recon_ramp_epochs = epochs

    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    steps = max(len(train_loader), 1)
    sched = torch.optim.lr_scheduler.OneCycleLR(
        opt, max_lr=lr * max_lr_mult, epochs=epochs, steps_per_epoch=steps,
        pct_start=0.3, div_factor=10.0, final_div_factor=100.0)

    history = {"epoch": [], "train_loss": [], "val_loss": [], "lr": []}
    best = float("inf")
    best_state = None
    best_epoch = -1
    no_improve = 0

    print(f"Phase 1: data-only training, {epochs} epochs "
          f"(mode={training_input_mode}, patience={patience})")
    print("=" * 68)

    for epoch in range(epochs):
        model.train()
        running = 0.0
        nb = 0
        recon_batches = 0
        ratio = _recon_ratio(epoch, training_input_mode,
                             recon_ratio_start, recon_ratio_end, recon_ramp_epochs)
        rng = np.random.RandomState(seed + epoch)

        for xb_actual, xb_recon, yb in train_loader:
            xb_actual = xb_actual.to(device)
            xb_recon = xb_recon.to(device)
            yb = yb.to(device)

            if training_input_mode == "actual":
                xb = xb_actual
            elif training_input_mode == "reconstructed":
                xb = xb_recon
                recon_batches += 1
            else:  # two_stream
                use_recon = rng.rand() < ratio
                xb = xb_recon if use_recon else xb_actual
                recon_batches += int(use_recon)

            opt.zero_grad()
            loss = loss_fn(model(xb), yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=grad_clip)
            opt.step()
            sched.step()  # OneCycleLR steps per batch

            running += loss.item()
            nb += 1

        train_loss = running / max(nb, 1)
        model.eval()
        with torch.no_grad():
            val_loss = float(loss_fn(model(X_val_t), y_val_t).item())
        lr_now = opt.param_groups[0]["lr"]

        history["epoch"].append(epoch)
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["lr"].append(lr_now)

        if val_loss < best:
            best = val_loss
            best_epoch = epoch
            no_improve = 0
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
        else:
            no_improve += 1

        if log_every and ((epoch + 1) % log_every == 0 or epoch == 0):
            print(f"Epoch {epoch + 1:3d}/{epochs} | train {train_loss:.6f} | "
                  f"val {val_loss:.6f} | lr {lr_now:.2e} | "
                  f"recon {recon_batches / max(nb, 1):.2f}")

        if no_improve >= patience:
            print(f"\nEarly stop at epoch {epoch + 1}: "
                  f"no val improvement for {patience} epochs.")
            break

    if restore_best and best_state is not None:
        model.load_state_dict(best_state)
    print(f"\nPhase 1 complete. Best val loss {best:.6f} @ epoch {best_epoch + 1} "
          f"(best weights restored).")
    return {"history": history, "best_val_loss": best, "best_epoch": best_epoch}


# ===========================================================================
#  OPTIONAL PHYSICS FINE-TUNE  (junction pressure continuity + mass conservation)
# ===========================================================================
def train_physics_phase(model, train_loader, X_val_t, y_val_t, *, loss_fn, device,
                        scenario_dfs, junctions, input_cols, output_cols,
                        input_min, input_max, output_min, output_max,
                        epochs=30, lr=5e-4, patience=60, seed=42,
                        training_input_mode="two_stream",
                        recon_ratio_start=0.5, recon_ratio_end=0.9, recon_ramp_epochs=None,
                        global_epoch_offset=0, history=None,
                        use_continuity=True, use_mass=False,
                        continuity_weight=2.0, mass_weight=1.0,
                        junc_target_ratio=0.20, min_physics_weight=0.15,
                        physics_weight_max=10.0, warmup_epochs=20, ema_decay=0.95,
                        physics_every_n=20, physics_batch_size=15,
                        guardrail_mult=1.2, phase1_best_val=None,
                        weight_decay=1e-4, grad_clip=1.0, restore_best=True, log_every=10):
    """OPT-IN soft-physics fine-tune on top of the data-trained model.

    Continues training the Phase-1 model with a junction loss added to the data
    loss. `compute_junction_losses` (libraries.junction_loss) supplies BOTH terms;
    `use_continuity` / `use_mass` toggle them by zeroing the respective weight.

    Because the backbone is single-valued at each junction node, continuity on the
    residual == continuity on full pressure, so the junction loss is valid even
    though the pressure head now emits a residual. Mass conservation acts on the
    predicted MassFlowrate aux output (not residual-retargeted), so it is unaffected.

    The junction term is adaptively weighted: w_j = warmup * junc_target_ratio *
    EMA(data) / EMA(junction), floored at `min_physics_weight`, capped at
    `physics_weight_max`, and shrunk by a guardrail if val loss exceeds
    `guardrail_mult` x the Phase-1 best. `physics_every_n` controls physics cadence
    (a physics batch of `physics_batch_size` scenarios every N data batches).

    SAFETY: the best-weight tracker is seeded with `phase1_best_val`, so a physics
    epoch is only saved if it BEATS Phase 1. Combined with restore_best, if physics
    never helps, the returned model is exactly the Phase-1 best — this phase can
    never degrade the deliverable. Returns {"history","best_val_loss","best_epoch"}.
    """
    import torch
    try:
        from .junction_loss import compute_junction_losses
    except Exception:
        from libraries.junction_loss import compute_junction_losses

    pc_w = float(continuity_weight) if use_continuity else 0.0
    mc_w = float(mass_weight) if use_mass else 0.0
    if pc_w == 0.0 and mc_w == 0.0:
        print("train_physics_phase: both continuity and mass are OFF -> nothing to do. "
              "Skipping (model unchanged).")
        return {"history": history or {"epoch": [], "train_loss": [], "val_loss": [], "lr": []},
                "best_val_loss": phase1_best_val if phase1_best_val is not None else float("inf"),
                "best_epoch": -1}

    if recon_ramp_epochs is None:
        recon_ramp_epochs = global_epoch_offset + epochs
    if history is None:
        history = {"epoch": [], "train_loss": [], "val_loss": [], "lr": []}

    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(
        opt, mode="min", factor=0.5, patience=15, min_lr=1e-6)

    scenario_ids = list(scenario_dfs.keys())
    ema_data = None
    ema_junc = None
    best = phase1_best_val if phase1_best_val is not None else float("inf")
    best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
    best_epoch = -1
    no_improve = 0
    guard = 1.0

    print(f"Physics phase: {epochs} epochs | continuity={'ON' if use_continuity else 'off'}"
          f"(w={pc_w}) mass={'ON' if use_mass else 'off'}(w={mc_w}) | "
          f"junc_target_ratio={junc_target_ratio} | every {physics_every_n} batches x "
          f"{physics_batch_size} scenarios | patience={patience}")
    if phase1_best_val is not None:
        print(f"  Phase-1 best val {phase1_best_val:.6f} seeds the best tracker "
              f"(physics must beat it to be saved).")
    print("=" * 68)

    for epoch in range(epochs):
        gepoch = global_epoch_offset + epoch
        warmup = min(epoch / max(warmup_epochs, 1), 1.0)  # 0 on first epoch, matches original
        ratio = _recon_ratio(gepoch, training_input_mode,
                             recon_ratio_start, recon_ratio_end, recon_ramp_epochs)
        rng = np.random.RandomState(seed + gepoch)

        model.train()
        run_data = 0.0
        run_junc = 0.0
        nb = 0
        npb = 0
        w_j = 0.0
        for bi, (xb_a, xb_r, yb) in enumerate(train_loader):
            xb_a = xb_a.to(device)
            xb_r = xb_r.to(device)
            yb = yb.to(device)
            if training_input_mode == "actual":
                xb = xb_a
            elif training_input_mode == "reconstructed":
                xb = xb_r
            else:
                xb = xb_r if rng.rand() < ratio else xb_a

            opt.zero_grad()
            data_loss = loss_fn(model(xb), yb)
            d = data_loss.detach().item()
            ema_data = d if ema_data is None else ema_decay * ema_data + (1 - ema_decay) * d

            if bi % physics_every_n == 0:
                sids = rng.choice(scenario_ids,
                                  size=min(physics_batch_size, len(scenario_ids)),
                                  replace=False)
                batch_scen = [scenario_dfs[s] for s in sids]
                junction_loss, _jc = compute_junction_losses(
                    model, batch_scen, junctions, input_cols, output_cols,
                    input_min, input_max, output_min, output_max,
                    flowline_col="BranchEquipment", node_id_col="node_id",
                    x_col="long", y_col="lat", distance_col="TotalDistance",
                    source_node_type=1, tol=1e-6,
                    pressure_continuity_weight=pc_w, mass_conservation_weight=mc_w,
                    device=device, epoch=epoch, total_epochs=epochs)
                jv = junction_loss.item() if torch.is_tensor(junction_loss) else float(junction_loss)
                ema_junc = max(jv, 1e-8) if ema_junc is None else \
                    ema_decay * ema_junc + (1 - ema_decay) * max(jv, 1e-8)
                w_j = warmup * junc_target_ratio * ema_data / ema_junc if ema_junc > 1e-8 else 0.0
                w_j = max(w_j, min_physics_weight * warmup)
                w_j = min(w_j, physics_weight_max * warmup) * guard
                total = data_loss + w_j * junction_loss
                run_junc += jv
                npb += 1
            else:
                total = data_loss

            total.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=grad_clip)
            opt.step()
            run_data += data_loss.item()
            nb += 1

        train_loss = run_data / max(nb, 1)
        model.eval()
        with torch.no_grad():
            val_loss = float(loss_fn(model(X_val_t), y_val_t).item())
        sched.step(val_loss)
        lr_now = opt.param_groups[0]["lr"]

        if (phase1_best_val is not None and val_loss > guardrail_mult * phase1_best_val
                and guard > 0.05):
            guard *= 0.5
            print(f"  [GUARDRAIL] val {val_loss:.6f} > {guardrail_mult}x Phase-1 "
                  f"({guardrail_mult * phase1_best_val:.6f}) -> physics weight scale {guard:.3f}")

        history["epoch"].append(gepoch)
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["lr"].append(lr_now)

        if val_loss < best:
            best = val_loss
            best_epoch = epoch
            no_improve = 0
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
        else:
            no_improve += 1

        if log_every and ((epoch + 1) % log_every == 0 or epoch == 0):
            avg_junc = run_junc / max(npb, 1)
            print(f"Epoch {epoch + 1:3d}/{epochs} | data {train_loss:.6f} | "
                  f"junc {avg_junc:.6f} | val {val_loss:.6f} | w_j {w_j:.4f} | "
                  f"lr {lr_now:.2e} | guard {guard:.2f}")

        if no_improve >= patience:
            print(f"\nEarly stop at epoch {epoch + 1}: no val improvement for {patience} epochs.")
            break

    if restore_best and best_state is not None:
        model.load_state_dict(best_state)
    improved = phase1_best_val is None or best < phase1_best_val
    print(f"\nPhysics phase complete. Best val {best:.6f} @ epoch {best_epoch + 1} | "
          f"{'improved on' if improved else 'did NOT beat'} Phase 1 "
          f"-> {'physics' if improved else 'Phase-1'} weights restored.")
    return {"history": history, "best_val_loss": best, "best_epoch": best_epoch}


# ===========================================================================
#  PREDICTION + METRICS
# ===========================================================================
def predict_pressure(model, X_t, output_scaler, pbb, *, pressure_index):
    """Predicted node pressure in psi = residual (inverse-scaled) + backbone pbb."""
    import torch
    model.eval()
    with torch.no_grad():
        scaled = model(X_t).cpu().numpy()
    return output_scaler.inverse_transform(scaled)[:, pressure_index] + np.asarray(pbb)


def regression_metrics(y_true, y_pred):
    """MAE / RMSE / R2 / MAPE for a 1-D pressure vector (psi)."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    err = y_pred - y_true
    ss_res = float((err ** 2).sum())
    ss_tot = float(((y_true - y_true.mean()) ** 2).sum())
    return {
        "mae": float(np.abs(err).mean()),
        "rmse": float(np.sqrt((err ** 2).mean())),
        "r2": (1.0 - ss_res / ss_tot) if ss_tot > 0 else float("nan"),
        "mape": float(np.mean(np.abs(err / (np.abs(y_true) + 1e-8))) * 100),
        "n": int(y_true.size),
    }


def print_metrics(title, m):
    print(f"{title}: MAE={m['mae']:.3f} psi | RMSE={m['rmse']:.3f} psi | "
          f"R2={m['r2']:.4f} | MAPE={m['mape']:.2f}% | n={m['n']}")


# ===========================================================================
#  REPORTING HELPERS  (pure numpy / pandas; no torch)
# ===========================================================================
def attach_predictions(df_slice, p_pred, p_act, *, pred_col="P_pred",
                       act_col="P_act", err_col="err"):
    """Return a row-aligned copy of df_slice with prediction/actual/error columns.

    df_slice must already be sliced to the same rows (and order) as p_pred/p_act,
    e.g. trunk_data[val_mask]. Index is reset so groupby/positional ops are safe.
    """
    out = df_slice.reset_index(drop=True).copy()
    out[pred_col] = np.asarray(p_pred)
    out[act_col] = np.asarray(p_act)
    out[err_col] = out[pred_col] - out[act_col]
    return out


def accuracy_by_pressure_bin(p_act, p_pred, *, bins=None, title=None):
    """Print absolute accuracy by actual-pressure bin; return list of row dicts."""
    if bins is None:
        bins = PRESSURE_BINS
    p_act = np.asarray(p_act, float)
    err = np.asarray(p_pred, float) - p_act
    if title:
        print(title)
    print(f"{'bin (psi)':>14} {'n':>7} {'bias':>10} {'MAE':>8} {'MAPE%':>7} {'P95|err|':>9}")
    rows = []
    for lo, hi in bins:
        m = (p_act >= lo) & (p_act < hi)
        if m.sum() == 0:
            continue
        e = err[m]
        a = p_act[m]
        row = {"lo": lo, "hi": hi, "n": int(m.sum()), "bias": float(e.mean()),
               "mae": float(np.abs(e).mean()),
               "mape": float(100 * np.abs(e / (a + 1e-8)).mean()),
               "p95": float(np.percentile(np.abs(e), 95))}
        rows.append(row)
        hi_disp = hi if hi < 1e9 else 99999
        print(f"  [{lo:4.0f},{hi_disp:5.0f}) {row['n']:7d} {row['bias']:+10.2f} "
              f"{row['mae']:8.2f} {row['mape']:7.2f} {row['p95']:9.2f}")
    return rows


def tail_summary(p_act, p_pred, *, threshold=250.0, label="TAIL"):
    """Print + return bias/MAE/RMSE for the high-pressure tail (P_act > threshold)."""
    p_act = np.asarray(p_act, float)
    err = np.asarray(p_pred, float) - p_act
    m = p_act > threshold
    if m.sum() == 0:
        print(f"  {label} (>{threshold:.0f} psi): no rows")
        return None
    e = err[m]
    stats = {"n": int(m.sum()), "bias": float(e.mean()),
             "mae": float(np.abs(e).mean()), "rmse": float(np.sqrt((e ** 2).mean()))}
    print(f"  {label} (>{threshold:.0f} psi): n={stats['n']}  bias={stats['bias']:+.2f}  "
          f"MAE={stats['mae']:.2f}  RMSE={stats['rmse']:.2f} psi")
    return stats


def within_flowline_profile_fidelity(df, *, gsid_col, flowline_col,
                                     act_col="P_act", pred_col="P_pred",
                                     min_nodes=5, min_range_psi=5.0, verbose=True):
    """Score how well the predicted pressure PROFILE tracks the actual one within
    each (scenario, flowline) that has enough nodes and enough pressure range.

    Two numbers: profile shape correlation (order-independent), and adjacent-node
    dP error (does the model get the local pressure gradient, i.e. WHERE along the
    branch pressure climbs). Returns a dict of aggregates.
    """
    shape_corr = []
    grad_mae = []
    n_buckets = 0
    for _key, g in df.groupby([gsid_col, flowline_col], sort=False):
        if len(g) < min_nodes:
            continue
        pa = g[act_col].to_numpy(dtype=float)
        pp = g[pred_col].to_numpy(dtype=float)
        if (pa.max() - pa.min()) < min_range_psi:
            continue
        n_buckets += 1
        if pa.std() > 1e-9 and pp.std() > 1e-9:
            shape_corr.append(float(np.corrcoef(pa, pp)[0, 1]))
        if len(g) >= 2:
            grad_mae.append(float(np.abs(np.diff(pp) - np.diff(pa)).mean()))
    sc = np.asarray(shape_corr)
    gm = np.asarray(grad_mae)
    stats = {
        "n_buckets": n_buckets,
        "shape_corr_mean": float(sc.mean()) if sc.size else float("nan"),
        "shape_corr_median": float(np.median(sc)) if sc.size else float("nan"),
        "shape_corr_p05": float(np.percentile(sc, 5)) if sc.size else float("nan"),
        "grad_mae_mean": float(gm.mean()) if gm.size else float("nan"),
        "grad_mae_median": float(np.median(gm)) if gm.size else float("nan"),
    }
    if verbose:
        print(f"WITHIN-FLOWLINE PROFILE FIDELITY "
              f"(>= {min_nodes} nodes, >= {min_range_psi:.0f} psi range)")
        if n_buckets == 0:
            print("  No (scenario, flowline) group met the node/range thresholds.")
        else:
            print(f"  buckets scored          : {n_buckets}")
            if sc.size:
                print(f"  profile shape corr      : mean={stats['shape_corr_mean']:.4f}  "
                      f"median={stats['shape_corr_median']:.4f}  "
                      f"p05={stats['shape_corr_p05']:.4f}")
            if gm.size:
                print(f"  adjacent-node dP MAE    : mean={stats['grad_mae_mean']:.3f}  "
                      f"median={stats['grad_mae_median']:.3f} psi")
    return stats


def junction_hotspot_table(df, junctions, *, act_col="P_act", pred_col="P_pred",
                           x_col="long", y_col="lat", round_decimals=6,
                           sort="mean_actP", top=None):
    """Per-junction pred-vs-actual error at nodes sitting on each junction coord.

    sort: "mean_actP" (highest-pressure junctions first, matches the validation
    report) or "absbias" (worst |bias| first, matches the blind report). Returns
    the list of row dicts actually printed.
    """
    err_col = "_hs_err"
    d = df[[act_col, pred_col, x_col, y_col]].copy()
    d[err_col] = d[pred_col] - d[act_col]
    xr = d[x_col].round(round_decimals).to_numpy()
    yr = d[y_col].round(round_decimals).to_numpy()
    a = d[act_col].to_numpy(dtype=float)
    e = d[err_col].to_numpy(dtype=float)

    rows = []
    for j in junctions:
        jx = round(j["coords"][0], round_decimals)
        jy = round(j["coords"][1], round_decimals)
        m = (xr == jx) & (yr == jy)
        if m.sum() == 0:
            continue
        nfl = len(set(j.get("flowline", []))) if j.get("flowline") is not None else 0
        rows.append({"id": str(j["id"]), "n_fl": nfl, "n": int(m.sum()),
                     "mean_actP": float(a[m].mean()), "bias": float(e[m].mean()),
                     "mae": float(np.abs(e[m]).mean())})
    if not rows:
        print("  (no junction nodes present in this split)")
        return rows

    if sort == "absbias":
        rows_sorted = sorted(rows, key=lambda r: -abs(r["bias"]))
        header_note = "worst by |bias| (bias<0 = MISSED overpressure)"
    else:
        rows_sorted = sorted(rows, key=lambda r: -r["mean_actP"])
        header_note = "highest mean actual-P first"
    shown = rows_sorted[:top] if top else rows_sorted

    print(f"JUNCTION HOTSPOTS - {header_note}")
    print(f"{'junction':>12} {'#fl':>4} {'n':>7} {'mean_actP':>10} {'bias':>9} {'MAE':>8}")
    for r in shown:
        print(f"{r['id']:>12} {r['n_fl']:>4} {r['n']:>7} {r['mean_actP']:>10.1f} "
              f"{r['bias']:>+9.2f} {r['mae']:>8.2f}")
    return shown


def near_source_cluster_tail(df, cluster_flowlines, *, flowline_col="BranchEquipment",
                             act_col="P_act", pred_col="P_pred", threshold=250.0):
    """Tail error (P_act > threshold) on the named near-source cluster flowlines."""
    err = (df[pred_col] - df[act_col]).to_numpy(dtype=float)
    fl = df[flowline_col].astype(str).to_numpy()
    a = df[act_col].to_numpy(dtype=float)
    print(f"NEAR-SOURCE CLUSTER FLOWLINES - tail error (P>{threshold:.0f} psi)")
    print(f"{'flowline':>10} {'n':>7} {'bias':>8} {'MAE':>8} {'MAPE%':>7}")
    rows = []
    for f in cluster_flowlines:
        m = (fl == str(f)) & (a > threshold)
        if m.sum() == 0:
            continue
        e = err[m]
        rows.append({"flowline": str(f), "n": int(m.sum()), "bias": float(e.mean()),
                     "mae": float(np.abs(e).mean()),
                     "mape": float(100 * np.abs(e / (a[m] + 1e-8)).mean())})
        print(f"{str(f):>10} {int(m.sum()):>7} {e.mean():>+8.2f} "
              f"{np.abs(e).mean():>8.2f} {100 * np.abs(e / (a[m] + 1e-8)).mean():>7.2f}")
    return rows


def full_pressure_report(df, *, gsid_col, flowline_col, act_col="P_act",
                         pred_col="P_pred", x_col="long", y_col="lat",
                         junctions=None, junction_sort="mean_actP", junction_top=None,
                         cluster_flowlines=None, min_nodes=5, min_range_psi=5.0,
                         tail_psi=250.0, title=None):
    """One report used by BOTH the validation tail cell and the blind cell:
    overall metrics -> accuracy by bin -> tail summary -> within-flowline profile
    fidelity -> junction hotspots -> near-source cluster tail. Returns all numbers.
    """
    p_act = df[act_col].to_numpy(dtype=float)
    p_pred = df[pred_col].to_numpy(dtype=float)
    if title:
        print("#" * 78)
        print(f"#  {title}")
        print("#" * 78)

    overall = regression_metrics(p_act, p_pred)
    print_metrics("Overall", overall)
    print("-" * 78)

    bins = accuracy_by_pressure_bin(p_act, p_pred,
                                    title="ABSOLUTE ACCURACY BY PRESSURE BIN")
    tail = tail_summary(p_act, p_pred, threshold=tail_psi)
    print()
    profile = within_flowline_profile_fidelity(
        df, gsid_col=gsid_col, flowline_col=flowline_col, act_col=act_col,
        pred_col=pred_col, min_nodes=min_nodes, min_range_psi=min_range_psi)

    hotspots = None
    if junctions is not None and {x_col, y_col}.issubset(df.columns):
        print()
        hotspots = junction_hotspot_table(
            df, junctions, act_col=act_col, pred_col=pred_col, x_col=x_col,
            y_col=y_col, sort=junction_sort, top=junction_top)

    cluster = None
    if cluster_flowlines:
        print()
        cluster = near_source_cluster_tail(
            df, cluster_flowlines, flowline_col=flowline_col, act_col=act_col,
            pred_col=pred_col, threshold=tail_psi)

    return {"overall": overall, "bins": bins, "tail": tail, "profile": profile,
            "hotspots": hotspots, "cluster": cluster}


# ===========================================================================
#  PLOTS
# ===========================================================================
def parity_plot(p_act, p_pred, *, title="Predicted vs Actual Pressure (psi)",
                ax=None):
    """Scatter of predicted vs actual pressure with the y=x reference line."""
    import matplotlib.pyplot as plt
    p_act = np.asarray(p_act, float)
    p_pred = np.asarray(p_pred, float)
    if ax is None:
        _fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(p_act, p_pred, alpha=0.1, s=2, c="steelblue")
    lo = float(min(p_act.min(), p_pred.min()))
    hi = float(max(p_act.max(), p_pred.max()))
    ax.plot([lo, hi], [lo, hi], "r--", lw=1, label="y = x")
    ax.set_xlabel("Actual pressure (psi)")
    ax.set_ylabel("Predicted pressure (psi)")
    ax.set_title(title)
    ax.legend(loc="upper left")
    ax.grid(True, alpha=0.3)
    return ax


def training_history_plot(history, *, ax=None):
    """Train/val loss curves for the data-only phase (log-y)."""
    import matplotlib.pyplot as plt
    if ax is None:
        _fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(history["epoch"], history["train_loss"], label="train")
    ax.plot(history["epoch"], history["val_loss"], label="val")
    ax.set_yscale("log")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss (scaled residual)")
    ax.set_title("Phase 1 — data-only training")
    ax.legend()
    ax.grid(True, alpha=0.3)
    return ax


# ===========================================================================
#  LAMBDA INVERSE  (analytic post-hoc friction-multiplier recovery)
# ===========================================================================
# Friction closure (per flowline, sink-anchored backbone):
#     P[start] - P[end] = a_grav * dH  +  f0 * dB(lambda_eng)
#   where, accumulating along the flowline (nodes sorted by TotalDistance):
#     dH        = sum  rr*(z[i+1]-z[i]) / 144                       (gravity integral)
#     dB(lam)   = sum  lam[i]*rr*vv^2*dl / (2*dd) / (gc*144)        (friction integral)
#     dB_unit   = dB(lam == 1)                                      (lambda=1 base integral)
# Solve the closure for the friction multiplier the pressure field IMPLIES:
#     lambda_recovered = ( (P[start]-P[end]) - a_grav*dH ) / dB_unit
# Applied to the MODEL pressure field this returns the effective multiplier the
# network reproduces; applied to the ACTUAL field it returns the data-implied
# multiplier. Both absorb the backbone's per-flowline f0 correction, so
# lambda_recovered ~= f0 * lambda_engineer -- they live on the same scale as
# f0*lambda_eng, and lambda_recovered / lambda_engineer ~= f0 (the correction the
# engineers' hand-set lambda was missing). lambda_engineer below is the
# integral-weighted mean of the raw `lambda_friction` column over the flowline.
#
# This is a READ-OFF, not a fit: no gradients, no optimisation. It can be called
# on any (scenario, flowline) frame that carries predicted + actual pressures, so
# it works post-hoc OR as a per-epoch training diagnostic. (A *trainable* lambda
# co-optimised with the network weights would be non-identifiable here -- the
# residual head can absorb friction error -- which is why friction is fixed by the
# backbone's least-squares f0 and only read back out here.)
def recover_lambda_inverse(df, backbone_by_trunk, *, trunk_col, gsid_col,
                           flowline_col="BranchEquipment", pred_col="P_pred",
                           act_col="P_act", dist_col="TotalDistance",
                           elev_col="Elevation", vel_col="VelocityLiquid",
                           rho_col="DensityLiquidInSitu",
                           diam_col="PipeInsideDiameter", lam_col="lambda_friction",
                           min_nodes=3, min_unit_integral=1e-9):
    """Recover the per-flowline effective friction multiplier from a pressure field.

    For every (scenario, flowline) with >= min_nodes, solve the backbone friction
    closure for lambda using both the model-predicted and the actual pressures, and
    report the engineers' integral-weighted lambda alongside. `a_grav` is looked up
    per trunk from `backbone_by_trunk`. Returns a tidy per-(scenario, flowline)
    DataFrame; flowlines whose lambda=1 friction integral is ~0 (flat / no drop, so
    lambda is unidentifiable) are skipped.
    """
    import pandas as pd
    from libraries.backbone_reconstruction import GC, PSI

    rows = []
    for (gsid, fl), g in df.groupby([gsid_col, flowline_col], sort=False):
        if len(g) < min_nodes:
            continue
        trunk = g[trunk_col].iloc[0]
        coeffs = backbone_by_trunk.get(trunk)
        if coeffs is None:
            continue
        a_grav = float(coeffs["a_grav"])

        gg = g.sort_values(dist_col)
        L = gg[dist_col].to_numpy(float)
        z = gg[elev_col].to_numpy(float)
        v = gg[vel_col].to_numpy(float)
        rho = gg[rho_col].to_numpy(float)
        d = gg[diam_col].to_numpy(float) / 12.0
        lam = gg[lam_col].to_numpy(float)
        Pp = gg[pred_col].to_numpy(float)
        Pa = gg[act_col].to_numpy(float)

        dl = np.diff(L)
        keep = dl > 0
        if keep.sum() == 0:
            continue
        vv = 0.5 * (v[:-1] + v[1:])
        rr = 0.5 * (rho[:-1] + rho[1:])
        dd = 0.5 * (d[:-1] + d[1:])
        dz = z[1:] - z[:-1]
        dH_seg = np.where(keep, rr * dz / PSI, 0.0)
        base_seg = np.where(keep, rr * vv * vv * dl / (2.0 * dd) / (GC * PSI), 0.0)
        lam_seg = lam[:-1]                      # lam[i] drives segment i (matches backbone)

        dH = float(np.nansum(dH_seg))
        dB_unit = float(np.nansum(base_seg))
        dB_eng = float(np.nansum(lam_seg * base_seg))
        if not np.isfinite(dB_unit) or abs(dB_unit) < min_unit_integral:
            continue

        dP_model = float(Pp[0] - Pp[-1])
        dP_act = float(Pa[0] - Pa[-1])
        lam_eng = dB_eng / dB_unit
        lam_model = (dP_model - a_grav * dH) / dB_unit
        lam_actual = (dP_act - a_grav * dH) / dB_unit

        rows.append({
            "gsid": gsid, "flowline": fl, "trunk": trunk, "n_nodes": int(len(gg)),
            "length": float(L[-1] - L[0]),
            "lambda_engineer": lam_eng,
            "lambda_model": lam_model,
            "lambda_actual": lam_actual,
            "ratio_model_eng": lam_model / lam_eng if lam_eng != 0 else np.nan,
            "ratio_actual_eng": lam_actual / lam_eng if lam_eng != 0 else np.nan,
            "ratio_model_actual": lam_model / lam_actual if lam_actual != 0 else np.nan,
            "dB_unit": dB_unit, "dH": dH,
        })
    return pd.DataFrame(rows)


def lambda_comparison_report(lam_df, *, top=25, plot=True, title=None):
    """Aggregate `recover_lambda_inverse` output per flowline and (optionally) plot.

    Prints a per-flowline table (median lambda across scenarios for engineer / model
    / actual, plus the model:actual agreement ratio) and returns the aggregated
    DataFrame. The plot has two panels: grouped bars of median lambda per flowline,
    and a lambda_actual-vs-lambda_model parity scatter (ideal = y=x, i.e. the model
    reproduces the data-implied friction).
    """
    if lam_df is None or len(lam_df) == 0:
        print("lambda_comparison_report: no rows (nothing identifiable).")
        return None

    agg = (lam_df.groupby("flowline")
           .agg(n=("gsid", "size"),
                lambda_engineer=("lambda_engineer", "median"),
                lambda_model=("lambda_model", "median"),
                lambda_actual=("lambda_actual", "median"),
                ratio_model_actual=("ratio_model_actual", "median"))
           .reset_index()
           .sort_values("n", ascending=False))

    if title:
        print("#" * 78)
        print(f"#  {title}")
        print("#" * 78)
    print("Per-flowline friction multiplier: engineers' lambda vs recovered "
          "(effective, absorbs backbone f0).")
    print("  ratio model/actual ~ 1.0 means the model reproduces the data-implied "
          "friction.\n")
    print(f"{'flowline':>12} {'n':>5} {'lam_eng':>10} {'lam_model':>10} "
          f"{'lam_actual':>11} {'model/act':>10}")
    for r in agg.head(top).itertuples(index=False):
        print(f"{str(r.flowline):>12} {r.n:5d} {r.lambda_engineer:10.4f} "
              f"{r.lambda_model:10.4f} {r.lambda_actual:11.4f} "
              f"{r.ratio_model_actual:10.3f}")

    # Overall (scenario-level) summary across all identifiable flowlines.
    med = lam_df[["lambda_engineer", "lambda_model", "lambda_actual"]].median()
    ract = lam_df["ratio_actual_eng"].median()
    rmod = lam_df["ratio_model_eng"].median()
    rma = lam_df["ratio_model_actual"].median()
    print(f"\nOVERALL medians  | lambda_eng={med['lambda_engineer']:.4f}  "
          f"lambda_model={med['lambda_model']:.4f}  "
          f"lambda_actual={med['lambda_actual']:.4f}")
    print(f"                 | recovered/engineer: actual={ract:.3f}  model={rmod:.3f}  "
          f"(this ratio ~ backbone f0, the correction to hand-set lambda)")
    print(f"                 | model/actual agreement={rma:.3f}  (1.0 = perfect)")

    if plot:
        import matplotlib.pyplot as plt
        show = agg.head(min(top, len(agg)))
        fig, (a0, a1) = plt.subplots(1, 2, figsize=(15, 5))
        x = np.arange(len(show))
        w = 0.27
        a0.bar(x - w, show["lambda_engineer"], w, label="engineer", color="#888888")
        a0.bar(x, show["lambda_model"], w, label="model", color="steelblue")
        a0.bar(x + w, show["lambda_actual"], w, label="actual", color="darkorange")
        a0.set_xticks(x)
        a0.set_xticklabels([str(f) for f in show["flowline"]], rotation=60, ha="right",
                           fontsize=8)
        a0.set_ylabel("friction multiplier lambda")
        a0.set_title("Median lambda per flowline")
        a0.legend()
        a0.grid(True, axis="y", alpha=0.3)

        la = lam_df["lambda_actual"].to_numpy(float)
        lm = lam_df["lambda_model"].to_numpy(float)
        a1.scatter(la, lm, s=8, alpha=0.3, c="steelblue")
        finite = np.isfinite(la) & np.isfinite(lm)
        if finite.any():
            lo = float(min(la[finite].min(), lm[finite].min()))
            hi = float(max(la[finite].max(), lm[finite].max()))
            a1.plot([lo, hi], [lo, hi], "r--", lw=1, label="y = x")
        a1.set_xlabel("lambda (actual pressures)")
        a1.set_ylabel("lambda (model pressures)")
        a1.set_title("Recovered friction: model vs actual")
        a1.legend(loc="upper left")
        a1.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()

    return agg
