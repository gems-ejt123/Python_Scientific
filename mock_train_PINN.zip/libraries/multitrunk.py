"""
multitrunk.py  —  Multi-trunk data plumbing for the single-shared PI-KAN surrogate.

TORCH-FREE by design: everything here is pure pandas/numpy so the whole data
pipeline (load -> prepare -> split -> reconstruct -> topology) can be unit-tested
without a GPU. The notebook does the tensor/scaler/model work on top of the raw
arrays this module returns.

Design (agreed with Emilio — "Single shared model"):
  * Pool ALL trunks into ONE model with GLOBAL scalers and one deployable artifact.
  * Raw `scenario` numbers (0..N) collide across trunks, so every scenario is
    re-keyed by a globally-unique id:  gsid = "<Troncal>||<scenario>".
  * Junction coordinates are geographic (long/lat) and therefore unique per trunk,
    so a UNION of all trunks' junctions is collision-free, and the junction split
    priors pool safely across trunks.
  * The split is stratified by max-pressure WITHIN each trunk, then unioned, so
    every trunk is represented in train/val/blind and the high-pressure tail is
    covered everywhere.

Public API (see __all__ at bottom).
"""

import os
import glob
import zipfile
import numpy as np
import pandas as pd


def _get_detect_junctions_from_nodes():
    """Lazy import so this module loads even before networkx is available.

    Only detect_union_junctions needs it. Kept torch-free (networkx/numpy/sklearn).
    """
    try:
        from cluster_by_junctions import detect_junctions_from_nodes
    except Exception:  # allow import from repo root too
        from libraries.cluster_by_junctions import detect_junctions_from_nodes
    return detect_junctions_from_nodes


# ---------------------------------------------------------------------------
# Column contracts (must match the notebook config cell).
# ---------------------------------------------------------------------------
INPUT_COLS = [
    "FlowrateLiquidInsitu",
    "Watercut",
    "ElevationDifference",
    "TotalDistance",
    "PipeInsideDiameter",
]
OUTPUT_COLS = ["Pressure", "MassFlowrate", "HoldupFractionLiquid", "lambda_friction"]

TRUNK_COL = "Troncal"
SCENARIO_COL = "scenario"
GSID_COL = "gsid"
GSID_SEP = "||"

# bbl -> ft^3 and day -> s for MassFlowrate.
_BBL_TO_FT3 = 5.6146
_DAY_TO_S = 86400.0


# ===========================================================================
# 1. DISCOVERY + LOAD  (auto-detect compression + delimiter + all trunks)
# ===========================================================================
def discover_data_file(trunk_dir):
    """Return the path of the single data file dropped in `trunk_dir`.

    Accepts .zip (compressed multi-trunk export) or .csv. If several files are
    present, prefers a .zip, then the largest file. Raises if none found.
    """
    if os.path.isfile(trunk_dir):
        return trunk_dir
    cands = []
    for ext in ("*.zip", "*.csv", "*.gz"):  # "*.csv.gz" is a subset of "*.gz"
        cands.extend(glob.glob(os.path.join(trunk_dir, ext)))
    # de-duplicate (a .csv.gz would otherwise match twice) while keeping only files
    cands = list(dict.fromkeys(c for c in cands if os.path.isfile(c)))
    if not cands:
        raise FileNotFoundError(f"No .zip/.csv/.gz data file found in {trunk_dir!r}")
    zips = [c for c in cands if c.lower().endswith(".zip")]
    pick = zips[0] if zips else max(cands, key=os.path.getsize)
    return pick


def _open_text_handle(path):
    """Yield (name, file-like-text) for a csv, a .gz, or the first csv in a .zip."""
    low = path.lower()
    if low.endswith(".zip"):
        zf = zipfile.ZipFile(path)
        inner = [n for n in zf.namelist() if n.lower().endswith(".csv")]
        if not inner:
            inner = [n for n in zf.namelist() if not n.endswith("/")]
        if not inner:
            raise ValueError(f"{path}: zip contains no readable member")
        return inner[0], zf.open(inner[0]), zf
    return os.path.basename(path), open(path, "rb"), None


def _sniff_delimiter(sample_bytes):
    """Pick ';' or ',' by counting occurrences in the header line."""
    head = sample_bytes.split(b"\n", 1)[0]
    return ";" if head.count(b";") >= head.count(b",") else ","


def load_all_trunks(path, verbose=True):
    """Load the full multi-trunk table, auto-detecting compression + delimiter.

    Returns a DataFrame with an added globally-unique `gsid` column. Does NOT
    filter to a single trunk — this is the whole point of the multi-trunk model.
    """
    name, fh, zf = _open_text_handle(path)
    try:
        raw = fh.read()
    finally:
        fh.close()
        if zf is not None:
            zf.close()
    # gzip is advertised by discover_data_file, so support it here: a raw gzip
    # stream fed to pd.read_csv(BytesIO(...)) can't be inferred (no filename) and
    # would fail on the first byte, so decompress up front. Covers a bare *.gz and
    # a *.csv.gz stored inside a zip.
    if name.lower().endswith(".gz") or path.lower().endswith(".gz") or raw[:2] == b"\x1f\x8b":
        import gzip

        raw = gzip.decompress(raw)
    delim = _sniff_delimiter(raw[:4096])
    import io

    df = pd.read_csv(io.BytesIO(raw), sep=delim)
    if TRUNK_COL not in df.columns:
        raise KeyError(
            f"Expected a '{TRUNK_COL}' column to identify trunks; got {list(df.columns)[:10]}..."
        )
    df[GSID_COL] = (
        df[TRUNK_COL].astype(str) + GSID_SEP + df[SCENARIO_COL].astype(str)
    )
    if verbose:
        trunks = df[TRUNK_COL].unique().tolist()
        print(f"Loaded {name}: {df.shape[0]:,} rows, delimiter={delim!r}")
        print(f"Trunks detected ({len(trunks)}): {trunks}")
        for t in trunks:
            sub = df[df[TRUNK_COL] == t]
            print(
                f"  {t}: {sub.shape[0]:,} rows | "
                f"{sub[SCENARIO_COL].nunique()} scenarios | "
                f"{sub['BranchEquipment'].nunique()} flowlines"
            )
    return df


# ===========================================================================
# 2. PREPARE  (per-trunk derived columns; torch-free)
# ===========================================================================
def _elevation_difference_one_trunk(df, elevation_col="Elevation",
                                    flowline_col="BranchEquipment",
                                    node_type_col="node_type",
                                    source_node_type=1):
    """ElevationDifference = Elevation - reference, where reference is the first
    source node's elevation per flowline (else the flowline's first node).

    Faithful torch-free reimplementation of prepare_data.calculate_elevation_differences,
    scoped to a single trunk so flowline-name collisions across trunks cannot leak.
    """
    d = df.copy().reset_index(drop=True)
    src = d[d[node_type_col] == source_node_type]
    ref = src.groupby(flowline_col)[elevation_col].first()
    # Flowlines lacking a source node fall back to their first node.
    missing = set(d[flowline_col].unique()) - set(ref.index)
    if missing:
        fb = d[d[flowline_col].isin(missing)].groupby(flowline_col)[elevation_col].first()
        ref = pd.concat([ref, fb])
    d["ElevationDifference"] = d[elevation_col] - d[flowline_col].map(ref)
    return d["ElevationDifference"].values


def prepare_dataframe(df, m_to_ft=1, recompute=False, verbose=True):
    """Add the derived columns the model needs, PER TRUNK.

    By default this PRESERVES already-present derived columns (ElevationDifference,
    MassFlowrate) and only computes what is missing. This matters because an
    already-processed export can carry a unit convention that differs from a raw
    dump: e.g. the single-trunk trunk_data.csv stores ElevationDifference in FEET
    (raw Elevation was meters, ×3.28084), whereas the BACKBONE notebook config uses
    M_TO_FT=1. Overwriting would silently switch units mid-pipeline. Set
    recompute=True to force canonical recomputation with the given m_to_ft.

    Derived columns:
      * ElevationDifference : per-trunk, source-referenced (Elevation - reference)
      * MassFlowrate        : FlowrateLiquidInsitu * 5.6146/86400 * DensityLiquidInSitu
      * lambda_friction_valid + per-trunk median fill of NaN lambda_friction

    Returns a new sorted DataFrame; leaves gsid intact.
    """
    df = df.copy()

    # A column needs a FULL (re)compute only when it is genuinely unavailable:
    # forced by recompute, missing entirely, or all-NaN. A *partial* NaN is a
    # data-quality gap, not a reason to overwrite good values — see below.
    def _absent(col):
        return recompute or (col not in df.columns) or bool(df[col].isna().all())

    def _partial_nan(col):
        return (not recompute) and (col in df.columns) and bool(df[col].isna().any())

    # --- unit conversion only when we are (re)computing from raw geometry ---
    if recompute and m_to_ft != 1:
        for col in ("TotalDistance", "Elevation", "HorizontalDistance"):
            if col in df.columns:
                df[col] = df[col] * m_to_ft

    def _compute_ediff_full():
        ediff = np.empty(len(df), dtype=np.float64)
        for _t, idx in df.groupby(TRUNK_COL).groups.items():
            ediff[df.index.get_indexer(idx)] = _elevation_difference_one_trunk(df.loc[idx])
        return ediff

    # --- per-trunk elevation difference ---
    # ElevationDifference carries a UNIT convention (the shipped trunk_data.csv is
    # in FEET; a raw recompute here uses M_TO_FT). Recomputing the whole column
    # because a few rows are NaN would silently mix units, so we only backfill the
    # NaN rows and warn — never clobber existing good values.
    if _absent("ElevationDifference"):
        df["ElevationDifference"] = _compute_ediff_full()
        if verbose:
            print("ElevationDifference: computed (per-trunk, source-referenced).")
    elif _partial_nan("ElevationDifference"):
        nan_mask = df["ElevationDifference"].isna().to_numpy()
        df.loc[nan_mask, "ElevationDifference"] = _compute_ediff_full()[nan_mask]
        print(
            f"WARNING: ElevationDifference had {int(nan_mask.sum())} NaN row(s); "
            "backfilled per-trunk. Existing values were PRESERVED — if the input "
            "column is in feet, the backfilled rows (M_TO_FT-based) may not match units."
        )
    elif verbose:
        print("ElevationDifference: preserved from input (already present).")

    # --- MassFlowrate (row-wise, unit-safe formula) ---
    _mass = (
        df["FlowrateLiquidInsitu"] * _BBL_TO_FT3 / _DAY_TO_S * df["DensityLiquidInSitu"]
    )
    if _absent("MassFlowrate"):
        df["MassFlowrate"] = _mass
        if verbose:
            print("MassFlowrate: computed from FlowrateLiquidInsitu × DensityLiquidInSitu.")
    elif _partial_nan("MassFlowrate"):
        nan_mask = df["MassFlowrate"].isna().to_numpy()
        df.loc[nan_mask, "MassFlowrate"] = _mass[nan_mask]
        if verbose:
            print(f"MassFlowrate: backfilled {int(nan_mask.sum())} NaN row(s) (unit-safe formula).")
    elif verbose:
        print("MassFlowrate: preserved from input (already present).")

    # --- lambda_friction validity + per-trunk median fill ---
    if "lambda_friction_valid" not in df.columns or recompute:
        df["lambda_friction_valid"] = df["lambda_friction"].notna()
    filled = 0
    for _t, idx in df.groupby(TRUNK_COL).groups.items():
        sub = df.loc[idx, "lambda_friction"]
        n_nan = int(sub.isna().sum())
        if n_nan:
            med = sub[sub.notna()].median()
            df.loc[idx, "lambda_friction"] = sub.fillna(med)
            filled += n_nan
    if verbose and filled:
        print(f"Filled {filled} NaN lambda_friction values (per-trunk median).")

    df = df.sort_values([TRUNK_COL, SCENARIO_COL, "BranchEquipment", "TotalDistance"]).reset_index(drop=True)
    return df


def select_scenarios(df, num_scenarios=None):
    """Optionally cap the number of scenarios kept PER TRUNK (keeps lowest ids)."""
    if num_scenarios is None:
        return df
    keep = []
    for _t, sub in df.groupby(TRUNK_COL, sort=False):
        sids = sorted(sub[SCENARIO_COL].unique())[:num_scenarios]
        keep.append(sub[sub[SCENARIO_COL].isin(sids)])
    return pd.concat(keep).reset_index(drop=True)


# ===========================================================================
# 3. SPLIT  (max-pressure-stratified within each trunk, then unioned)
# ===========================================================================
def stratified_split_by_trunk(df, seed=42, val_split=0.10, blind_split=0.10,
                              block=20, verbose=True):
    """Return (train_gsids, val_gsids, blind_gsids) as arrays of gsid strings.

    Each trunk is stratified independently by per-scenario max pressure using the
    same sliding-block dealing as the single-trunk notebook, guaranteeing tail
    coverage in all three partitions for EVERY trunk. Results are unioned.
    """
    train, val, blind = [], [], []
    per_trunk = {}
    for t, sub in df.groupby(TRUNK_COL, sort=False):
        maxP = sub.groupby(GSID_COL)["Pressure"].max()
        order = maxP.sort_values().index.to_numpy()  # ascending by max pressure
        rng = np.random.RandomState(seed)
        tr, va, bl = [], [], []
        for s in range(0, len(order), block):
            blk = list(order[s:s + block])
            rng.shuffle(blk)
            n = len(blk)
            nv = max(1, int(round(n * val_split))) if n >= 2 else 0
            nbl = max(1, int(round(n * blind_split))) if n >= 3 else 0
            va.extend(blk[:nv])
            bl.extend(blk[nv:nv + nbl])
            tr.extend(blk[nv + nbl:])
        train += tr
        val += va
        blind += bl
        per_trunk[t] = (len(tr), len(va), len(bl))

    train = np.array(train)
    val = np.array(val)
    blind = np.array(blind)
    # Disjointness across the whole pool.
    assert not (set(train) & set(val)), "train/val overlap"
    assert not (set(train) & set(blind)), "train/blind overlap"
    assert not (set(val) & set(blind)), "val/blind overlap"

    if verbose:
        print(f"Split (unioned): train={len(train)} | val={len(val)} | blind={len(blind)} gsids")
        for t, (a, b, c) in per_trunk.items():
            print(f"  {t}: train={a} val={b} blind={c}")
    return train, val, blind


# ===========================================================================
# 4. FLOW GRAPH + JUNCTION SPLIT PRIORS + SOURCE-ONLY RECONSTRUCTION
#    (all keyed by gsid; ported from notebook cell 15, scenario -> gsid)
# ===========================================================================
def build_flow_graph(df, x_col="long", y_col="lat", branch_col="BranchEquipment",
                     dist_col="TotalDistance", node_type_col="node_type"):
    """Build (junction_graph, flowline_order, source_flowlines) for one scenario df.

    Coordinate-based and gsid-agnostic: operates purely on the rows handed to it.
    """
    d = df.copy()
    d["x_r"] = d[x_col].round(6)
    d["y_r"] = d[y_col].round(6)

    junction_coords = {}
    for (x, y), grp in d.groupby(["x_r", "y_r"]):
        branches = grp[branch_col].unique().tolist()
        if len(branches) >= 2:
            junction_coords[(x, y)] = branches

    junction_graph = {}
    all_flowlines = d[branch_col].unique().tolist()
    for jcoord, branches in junction_coords.items():
        incoming, outgoing = [], []
        for fl in branches:
            fl_data = d[d[branch_col] == fl].sort_values(dist_col)
            first_coord = (round(fl_data.iloc[0][x_col], 6), round(fl_data.iloc[0][y_col], 6))
            last_coord = (round(fl_data.iloc[-1][x_col], 6), round(fl_data.iloc[-1][y_col], 6))
            if last_coord == jcoord:
                incoming.append(fl)
            elif first_coord == jcoord:
                outgoing.append(fl)
        junction_graph[jcoord] = {"incoming": incoming, "outgoing": outgoing}

    succ = {fl: [] for fl in all_flowlines}
    pred = {fl: [] for fl in all_flowlines}
    for info in junction_graph.values():
        for in_fl in info["incoming"]:
            for out_fl in info["outgoing"]:
                succ[in_fl].append(out_fl)
                pred[out_fl].append(in_fl)

    in_degree = {fl: len(pred[fl]) for fl in all_flowlines}
    queue = [fl for fl, deg in in_degree.items() if deg == 0]
    flowline_order = []
    while queue:
        fl = queue.pop(0)
        flowline_order.append(fl)
        for nxt in succ[fl]:
            in_degree[nxt] -= 1
            if in_degree[nxt] == 0:
                queue.append(nxt)

    source_flowlines = d.loc[d[node_type_col] == 1, branch_col].unique().tolist()
    return junction_graph, flowline_order, source_flowlines


def build_trunk_structures(df, gsids=None):
    """Build the flow-graph structure ONCE per trunk and reuse it everywhere.

    Topology (junction graph, flowline order, source flowlines) is identical
    across all scenarios of a trunk — only the flow VALUES change. Rebuilding it
    per scenario was the pipeline's dominant cost (~26 s over 255 scenarios), so
    we cache one structure per trunk keyed off a representative scenario.

    Returns {trunk_name: (junction_graph, flowline_order, source_flowlines)}.
    """
    gsid_pool = set(gsids) if gsids is not None else None
    structures = {}
    for t, sub in df.groupby(TRUNK_COL, sort=False):
        gids = sub[GSID_COL].unique().tolist()
        if gsid_pool is not None:
            gids = [g for g in gids if g in gsid_pool]
        if not gids:
            continue
        rep = sub[sub[GSID_COL] == gids[0]]
        structures[t] = build_flow_graph(rep)
    return structures


def fit_junction_split_priors(df, gsids, structures=None):
    """Learn outgoing split ratios per junction signature from TRAIN gsids only.

    Key = (jcoord, tuple(sorted(outgoing))). Because jcoord is geographic and
    unique per trunk, this pools safely across all trunks in one dict. Uses the
    cached per-trunk structure so the junction graph is built once, not per
    scenario. For a purely convergent (gathering) network this returns {} — every
    junction has a single outlet, so no split ratios are needed.
    """
    if structures is None:
        structures = build_trunk_structures(df, gsids)
    # Map gsid -> trunk once.
    gsid_trunk = df.drop_duplicates(GSID_COL).set_index(GSID_COL)[TRUNK_COL].to_dict()
    raw = {}
    for gid in gsids:
        s_df = df[df[GSID_COL] == gid]
        if len(s_df) == 0:
            continue
        struct = structures.get(gsid_trunk.get(gid))
        if struct is None:
            continue
        j_graph = struct[0]
        for jcoord, info in j_graph.items():
            outgoing = list(info.get("outgoing", []))
            incoming = list(info.get("incoming", []))
            if len(outgoing) <= 1 or len(incoming) == 0:
                continue
            key = (jcoord, tuple(sorted(outgoing)))
            outgoing_q = {}
            for fl in outgoing:
                fl_rows = s_df[s_df["BranchEquipment"] == fl]
                if len(fl_rows) == 0:
                    continue
                outgoing_q[fl] = float(fl_rows["FlowrateLiquidInsitu"].iloc[0])
            total_out = sum(max(v, 0.0) for v in outgoing_q.values())
            if total_out <= 1e-8:
                continue
            raw.setdefault(key, {fl: [] for fl in outgoing})
            for fl in outgoing:
                raw[key].setdefault(fl, []).append(max(outgoing_q.get(fl, 0.0), 0.0) / total_out)

    priors = {}
    for key, per_fl in raw.items():
        ratios = {fl: float(np.mean(v)) for fl, v in per_fl.items() if len(v)}
        s = sum(ratios.values())
        if s > 1e-8:
            priors[key] = {fl: r / s for fl, r in ratios.items()}
    return priors


def _reconstruct_source_only_for_scenario(df, split_priors=None, structure=None):
    """Return df[["FlowrateLiquidInsitu","Watercut"]] with source-propagated values.

    Ported from notebook cell 15. `structure` = (junction_graph, flowline_order,
    source_flowlines) may be supplied to skip the per-scenario graph rebuild
    (topology is identical across a trunk's scenarios).
    """
    d = df.copy().sort_values(["BranchEquipment", "TotalDistance"])
    if structure is None:
        junction_graph, flowline_order, source_flowlines = build_flow_graph(d)
    else:
        junction_graph, flowline_order, source_flowlines = structure
    flowline_flow, flowline_wc = {}, {}

    for fl in flowline_order:
        fl_mask = d["BranchEquipment"] == fl
        if fl in source_flowlines:
            src_rows = d[fl_mask & (d["node_type"] == 1)]
            if len(src_rows) == 0:
                src_rows = d[fl_mask].head(1)
            Q = float(src_rows["FlowrateLiquidInsitu"].iloc[0])
            Wc = float(src_rows["Watercut"].iloc[0])
        else:
            fed_by = None
            for jcoord, info in junction_graph.items():
                if fl in info["outgoing"]:
                    fed_by = jcoord
                    break
            if fed_by is None:
                Q = float(d.loc[fl_mask, "FlowrateLiquidInsitu"].iloc[0])
                Wc = float(d.loc[fl_mask, "Watercut"].iloc[0])
            else:
                incoming = junction_graph[fed_by]["incoming"]
                outgoing = junction_graph[fed_by]["outgoing"]
                total_in = float(sum(flowline_flow.get(i, 0.0) for i in incoming))
                if total_in > 0:
                    Wc = float(sum(flowline_flow.get(i, 0.0) * flowline_wc.get(i, 0.5)
                                   for i in incoming) / total_in)
                else:
                    Wc = 0.5
                if len(outgoing) <= 1:
                    Q = total_in
                else:
                    key = (fed_by, tuple(sorted(outgoing)))
                    pri = split_priors.get(key, {}) if split_priors is not None else {}
                    ratio = pri.get(fl, None)
                    if ratio is None:
                        ratio = 1.0 / max(len(outgoing), 1)
                    Q = total_in * float(ratio)
        d.loc[fl_mask, "FlowrateLiquidInsitu"] = Q
        d.loc[fl_mask, "Watercut"] = Wc
        flowline_flow[fl] = Q
        flowline_wc[fl] = Wc
    return d[["FlowrateLiquidInsitu", "Watercut"]]


def reconstruct_source_only(df, split_priors, structures=None):
    """Return a copy of df with source-only propagated Flowrate/Watercut, per gsid.

    Reuses one cached flow-graph structure per trunk (topology is scenario-invariant).
    """
    if structures is None:
        structures = build_trunk_structures(df)
    gsid_trunk = df.drop_duplicates(GSID_COL).set_index(GSID_COL)[TRUNK_COL].to_dict()
    out = df.copy()
    for gid, sc in df.groupby(GSID_COL, sort=False):
        struct = structures.get(gsid_trunk.get(gid))
        rec = _reconstruct_source_only_for_scenario(sc, split_priors=split_priors, structure=struct)
        out.loc[rec.index, ["FlowrateLiquidInsitu", "Watercut"]] = rec[["FlowrateLiquidInsitu", "Watercut"]]
    return out


# ===========================================================================
# 5. UNION JUNCTIONS + PER-TRUNK TOPOLOGY REGISTRY
# ===========================================================================
def detect_union_junctions(df, min_flowlines=2, round_decimals=6):
    """Detect real junctions per trunk (one representative scenario each) and
    return the UNION list. Safe because junction coords are unique per trunk.
    """
    detect_junctions_from_nodes = _get_detect_junctions_from_nodes()
    union = []
    for t, sub in df.groupby(TRUNK_COL, sort=False):
        gid0 = sub[GSID_COL].iloc[0]
        scen0 = sub[sub[GSID_COL] == gid0].copy()
        js = detect_junctions_from_nodes(
            scen0, node_id_col="node_id", x_col="long", y_col="lat",
            branch_col="BranchEquipment", round_decimals=round_decimals,
        )
        js = [j for j in js if len(set(j["flowline"])) >= min_flowlines]
        for j in js:
            j = dict(j)
            j["trunk"] = t
            union.append(j)
    return union


def build_topology_registry(df):
    """Per-trunk deployment topology, keyed by trunk name."""
    registry = {}
    for t, sub in df.groupby(TRUNK_COL, sort=False):
        gid0 = sub[GSID_COL].iloc[0]
        scen0 = sub[sub[GSID_COL] == gid0].copy()
        j_graph, flowline_order, source_flowlines = build_flow_graph(scen0)
        sink_fls = scen0.loc[scen0["node_type"] == -1, "BranchEquipment"].unique().tolist()
        jg_ser = {
            f"{k[0]},{k[1]}": {"incoming": v["incoming"], "outgoing": v["outgoing"]}
            for k, v in j_graph.items()
        }
        registry[t] = {
            "trunk": t,
            "template_gsid": gid0,
            "topology_template": scen0.reset_index(drop=True),
            "junction_graph": jg_ser,
            "flowline_order": flowline_order,
            "source_flowlines": source_flowlines,
            "sink_flowlines": sink_fls,
            "n_nodes": int(len(scen0)),
        }
    return registry


def best_model_score(pressure_mae, junction_pressure_error, junction_weight=1.0):
    """Composite selection metric (LOWER is better): Pressure MAE + junction error (psi)."""
    return float(pressure_mae) + float(junction_weight) * float(junction_pressure_error)


def per_trunk_and_overall_report(y_true, y_pred, trunk_of_row):
    """MAE/RMSE per trunk and overall from 1-D pressure arrays (raw psi)."""
    y_true = np.asarray(y_true, float); y_pred = np.asarray(y_pred, float)
    trunk_of_row = np.asarray(trunk_of_row)
    out = {}
    for t in np.unique(trunk_of_row):
        m = trunk_of_row == t; err = y_pred[m] - y_true[m]
        out[str(t)] = {"mae": float(np.mean(np.abs(err))), "rmse": float(np.sqrt(np.mean(err**2))), "n": int(m.sum())}
    err = y_pred - y_true
    out["__overall__"] = {"mae": float(np.mean(np.abs(err))), "rmse": float(np.sqrt(np.mean(err**2))), "n": int(len(err))}
    return out


__all__ = [
    "INPUT_COLS", "OUTPUT_COLS", "TRUNK_COL", "SCENARIO_COL", "GSID_COL", "GSID_SEP",
    "discover_data_file", "load_all_trunks", "prepare_dataframe", "select_scenarios",
    "stratified_split_by_trunk", "build_flow_graph", "build_trunk_structures",
    "fit_junction_split_priors", "reconstruct_source_only", "detect_union_junctions",
    "build_topology_registry", "best_model_score", "per_trunk_and_overall_report",
]
