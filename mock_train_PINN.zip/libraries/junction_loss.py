import torch
import numpy as np
from libraries.cluster_by_junctions import classify_flowline_direction
from libraries.memory_utils import get_device

def compute_junction_losses(model, batch_data, junctions, input_cols, output_cols,
                            input_min, input_max, output_min, output_max,
                            flowline_col="BranchEquipment", node_id_col="node_id",
                            x_col="long", y_col="lat", distance_col="TotalDistance",
                            source_node_type=1, tol=1e-6,
                            pressure_continuity_weight=1.0, mass_conservation_weight=1.0,
                            device=None,
                            epoch=0, total_epochs=100):
    """
    Computes junction-based physics losses based on pressure continuity and mass conservation.
    The function implements curriculum learning by increasing junction complexity during training.

    Parameters:
        model: Torch NN model used to compute predictions.
        batch_data: List of dataframes, one per scenario.
        junctions: List of dictionaries defining junction properties (coords, node_ids, flowlines).
        input_cols, output_cols: Lists defining input and output feature names.
        input_min, input_max, output_min, output_max: Scaling parameters.
        flowline_col, node_id_col: Column names for flowline and node identifiers.
        x_col, y_col: Names for spatial coordinates columns.
        distance_col: Column name for distance measure.
        source_node_type: Identifier for source nodes.
        tol: Tolerance when matching node coordinates to junctions.
        pressure_continuity_weight: Loss weight for pressure continuity.
        mass_conservation_weight: Loss weight for mass conservation.
        device: Device for computation (cpu or cuda).
        epoch: Current epoch number.
        total_epochs: Total number of training epochs.

    Returns:
        total_junction_loss: Weighted combined loss.
        loss_components: Dictionary with individual loss components and junctions processed.
    """

    # Set device if not provided (auto-detect GPU if available)
    if device is None:
        device = get_device(force_cuda=True)

    # Quick exit for empty data or no junctions - return zero loss
    if not batch_data or not junctions:
        zero = torch.tensor(0.0, device=device, requires_grad=True)
        return zero, {'pressure_continuity_loss': 0.0, 'mass_conservation_loss': 0.0}

    # Precompute scaling tensors
    input_min_t  = torch.tensor(input_min,  dtype=torch.float32, device=device)
    input_max_t  = torch.tensor(input_max,  dtype=torch.float32, device=device)
    output_min_t = torch.tensor(output_min, dtype=torch.float32, device=device)
    output_max_t = torch.tensor(output_max, dtype=torch.float32, device=device)
    scale_in = (input_max_t - input_min_t) + 1e-8 # Add epsilon to avoid div-by-zero

    # === CURRICULUM LEARNING ===
    # Sort junctions by complexity (nodes × flowlines)
    # We'll start with simpler junctions and gradually add more complex ones
    sorted_junc = sorted(
        junctions,
        key=lambda j: len(j.get('node_ids', [])) * len(j.get('flowlines', [])))
     # Calculate fraction of curriculum to use based on current epoch
    frac = min(1.0, float(epoch) / float( 0.5 * total_epochs))
    # Determine how many junctions to use in current epoch (minimum 1)
    n_active = max(1, int(len(sorted_junc) * frac))
    # Select the n_active simplest junctions
    active_junctions = sorted_junc[:n_active]

    # Print junction curriculum progress (only once per epoch)
    if getattr(compute_junction_losses, 'last_epoch', -1) != epoch:
        print(f"Epoch {epoch}: Using {n_active}/{len(junctions)} junctions ({frac*100:.1f}% curriculum)")
        compute_junction_losses.last_epoch = epoch

    # Initialize loss accumulators and junction counter
    total_p_loss = torch.tensor(0.0, device=device)
    total_m_loss = torch.tensor(0.0, device=device)
    count = 0
    # Direction-coverage diagnostics (logging only, no effect on the loss).
    # A junction with flow classified in only ONE direction makes
    # rel_mass_error = |in-out|/(|in|+|out|) saturate at 1.0, so its mass term
    # is uninformative. Count these to see how much of avg mass loss is real.
    n_onesided = 0
    n_balanced = 0

    # Loop through each scenario's data
    for scenario_data in batch_data:
        df = scenario_data.reset_index(drop=True)
        coords = df[[x_col, y_col]].values

        # --- Pre-gather ALL junction node indices for this scenario ---
        # This allows a single batched model call instead of per-junction calls
        junction_idx_map = []  # list of (junction, global_indices) tuples
        all_junction_idxs = []

        for junction in active_junctions:
            jc = np.array(junction['coords'])
            dists = np.linalg.norm(coords - jc, axis=1)
            idxs = np.where(dists < tol)[0]
            if idxs.size < 2:
                continue
            junction_idx_map.append((junction, idxs))
            all_junction_idxs.append(idxs)

        if not junction_idx_map:
            continue

        # --- Single batched model call for ALL junction nodes in this scenario ---
        unique_idxs = np.unique(np.concatenate(all_junction_idxs))
        inputs = df.loc[unique_idxs, input_cols].to_numpy(np.float32)
        inp_t = torch.tensor(inputs, device=device)
        scaled = 2.0 * (inp_t - input_min_t) / scale_in - 1.0
        all_preds = model(scaled)  # (n_unique_nodes, n_outputs)

        # Build a mapping from global df index → position in all_preds
        idx_to_pos = {int(gidx): pos for pos, gidx in enumerate(unique_idxs)}

        # --- Unscale ALL predictions at once ---
        phys_preds_all = torch.zeros_like(all_preds, device=device)
        for i, col in enumerate(output_cols):
            norm = (all_preds[:, i] + 1) / 2
            phys_preds_all[:, i] = norm * (output_max_t[i] - output_min_t[i]) + output_min_t[i]

        # --- Scatter results to per-junction losses ---
        for junction, idxs in junction_idx_map:
            # Look up predictions for this junction's nodes
            local_positions = [idx_to_pos[int(gidx)] for gidx in idxs]
            phys_preds = phys_preds_all[local_positions]

            # === PRESSURE CONTINUITY CALCULATION (label-free, normalized space) ===
            # All branches meeting at a junction must share the SAME pressure.
            # Enforce this as a label-free constraint: penalize the spread of the
            # model's OWN predicted pressures across the junction's nodes.
            #   L_cont = Var_k( P_hat_k )   in [0,1] normalized space
            # (The previous version anchored predictions to the measured data mean,
            #  which leaks the ground-truth pressure and is not deployable.)
            if 'Pressure' in output_cols:
                pi = output_cols.index('Pressure')
                pvals = phys_preds[:, pi]
                p_range = output_max_t[pi] - output_min_t[pi] + 1e-8

                # Predicted pressure in [0,1] normalized space
                p_norm_pred = (pvals - output_min_t[pi]) / p_range

                # Variance of predicted pressures at the junction -> 0 at continuity
                if p_norm_pred.numel() >= 2:
                    total_p_loss = total_p_loss + p_norm_pred.var(unbiased=False)

            # === MASS CONSERVATION CALCULATION ===
            # sum(m_dot_in) == sum(m_dot_out) at the junction. Kept in TENSOR space
            # (no .item()) so gradients flow back to the predicted MassFlowrate head.
            if 'MassFlowrate' in output_cols:
                mi = output_cols.index('MassFlowrate')
                inflow = torch.zeros((), device=device)
                outflow = torch.zeros((), device=device)
                n_in = 0
                n_out = 0
                for loc_idx, gid in enumerate(idxs):
                    direction = classify_flowline_direction(
                        df.at[gid, flowline_col],
                        junction['coords'], df, x_col, y_col, distance_col, tol
                    )
                    flow = phys_preds[loc_idx, mi]  # tensor -> preserves gradient
                    if direction == 'incoming':
                        inflow = inflow + flow
                        n_in += 1
                    elif direction == 'outgoing':
                        outflow = outflow + flow
                        n_out += 1
                # Track coverage: a junction with flow on only one side gives a
                # saturated (==1.0) mass error that carries no useful gradient.
                if n_in == 0 or n_out == 0:
                    n_onesided += 1
                else:
                    n_balanced += 1
                total = inflow.abs() + outflow.abs() + 1e-8
                rel_mass_error = (inflow - outflow).abs() / (total + 1e-8)
                total_m_loss = total_m_loss + rel_mass_error ** 2

            count += 1

    if count > 0:
        total_p_loss /= count
        total_m_loss /= count

    loss = pressure_continuity_weight * total_p_loss \
         + mass_conservation_weight * total_m_loss
    components = {
        'pressure_continuity_loss': total_p_loss.item(),
        'mass_conservation_loss':    total_m_loss.item(),
        'n_junctions_processed':     count,
        'n_onesided':                n_onesided,
        'n_balanced':                n_balanced,
    }
    return loss, components
