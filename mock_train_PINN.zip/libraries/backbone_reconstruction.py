"""
Sink-anchored hydrostatic + friction pressure backbone (hard physics constraint).

FRICTION INVERSE (2026-08): friction_mode="per_flowline" in fit_backbone solves
ONE friction multiplier per flowline (ridge-regularised least squares, sparse
fallback to global f0). Reduces exactly to the global backbone when all f0 equal
(Bmat.sum(axis=1) == B_node). Validated on 7C: held-out MAE 2.60->2.37,
RMSE 3.89->3.52, tail>250 MAE 9.26->8.13, bias unchanged (safe over-prediction).

Backbone:  P_bb = P_sink + a_grav*H + f0*B , accumulated sink->node.
    H = sum rho*(z_down-z_up)/144
    B = sum lambda*rho*v^2*dl/(2d)/(gc*144)
"""
from __future__ import annotations
import numpy as np
import pandas as pd

GC = 32.174
PSI = 144.0
BBL_TO_FT3 = 5.6146
DAY_TO_S = 86400.0

FL_COL = "BranchEquipment"
DIST_COL = "TotalDistance"
ELEV_COL = "Elevation"
X_COL, Y_COL = "long", "lat"


def build_directed_graph(topology_df, x_col=X_COL, y_col=Y_COL,
                         branch_col=FL_COL, dist_col=DIST_COL,
                         node_type_col="node_type", round_decimals=6):
    d = topology_df.copy()
    d["_xr"] = d[x_col].round(round_decimals)
    d["_yr"] = d[y_col].round(round_decimals)
    source_fls = d.loc[d[node_type_col] == 1, branch_col].unique().tolist()
    sink_fls = d.loc[d[node_type_col] == -1, branch_col].unique().tolist()
    junction_coords = {}
    for (x, y), grp in d.groupby(["_xr", "_yr"]):
        br = grp[branch_col].unique()
        if len(br) >= 2:
            junction_coords[(x, y)] = list(br)
    jg = {}
    for jc, branches in junction_coords.items():
        inc, out = [], []
        for fl in branches:
            fld = d[d[branch_col] == fl].sort_values(dist_col)
            fc = (round(fld.iloc[0][x_col], round_decimals),
                  round(fld.iloc[0][y_col], round_decimals))
            lc = (round(fld.iloc[-1][x_col], round_decimals),
                  round(fld.iloc[-1][y_col], round_decimals))
            if lc == jc:
                inc.append(fl)
            elif fc == jc:
                out.append(fl)
        jg[jc] = {"incoming": inc, "outgoing": out}
    succ = {fl: [] for fl in d[branch_col].unique()}
    pred = {fl: [] for fl in d[branch_col].unique()}
    for jc, info in jg.items():
        for i in info["incoming"]:
            for o in info["outgoing"]:
                succ[i].append(o)
                pred[o].append(i)
    indeg = {fl: len(pred[fl]) for fl in succ}
    queue = [fl for fl, dg in indeg.items() if dg == 0]
    order = []
    while queue:
        fl = queue.pop(0)
        order.append(fl)
        for s in succ[fl]:
            indeg[s] -= 1
            if indeg[s] == 0:
                queue.append(s)
    return source_fls, (sink_fls[0] if sink_fls else None), jg, order


def velocity_from_flow(flow_bbl_d, diameter_in, density=None, mass_flowrate=None):
    d_ft = np.asarray(diameter_in, float) / 12.0
    area = np.pi * d_ft ** 2 / 4.0
    q_ft3s = np.asarray(flow_bbl_d, float) * BBL_TO_FT3 / DAY_TO_S
    return q_ft3s / np.clip(area, 1e-12, None)


def _flowline_channels(g, vel_col="VelocityLiquid", rho_col="DensityLiquidInSitu",
                       diam_col="PipeInsideDiameter", lam_col="lambda_friction"):
    g = g.sort_values(DIST_COL)
    L = g[DIST_COL].to_numpy(float)
    z = g[ELEV_COL].to_numpy(float)
    v = g[vel_col].to_numpy(float)
    rho = g[rho_col].to_numpy(float)
    d = g[diam_col].to_numpy(float) / 12.0
    lam = g[lam_col].to_numpy(float)
    n = len(g)
    H = np.zeros(n)
    B = np.zeros(n)
    for i in range(n - 1):
        dl = L[i + 1] - L[i]
        if dl <= 0:
            H[i + 1] = H[i]; B[i + 1] = B[i]
            continue
        vv = 0.5 * (v[i] + v[i + 1])
        rr = 0.5 * (rho[i] + rho[i + 1])
        dd = 0.5 * (d[i] + d[i + 1])
        H[i + 1] = H[i] + rr * (z[i + 1] - z[i]) / PSI
        B[i + 1] = B[i] + lam[i] * rr * vv * vv * dl / (2.0 * dd) / (GC * PSI)
    return H, B, g.index.to_numpy()


def backbone_channels(scenario_df, junction_graph, flowline_order, sink_fl,
                      **col_kw):
    prof = {}
    for fl, g in scenario_df.groupby(FL_COL, sort=False):
        if len(g) < 2:
            continue
        prof[fl] = _flowline_channels(g, **col_kw)
    out_junc, in_junc = {}, {}
    for jc, info in junction_graph.items():
        for fl in info["outgoing"]:
            out_junc[fl] = jc
        for fl in info["incoming"]:
            in_junc[fl] = jc
    junc_H, junc_B = {}, {}
    nidx, nH, nB = [], [], []
    for fl in reversed(flowline_order):
        if fl not in prof:
            continue
        H, B, idx = prof[fl]
        if fl == sink_fl:
            hdown, bdown = 0.0, 0.0
        elif fl in in_junc and in_junc[fl] in junc_H:
            hdown, bdown = junc_H[in_junc[fl]], junc_B[in_junc[fl]]
        else:
            hdown, bdown = 0.0, 0.0
        hup, bup = hdown + H[-1], bdown + B[-1]
        if fl in out_junc:
            junc_H[out_junc[fl]] = hup
            junc_B[out_junc[fl]] = bup
        for k, ni in enumerate(idx):
            nidx.append(ni)
            nH.append(hup - H[k])
            nB.append(bup - B[k])
    return np.array(nidx), np.array(nH), np.array(nB)


def backbone_channels_decomp(scenario_df, junction_graph, flowline_order, sink_fl,
                             flowline_index, **col_kw):
    F = len(flowline_index)
    prof = {}
    for fl, g in scenario_df.groupby(FL_COL, sort=False):
        if len(g) < 2:
            continue
        prof[fl] = _flowline_channels(g, **col_kw)
    out_junc, in_junc = {}, {}
    for jc, info in junction_graph.items():
        for fl in info["outgoing"]:
            out_junc[fl] = jc
        for fl in info["incoming"]:
            in_junc[fl] = jc
    junc_H, junc_Bvec = {}, {}
    nidx, nH, rows = [], [], []
    for fl in reversed(flowline_order):
        if fl not in prof:
            continue
        H, B, idx = prof[fl]
        j = flowline_index.get(fl, None)
        if fl == sink_fl:
            hdown = 0.0
            bdown = np.zeros(F)
        elif fl in in_junc and in_junc[fl] in junc_H:
            hdown = junc_H[in_junc[fl]]
            bdown = junc_Bvec[in_junc[fl]]
        else:
            hdown = 0.0
            bdown = np.zeros(F)
        hup = hdown + H[-1]
        bup = bdown.copy()
        if j is not None:
            bup[j] += B[-1]
        if fl in out_junc:
            junc_H[out_junc[fl]] = hup
            junc_Bvec[out_junc[fl]] = bup
        for k, ni in enumerate(idx):
            nidx.append(ni)
            nH.append(hup - H[k])
            row = bup.copy()
            if j is not None:
                row[j] = bup[j] - B[k]
            rows.append(row)
    Bmat = np.array(rows) if rows else np.zeros((0, F))
    return np.array(nidx), np.array(nH), Bmat


def _gather(df, scen_ids, jg, order, sink_fl, scen_col="scenario",
            pressure_col="Pressure", **col_kw):
    H, B, P, idxs = [], [], [], []
    for s in scen_ids:
        sd = df[df[scen_col] == s]
        idx, h, b = backbone_channels(sd, jg, order, sink_fl, **col_kw)
        if len(idx) == 0:
            continue
        H.append(h); B.append(b)
        P.append(sd.loc[idx, pressure_col].to_numpy(float))
        idxs.append(idx)
    return (np.concatenate(H), np.concatenate(B), np.concatenate(P))


def _gather_decomp(df, scen_ids, jg, order, sink_fl, flowline_index,
                   scen_col="scenario", pressure_col="Pressure", **col_kw):
    H, Bm, P = [], [], []
    for s in scen_ids:
        sd = df[df[scen_col] == s]
        idx, h, bmat = backbone_channels_decomp(sd, jg, order, sink_fl, flowline_index, **col_kw)
        if len(idx) == 0:
            continue
        H.append(h); Bm.append(bmat)
        P.append(sd.loc[idx, pressure_col].to_numpy(float))
    return np.concatenate(H), np.concatenate(Bm, axis=0), np.concatenate(P)


def fit_backbone(df, train_scenarios, topology_df=None, sink_pressure=None,
                 fit_gravity_scale=True, friction_mode="global",
                 ridge=1.0, min_obs=200, scen_col="scenario",
                 pressure_col="Pressure", node_type_col="node_type",
                 **col_kw):
    """Fit backbone coefficients on TRAIN nodes.

    friction_mode="global"       -> one f0 for the whole trunk.
    friction_mode="per_flowline" -> friction inverse: one ridge-regularised f0 per
        flowline, sharing a single a_grav; flowlines with < min_obs train node-rows
        fall back to the global f0; ridge pulls each f0 toward the global value.
    """
    if topology_df is None:
        topology_df = df[df[scen_col] == train_scenarios[0]]
    source_fls, sink_fl, jg, order = build_directed_graph(
        topology_df, node_type_col=node_type_col)
    if sink_pressure is None:
        sink_rows = df[(df[scen_col].isin(train_scenarios)) &
                       (df[node_type_col] == -1)]
        sink_pressure = float(sink_rows[pressure_col].mean()) if len(sink_rows) \
            else float(df[df[scen_col].isin(train_scenarios)][pressure_col].min())
    H, B, P = _gather(df, train_scenarios, jg, order, sink_fl,
                      scen_col=scen_col, pressure_col=pressure_col, **col_kw)
    target = P - sink_pressure
    if fit_gravity_scale:
        A = np.stack([H, B], axis=1)
        coef, *_ = np.linalg.lstsq(A, target, rcond=None)
        a_grav, f0 = float(coef[0]), float(coef[1])
    else:
        a_grav = 1.0
        f0 = float((B * (target - H)).sum() / (B * B).sum())
    result = {
        "sink_pressure": sink_pressure, "a_grav": a_grav, "f0": f0,
        "graph": (jg, order, sink_fl), "source_fls": source_fls,
        "friction_mode": "global",
    }
    if friction_mode == "per_flowline":
        fls = sorted(pd.unique(df[FL_COL]))
        flowline_index = {f: i for i, f in enumerate(fls)}
        Hd, Bmat, Pd = _gather_decomp(df, train_scenarios, jg, order, sink_fl,
                                      flowline_index, scen_col=scen_col,
                                      pressure_col=pressure_col, **col_kw)
        y = (Pd - sink_pressure) - a_grav * Hd
        BtB = Bmat.T @ Bmat
        counts = (Bmat != 0).sum(axis=0)
        lam = ridge * np.maximum(counts.max(), 1.0) / np.maximum(counts, 1.0)
        Aridge = BtB + np.diag(lam)
        rhs = Bmat.T @ y + lam * f0
        f0vec = np.linalg.solve(Aridge, rhs)
        f0vec = np.where(counts >= min_obs, f0vec, f0)
        f0_by_flowline = {f: float(f0vec[i]) for f, i in flowline_index.items()}
        predd = sink_pressure + a_grav * Hd + Bmat @ f0vec
        errd = predd - Pd
        r2 = 1 - (errd ** 2).sum() / ((Pd - Pd.mean()) ** 2).sum()
        result.update({
            "friction_mode": "per_flowline",
            "f0_by_flowline": f0_by_flowline,
            "flowline_index": flowline_index,
            "train_r2": float(r2), "train_mae": float(np.abs(errd).mean()),
        })
        return result
    pred = sink_pressure + a_grav * H + f0 * B
    err = pred - P
    r2 = 1 - (err ** 2).sum() / ((P - P.mean()) ** 2).sum()
    result.update({"train_r2": float(r2), "train_mae": float(np.abs(err).mean())})
    return result


def backbone_pressure(scenario_df, coeffs, **col_kw):
    jg, order, sink_fl = coeffs["graph"]
    if coeffs.get("friction_mode") == "per_flowline":
        fidx = coeffs["flowline_index"]
        idx, H, Bmat = backbone_channels_decomp(scenario_df, jg, order, sink_fl,
                                                fidx, **col_kw)
        f0vec = np.array([coeffs["f0_by_flowline"].get(f, coeffs["f0"])
                          for f in sorted(fidx, key=fidx.get)])
        pbb = coeffs["sink_pressure"] + coeffs["a_grav"] * H + Bmat @ f0vec
        return idx, pbb
    idx, H, B = backbone_channels(scenario_df, jg, order, sink_fl, **col_kw)
    pbb = coeffs["sink_pressure"] + coeffs["a_grav"] * H + coeffs["f0"] * B
    return idx, pbb


def add_backbone_columns(df, coeffs, scen_col="scenario",
                         pressure_col="Pressure", out_col="P_backbone",
                         resid_col="P_residual", **col_kw):
    df = df.copy()
    df[out_col] = np.nan
    for s, sd in df.groupby(scen_col, sort=False):
        idx, pbb = backbone_pressure(sd, coeffs, **col_kw)
        df.loc[idx, out_col] = pbb
    if pressure_col in df.columns:
        df[resid_col] = df[pressure_col] - df[out_col]
    return df
