"""
Hybrid FE-GNN-PINN for a trunk pipeline network.

This module implements a Feature-Enriched Graph Neural Network PINN (FE-GNN-PINN)
that structurally encodes the pipeline topology instead of relying only on soft
physics penalties:

  * Message passing along pipe segments  -> pressure at node i depends on its
    neighbours, so dP/dL becomes an edge quantity the network models directly
    (within-flowline coherence by construction).
  * Shared junction node embeddings      -> pressure continuity at junctions is
    near-exact by construction (coincident nodes exchange messages every layer).
  * Node aggregation of edge messages     -> Kirchhoff-style mass balance becomes
    an inductive bias rather than a fought-against penalty.

The physics losses already in the pipeline (momentum on edges, junction
continuity + mass at nodes, sink/source boundary) then ALIGN with the
architecture instead of fighting it.

Design goals / constraints
--------------------------
* NO torch_geometric dependency — message passing is hand-rolled with sparse
  scatter (``index_add_``), which is also lighter for deployment.
* DROP-IN with the existing training / evaluation / inference code, which calls
  ``model(x)`` with ``x`` of shape ``[rows, n_input]`` (scaled to [-1, 1]). The
  model carries the fixed single-scenario graph internally and:
     - when ``rows`` is a whole number of full-scenario blocks (``rows % N == 0``)
       it runs true graph message passing over the (batched) topology;
     - otherwise it falls back to a node-wise forward (encoder + heads, no
       message passing) so arbitrary row sub-batches still produce valid
       pressures. The message-passing weights are trained via the full-scenario
       data-loss forward passes (see ``build_scenario_loader``).
* Hidden activations are tanh / SiLU (swish) only — never ReLU — so autograd
  through the momentum ``dP/dL`` residual stays informative (PINN skill rule).
* Multi-output heads match ``SimpleEnhancedKAN``: output 0 is pressure
  (``pressure_activation``), outputs 1.. are auxiliary closures
  (``aux_activation``). All targets are MinMax-scaled to [-1, 1].
* Optional Fourier feature enrichment on coordinate-like node inputs (reusing
  ``FourierFeatureEnrichment``) makes this a hybrid FE-GNN-PINN.

The graph is IDENTICAL across scenarios (same topology), so it is built once
from a single scenario laid out in the canonical row order used everywhere in
the notebook: ``sort_values(["BranchEquipment", "TotalDistance"])``.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from libraries.kan_architecture import FourierFeatureEnrichment


# ---------------------------------------------------------------------------
#  Graph container
# ---------------------------------------------------------------------------
class PipelineGraph:
    """Fixed single-scenario topology for the trunk network.

    Attributes
    ----------
    n_nodes : int
        Number of nodes per scenario (canonical order).
    edge_index : torch.LongTensor  [2, E]
        Directed edges (both directions are included explicitly). Column k is a
        (src, dst) pair with positions in ``0..n_nodes-1``.
    edge_attr : torch.FloatTensor  [E, n_edge_feat]
        Per-edge features, already standardized (see ``build_pipeline_graph``).
    node_order : np.ndarray  [n_nodes]
        The ``node_id`` sequence defining position -> node identity. Row order of
        any per-scenario input MUST match this (it does when the frame is sorted
        by ["BranchEquipment", "TotalDistance"]).
    is_junction_edge : torch.BoolTensor [E]
        True for junction cross-links, False for in-pipe segment edges.
    """

    def __init__(self, n_nodes, edge_index, edge_attr, node_order, is_junction_edge):
        self.n_nodes = int(n_nodes)
        self.edge_index = edge_index
        self.edge_attr = edge_attr
        self.node_order = node_order
        self.is_junction_edge = is_junction_edge

    @property
    def n_edges(self):
        return int(self.edge_index.shape[1])

    @property
    def n_edge_feat(self):
        return int(self.edge_attr.shape[1])


def build_pipeline_graph(scenario_df, flowline_col="BranchEquipment",
                         distance_col="TotalDistance", x_col="long", y_col="lat",
                         elevation_col="ElevationDifference",
                         diameter_col="PipeInsideDiameter",
                         node_id_col="node_id", round_decimals=6):
    """Build the fixed pipeline graph from a single scenario's topology.

    Edges
    -----
    * In-pipe segments: consecutive nodes within each flowline (sorted by
      distance) are connected -> message passing carries the pressure gradient
      along the pipe, so dP/dL is an explicit edge quantity.
    * Junction cross-links: nodes sharing a (rounded) coordinate are fully
      connected -> coincident junction nodes exchange messages and converge to a
      shared pressure (continuity by construction).

    All edges are added in BOTH directions with direction-aware features
    (signed Δdistance / Δelevation) so up- and down-stream coupling both flow.

    Edge features (columns): [Δdistance, Δelevation, diameter, is_junction].
    The first three are standardized (zero mean / unit std over edges); the
    binary junction flag is left as 0/1.

    Parameters
    ----------
    scenario_df : pd.DataFrame
        One scenario's rows (all nodes). Any canonical/sorted order is accepted;
        the returned ``node_order`` records the exact ordering used.

    Returns
    -------
    PipelineGraph
    """
    df = scenario_df.sort_values([flowline_col, distance_col]).reset_index(drop=True)
    n_nodes = len(df)

    dist = df[distance_col].to_numpy(np.float64)
    elev = df[elevation_col].to_numpy(np.float64)
    diam = df[diameter_col].to_numpy(np.float64)
    node_order = df[node_id_col].to_numpy()

    src_list, dst_list = [], []
    d_dist, d_elev, e_diam, e_junc = [], [], [], []

    def _add_edge(i, j, is_junction):
        # forward i -> j
        src_list.append(i); dst_list.append(j)
        d_dist.append(dist[j] - dist[i])
        d_elev.append(elev[j] - elev[i])
        e_diam.append(0.5 * (diam[i] + diam[j]))
        e_junc.append(1.0 if is_junction else 0.0)
        # reverse j -> i (signed features flip)
        src_list.append(j); dst_list.append(i)
        d_dist.append(dist[i] - dist[j])
        d_elev.append(elev[i] - elev[j])
        e_diam.append(0.5 * (diam[i] + diam[j]))
        e_junc.append(1.0 if is_junction else 0.0)

    # (a) In-pipe segment edges
    for _fl, grp in df.groupby(flowline_col, sort=False):
        pos = grp.index.to_numpy()  # already sorted by distance within the flowline
        for a, b in zip(pos[:-1], pos[1:]):
            _add_edge(int(a), int(b), is_junction=False)

    # (b) Junction cross-links: nodes sharing a rounded coordinate
    xr = df[x_col].round(round_decimals)
    yr = df[y_col].round(round_decimals)
    coord_key = xr.astype(str) + "_" + yr.astype(str)
    for _key, grp in df.groupby(coord_key, sort=False):
        pos = grp.index.to_numpy()
        if len(pos) < 2:
            continue
        for a_i in range(len(pos)):
            for b_i in range(a_i + 1, len(pos)):
                _add_edge(int(pos[a_i]), int(pos[b_i]), is_junction=True)

    if len(src_list) == 0:
        raise ValueError("No edges were built — check topology columns / ordering.")

    edge_index = torch.tensor([src_list, dst_list], dtype=torch.long)
    raw_attr = torch.tensor(
        np.stack([d_dist, d_elev, e_diam], axis=1), dtype=torch.float32
    )
    is_junc = torch.tensor(e_junc, dtype=torch.float32).unsqueeze(1)

    # Standardize the continuous edge features (guard against zero std).
    mean = raw_attr.mean(dim=0, keepdim=True)
    std = raw_attr.std(dim=0, keepdim=True).clamp_min(1e-6)
    std_attr = (raw_attr - mean) / std
    edge_attr = torch.cat([std_attr, is_junc], dim=1)  # [E, 4]

    return PipelineGraph(
        n_nodes=n_nodes,
        edge_index=edge_index,
        edge_attr=edge_attr,
        node_order=node_order,
        is_junction_edge=is_junc.squeeze(1).bool(),
    )


# ---------------------------------------------------------------------------
#  Edge-conditioned message-passing layer (MeshGraphNet / GraphSAGE style)
# ---------------------------------------------------------------------------
class EdgeConditionedMPLayer(nn.Module):
    """One round of edge-conditioned message passing with residual node update.

    message_e   = phi_e([h_src, h_dst, edge_attr])        (SiLU MLP)
    aggregate   = sum | mean | max over incoming messages per node
    h_new       = h + skip_scale * phi_n([h, aggregate])  (SiLU MLP, LayerNorm)

    Smooth (SiLU) activations keep the pressure field twice-differentiable so the
    momentum dP/dL residual carries meaningful gradients. LayerNorm (not batch
    norm) stabilizes the heterogeneous gradient magnitudes from physics losses.

    Aggregation choice matters for this problem: MEAN over-smooths a graph whose
    node target (pressure 35..459 psi) is highly heterogeneous, washing out sharp
    cluster/junction spikes. SUM (default) preserves local magnitude; MAX is the
    most contrast-preserving. The reduction is done with ``scatter_reduce_`` so no
    explicit degree normalization is needed.
    """

    def __init__(self, hidden_dim, edge_dim, skip_scale=0.15, aggregation="sum"):
        super().__init__()
        if aggregation not in ("sum", "mean", "max"):
            raise ValueError(f"aggregation must be sum|mean|max, got {aggregation}")
        self.skip_scale = skip_scale
        self.aggregation = aggregation
        self.edge_mlp = nn.Sequential(
            nn.Linear(2 * hidden_dim + edge_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.node_mlp = nn.Sequential(
            nn.Linear(2 * hidden_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, h, edge_index, edge_attr, deg=None):
        """h: [M, H] flattened nodes; edge_index: [2, Eb]; edge_attr: [Eb, edge_dim].
        ``deg`` is accepted for backward-compat but unused (scatter_reduce handles
        the mean directly)."""
        src, dst = edge_index[0], edge_index[1]
        msg = self.edge_mlp(torch.cat([h[src], h[dst], edge_attr], dim=1))  # [Eb, H]

        M, H = h.shape
        idx = dst.unsqueeze(-1).expand(-1, H)                # [Eb, H]
        agg = torch.zeros(M, H, device=h.device, dtype=h.dtype)
        reduce = {"sum": "sum", "mean": "mean", "max": "amax"}[self.aggregation]
        agg.scatter_reduce_(0, idx, msg, reduce=reduce, include_self=False)

        upd = self.node_mlp(torch.cat([h, agg], dim=1))
        return self.norm(h + self.skip_scale * upd)


# ---------------------------------------------------------------------------
#  Hybrid FE-GNN-PINN
# ---------------------------------------------------------------------------
class FEGNNPINN(nn.Module):
    """Feature-Enriched Graph Neural Network PINN.

    Pipeline: (optional Fourier enrichment) -> node encoder -> K edge-conditioned
    message-passing layers over the fixed topology -> multi-output heads
    (pressure + auxiliary closures).

    Drop-in ``forward(x)`` semantics (x scaled to [-1, 1], shape [rows, n_input]):
      * ``rows % n_nodes == 0`` -> reshape into full-scenario blocks and run true
        graph message passing (batched over the shared topology);
      * otherwise -> node-wise fallback (encoder + heads, no message passing).
    """

    def __init__(self, n_input, n_output, graph: PipelineGraph,
                 hidden_width=128, num_mp_layers=3,
                 pressure_activation="tanh", aux_activation="tanh",
                 enrich_indices=None, n_frequencies=3, fourier_sigma=1.2,
                 use_rff=True, use_fe=True, skip_scale=0.15, seed=0,
                 aggregation="sum", use_jk=True):
        super().__init__()
        self.n_input = n_input
        self.n_output = n_output
        self.n_nodes = graph.n_nodes
        self.pressure_activation_type = pressure_activation
        self.aux_activation_type = aux_activation
        self.use_fe = bool(use_fe and enrich_indices)
        self.use_jk = bool(use_jk)
        self.aggregation = aggregation

        # Fixed topology as buffers (moved by .to(device), saved in state_dict).
        self.register_buffer("edge_index", graph.edge_index)
        self.register_buffer("edge_attr", graph.edge_attr)
        edge_dim = graph.n_edge_feat

        # In-degree per node for mean aggregation (>=1 to avoid div-by-zero).
        deg = torch.zeros(self.n_nodes, 1)
        deg.index_add_(0, graph.edge_index[1], torch.ones(graph.n_edges, 1))
        deg = deg.clamp_min(1.0)
        self.register_buffer("deg_single", deg)

        # Optional Fourier feature enrichment on coordinate-like node inputs.
        if self.use_fe:
            self.enrichment = FourierFeatureEnrichment(
                in_features=n_input, enrich_indices=enrich_indices,
                n_frequencies=n_frequencies, sigma=fourier_sigma,
                use_rff=use_rff, seed=seed,
            )
            enc_in = self.enrichment.out_features
        else:
            self.enrichment = None
            enc_in = n_input

        self.node_encoder = nn.Sequential(
            nn.Linear(enc_in, hidden_width),
            nn.SiLU(),
            nn.Linear(hidden_width, hidden_width),
        )
        self.mp_layers = nn.ModuleList([
            EdgeConditionedMPLayer(hidden_width, edge_dim, skip_scale=skip_scale,
                                   aggregation=aggregation)
            for _ in range(num_mp_layers)
        ])
        # Jumping-Knowledge skip: concatenate the pre-message-passing encoded node
        # features (which carry the per-node FEKAN-Fourier detail) with the final
        # message-passed representation. This preserves sharp cluster/junction
        # spikes that mean/sum aggregation would otherwise smear across neighbours.
        head_in = hidden_width * 2 if self.use_jk else hidden_width
        self.head = nn.Linear(head_in, n_output)

        # Output activations (match SimpleEnhancedKAN convention).
        self.pressure_activation = _make_activation(pressure_activation)
        self.aux_activation = _make_activation(aux_activation)

        # Cache of batched edge tensors keyed by number of scenarios S.
        self._batch_cache = {}

    # -- helpers ------------------------------------------------------------
    def _apply_heads(self, h, z0=None):
        if self.use_jk:
            # z0 = pre-MP encoded features; in the node-wise fallback (no MP) h==z0.
            h = torch.cat([h, z0 if z0 is not None else h], dim=1)
        out = self.head(h)
        if self.n_output > 1:
            pressure = self.pressure_activation(out[:, 0]).unsqueeze(1)
            aux = self.aux_activation(out[:, 1:])
            return torch.cat([pressure, aux], dim=1)
        return self.pressure_activation(out)

    def _encode(self, x):
        return self.node_encoder(self.enrichment(x) if self.use_fe else x)

    def _batched_graph(self, S):
        """Return (edge_index_b [2, S*E], edge_attr_b [S*E, F], deg_b [S*N, 1])
        for S stacked scenarios, cached per S."""
        key = int(S)
        cached = self._batch_cache.get(key)
        dev = self.edge_index.device
        if cached is not None and cached[0].device == dev:
            return cached
        E = self.edge_index.shape[1]
        N = self.n_nodes
        offsets = (torch.arange(S, device=dev) * N).view(S, 1, 1)  # [S,1,1]
        ei = self.edge_index.unsqueeze(0) + offsets                # [S,2,E]
        ei = ei.permute(1, 0, 2).reshape(2, S * E)                 # [2, S*E]
        ea = self.edge_attr.unsqueeze(0).expand(S, E, -1).reshape(S * E, -1)
        deg = self.deg_single.unsqueeze(0).expand(S, N, 1).reshape(S * N, 1)
        cached = (ei.contiguous(), ea.contiguous(), deg.contiguous())
        self._batch_cache[key] = cached
        return cached

    # -- forward ------------------------------------------------------------
    def forward(self, x):
        rows = x.shape[0]
        N = self.n_nodes
        if rows > 0 and rows % N == 0:
            return self._graph_forward(x, rows // N)
        # Fallback: node-wise (no message passing) — keeps arbitrary sub-batches
        # working. MP weights are trained through the full-scenario data forward.
        z0 = self._encode(x)
        return self._apply_heads(z0, z0)

    def _graph_forward(self, x, S):
        edge_index_b, edge_attr_b, deg_b = self._batched_graph(S)
        z0 = self._encode(x)  # [S*N, H] pre-message-passing (JK skip source)
        h = z0
        for layer in self.mp_layers:
            h = layer(h, edge_index_b, edge_attr_b, deg_b)
        return self._apply_heads(h, z0)

    def get_activation_types(self):
        return {"pressure": self.pressure_activation_type,
                "mass_flow": self.aux_activation_type}


def _make_activation(name):
    if name == "tanh":
        return nn.Tanh()
    if name == "silu":
        return nn.SiLU()
    if name == "softplus":
        return nn.Softplus()
    return nn.Identity()


# ---------------------------------------------------------------------------
#  Factory
# ---------------------------------------------------------------------------
def create_fegnn_model(n_input, n_output, graph, hidden_width=128,
                       num_mp_layers=3, pressure_activation="tanh",
                       aux_activation="tanh", enrich_indices=None,
                       n_frequencies=3, fourier_sigma=1.2, use_rff=True,
                       use_fe=True, skip_scale=0.15, seed=0,
                       aggregation="sum", use_jk=True):
    """Create a hybrid FE-GNN-PINN bound to a fixed :class:`PipelineGraph`.

    Parameters mirror ``create_fekan_model`` where they overlap. ``enrich_indices``
    enables the Fourier feature enrichment (hybrid FE-GNN-PINN); pass ``None`` or
    ``use_fe=False`` for a plain GNN-PINN. ``aggregation`` (sum|mean|max) and
    ``use_jk`` (jumping-knowledge node skip) control over-smoothing.
    """
    return FEGNNPINN(
        n_input=n_input, n_output=n_output, graph=graph,
        hidden_width=hidden_width, num_mp_layers=num_mp_layers,
        pressure_activation=pressure_activation, aux_activation=aux_activation,
        enrich_indices=list(enrich_indices) if enrich_indices else None,
        n_frequencies=n_frequencies, fourier_sigma=fourier_sigma,
        use_rff=use_rff, use_fe=use_fe, skip_scale=skip_scale, seed=seed,
        aggregation=aggregation, use_jk=use_jk,
    )


# ---------------------------------------------------------------------------
#  Scenario-graph data loading (full-scenario batches so message passing trains)
# ---------------------------------------------------------------------------
class ScenarioGraphDataset(torch.utils.data.Dataset):
    """Yields one full scenario per item as ``(X_actual[N,·], X_recon[N,·],
    y[N,·])`` with rows in the graph's canonical node order.

    The row-level tensors from the notebook are reshaped to ``[n_scenarios, N,
    ·]`` assuming each contiguous block of ``N`` rows is one scenario in
    ``sort_values(["BranchEquipment", "TotalDistance"])`` order — the same layout
    used everywhere else in the pipeline.
    """

    def __init__(self, X_actual, X_recon, y, n_nodes):
        N = int(n_nodes)
        total = X_actual.shape[0]
        assert total % N == 0, (
            f"Row count {total} is not a multiple of n_nodes={N}; scenarios must "
            "share identical topology / node count for graph batching."
        )
        S = total // N
        self.X_actual = X_actual.view(S, N, -1)
        self.X_recon = X_recon.view(S, N, -1)
        self.y = y.view(S, N, -1)
        self.n_scenarios = S
        self.n_nodes = N

    def __len__(self):
        return self.n_scenarios

    def __getitem__(self, idx):
        return self.X_actual[idx], self.X_recon[idx], self.y[idx]


def _scenario_collate(batch):
    """Stack S scenarios back into flat ``[S*N, ·]`` tensors (graph-batched)."""
    xa = torch.cat([b[0] for b in batch], dim=0)
    xr = torch.cat([b[1] for b in batch], dim=0)
    yy = torch.cat([b[2] for b in batch], dim=0)
    return xa, xr, yy


def build_scenario_loader(X_actual, X_recon, y, n_nodes, batch_scenarios=8,
                          tail_pressure_psi=None, output_min=None,
                          output_max=None, pressure_index=0, tail_gamma=3.0,
                          tail_max_boost=6.0, shuffle=True, seed=42):
    """Build a DataLoader that yields full-scenario graph batches.

    Optionally weights scenarios by their high-pressure (tail) content — the
    node-level tail up-weighting from the row sampler, re-expressed at the
    scenario level (the user-noted rework of ``WeightedRandomSampler``).

    Returns
    -------
    (DataLoader, ScenarioGraphDataset)
    """
    ds = ScenarioGraphDataset(X_actual, X_recon, y, n_nodes)

    sampler = None
    do_shuffle = shuffle
    if tail_pressure_psi is not None and output_min is not None and output_max is not None:
        # Recover physical pressure per node from [-1, 1] scaled y, per scenario.
        omin = float(output_min[pressure_index]); omax = float(output_max[pressure_index])
        y_scaled = ds.y[:, :, pressure_index]                    # [S, N]
        p_psi = (y_scaled + 1.0) * 0.5 * (omax - omin) + omin
        tail_frac = (p_psi > tail_pressure_psi).float().mean(dim=1)  # [S]
        weights = (1.0 + tail_gamma * tail_frac).clamp(max=tail_max_boost).double()
        sampler = torch.utils.data.WeightedRandomSampler(
            weights=weights, num_samples=len(ds), replacement=True
        )
        do_shuffle = False

    g = torch.Generator().manual_seed(seed)
    loader = torch.utils.data.DataLoader(
        ds, batch_size=batch_scenarios, sampler=sampler,
        shuffle=(do_shuffle and sampler is None), collate_fn=_scenario_collate,
        drop_last=False, generator=g,
    )
    return loader, ds
