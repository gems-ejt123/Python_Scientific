import torch
import torch.nn as nn
import torch.nn.functional as F
from libraries.kan_architecture import KAN, EnhancedKAN, SimpleEnhancedKAN, FeatureEnrichedKAN

# Hybrid FE-GNN-PINN (graph-based) — re-exported so callers can keep the
# `from libraries.pinn_models import ...` import style used across the notebooks.
from libraries.gnn_pinn import (  # noqa: F401
    FEGNNPINN,
    PipelineGraph,
    build_pipeline_graph,
    create_fegnn_model,
    build_scenario_loader,
)

#--------------------------------
# Physics-Aware Layer Implementation
#--------------------------------
class PhysicsAwareLayer(nn.Module):
    """
    Physics-Aware Neural Network Layer with regulated skip connections.
    
    This specialized layer includes residual connections that help preserve physical
    information throughout the network, which is critical for properly modeling
    conservation laws and junction constraints in fluid networks.
    
    Features:
    - Normalized skip connections: Allow controlled information flow to prevent loss explosion
    - Improved gradient flow: Create shorter paths for backpropagation
    - Training stability: Help avoid vanishing gradients in deep networks
    
    Parameters:
        in_features (int): Size of input features
        out_features (int): Size of output features
        activation (nn.Module): Activation function to apply
        dropout_rate (float): Dropout rate for regularization (0 = no dropout)
        use_weight_norm (bool): Whether to apply weight normalization
        skip_scale (float): Scaling factor for skip connection (0-1)
    """
    def __init__(self, in_features, out_features, activation=None, 
                 dropout_rate=0.0, use_weight_norm=False, skip_scale=0.3):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features)
        
        # Initial skip connection scaling factor
        self.skip_scale = skip_scale
        
        # Apply weight normalization if requested
        if use_weight_norm:
            self.linear = nn.utils.parametrizations.weight_norm(self.linear)
        
        # Store activation function
        self.activation = activation
        
        # Add dropout if rate > 0
        self.dropout = nn.Dropout(dropout_rate) if dropout_rate > 0 else None
        
        # Add skip connection if dimensions match
        # Otherwise, use a projection to match dimensions
        if in_features == out_features:
            self.skip = nn.Identity()
        else:
            self.skip = nn.Linear(in_features, out_features)
            if use_weight_norm:
                self.skip = nn.utils.parametrizations.weight_norm(self.skip)
        
        # Add layer normalization for numerical stability
        self.norm = nn.LayerNorm(out_features)
        
    def forward(self, x, skip_scaling_factor=None):
        """
        Forward pass with controlled skip connection to preserve physical information
        
        Args:
            x: Input tensor
            skip_scaling_factor: Optional dynamic scaling factor (0-1) for the skip connection
        """
        # Direct path
        out = self.linear(x)
        
        # Apply activation if provided
        if self.activation is not None:
            out = self.activation(out)
            
        # Apply dropout if configured
        if self.dropout is not None:
            out = self.dropout(out)
        
        # Calculate scaling factor for skip connection
        effective_scale = self.skip_scale
        if skip_scaling_factor is not None:
            effective_scale = skip_scaling_factor
            
        # Add regulated skip connection (preserves physical information with controlled influence)
        skip_contribution = self.skip(x) * effective_scale
        out = out + skip_contribution
        
        # Apply layer normalization for stability
        out = self.norm(out)
        
        return out

#--------------------------------
# Surrogate PINN Class
#--------------------------------
class Surrogate_PINN(nn.Module):
    """
    Physics-Informed Neural Network for surrogate modeling of multiphase flow.
    Enhanced with physics-aware layers for better conservation law enforcement.
    
    This network architecture is specifically designed to:
    1. Preserve physical information through regulated skip connections
    2. Better enforce junction constraints (pressure continuity, mass conservation)
    3. Maintain numerical stability in deep configurations
    
    Parameters:
        n_input (int): Number of input features
        n_output (int): Number of output variables
        hidden_layers (list): List defining the size of each hidden layer
        hidden_activation (str): Activation function for hidden layers
        pressure_activation (str): Activation function for pressure output
        weight_norm (bool): Whether to apply weight normalization
        dropout_rate (float): Dropout rate for regularization
    """
    def __init__(self, n_input, n_output, hidden_layers=[64, 128, 256, 128, 64], 
                 hidden_activation="relu", pressure_activation="tanh",
                 weight_norm=False, dropout_rate=0.0):
        super().__init__()
        
        self.n_output = n_output
        self.pressure_activation_type = pressure_activation
        self.hidden_activation_type = hidden_activation
        
        # Set activation functions based on string input
        if hidden_activation == "relu":
            self.hidden_activation = nn.ReLU()
        elif hidden_activation == "tanh":
            self.hidden_activation = nn.Tanh()
        elif hidden_activation == "silu":
            self.hidden_activation = nn.SiLU()
        elif hidden_activation == "leaky_relu":
            self.hidden_activation = nn.LeakyReLU()
        else:
            raise ValueError(f"Unsupported hidden activation: {hidden_activation}")
            
        # Input layer
        self.input_layer = nn.Linear(n_input, hidden_layers[0])
        if weight_norm:
            self.input_layer = nn.utils.parametrizations.weight_norm(self.input_layer)
            
        # Input layer normalization
        self.input_norm = nn.LayerNorm(hidden_layers[0])
            
        # Hidden layers (modified to use PhysicsAwareLayer)
        self.hidden_layers = nn.ModuleList()
        for i in range(len(hidden_layers)-1):
            # Start with smaller skip connection influence in early layers
            initial_skip_scale = 0.1 if i < len(hidden_layers)//2 else 0.2
            
            # Create physics-aware layer instead of standard sequential setup
            # This integrates skip connections to better preserve physical relationships
            physics_layer = PhysicsAwareLayer(
                in_features=hidden_layers[i],
                out_features=hidden_layers[i+1],
                activation=self.hidden_activation,
                dropout_rate=dropout_rate,
                use_weight_norm=weight_norm,
                skip_scale=initial_skip_scale
            )
            self.hidden_layers.append(physics_layer)
            
        # Feature extraction layer
        self.feature_layer = self.hidden_activation
        
        # Output layers with different activations for different outputs
        if n_output >= 2:
            # Pressure output
            if pressure_activation == "silu":
                self.pressure_output = nn.Sequential(
                    nn.Linear(hidden_layers[-1], 1),
                    nn.SiLU()
                )
            elif pressure_activation == "tanh":
                self.pressure_output = nn.Sequential(
                    nn.Linear(hidden_layers[-1], 1),
                    nn.Tanh()
                )
            else:  # linear
                self.pressure_output = nn.Linear(hidden_layers[-1], 1)
                
            # Other outputs (usually flow rates without additional activation)
            self.other_outputs = nn.Linear(hidden_layers[-1], n_output - 1)
        else:
            # Single output with specified activation
            if pressure_activation == "silu":
                self.output_layer = nn.Sequential(
                    nn.Linear(hidden_layers[-1], n_output),
                    nn.SiLU()
                )
            elif pressure_activation == "tanh":
                self.output_layer = nn.Sequential(
                    nn.Linear(hidden_layers[-1], n_output),
                    nn.Tanh()
                )
            else:  # linear
                self.output_layer = nn.Linear(hidden_layers[-1], n_output)
                
        # Training phase tracker
        self.training_phase = 0.0
        
    def set_training_phase(self, phase):
        """
        Update training phase for progressive physics enforcement.
        
        Args:
            phase (float): Training phase between 0 and 1
        """
        self.training_phase = max(0.0, min(1.0, phase))
        
    def forward(self, x, skip_scaling_factor=None):
        """
        Forward pass through the physics-aware network
        
        Args:
            x: Input tensor [batch_size, n_input]
            skip_scaling_factor: Optional global scaling for skip connections
            
        Returns:
            Output tensor [batch_size, n_output]
        """
        # Input layer with normalization
        x = self.input_layer(x)
        x = self.input_norm(x)
        x = self.hidden_activation(x)
        
        # Pass through physics-aware hidden layers
        for i, layer in enumerate(self.hidden_layers):
            # Dynamic skip connection scaling based on training phase
            if skip_scaling_factor is None:
                # Progressive scaling: start conservative, increase with training
                layer_skip_factor = 0.05 + 0.25 * self.training_phase
            else:
                layer_skip_factor = skip_scaling_factor
                
            x = layer(x, skip_scaling_factor=layer_skip_factor)
        
        # Feature extraction
        x = self.feature_layer(x)
        
        # Generate outputs
        if self.n_output >= 2:
            # Separate pressure and other outputs
            pressure = self.pressure_output(x)
            others = self.other_outputs(x)
            output = torch.cat([pressure, others], dim=1)
        else:
            output = self.output_layer(x)
            
        return output

#--------------------------------
# Enhanced PINN Architectures
#--------------------------------

class ResidualPINN(nn.Module):
    """
    Physics-Informed Neural Network with residual connections to improve gradient flow.
    
    Residual connections help mitigate the vanishing gradient problem by providing
    direct pathways for gradients to flow through the network. This is especially
    useful for PINNs that need to capture both high-frequency physics and low-frequency
    behaviors in fluid dynamics simulations.
    
    Parameters:
    -----------
    input_dim : int
        Number of input features (source conditions, node properties, etc.)
    output_dim : int
        Number of output variables (pressure, flow rates, etc.)
    hidden_layers : list
        List of integers defining the width of each hidden layer
    dropout_rate : float
        Dropout probability for regularization (0.0-1.0)
    pressure_activation : str
        Activation function for pressure output ('tanh', 'linear', 'silu')
    hidden_activation : str
        Activation function for hidden layers ('relu', 'tanh', 'silu', etc.)
        
    Notes:
    ------
    - Best suited for deep networks (6+ layers) where gradient flow is a concern
    - Skip connections are only created between layers of matching dimensions
    - First output is assumed to be pressure and gets special activation treatment
    """
    def __init__(self, input_dim, output_dim, hidden_layers=[32, 64, 128, 256, 512, 256, 128, 64], 
                 dropout_rate=0.3, pressure_activation='tanh', hidden_activation='relu'):
        super(ResidualPINN, self).__init__()
        
        self.input_layer = nn.Linear(input_dim, hidden_layers[0])
        self.hidden_layers = nn.ModuleList()
        self.skip_connections = []
        
        # Create hidden layers with skip connections
        for i in range(len(hidden_layers)-1):
            # Regular layer
            self.hidden_layers.append(nn.Linear(hidden_layers[i], hidden_layers[i+1]))
            
            # Add skip connection if input/output dimensions allow
            if i > 0 and hidden_layers[i-1] == hidden_layers[i+1]:
                self.skip_connections.append((i-1, i+1))
                
        self.output_layer = nn.Linear(hidden_layers[-1], output_dim)
        
        # Activation functions
        self.hidden_activation = self._get_activation(hidden_activation)
        self.pressure_activation = self._get_activation(pressure_activation)
        self.dropout = nn.Dropout(dropout_rate)
        
    def _get_activation(self, activation_name):
        """Helper method to get activation function by name"""
        if activation_name.lower() == 'relu':
            return F.relu
        elif activation_name.lower() == 'tanh':
            return torch.tanh
        elif activation_name.lower() == 'silu' or activation_name.lower() == 'swish':
            return F.silu
        elif activation_name.lower() == 'linear':
            return lambda x: x
        else:
            return F.relu
    
    def forward(self, x):
        """
        Forward pass with residual connections.
        
        Parameters:
        -----------
        x : torch.Tensor
            Input tensor of shape [batch_size, input_dim]
            
        Returns:
        --------
        torch.Tensor
            Output tensor of shape [batch_size, output_dim]
            The first column (pressure) uses the pressure_activation,
            while other outputs remain unchanged
        """
        # Store intermediate outputs for skip connections
        layer_outputs = []
        
        # Input layer
        x = self.input_layer(x)
        x = self.hidden_activation(x)
        x = self.dropout(x)
        layer_outputs.append(x)
        
        # Hidden layers with residual connections
        for i, layer in enumerate(self.hidden_layers):
            identity = x
            x = layer(x)
            
            # Add residual connection for certain layer pairs
            for skip_from, skip_to in self.skip_connections:
                if i == skip_to:
                    x = x + layer_outputs[skip_from]
                    
            x = self.hidden_activation(x)
            x = self.dropout(x)
            layer_outputs.append(x)
        
        # Output layer
        x = self.output_layer(x)
        
        # Apply different activation to pressure (assumed to be first output)
        if x.shape[1] > 1:
            x[:, 0] = self.pressure_activation(x[:, 0])
        else:
            x = self.pressure_activation(x)
        
        return x

class BatchNormPINN(nn.Module):
    """
    PINN with batch normalization for enhanced training stability.
    
    Batch normalization helps stabilize training by normalizing layer inputs,
    reducing internal covariate shift and allowing for higher learning rates.
    This is particularly beneficial for PINNs trained on heterogeneous physics data.
    
    Parameters:
    -----------
    input_dim : int
        Number of input features
    output_dim : int
        Number of output variables
    hidden_layers : list
        List of integers defining the width of each hidden layer
    dropout_rate : float
        Dropout probability for regularization
    pressure_activation : str
        Activation function for pressure output
    hidden_activation : str
        Activation function for hidden layers
    """
    def __init__(self, input_dim, output_dim, hidden_layers=[64, 128, 256, 128, 64], 
                 dropout_rate=0.1, pressure_activation='tanh', hidden_activation='relu'):
        super(BatchNormPINN, self).__init__()
        
        # Input layer
        self.input_layer = nn.Linear(input_dim, hidden_layers[0])
        self.input_bn = nn.LayerNorm(hidden_layers[0])  # Using LayerNorm instead of BatchNorm for better stability
        
        # Hidden layers with normalization
        self.hidden_layers = nn.ModuleList()
        self.bn_layers = nn.ModuleList()
        
        for i in range(len(hidden_layers)-1):
            self.hidden_layers.append(nn.Linear(hidden_layers[i], hidden_layers[i+1]))
            self.bn_layers.append(nn.LayerNorm(hidden_layers[i+1]))
        
        # Output layer
        self.output_layer = nn.Linear(hidden_layers[-1], output_dim)
        
        # Activation functions
        self.hidden_activation = self._get_activation(hidden_activation)
        self.pressure_activation = self._get_activation(pressure_activation)
        self.dropout = nn.Dropout(dropout_rate)
        
    def _get_activation(self, activation_name):
        """Helper method to get activation function by name"""
        if activation_name.lower() == 'relu':
            return F.relu
        elif activation_name.lower() == 'tanh':
            return torch.tanh
        elif activation_name.lower() == 'silu' or activation_name.lower() == 'swish':
            return F.silu
        elif activation_name.lower() == 'linear':
            return lambda x: x
        else:
            return F.relu
    
    def forward(self, x):
        """
        Forward pass with batch normalization after each layer
        """
        # Input layer with normalization
        x = self.input_layer(x)
        x = self.input_bn(x)
        x = self.hidden_activation(x)
        x = self.dropout(x)
        
        # Hidden layers with normalization
        for layer, bn_layer in zip(self.hidden_layers, self.bn_layers):
            x = layer(x)
            x = bn_layer(x)
            x = self.hidden_activation(x)
            x = self.dropout(x)
        
        # Output layer
        x = self.output_layer(x)
        
        # Apply different activation to pressure
        if x.shape[1] > 1:
            x[:, 0] = self.pressure_activation(x[:, 0])
        else:
            x = self.pressure_activation(x)
        
        return x

class AdvancedActivationPINN(nn.Module):
    """
    PINN with advanced activation functions for better function approximation.
    
    Uses SiLU (Swish) activation which has shown superior performance for PINNs
    due to its smooth, non-monotonic properties that help capture complex physics.
    
    Parameters:
    -----------
    input_dim : int
        Number of input features
    output_dim : int
        Number of output variables
    hidden_layers : list
        List of integers defining the width of each hidden layer
    dropout_rate : float
        Dropout probability for regularization
    pressure_activation : str
        Activation function for pressure output
    hidden_activation : str
        Activation function for hidden layers (default: 'silu')
    """
    def __init__(self, input_dim, output_dim, hidden_layers=[64, 128, 256, 128, 64], 
                 dropout_rate=0.1, pressure_activation='tanh', hidden_activation='silu'):
        super(AdvancedActivationPINN, self).__init__()
        
        # Input layer
        self.input_layer = nn.Linear(input_dim, hidden_layers[0])
        
        # Hidden layers
        self.hidden_layers = nn.ModuleList()
        for i in range(len(hidden_layers)-1):
            self.hidden_layers.append(nn.Linear(hidden_layers[i], hidden_layers[i+1]))
        
        # Output layer
        self.output_layer = nn.Linear(hidden_layers[-1], output_dim)
        
        # Activation functions
        self.hidden_activation = self._get_activation(hidden_activation)
        self.pressure_activation = self._get_activation(pressure_activation)
        self.dropout = nn.Dropout(dropout_rate)
        
    def _get_activation(self, activation_name):
        """Helper method to get activation function by name"""
        if activation_name.lower() == 'relu':
            return F.relu
        elif activation_name.lower() == 'tanh':
            return torch.tanh
        elif activation_name.lower() == 'silu' or activation_name.lower() == 'swish':
            return F.silu
        elif activation_name.lower() == 'gelu':
            return F.gelu
        elif activation_name.lower() == 'mish':
            return F.mish
        elif activation_name.lower() == 'linear':
            return lambda x: x
        else:
            return F.silu  # Default to SiLU for advanced activation
    
    def forward(self, x):
        """
        Forward pass with advanced activation functions
        """
        # Input layer
        x = self.input_layer(x)
        x = self.hidden_activation(x)
        x = self.dropout(x)
        
        # Hidden layers
        for layer in self.hidden_layers:
            x = layer(x)
            x = self.hidden_activation(x)
            x = self.dropout(x)
        
        # Output layer
        x = self.output_layer(x)
        
        # Apply different activation to pressure
        if x.shape[1] > 1:
            x[:, 0] = self.pressure_activation(x[:, 0])
        else:
            x = self.pressure_activation(x)
        
        return x

class FourierFeaturePINN(nn.Module):
    """
    PINN with Fourier feature embedding for better high-frequency function approximation.
    
    Random Fourier features help neural networks represent high-frequency functions
    more effectively, which is crucial for capturing rapid changes in physical fields.
    
    Parameters:
    -----------
    input_dim : int
        Number of input features
    output_dim : int
        Number of output variables
    hidden_layers : list
        List of integers defining the width of each hidden layer
    dropout_rate : float
        Dropout probability for regularization
    pressure_activation : str
        Activation function for pressure output
    hidden_activation : str
        Activation function for hidden layers
    fourier_features : int
        Number of random Fourier features to generate
    sigma : float
        Standard deviation for random Fourier projection matrix
    """
    def __init__(self, input_dim, output_dim, hidden_layers=[64, 128, 256, 128, 64], 
                 dropout_rate=0.1, pressure_activation='tanh', hidden_activation='relu',
                 fourier_features=10, sigma=1.0):
        super(FourierFeaturePINN, self).__init__()
        
        # Fourier feature embedding
        self.register_buffer('B', torch.randn(input_dim, fourier_features) * sigma)
        
        # Input dimensions are expanded due to Fourier features
        expanded_input_dim = input_dim + 2 * fourier_features
        
        # Input layer
        self.input_layer = nn.Linear(expanded_input_dim, hidden_layers[0])
        
        # Hidden layers
        self.hidden_layers = nn.ModuleList()
        for i in range(len(hidden_layers)-1):
            self.hidden_layers.append(nn.Linear(hidden_layers[i], hidden_layers[i+1]))
        
        # Output layer
        self.output_layer = nn.Linear(hidden_layers[-1], output_dim)
        
        # Activation functions
        self.hidden_activation = self._get_activation(hidden_activation)
        self.pressure_activation = self._get_activation(pressure_activation)
        self.dropout = nn.Dropout(dropout_rate)
        
    def _get_activation(self, activation_name):
        """Helper method to get activation function by name"""
        if activation_name.lower() == 'relu':
            return F.relu
        elif activation_name.lower() == 'tanh':
            return torch.tanh
        elif activation_name.lower() == 'silu' or activation_name.lower() == 'swish':
            return F.silu
        elif activation_name.lower() == 'linear':
            return lambda x: x
        else:
            return F.relu
            
    def fourier_feature_transform(self, x):
        """Transform input using random Fourier features"""
        # Compute Fourier features: [cos(2π * x * B), sin(2π * x * B)]
        proj = torch.matmul(x, self.B) * 2 * torch.pi
        return torch.cat([torch.cos(proj), torch.sin(proj)], dim=-1)
    
    def forward(self, x):
        """
        Forward pass with Fourier feature embedding
        """
        # Apply Fourier feature transform
        fourier_features = self.fourier_feature_transform(x)
        
        # Concatenate original input with Fourier features
        x = torch.cat([x, fourier_features], dim=-1)
        
        # Input layer
        x = self.input_layer(x)
        x = self.hidden_activation(x)
        x = self.dropout(x)
        
        # Hidden layers
        for layer in self.hidden_layers:
            x = layer(x)
            x = self.hidden_activation(x)
            x = self.dropout(x)
        
        # Output layer
        x = self.output_layer(x)
        
        # Apply different activation to pressure
        if x.shape[1] > 1:
            x[:, 0] = self.pressure_activation(x[:, 0])
        else:
            x = self.pressure_activation(x)
        
        return x

class MultiScalePINN(nn.Module):
    """
    PINN with multi-scale architecture for capturing features at different scales.
    
    Uses parallel branches to process information at different scales, then combines
    them for final prediction. This helps capture both local and global patterns.
    
    Parameters:
    -----------
    input_dim : int
        Number of input features
    output_dim : int
        Number of output variables
    hidden_layers : list
        List of integers defining the width of each hidden layer
    dropout_rate : float
        Dropout probability for regularization
    pressure_activation : str
        Activation function for pressure output
    hidden_activation : str
        Activation function for hidden layers
    """
    def __init__(self, input_dim, output_dim, hidden_layers=[64, 128, 256, 128, 64], 
                 dropout_rate=0.1, pressure_activation='tanh', hidden_activation='relu'):
        super(MultiScalePINN, self).__init__()
        
        # Main branch (full resolution)
        self.main_input = nn.Linear(input_dim, hidden_layers[0])
        self.main_hidden = nn.ModuleList()
        for i in range(len(hidden_layers)-1):
            self.main_hidden.append(nn.Linear(hidden_layers[i], hidden_layers[i+1]))
        
        # Coarse branch (reduced features)
        coarse_dim = hidden_layers[0] // 2
        self.coarse_input = nn.Linear(input_dim, coarse_dim)
        self.coarse_hidden = nn.Linear(coarse_dim, coarse_dim)
        
        # Fine branch (detail extraction)
        self.fine_input = nn.Linear(input_dim, hidden_layers[0] // 4)
        self.fine_hidden = nn.Linear(hidden_layers[0] // 4, hidden_layers[0] // 4)
        
        # Combination layer
        combined_features = hidden_layers[-1] + coarse_dim + hidden_layers[0] // 4
        self.combination = nn.Linear(combined_features, output_dim)
        
        # Activation functions
        self.hidden_activation = self._get_activation(hidden_activation)
        self.pressure_activation = self._get_activation(pressure_activation)
        self.dropout = nn.Dropout(dropout_rate)
        
    def _get_activation(self, activation_name):
        """Helper method to get activation function by name"""
        if activation_name.lower() == 'relu':
            return F.relu
        elif activation_name.lower() == 'tanh':
            return torch.tanh
        elif activation_name.lower() == 'silu' or activation_name.lower() == 'swish':
            return F.silu
        elif activation_name.lower() == 'linear':
            return lambda x: x
        else:
            return F.relu
    
    def forward(self, x):
        """
        Forward pass through multi-scale branches
        """
        # Main branch
        main = self.main_input(x)
        main = self.hidden_activation(main)
        main = self.dropout(main)
        
        for layer in self.main_hidden:
            main = layer(main)
            main = self.hidden_activation(main)
            main = self.dropout(main)
        
        # Coarse branch
        coarse = self.coarse_input(x)
        coarse = self.hidden_activation(coarse)
        coarse = self.coarse_hidden(coarse)
        coarse = self.hidden_activation(coarse)
        coarse = self.dropout(coarse)
        
        # Fine branch
        fine = self.fine_input(x)
        fine = self.hidden_activation(fine)
        fine = self.fine_hidden(fine)
        fine = self.hidden_activation(fine)
        fine = self.dropout(fine)
        
        # Combine all branches
        combined = torch.cat([main, coarse, fine], dim=1)
        output = self.combination(combined)
        
        # Apply different activation to pressure
        if output.shape[1] > 1:
            output[:, 0] = self.pressure_activation(output[:, 0])
        else:
            output = self.pressure_activation(output)
        
        return output

class FourierBatchNormPINN(nn.Module):
    """
    PINN with both Fourier feature embedding and batch normalization.
    
    Combines the benefits of Fourier features for high-frequency function approximation
    with the training stability provided by batch normalization.
    
    Parameters:
    -----------
    input_dim : int
        Number of input features
    output_dim : int
        Number of output variables
    hidden_layers : list
        List of integers defining the width of each hidden layer
    dropout_rate : float
        Dropout probability for regularization
    pressure_activation : str
        Activation function for pressure output
    hidden_activation : str
        Activation function for hidden layers
    fourier_features : int
        Number of random Fourier features to generate
    sigma : float
        Standard deviation for random Fourier projection matrix
    """
    def __init__(self, input_dim, output_dim, hidden_layers=[64, 128, 256, 128, 64], 
                 dropout_rate=0.1, pressure_activation='tanh', hidden_activation='relu',
                 fourier_features=10, sigma=0.15):
        super(FourierBatchNormPINN, self).__init__()
        
        self.input_dim = input_dim
        
        # Fourier feature embedding — σ controls the frequency scale.
        # With inputs in [-1, 1], σ=0.15 gives max argument ≈ 2π·0.15·√6 ≈ 2.3 rad
        # (< 1 full cycle), avoiding high-frequency artifacts that destabilize
        # momentum loss dP/dL computation between adjacent nodes.
        self.register_buffer('B', torch.randn(input_dim, fourier_features) * sigma)
        
        # Input dimensions are expanded due to Fourier features
        expanded_input_dim = input_dim + 2 * fourier_features
        
        # Input layer
        self.input_layer = nn.Linear(expanded_input_dim, hidden_layers[0])
        self.input_bn = nn.LayerNorm(hidden_layers[0])
        
        # Hidden layers with batch normalization
        self.hidden_layers = nn.ModuleList()
        self.bn_layers = nn.ModuleList()
        
        for i in range(len(hidden_layers)-1):
            self.hidden_layers.append(nn.Linear(hidden_layers[i], hidden_layers[i+1]))
            self.bn_layers.append(nn.LayerNorm(hidden_layers[i+1]))
        
        # Output layer — takes hidden + raw input (skip connection for DC component)
        self.output_layer = nn.Linear(hidden_layers[-1] + input_dim, output_dim)
        
        # Activation functions
        self.hidden_activation = self._get_activation(hidden_activation)
        self.pressure_activation = self._get_activation(pressure_activation)
        self.dropout = nn.Dropout(dropout_rate)
    
    def _get_activation(self, activation):
        """Helper method to get activation function by name"""
        if activation.lower() == 'relu':
            return F.relu
        elif activation.lower() == 'tanh':
            return torch.tanh
        elif activation.lower() == 'silu' or activation.lower() == 'swish':
            return F.silu
        elif activation.lower() == 'linear':
            return lambda x: x
        else:
            return F.relu
    
    def fourier_feature_transform(self, x):
        """Transform input using random Fourier features"""
        # Compute Fourier features: [cos(2π * x * B), sin(2π * x * B)]
        proj = torch.matmul(x, self.B) * 2 * torch.pi
        return torch.cat([torch.cos(proj), torch.sin(proj)], dim=-1)
    
    def forward(self, x):
        """
        Forward pass with Fourier features, batch normalization, and input skip.
        
        The raw input is concatenated with the last hidden layer before the output
        projection. This gives the output layer direct access to the low-frequency
        (DC) component of the input, so Fourier features only need to learn the
        high-frequency residual — preventing the Fourier basis from dominating
        the pressure prediction and stabilizing dP/dL for momentum loss.
        """
        # Save raw input for skip connection to output layer
        x_raw = x
        
        # Apply Fourier feature transform
        fourier_features = self.fourier_feature_transform(x)
        
        # Concatenate original input with Fourier features
        x = torch.cat([x, fourier_features], dim=-1)
        
        # Input layer with normalization
        x = self.input_layer(x)
        x = self.input_bn(x)
        x = self.hidden_activation(x)
        x = self.dropout(x)
        
        # Hidden layers with normalization
        for layer, bn_layer in zip(self.hidden_layers, self.bn_layers):
            x = layer(x)
            x = bn_layer(x)
            x = self.hidden_activation(x)
            x = self.dropout(x)
        
        # Output layer with raw input skip connection (DC path)
        x = torch.cat([x, x_raw], dim=-1)
        x = self.output_layer(x)
        
        # Apply different activation to pressure
        if x.shape[1] > 1:
            x[:, 0] = self.pressure_activation(x[:, 0])
        else:
            x = self.pressure_activation(x)
        
        return x

class TrunkPINN(nn.Module):
    """
    Individual PINN model for a specific trunk with physics constraints.
    
    This model handles:
    1. Data-driven pressure prediction from source conditions
    2. Momentum conservation along pipe segments
    3. Junction continuity constraints
    4. Sink boundary conditions (minimum pressure)
    """
    
    def __init__(self, trunk_name=None, input_dim=26, output_dim=1, 
                 architecture='fourier', hidden_layers=[64, 128, 256, 512, 128, 64],
                 physics_enabled=False):
        super(TrunkPINN, self).__init__()
        
        self.trunk_name = trunk_name or "default"
        self.physics_enabled = physics_enabled
        self.input_dim = input_dim
        self.output_dim = output_dim
        
        # Create the base PINN model based on architecture type
        if architecture == 'kan':
            self.base_model = create_kan_model(
                n_input=input_dim,
                n_output=output_dim,
                hidden_width=64,
                num_layers=4,
                pressure_activation="tanh",
                kan_implementation="simple_enhanced"
            )
        elif architecture == 'surrogate':
            self.base_model = Surrogate_PINN(
                n_input=input_dim,
                n_output=output_dim,
                hidden_layers=hidden_layers,
                hidden_activation="relu",
                pressure_activation="tanh",
                dropout_rate=0.1
            )
        else:  # Use factory function for other architectures
            self.base_model = create_pinn_model(
                architecture_type=architecture,
                input_dim=input_dim,
                output_dim=output_dim,
                hidden_layers=hidden_layers,
                dropout_rate=0.1,
                pressure_activation='tanh',
                hidden_activation='relu'
            )
        
        # Physics loss weights (can be adjusted during training)
        self.physics_weights = {
            'momentum': 0.0,      # Initially disabled for data-only training
            'junction': 0.0,      # Initially disabled
            'boundary': 0.0       # Initially disabled
        }
        
        # Training statistics
        self.training_stats = {
            'epochs_trained': 0,
            'best_loss': float('inf'),
            'data_loss': [],
            'physics_loss': []
        }
    
    def forward(self, x):
        """Forward pass through the base model"""
        return self.base_model(x)
    
    def enable_physics(self, momentum_weight=0.5, junction_weight=0.8, boundary_weight=1.0):
        """Enable physics constraints with specified weights"""
        self.physics_enabled = True
        self.physics_weights['momentum'] = momentum_weight
        self.physics_weights['junction'] = junction_weight
        self.physics_weights['boundary'] = boundary_weight
        print(f"Physics enabled for {self.trunk_name}: M={momentum_weight}, J={junction_weight}, B={boundary_weight}")
    
    def disable_physics(self):
        """Disable all physics constraints for pure data fitting"""
        self.physics_enabled = False
        for key in self.physics_weights:
            self.physics_weights[key] = 0.0
        print(f"Physics disabled for {self.trunk_name} - pure data fitting mode")
    
    def get_total_loss(self, data_loss, momentum_loss=0.0, junction_loss=0.0, boundary_loss=0.0):
        """Calculate total loss combining data and physics terms"""
        total_loss = data_loss
        
        if self.physics_enabled:
            total_loss += self.physics_weights['momentum'] * momentum_loss
            total_loss += self.physics_weights['junction'] * junction_loss
            total_loss += self.physics_weights['boundary'] * boundary_loss
        
        return total_loss
    
    def get_activation_types(self):
        """
        Return the activation types used by this model
        """
        return {
            "pressure": "tanh",  # Default pressure activation
            "hidden": "relu"     # Default hidden activation
        }


class MultiTrunkPINN(nn.Module):
    """
    Ensemble model managing multiple trunk-specific PINNs with unified interface.
    
    This orchestrator:
    1. Manages individual trunk models
    2. Handles trunk-specific predictions
    3. Enables cross-trunk validation
    4. Provides unified training interface
    """
    
    def __init__(self, trunk_names, input_dim, output_dim=1, architecture='fourier'):
        super(MultiTrunkPINN, self).__init__()
        
        self.trunk_names = trunk_names
        self.input_dim = input_dim
        self.output_dim = output_dim
        
        # Create individual trunk models
        self.trunk_models = nn.ModuleDict()
        for trunk_name in trunk_names:
            self.trunk_models[trunk_name] = TrunkPINN(
                trunk_name=trunk_name,
                input_dim=input_dim,
                output_dim=output_dim,
                architecture=architecture
            )
        
        # Global training statistics
        self.global_stats = {
            'total_epochs': 0,
            'trunk_performance': {},
            'cross_validation_scores': {}
        }
        
        print(f"MultiTrunkPINN created with {len(trunk_names)} trunks: {trunk_names}")
    
    def forward(self, x, trunk_name):
        """Forward pass for specific trunk"""
        if trunk_name not in self.trunk_models:
            raise ValueError(f"Unknown trunk: {trunk_name}")
        return self.trunk_models[trunk_name](x)
    
    def predict_all_trunks(self, trunk_data_dict):
        """Get predictions for all trunks simultaneously"""
        predictions = {}
        for trunk_name, data in trunk_data_dict.items():
            if trunk_name in self.trunk_models:
                predictions[trunk_name] = self.trunk_models[trunk_name](data)
        return predictions
    
    def enable_physics_all(self, **physics_weights):
        """Enable physics for all trunk models"""
        for trunk_model in self.trunk_models.values():
            trunk_model.enable_physics(**physics_weights)
    
    def disable_physics_all(self):
        """Disable physics for all trunk models"""
        for trunk_model in self.trunk_models.values():
            trunk_model.disable_physics()
    
    def get_model_summary(self):
        """Get summary of all trunk models"""
        summary = {}
        for trunk_name, model in self.trunk_models.items():
            summary[trunk_name] = {
                'parameters': sum(p.numel() for p in model.parameters()),
                'physics_enabled': model.physics_enabled,
                'physics_weights': model.physics_weights.copy(),
                'epochs_trained': model.training_stats['epochs_trained']
            }
        return summary


print("✅ Trunk-specific PINN architectures defined")
print("   - TrunkPINN: Individual trunk model with physics constraints")
print("   - MultiTrunkPINN: Ensemble manager for all trunks")
print("=" * 60)

#--------------------------------
# Model Factory Functions
#--------------------------------

def create_pinn_model(architecture_type, input_dim, output_dim, **kwargs):
    """
    Factory function to create different PINN architectures.
    
    This function provides a unified interface for creating various PINN architectures,
    making it easy to experiment with different models without changing the training code.
    
    Parameters:
    -----------
    architecture_type : str
        Type of architecture to create. Options:
        - 'fourier_batchnorm': FourierBatchNormPINN (recommended for most cases)
        - 'residual': ResidualPINN
        - 'batchnorm': BatchNormPINN
        - 'advanced_activation': AdvancedActivationPINN
        - 'fourier': FourierFeaturePINN
        - 'multiscale': MultiScalePINN
    input_dim : int
        Number of input features
    output_dim : int
        Number of output variables
    **kwargs : dict
        Additional arguments passed to the specific architecture
        
    Returns:
    --------
    nn.Module
        Initialized PINN model of the specified architecture
        
    Examples:
    ---------
    >>> model = create_pinn_model('fourier_batchnorm', input_dim=5, output_dim=2, 
    ...                          fourier_features=15, sigma=1.2)
    >>> model = create_pinn_model('residual', input_dim=5, output_dim=2, 
    ...                          hidden_layers=[64, 128, 256, 128, 64])
    """
    # Extract common parameters
    hidden_layers = kwargs.get('hidden_layers', [32, 64, 128, 256, 512, 256, 128, 64])
    dropout_rate = kwargs.get('dropout_rate', 0.3)
    pressure_activation = kwargs.get('pressure_activation', 'tanh')
    hidden_activation = kwargs.get('hidden_activation', 'relu')

    if architecture_type == 'fourier_batchnorm':
        # Explicitly set default values if none provided
        fourier_features = kwargs.get('fourier_features', 10)
        sigma = kwargs.get('sigma', 0.15)
        
        return FourierBatchNormPINN(
            input_dim=input_dim,
            output_dim=output_dim,
            hidden_layers=kwargs.get('hidden_layers', [64, 128, 256, 128, 64]),
            dropout_rate=kwargs.get('dropout_rate', 0.1),
            pressure_activation=kwargs.get('pressure_activation', 'tanh'),
            hidden_activation=kwargs.get('hidden_activation', 'relu'),
            fourier_features=fourier_features,  # Use the explicit variable
            sigma=sigma  # Use the explicit variable
        )
    
    elif architecture_type == 'residual':
        return ResidualPINN(
            input_dim=input_dim,
            output_dim=output_dim,
            hidden_layers=hidden_layers,
            dropout_rate=dropout_rate,
            pressure_activation=pressure_activation,
            hidden_activation=hidden_activation
        )
    elif architecture_type == 'batchnorm':
        return BatchNormPINN(
            input_dim=input_dim,
            output_dim=output_dim,
            hidden_layers=hidden_layers,
            dropout_rate=dropout_rate,
            pressure_activation=pressure_activation,
            hidden_activation=hidden_activation
        )
    elif architecture_type == 'advanced_activation':
        # Default to SiLU for advanced activation if not specified
        if 'hidden_activation' not in kwargs:
            hidden_activation = 'silu'
        return AdvancedActivationPINN(
            input_dim=input_dim,
            output_dim=output_dim,
            hidden_layers=hidden_layers,
            dropout_rate=dropout_rate,
            pressure_activation=pressure_activation,
            hidden_activation=hidden_activation
        )
    elif architecture_type == 'fourier':
        fourier_features = kwargs.get('fourier_features', 10)
        sigma = kwargs.get('sigma', 1.0)
        return FourierFeaturePINN(
            input_dim=input_dim,
            output_dim=output_dim,
            hidden_layers=hidden_layers,
            dropout_rate=dropout_rate,
            pressure_activation=pressure_activation,
            hidden_activation=hidden_activation,
            fourier_features=fourier_features,
            sigma=sigma
        )
    elif architecture_type == 'multiscale':
        return MultiScalePINN(
            input_dim=input_dim,
            output_dim=output_dim,
            hidden_layers=hidden_layers,
            dropout_rate=dropout_rate,
            pressure_activation=pressure_activation,
            hidden_activation=hidden_activation
        )
    else:
        raise ValueError(f"Unknown architecture type: {architecture_type}")


def create_kan_model(n_input, n_output, hidden_width=32, num_layers=2, 
                    spline_degree=3, num_basis=8, pressure_activation="tanh",
                    kan_implementation="simple_enhanced"):
    """
    Creates a KAN model compatible with the existing pipeline.
    
    This factory function allows choosing between different KAN implementations
    based on requirements such as memory constraints and model complexity.
    
    Args:
        n_input (int): Number of input features
        n_output (int): Number of output features (usually 2 - pressure and mass flow)
        hidden_width (int): Width of hidden layers
        num_layers (int): Number of transformation layers
        spline_degree (int): Degree of B-spline basis (usually 3)
        num_basis (int): Number of basis functions per feature
        pressure_activation (str): Activation for pressure output
        kan_implementation (str): Which KAN implementation to use.
                                 Options: "original", "enhanced", "simple_enhanced"
        
    Returns:
        nn.Module: KAN model instance
    """
    # Use the explicitly specified implementation type
    model_type = kan_implementation
    
    if model_type == "original":
        # Original simplified KAN as implemented in previous version
        return KAN(
            n_input=n_input,
            n_output=n_output,
            hidden_width=hidden_width, 
            num_layers=num_layers,
            pressure_activation=pressure_activation
        )
    elif model_type == "enhanced":
        # Full KAN implementation with B-splines for all feature-node combinations
        return EnhancedKAN(
            n_input=n_input,
            n_output=n_output,
            hidden_width=hidden_width,
            num_layers=num_layers,
            spline_degree=spline_degree,
            num_basis=num_basis,
            pressure_activation=pressure_activation
        )
    elif model_type == "simple_enhanced":
        # Memory-efficient KAN that processes features in chunks
        return SimpleEnhancedKAN(
            n_input=n_input,
            n_output=n_output,
            hidden_width=hidden_width,
            num_layers=num_layers,
            spline_degree=spline_degree,
            num_basis=num_basis,
            pressure_activation=pressure_activation
        )
    else:
        raise ValueError(f"Unknown KAN implementation type: {model_type}")


def create_fekan_model(n_input, n_output, hidden_width=128, num_layers=4,
                       spline_degree=3, num_basis=8, pressure_activation="tanh",
                       enrich_indices=(2, 3), n_frequencies=6, fourier_sigma=2.0,
                       use_rff=True, backbone_impl="simple_enhanced", seed=0,
                       aux_activation="softplus"):
    """
    Creates a PI-FEKAN model (Feature-Enriched KAN, arXiv:2602.16530).

    A Fourier feature-enrichment layer is prepended to a KAN backbone to overcome
    the spectral bias that produces within-flowline pressure-gradient errors on
    sharp (cluster / intersection) flowlines. Only the coordinate-like inputs in
    ``enrich_indices`` are enriched; all other inputs pass through raw. The
    enrichment adds NO trainable parameters.

    Args:
        n_input (int): number of original input features.
        n_output (int): number of outputs (pressure [+ mass flow]).
        hidden_width (int): backbone hidden width.
        num_layers (int): backbone transformation layers.
        spline_degree (int): B-spline degree (only used by the 'enhanced' backbone).
        num_basis (int): basis functions per feature (only the 'enhanced' backbone).
        pressure_activation (str): pressure output activation ('tanh'|'silu'|None).
        enrich_indices (sequence[int]): input column indices to enrich.
        n_frequencies (int): Fourier terms m per enriched column.
        fourier_sigma (float): std of N(0, sigma^2) for random Fourier features.
        use_rff (bool): random Fourier features (True) vs deterministic integers.
        backbone_impl (str): 'simple_enhanced' (current MLP) or 'enhanced' (B-spline KAN).
        seed (int): RNG seed for reproducible fixed frequencies.

    Returns:
        nn.Module: FeatureEnrichedKAN instance.
    """
    return FeatureEnrichedKAN(
        n_input=n_input,
        n_output=n_output,
        hidden_width=hidden_width,
        num_layers=num_layers,
        pressure_activation=pressure_activation,
        spline_degree=spline_degree,
        num_basis=num_basis,
        backbone_impl=backbone_impl,
        enrich_indices=tuple(enrich_indices),
        n_frequencies=n_frequencies,
        sigma=fourier_sigma,
        use_rff=use_rff,
        seed=seed,
        aux_activation=aux_activation,
    )
