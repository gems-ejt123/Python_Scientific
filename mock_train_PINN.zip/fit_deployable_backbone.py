"""
fit_deployable_backbone.py  —  per-CPF, per-trunk DEPLOYABLE backbone fit + diagnostic.

Run this on Azure (where the full, confidential CPF1/CPF2 training data lives) BEFORE
committing a bundle. It answers one question empirically: is the per-flowline f0 fit on
the DEPLOYABLE frame (superficial velocity q/A, lambda=1) as good as the f0 fit on the
ACTUAL PIPESIM VelocityLiquid/lambda_friction?  If yes, train==deploy holds for free and
you can trust the saved bundle's backbone anchor.

It reuses the EXACT data prep and fit call from PINN_MultiTrunk_PI-KAN_2026_BADI.ipynb
cell 10, so there is no risk of the diagnostic diverging from training.

Usage (per CPF):
    PINN_BASE_DIR=/path/to/CPF2  python fit_deployable_backbone.py --data data_processed/CPF2.parquet
or edit DATA_PATH below. No torch required — this is the pure backbone path.
"""
from __future__ import annotations
import os, sys, argparse
import numpy as np
import pandas as pd

# --- make ./libraries importable regardless of cwd -------------------------
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from libraries import multitrunk as mt
from libraries import deploy_predict as dp
from libraries.backbone_reconstruction import fit_backbone, add_backbone_columns

# ===========================================================================
# Constants — MUST match the training notebook (cell 3). Override via env.
# ===========================================================================
RHO_OIL_INSITU    = float(os.environ.get("RHO_OIL_INSITU",   46.0))   # lb/ft3
RHO_WATER_INSITU  = float(os.environ.get("RHO_WATER_INSITU", 64.0))   # lb/ft3
SINK_PRESSURE_PSI = float(os.environ.get("SINK_PRESSURE_PSI", 44.7))  # psi Dirichlet BC
M_TO_FT           = 3.280839895
SEED, VAL, BLIND  = 42, 0.10, 0.10                                    # stratified_split_by_trunk


def _fit_one(frame, tr_train, rep_gsid, tag):
    """Fit a per-flowline backbone on `frame` and score it on its train rows.
    Returns (coeffs, r2, mae). `frame` is either the deployable copy or the raw
    (actual-velocity) trunk frame — the ONLY difference between the two calls."""
    topo_df = frame[frame[mt.GSID_COL] == rep_gsid]
    co = fit_backbone(frame, tr_train, topology_df=topo_df,
                      sink_pressure=SINK_PRESSURE_PSI, fit_gravity_scale=True,
                      scen_col=mt.GSID_COL, friction_mode="per_flowline",
                      ridge=1.0, min_obs=200)
    return co, co.get("train_r2", float("nan")), co.get("train_mae", float("nan"))


def run(data_path, verbose=True):
    print(f"\n=== DATA: {data_path} ===")
    df = mt.load_all_trunks(data_path, verbose=verbose)
    df = mt.prepare_dataframe(df, m_to_ft=M_TO_FT, recompute=False, verbose=verbose)
    trunk_structures = mt.build_trunk_structures(df)
    trunks = df[mt.TRUNK_COL].unique().tolist()

    rows = []
    for tr in trunks:
        tdf = df[df[mt.TRUNK_COL] == tr].copy().reset_index(drop=True)
        structures = {tr: trunk_structures[tr]}
        tr_train, tr_val, tr_blind = mt.stratified_split_by_trunk(
            tdf, seed=SEED, val_split=VAL, blind_split=BLIND)
        if not len(tr_train):
            print(f"[skip] {tr}: empty train split"); continue
        rep_gsid = tr_train[0]

        # DEPLOYABLE fit — what the saved bundle uses (velocity=q/A, lambda=1, rho from wc)
        tdf_dep = dp.deployable_backbone_columns(
            tdf, rho_oil=RHO_OIL_INSITU, rho_water=RHO_WATER_INSITU)
        co_dep, r2_dep, mae_dep = _fit_one(tdf_dep, tr_train, rep_gsid, "deploy")

        # ACTUAL fit — reference only (uses PIPESIM VelocityLiquid/lambda_friction)
        co_act, r2_act, mae_act = _fit_one(tdf, tr_train, rep_gsid, "actual")

        f0_dep = np.asarray(co_dep.get("f0_by_flowline", []), float)
        f0_act = np.asarray(co_act.get("f0_by_flowline", []), float)
        f0_ratio = (np.nanmedian(f0_dep / np.where(f0_act == 0, np.nan, f0_act))
                    if f0_dep.size and f0_dep.size == f0_act.size else float("nan"))

        rows.append(dict(trunk=tr, n_train=len(tr_train),
                         r2_dep=r2_dep, mae_dep=mae_dep,
                         r2_act=r2_act, mae_act=mae_act,
                         d_mae=mae_dep - mae_act, f0_ratio_med=f0_ratio,
                         f0_dep=f0_dep, f0_act=f0_act, coeffs_dep=co_dep))

        print(f"\n--- TRUNK {tr}  (train scenarios: {len(tr_train)}) ---")
        print(f"  DEPLOY  fit:  R2={r2_dep:.4f}  MAE={mae_dep:6.2f} psi")
        print(f"  ACTUAL  fit:  R2={r2_act:.4f}  MAE={mae_act:6.2f} psi")
        print(f"  delta MAE (deploy-actual): {mae_dep-mae_act:+.2f} psi   "
              f"| median f0_dep/f0_act: {f0_ratio:.3f}")
        if f0_dep.size:
            with np.printoptions(precision=3, suppress=True):
                print(f"  f0 (deploy):  {f0_dep}")
                print(f"  f0 (actual):  {f0_act}")

    # ---- summary table ----
    if rows:
        summ = pd.DataFrame([{k: r[k] for k in
                              ("trunk", "n_train", "r2_dep", "mae_dep",
                               "r2_act", "mae_act", "d_mae", "f0_ratio_med")}
                             for r in rows])
        print("\n================ SUMMARY (per trunk) ================")
        print(summ.to_string(index=False,
              float_format=lambda v: f"{v:.3f}"))
        print("\nVERDICT: deployable f0 is acceptable where |d_mae| is small "
              "(a few psi) and R2_dep ~ R2_act. Large d_mae on a trunk means "
              "superficial velocity is a poor proxy there (check holdup / GOR).")
    return rows


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=None,
                    help="path to the CPF trunk data file (parquet/csv). "
                         "Defaults to $PINN_BASE_DIR/data_processed/<discovered>.")
    ap.add_argument("--base", default=os.environ.get("PINN_BASE_DIR", HERE))
    args = ap.parse_args()

    data_path = args.data
    if data_path is None:
        data_path = mt.discover_data_file(os.path.join(args.base, "data_processed"))
    if not os.path.isfile(data_path):
        sys.exit(f"data file not found: {data_path}")
    run(data_path)
