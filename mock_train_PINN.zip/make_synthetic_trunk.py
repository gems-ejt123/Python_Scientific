"""
make_synthetic_trunk.py — generate a small, physically-consistent SYNTHETIC trunk you
can feed straight into the BADI pipeline (train / save / digest / diagnostics).

Topology (one trunk, "T1"):

        S1 --FL1-->\
                    J --FL3--> SINK
        S2 --FL2-->/

    two source flowlines (FL1, FL2) merge at a geographic junction J, then a single
    trunk flowline FL3 runs to the sink. This exercises the junction split priors and
    the per-flowline backbone (each flowline gets enough node-rows for its own f0).

Pressures are generated with the SAME backbone physics the model uses
(`backbone_channels`: P = P_sink + a_grav*H + f0*B, with lambda in B), plus light
noise, so `fit_backbone` recovers sensible coefficients and the friction diagnostic
has real signal. Nothing here is real field data.

Output: 13082026/data_processed/T1_synthetic.csv   (100 scenarios)
Run:    python make_synthetic_trunk.py
"""
from __future__ import annotations
import os, sys
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
from libraries.backbone_reconstruction import (
    build_directed_graph, backbone_channels, velocity_from_flow)

# ------------------------------------------------------------------ config ---
N_SCENARIOS   = 100
SEED          = 7
SINK_PRESSURE = 44.7          # psi, Dirichlet anchor at the sink
A_GRAV        = 1.0           # gravity scale used to synthesise pressure
FRICTION_F0   = 0.0273        # base Darcy factor: friction = F0 * lambda * B_lam1
RHO_OIL       = 46.0          # lb/ft3 in-situ
RHO_WATER     = 64.0          # lb/ft3 in-situ
PRESS_NOISE   = 1.5           # psi gaussian noise added to synthetic pressure

# per-flowline geometry: (name, n_nodes, (lon0,lat0), (lon1,lat1),
#                         elev0_ft, elev1_ft, dist_end_ft, diameter_in, lambda_true)
J = (0.020000, 0.010000)      # junction coordinate (shared, exact)
FLOWLINES = [
    ("FL1", 8,  (0.000000, 0.000000), J,                40.0, 25.0, 2200.0, 8.0,  55.0),
    ("FL2", 7,  (0.000000, 0.020000), J,                38.0, 25.0, 1900.0, 6.0,  70.0),
    ("FL3", 12, J,               (0.045000, 0.010000),  25.0,  5.0, 3000.0, 10.0, 45.0),
]
SOURCE_FLS = ["FL1", "FL2"]
SINK_FL    = "FL3"


def _line_nodes():
    """Static per-node geometry (same for every scenario). Returns a DataFrame with
    node_id, BranchEquipment, TotalDistance, Elevation, long, lat, PipeInsideDiameter,
    node_type, lambda_true."""
    rows, nid = [], 0
    for name, n, (x0, y0), (x1, y1), z0, z1, dend, diam, lam in FLOWLINES:
        for k in range(n):
            t = k / (n - 1)
            rows.append(dict(
                node_id=nid, BranchEquipment=name,
                TotalDistance=round(t * dend, 3),
                Elevation=round(z0 + t * (z1 - z0), 4),
                long=round(x0 + t * (x1 - x0), 6),
                lat=round(y0 + t * (y1 - y0), 6),
                PipeInsideDiameter=diam, lambda_true=lam,
                node_type=0,
            ))
            nid += 1
    d = pd.DataFrame(rows)
    # node_type: source = first node of each source flowline; sink = last node of FL3
    for fl in SOURCE_FLS:
        i0 = d.index[d.BranchEquipment == fl].min()
        d.loc[i0, "node_type"] = 1
    isink = d.index[d.BranchEquipment == SINK_FL].max()
    d.loc[isink, "node_type"] = -1
    return d


def _liquid_density(wc):
    return wc * RHO_WATER + (1.0 - wc) * RHO_OIL


def build():
    rng = np.random.default_rng(SEED)
    geom = _line_nodes()

    # topology (identical every scenario) — used to synthesise pressures
    src_fls, sink_fl, jg, order = build_directed_graph(geom)

    frames = []
    for s in range(N_SCENARIOS):
        q1 = float(rng.uniform(5000, 12000))   # FL1 source liquid rate, bbl/d
        q2 = float(rng.uniform(4000, 9000))    # FL2 source liquid rate
        wc1 = float(rng.uniform(0.80, 0.92))
        wc2 = float(rng.uniform(0.80, 0.92))
        q3 = q1 + q2                            # continuity at the junction
        wc3 = (q1 * wc1 + q2 * wc2) / q3        # flow-weighted watercut downstream

        flow_of = {"FL1": q1, "FL2": q2, "FL3": q3}
        wc_of   = {"FL1": wc1, "FL2": wc2, "FL3": wc3}

        d = geom.copy()
        d["Troncal"] = "T1"
        d["scenario"] = s
        d["FlowrateLiquidInsitu"] = d.BranchEquipment.map(flow_of).astype(float)
        d["Watercut"] = d.BranchEquipment.map(wc_of).astype(float)
        d["DensityLiquidInSitu"] = _liquid_density(d["Watercut"].to_numpy())
        d["VelocityLiquid"] = velocity_from_flow(
            d["FlowrateLiquidInsitu"].to_numpy(), d["PipeInsideDiameter"].to_numpy())
        # per-flowline lambda with a little scenario-to-scenario jitter
        lam_jit = {fl: float(np.clip(rng.normal(1.0, 0.04), 0.85, 1.15)) for fl in flow_of}
        d["lambda_friction"] = d["lambda_true"] * d.BranchEquipment.map(lam_jit)
        d["HoldupFractionLiquid"] = np.clip(rng.normal(0.97, 0.01, len(d)), 0.9, 1.0)

        # synthesise pressure from the SAME backbone physics the model uses
        idx, H, B = backbone_channels(d, jg, order, sink_fl)
        P = np.full(len(d), np.nan)
        P[np.asarray(idx)] = SINK_PRESSURE + A_GRAV * H + FRICTION_F0 * B
        P = P + rng.normal(0.0, PRESS_NOISE, len(d))
        d["Pressure"] = P
        frames.append(d)

    out = pd.concat(frames, ignore_index=True).drop(columns=["lambda_true"])
    # column order: identifiers first, then physics
    lead = ["Troncal", "scenario", "node_id", "node_type", "BranchEquipment",
            "TotalDistance", "Elevation", "long", "lat", "PipeInsideDiameter"]
    rest = [c for c in out.columns if c not in lead]
    out = out[lead + rest]

    outdir = os.path.join(HERE, "data_processed")
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, "T1_synthetic.csv")
    out.to_csv(path, index=False)
    print(f"wrote {path}")
    print(f"  {out.shape[0]} rows | {out.scenario.nunique()} scenarios | "
          f"{out.BranchEquipment.nunique()} flowlines | "
          f"nodes/scenario = {len(geom)}")
    print(f"  Pressure range [{out.Pressure.min():.1f}, {out.Pressure.max():.1f}] psi "
          f"(sink anchor {SINK_PRESSURE})")
    return path


if __name__ == "__main__":
    build()
