"""
make_synthetic_trunk.py — generate a small, physically-consistent SYNTHETIC trunk you
can feed straight into the BADI pipeline (train / save / digest / diagnostics).

Topology (one trunk, "T1"):

        S1 --FL1-->\
                    J --FL3--> SINK
        S2 --FL2-->/

    two source flowlines (FL1, FL2) merge at a geographic junction J, then a single
    trunk flowline FL3 runs to the sink. This exercises the junction split priors and
    the per-flowline backbone (each flowline gets enough node-rows for its own f0).

Pressures are generated with PHYSICAL friction consistent with the model's
deployable momentum closure: per segment f = churchill(Re, eps/D) * lambda_mult,
where lambda_mult (~1.0) is a CALIBRATION MULTIPLIER, not the friction factor.
P = P_sink + a_grav*H + friction, plus light noise. Because the same friction
physics generates the data and closes the physics loss, `fit_backbone` recovers a
sensible per-flowline f0 and the KAN residual (the Re-dependence a constant f0
misses) is a real, learnable signal. Nothing here is real field data.

Output: T1_synthetic.csv (next to the notebook, 100 scenarios)
Run:    python make_synthetic_trunk.py
"""
from __future__ import annotations
import os, sys
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
from libraries.backbone_reconstruction import (
    build_directed_graph, backbone_channels, velocity_from_flow)
from libraries.physics_decoder import friction_factor_churchill

# ------------------------------------------------------------------ config ---
N_SCENARIOS   = 100
SEED          = 7
SINK_PRESSURE = 44.7          # psi, Dirichlet anchor at the sink
A_GRAV        = 1.0           # gravity scale used to synthesise pressure
RHO_OIL       = 46.0          # lb/ft3 in-situ
RHO_WATER     = 64.0          # lb/ft3 in-situ
PRESS_NOISE   = 1.5           # psi gaussian noise added to synthetic pressure

# PHYSICAL friction: f = churchill(Re, eps/D) * lambda_mult, where lambda_mult is a
# ~1.0 CALIBRATION MULTIPLIER (NOT the friction factor). mu/roughness match the
# notebook's momentum closure so generator == closure == deployment physics.
LIQ_VISCOSITY_CP  = 2000.0    # in-situ heavy-oil/water emulsion viscosity (Rubiales)
PIPE_ROUGHNESS_IN = 0.0018    # absolute roughness, commercial steel
MU_EFF_LBFTS = LIQ_VISCOSITY_CP / 1488.0   # cP -> lb/ft-s
EPS_FT       = PIPE_ROUGHNESS_IN / 12.0    # in -> ft

# per-flowline geometry: (name, n_nodes, (lon0,lat0), (lon1,lat1),
#                         elev0_ft, elev1_ft, dist_end_ft, diameter_in, lambda_mult)
J = (0.020000, 0.010000)      # junction coordinate (shared, exact)
FLOWLINES = [
    ("FL1", 8,  (0.000000, 0.000000), J,                40.0, 25.0, 2200.0, 8.0,  1.05),
    ("FL2", 7,  (0.000000, 0.020000), J,                38.0, 25.0, 1900.0, 6.0,  1.12),
    ("FL3", 12, J,               (0.045000, 0.010000),  25.0,  5.0, 3000.0, 10.0, 0.95),
]
SOURCE_FLS = ["FL1", "FL2"]
SINK_FL    = "FL3"


def _line_nodes():
    """Static per-node geometry (same for every scenario). Returns a DataFrame with
    node_id, BranchEquipment, TotalDistance, Elevation, long, lat, PipeInsideDiameter,
    node_type, lambda_true."""
    rows, nid = [], 0
    for name, n, (x0, y0), (x1, y1), z0, z1, dend, diam, lam in FLOWLINES:
        for k in range(n):
            t = k / (n - 1)
            rows.append(dict(
                node_id=nid, BranchEquipment=name,
                TotalDistance=round(t * dend, 3),
                Elevation=round(z0 + t * (z1 - z0), 4),
                long=round(x0 + t * (x1 - x0), 6),
                lat=round(y0 + t * (y1 - y0), 6),
                PipeInsideDiameter=diam, lambda_true=lam,
                node_type=0,
            ))
            nid += 1
    d = pd.DataFrame(rows)
    # node_type: source = first node of each source flowline; sink = last node of FL3
    for fl in SOURCE_FLS:
        i0 = d.index[d.BranchEquipment == fl].min()
        d.loc[i0, "node_type"] = 1
    isink = d.index[d.BranchEquipment == SINK_FL].max()
    d.loc[isink, "node_type"] = -1
    return d


def _liquid_density(wc):
    return wc * RHO_WATER + (1.0 - wc) * RHO_OIL


def build():
    rng = np.random.default_rng(SEED)
    geom = _line_nodes()

    # topology (identical every scenario) — used to synthesise pressures
    src_fls, sink_fl, jg, order = build_directed_graph(geom)

    frames = []
    for s in range(N_SCENARIOS):
        q1 = float(rng.uniform(5000, 12000))   # FL1 source liquid rate, bbl/d
        q2 = float(rng.uniform(4000, 9000))    # FL2 source liquid rate
        wc1 = float(rng.uniform(0.80, 0.92))
        wc2 = float(rng.uniform(0.80, 0.92))
        q3 = q1 + q2                            # continuity at the junction
        wc3 = (q1 * wc1 + q2 * wc2) / q3        # flow-weighted watercut downstream

        flow_of = {"FL1": q1, "FL2": q2, "FL3": q3}
        wc_of   = {"FL1": wc1, "FL2": wc2, "FL3": wc3}

        d = geom.copy()
        d["Troncal"] = "T1"
        d["scenario"] = s
        d["FlowrateLiquidInsitu"] = d.BranchEquipment.map(flow_of).astype(float)
        d["Watercut"] = d.BranchEquipment.map(wc_of).astype(float)
        d["DensityLiquidInSitu"] = _liquid_density(d["Watercut"].to_numpy())
        d["VelocityLiquid"] = velocity_from_flow(
            d["FlowrateLiquidInsitu"].to_numpy(), d["PipeInsideDiameter"].to_numpy())
        # per-flowline lambda MULTIPLIER (~1.0) with a little scenario jitter
        lam_jit = {fl: float(np.clip(rng.normal(1.0, 0.04), 0.85, 1.15)) for fl in flow_of}
        d["lambda_friction"] = d["lambda_true"] * d.BranchEquipment.map(lam_jit)
        d["HoldupFractionLiquid"] = np.clip(rng.normal(0.97, 0.01, len(d)), 0.9, 1.0)

        # PHYSICAL friction: Darcy factor f = churchill(Re, eps/D) times the ~1.0
        # lambda multiplier. Fold f into the friction channel (so f0 = 1) => the
        # generator uses the SAME friction the deployable closure computes, so the
        # data target and the physics loss agree (Re-dependence is the learnable signal).
        v   = d["VelocityLiquid"].to_numpy(float)
        rho = d["DensityLiquidInSitu"].to_numpy(float)
        dft = d["PipeInsideDiameter"].to_numpy(float) / 12.0
        Re  = rho * v * dft / MU_EFF_LBFTS
        f_dw = friction_factor_churchill(Re, EPS_FT / dft) * d["lambda_friction"].to_numpy(float)

        d_tmp = d.copy(); d_tmp["lambda_friction"] = f_dw   # channel now carries the full Darcy f
        idx, H, B = backbone_channels(d_tmp, jg, order, sink_fl)
        P = np.full(len(d), np.nan)
        P[np.asarray(idx)] = SINK_PRESSURE + A_GRAV * H + B   # f already in B => f0 = 1
        P = P + rng.normal(0.0, PRESS_NOISE, len(d))
        d["Pressure"] = P
        frames.append(d)

    out = pd.concat(frames, ignore_index=True).drop(columns=["lambda_true"])
    # column order: identifiers first, then physics
    lead = ["Troncal", "scenario", "node_id", "node_type", "BranchEquipment",
            "TotalDistance", "Elevation", "long", "lat", "PipeInsideDiameter"]
    rest = [c for c in out.columns if c not in lead]
    out = out[lead + rest]

    outdir = HERE
    path = os.path.join(outdir, "T1_synthetic.csv")
    out.to_csv(path, index=False)
    print(f"wrote {path}")
    print(f"  {out.shape[0]} rows | {out.scenario.nunique()} scenarios | "
          f"{out.BranchEquipment.nunique()} flowlines | "
          f"nodes/scenario = {len(geom)}")
    print(f"  Pressure range [{out.Pressure.min():.1f}, {out.Pressure.max():.1f}] psi "
          f"(sink anchor {SINK_PRESSURE})")
    return path


if __name__ == "__main__":
    build()
