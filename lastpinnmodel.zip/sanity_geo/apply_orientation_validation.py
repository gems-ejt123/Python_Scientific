"""Add the orientation validation cells to BADI_Liquid_Thermal_CPF2.ipynb.

Run once, from anywhere:

    python sanity_geo/apply_orientation_validation.py --check    # report only, write nothing
    python sanity_geo/apply_orientation_validation.py

The notebook stays in the project root; only this patcher lives in sanity_geo/.
The default --notebook path points one level up, so no argument is needed.

The notebook carries large stored outputs, including the traceback that started
this work, so the patch edits the JSON in place rather than rewriting the file
from source. Every existing output and execution count survives untouched.

The patch is idempotent. Running it twice is a no-op and says so. The original
notebook is copied to BADI_Liquid_Thermal_CPF2.ipynb.bak on the first run only,
so a second run cannot overwrite the pre-patch backup with a patched one.

What it changes, and nothing else:
  1. cell 658810ac      frame.HEAD(10) -> frame.head(10)
  2. cell setup         import orientation_sweep and orientation_summary
  3. cell configuration add RUN_ORIENTATION_SWEEP
  4. new markdown + code cells between 59e6a73e and model-label
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

# sanity_geo/ sits one level below the project root that holds the notebook.
PROJECT_DIR = Path(__file__).resolve().parent.parent
NOTEBOOK = PROJECT_DIR / "BADI_Liquid_Thermal_CPF2.ipynb"

OLD_IMPORT = ("from liquid_badi.data import TRUNKS, inspect_export, load_profiles, "
              "prepare_data, filter_inconsistent_scenarios")
NEW_IMPORT = ("from liquid_badi.data import (TRUNKS, inspect_export, load_profiles, prepare_data,\n"
              "                              filter_inconsistent_scenarios, orientation_sweep, "
              "orientation_summary)")

ANCHOR_SETTING = "COORDINATE_DECIMALS = 8"
NEW_SETTING = ("RUN_ORIENTATION_SWEEP = True  # Re-derive branch direction in every simulation, "
               "not just the reference one.")

MARKDOWN_ID = "orientation-label"
CODE_ID = "orientation-check"

MARKDOWN_SOURCE = """## 2b. Orientation validation

PIPESIM exports each branch in increasing `TotalDistance`. That is a storage convention, not a statement about which way fluid runs, so a branch can be stored back to front. The solver is handed one fixed direction per branch, and when that direction is wrong the cycle solve fails outright with `Cycle solve stalled or requires reversed flow`.

Direction is therefore taken from mass continuity rather than from storage order: at every junction the branch flows have to balance, and that balance fixes which way each branch runs. The rules live in `liquid_badi.data` so that there is exactly one copy of them. Duplicating them in a notebook cell would let the two copies drift apart, which is the same class of failure this fixes.

Two checks run below. The first reports what the reference scenario resolved, and stops if any branch was left undetermined. The second re-derives direction in every simulation, and stops if a branch that is carrying liquid ever reverses. A single fixed orientation cannot represent a branch that genuinely changes direction, and that failure is quiet: the model would not crash, it would train and then predict badly on whichever simulations the direction is wrong for. A branch that never carries flow has no direction to find, so it is reported separately rather than counted as a failure.

The sweep is the slow check. Expect a few minutes across 298 simulations and five trunks. Set `RUN_ORIENTATION_SWEEP = False` in the configuration cell to skip it.

The standalone equivalents of these checks live in `sanity_geo/`."""

CODE_SOURCE = """orientation_audit = {trunk: audit['orientation'] for trunk, audit in prepared.audit['trunks'].items()}
display(pd.DataFrame([{'trunk': trunk,
                       'reversed_vs_storage_order': len(record['reversed_edges']),
                       'unresolved_edges': len(record['unresolved_edges']),
                       'flagged_nodes': len(record['flagged']),
                       'worst_relative_residual': record['worst_relative_continuity_residual'],
                       'worst_node': record['worst_node'],
                       'resolution': record['resolution']}
                      for trunk, record in orientation_audit.items()]))
for trunk, record in orientation_audit.items():
    if record['reversed_edges']:
        print(trunk, '- stored back to front, corrected by continuity:', record['reversed_edges'])
blocking = {trunk: {'unresolved_edges': record['unresolved_edges'], 'flagged': record['flagged']}
            for trunk, record in orientation_audit.items()
            if record['unresolved_edges'] or record['flagged']}
if blocking:
    raise ValueError('Reference-scenario orientation is not fully determined. Continuity could not fix '
                     'a direction for every branch, so the solver would be handed a guess: '
                     + json.dumps(blocking, indent=2, default=str))

if RUN_ORIENTATION_SWEEP:
    orientation_report = orientation_sweep(frame, source_map, seed=SEED,
                                           geometry_tolerance_m=GEOMETRY_TOLERANCE_M,
                                           coordinate_decimals=COORDINATE_DECIMALS,
                                           trunks=set(SELECTED_TRUNKS))
    prepared.audit['orientation_sweep'] = orientation_report
    display(orientation_summary(orientation_report))
    for trunk, record in orientation_report['trunks'].items():
        for entry in record['flipping_edges']:
            print(trunk, '-', entry['edge'], 'reverses in', entry['reversed_scenarios'],
                  'simulations; rate spans', entry['min_rate_bbl_day'], 'to',
                  entry['max_rate_bbl_day'], 'bbl/day; examples', entry['first_examples'])
        if record['unresolved_edges_with_flow']:
            print(trunk, '- carrying flow but direction unresolved:', record['unresolved_edges_with_flow'])
        if record['always_zero_flow_edges']:
            print(trunk, '- never carries flow, direction undefined and harmless:',
                  record['always_zero_flow_edges'])
    if not orientation_report['clean']:
        raise ValueError('At least one branch changes direction across simulations, or continuity did not '
                         'close. One fixed orientation cannot represent that; inspect orientation_report '
                         'before training rather than widening the tolerance.')
    print('Direction is constant across', orientation_report['scenarios_checked'],
          'simulations. Scope:', orientation_report['scope'])
else:
    print('Orientation sweep disabled. Only the reference scenario was checked; a branch that reverses '
          'in another simulation would go unnoticed.')"""


def as_lines(text):
    """nbformat stores source as a list of lines, every line but the last keeping its newline."""
    return text.splitlines(keepends=True)


def as_text(source):
    return source if isinstance(source, str) else "".join(source)


def find(cells, cell_id):
    for index, cell in enumerate(cells):
        if cell.get("id") == cell_id:
            return index, cell
    raise SystemExit(f"Cell id {cell_id!r} is absent. This is not the expected notebook; nothing written.")


def patch(notebook):
    """Return (changes_applied, notes). Mutates notebook only for steps not already present."""
    cells = notebook["cells"]
    applied, notes = [], []

    _, head_cell = find(cells, "658810ac")
    head_text = as_text(head_cell["source"])
    if "frame.HEAD(10)" in head_text:
        head_cell["source"] = as_lines(head_text.replace("frame.HEAD(10)", "frame.head(10)"))
        applied.append("1. frame.HEAD(10) -> frame.head(10)")
    elif "frame.head(10)" in head_text:
        notes.append("1. already reads frame.head(10)")
    else:
        raise SystemExit("Cell 658810ac holds neither frame.HEAD(10) nor frame.head(10); nothing written.")

    _, setup_cell = find(cells, "setup")
    setup_text = as_text(setup_cell["source"])
    if OLD_IMPORT in setup_text:
        setup_cell["source"] = as_lines(setup_text.replace(OLD_IMPORT, NEW_IMPORT))
        applied.append("2. import extended with orientation_sweep, orientation_summary")
    elif "orientation_sweep" in setup_text:
        notes.append("2. import already carries orientation_sweep")
    else:
        raise SystemExit("The expected liquid_badi.data import line is absent from the setup cell; "
                         "nothing written.")

    _, config_cell = find(cells, "configuration")
    config_text = as_text(config_cell["source"])
    if "RUN_ORIENTATION_SWEEP" in config_text:
        notes.append("3. RUN_ORIENTATION_SWEEP already set")
    elif ANCHOR_SETTING in config_text:
        lines = config_text.split("\n")
        at = next(i for i, line in enumerate(lines) if line.strip() == ANCHOR_SETTING)
        lines.insert(at + 1, NEW_SETTING)
        config_cell["source"] = as_lines("\n".join(lines))
        applied.append("3. RUN_ORIENTATION_SWEEP added after COORDINATE_DECIMALS")
    else:
        raise SystemExit(f"{ANCHOR_SETTING!r} is absent from the configuration cell; nothing written.")

    existing = {cell.get("id") for cell in cells}
    if MARKDOWN_ID in existing or CODE_ID in existing:
        notes.append("4. validation cells already present")
    else:
        anchor, _ = find(cells, "model-label")
        after, _ = find(cells, "59e6a73e")
        if anchor != after + 1:
            raise SystemExit("model-label does not directly follow 59e6a73e; the notebook has been "
                             "restructured. Insert the two cells by hand instead. Nothing written.")
        cells[anchor:anchor] = [
            {"cell_type": "markdown", "id": MARKDOWN_ID, "metadata": {},
             "source": as_lines(MARKDOWN_SOURCE)},
            {"cell_type": "code", "id": CODE_ID, "metadata": {}, "execution_count": None,
             "outputs": [], "source": as_lines(CODE_SOURCE)},
        ]
        applied.append("4. markdown + code validation cells inserted before model-label")

    return applied, notes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--notebook", default=str(NOTEBOOK),
                        help="Path to the notebook. Defaults to the one in the parent of sanity_geo/.")
    parser.add_argument("--check", action="store_true", help="Report what would change; write nothing.")
    args = parser.parse_args()

    path = Path(args.notebook)
    if not path.is_file():
        raise SystemExit(f"{path} not found. Pass --notebook explicitly.")

    notebook = json.loads(path.read_text(encoding="utf-8"))
    outputs_before = sum(len(c.get("outputs", [])) for c in notebook["cells"] if c["cell_type"] == "code")
    cells_before = len(notebook["cells"])

    applied, notes = patch(notebook)
    for note in notes:
        print("unchanged:", note)
    for change in applied:
        print("applied:  ", change)
    if not applied:
        print("Nothing to do; the notebook is already patched.")
        return

    outputs_after = sum(len(c.get("outputs", [])) for c in notebook["cells"] if c["cell_type"] == "code")
    if outputs_after != outputs_before:
        raise SystemExit(f"Output count changed {outputs_before} -> {outputs_after}; refusing to write.")
    if len(notebook["cells"]) not in (cells_before, cells_before + 2):
        raise SystemExit("Unexpected cell count change; refusing to write.")

    if args.check:
        print(f"--check: no file written. {len(applied)} change(s) pending, "
              f"{outputs_before} stored outputs would be preserved.")
        return

    backup = path.with_suffix(path.suffix + ".bak")
    if backup.exists():
        print("backup:    already exists, kept as is:", backup.name)
    else:
        shutil.copy2(path, backup)
        print("backup:   ", backup.name)

    # Jupyter's own on-disk convention, so the diff stays small and git-friendly.
    path.write_text(json.dumps(notebook, indent=1, ensure_ascii=False, sort_keys=True) + "\n",
                    encoding="utf-8")

    written = path.read_text(encoding="utf-8")
    reread = json.loads(written)
    assert sum(len(c.get("outputs", [])) for c in reread["cells"] if c["cell_type"] == "code") == outputs_before
    assert "frame.HEAD(10)" not in written
    print(f"written:   {path.name}, {len(reread['cells'])} cells, {outputs_before} stored outputs intact.")
    print("Restart the kernel and run from the setup cell.")


if __name__ == "__main__":
    sys.exit(main())
