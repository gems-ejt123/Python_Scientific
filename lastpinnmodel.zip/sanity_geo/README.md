# sanity_geo

Standalone geometry and orientation checks for the CPF2 liquid BADI network. Nothing
here trains, and nothing here is imported by `liquid_badi/`. Each script adds the
parent folder to `sys.path`, so all three run from any working directory and need no
arguments in the normal case.

The notebook stays in the project root. These are the command-line equivalents of the
checks it runs, useful when you want an answer without starting a kernel.

## check_orientation.py

Builds each trunk twice, once in the exported `TotalDistance` storage order and once
with continuity-derived direction, then prints the worst nodal mass-balance residual
under each. That residual is the evidence: storage order is a convention about how
rows were written, not a statement about which way fluid runs, and where the two
disagree the imbalance shows it.

    python sanity_geo/check_orientation.py

Exit code 0 when every trunk resolves, 1 when something is left unresolved or flagged.

## diagnose_cycles.py

For a trunk with parallel paths, decides from data whether a stalled cycle solve is an
orientation problem or a conditioning problem. It scans each loop coordinate over its
feasible interval and reports whether the loop residual changes sign there. A sign
change means a nonnegative-flow root exists and the step control missed it; no sign
change means the loop genuinely cannot close without reverse flow on some branch.

    python sanity_geo/diagnose_cycles.py --scenarios 5
    python sanity_geo/diagnose_cycles.py --scenarios 5 --output-dir reports/cycles

Also importable from the notebook:

    import sys; sys.path.insert(0, str(PROJECT_DIR / 'sanity_geo'))
    import diagnose_cycles
    report = diagnose_cycles.run(baseline, prepared, scenario_ids=prepared.splits['validation'][:5])

## check_profile_alignment.py

Different failure from the two above. Those ask which way a branch runs; this one asks
whether a branch's state columns describe the same points as its geometry columns. In
`FL RUBI_CLUSTER 52_2` they do not: row i carries the geometry of point i and the pressure,
temperature, watercut and rate of point n-1-i. Pressure is single valued at a junction, so
the evidence is a node where branches that should agree to twelve digits disagree by psi.

For each branch endpoint it compares the branch against the consensus of the other branches
meeting at that node, as stored and with the two ends swapped, and flags a branch only when
swapping wins by a wide margin at both ends in every scenario.

    python sanity_geo/check_profile_alignment.py
    python sanity_geo/check_profile_alignment.py --scenarios 0 1 2 --output-dir reports/alignment

Exit code 0 when every branch is aligned, 1 when one is flagged. It never edits the export.

This script is a command line front end only. The rule lives in
`liquid_badi.preflight.check_profile_alignment`, which is the same copy the notebook runs.

## apply_preflight_section.py

One-shot patcher that puts the sanity-check section into `BADI_Liquid_Thermal_CPF2.ipynb`
and renumbers the headings into the intended execution order: environment and configuration,
data loading and preprocessing, topology and physics sanity checks, ensemble preparation,
training, evaluation. It edits the notebook JSON in place so the stored outputs survive,
refuses to write if the stored-output count would change, backs up to `.ipynb.bak` on first
run, and is idempotent.

    python sanity_geo/apply_preflight_section.py --check
    python sanity_geo/apply_preflight_section.py

The cells it inserts contain calls, tables and one `raise_if_blocking()`, nothing else.

## apply_orientation_validation.py

One-shot patcher that inserts the orientation validation cells into
`BADI_Liquid_Thermal_CPF2.ipynb`. It edits the notebook JSON in place so the stored
outputs survive, backs up to `.ipynb.bak` on first run, and is idempotent.

    python sanity_geo/apply_orientation_validation.py --check
    python sanity_geo/apply_orientation_validation.py

Once the notebook is patched this script has nothing left to do, but it is kept so the
edit it made is auditable rather than folklore.

## Where the rules actually live

None of these scripts reimplements a rule. `_orient_by_continuity`, `orientation_sweep` and
`orientation_summary` are all in `liquid_badi/data.py`; the ten families of input, topology,
physics, split and alignment checks are all in `liquid_badi/preflight.py`; and everything
here, the notebook included, calls into those single copies. A second copy of the rules
would be free to drift out of step with the solver, which is the failure this work fixed.
