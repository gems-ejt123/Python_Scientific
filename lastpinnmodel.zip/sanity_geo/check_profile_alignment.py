"""Find branches whose state columns are stored opposite to their geometry columns.

Motivation, from FL RUBI_CLUSTER 52_2 in trunk 7-7A. Every profile row carries two
independent blocks:

    geometry   TotalDistance, Elevation, long, lat
    state      Pressure, Temperature, Watercut, FlowrateLiquidInsitu, densities

For almost every branch the two blocks describe the same point. For a few they do not:
row i holds the geometry of point i and the state of point n-1-i. Pressure is the giveaway
because it is single valued at a junction, so a misaligned branch reports the far node's
pressure at the near node and a junction that should agree to 1e-12 disagrees by psi.

The test is a comparison, not a threshold. For each branch endpoint, take the consensus
pressure of the *other* branches meeting at that node, then ask whether the branch matches
that consensus better as stored or with its two ends swapped. A branch is flagged only when
swapping is better by a wide margin at both ends and in every scenario checked, which is not
something noise produces.

This file is a command line front end only. The rule itself lives in
`liquid_badi.preflight.check_profile_alignment`, which is the same copy the notebook's
sanity-check section runs, so the two can never disagree. Read only: it trains nothing and
never edits the export.

    python sanity_geo/check_profile_alignment.py
    python sanity_geo/check_profile_alignment.py --scenarios 0 1 2 --trunks RUBIALES_TRONCAL_7-7A
    python sanity_geo/check_profile_alignment.py --export ../data_processed/some_other_export.csv

Exit code 0 when every branch is aligned, 1 when at least one is flagged.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parent.parent
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from liquid_badi.preflight import ALIGNMENT_MARGIN_PSI, check_profile_alignment  # noqa: E402

DEFAULT_EXPORT = "full_data_training_rubiales_CPF2_local_first_10_scenarios.csv"


def load(path):
    """Accept a raw export: add the normalized columns `check_profile_alignment` expects."""
    frame = pd.read_csv(path)
    if "pressure_psia" not in frame:
        frame["pressure_psia"] = frame["Pressure"]
    if "trunk" not in frame:
        frame["trunk"] = frame["Troncal"]
    frame["scenario"] = frame["scenario"].astype(str)
    return frame


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--project-dir", default=str(PROJECT_DIR))
    parser.add_argument("--export", default=DEFAULT_EXPORT)
    parser.add_argument("--trunks", nargs="*", default=None)
    parser.add_argument("--scenarios", nargs="*", default=["0", "1", "2"])
    parser.add_argument("--decimals", type=int, default=8)
    parser.add_argument("--margin-psi", type=float, default=ALIGNMENT_MARGIN_PSI,
                        help="Swapping must beat the stored order by at least this much in every "
                             "scenario before a branch is called misaligned.")
    parser.add_argument("--output-dir", default=None)
    args = parser.parse_args(argv)

    path = Path(args.export)
    if not path.is_absolute():
        path = Path(args.project_dir) / args.export
    frame = load(path)

    report = check_profile_alignment(frame, scenarios=args.scenarios, trunks=args.trunks,
                                     coordinate_decimals=args.decimals,
                                     margin_psi=args.margin_psi)
    summary = report.context.get("alignment_summary")
    if summary is not None:
        print(summary.to_string(index=False))
        print()
    print(report.summary())

    if not report.ok:
        print()
        print("Do not silently reverse these. Confirm each one against the PIPESIM case first; "
              "the export is the suspect, not the simulation.")

    if args.output_dir and summary is not None:
        directory = Path(args.output_dir)
        directory.mkdir(parents=True, exist_ok=True)
        summary.to_csv(directory / "profile_alignment_summary.csv", index=False)
        print("written:", directory / "profile_alignment_summary.csv")

    return 0 if report.ok else 1


if __name__ == "__main__":
    sys.exit(main())
