"""Standalone loop-solver diagnostic for the CPF2 liquid BADI network.

Purpose: decide, from data rather than inspection, why the cycle solve stalls.
It answers one question per trunk and scenario: is the loop closure reachable
with nonnegative branch flows under the exported orientation, or does it
genuinely require reverse flow on a named branch?

This file imports the library read-only. It trains nothing and writes nothing
except the CSV/JSON report you ask for.

Lives in sanity_geo/ and imports liquid_badi from the folder above.

Use inside the notebook, after the `59e6a73e` prepare_data cell:

    import sys; sys.path.insert(0, str(PROJECT_DIR / 'sanity_geo'))
    import diagnose_cycles
    report = diagnose_cycles.run(baseline, prepared,
                                 scenario_ids=prepared.splits['validation'][:5])
    display(report['topology'])
    display(report['scenarios'])

or from a shell, mirroring the notebook configuration exactly:

    python sanity_geo/diagnose_cycles.py --scenarios 5
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import torch

# sanity_geo/ sits one level below the project root that holds liquid_badi/.
PROJECT_DIR = Path(__file__).resolve().parent.parent
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))


def cycle_topology(network):
    """One row per chord edge: which branches close the loop and in which sense."""
    rows = []
    cycles = network.cycles
    for column in range(cycles.shape[1]):
        members = torch.nonzero(cycles[:, column]).flatten().tolist()
        for edge_index in members:
            edge = network.edges[edge_index]
            sign = float(cycles[edge_index, column])
            rows.append({
                "loop": column,
                "edge_id": edge["id"],
                "up": edge["up"],
                "down": edge["down"],
                "sign": sign,
                "role": "chord" if edge_index == members[-1] and sign == 1. else "tree",
                "length_m": float(edge["distance_m"][-1]),
                "elevation_change_m": float(edge["elevation_m"][-1] - edge["elevation_m"][0]),
                "diameter_m_min": float(min(edge["diameter_m"])),
                "diameter_m_max": float(max(edge["diameter_m"])),
            })
    return rows


def _loop_probe(network, rates, watercuts, grid=25, span=4.0):
    """Residual, Jacobian and a feasible scan of the loop-flow coordinates at z=0."""
    source_at = network._inputs(rates, watercuts)
    q0 = network._initial_flows(rates, source_at)

    def residual(z):
        trial = network._transport(q0 + network.cycles @ z, rates, watercuts, source_at)
        return network.cycles.T @ torch.stack([d.sum() for d in trial["drops"]])

    with torch.enable_grad():
        z0 = q0.new_zeros(network.cycles.shape[1], requires_grad=True)
        r0 = residual(z0).detach()
        jac = torch.autograd.functional.jacobian(residual, z0).detach()
    try:
        condition = float(torch.linalg.cond(jac))
    except RuntimeError:
        condition = float("nan")
    try:
        newton = torch.linalg.solve(jac, r0)
        newton_norm = float(newton.abs().max())
    except RuntimeError:
        newton, newton_norm = None, float("nan")

    # Feasible interval of each loop coordinate with the others held at zero.
    intervals, scans = [], []
    for column in range(network.cycles.shape[1]):
        direction = network.cycles[:, column]
        lower, upper = -float("inf"), float("inf")
        for edge_index in range(len(network.edges)):
            coefficient = float(direction[edge_index])
            if coefficient == 0.:
                continue
            limit = -float(q0[edge_index]) / coefficient
            if coefficient > 0:
                lower = max(lower, limit)
            else:
                upper = min(upper, limit)
        intervals.append({
            "loop": column,
            "z_min_m3_s": lower,
            "z_max_m3_s": upper,
            "feasible_width_m3_s": upper - lower,
            "residual_at_zero_pa": float(r0[column]),
        })
        # Sign change of the loop residual inside the feasible interval proves a
        # nonnegative-flow root exists along this coordinate.
        low = lower if np.isfinite(lower) else -span * float(q0.abs().max())
        high = upper if np.isfinite(upper) else span * float(q0.abs().max())
        values = []
        for value in np.linspace(low * 0.999, high * 0.999, grid):
            probe = q0.new_zeros(network.cycles.shape[1])
            probe[column] = float(value)
            with torch.no_grad():
                values.append(float(residual(probe)[column]))
        values = np.asarray(values)
        finite = values[np.isfinite(values)]
        scans.append({
            "loop": column,
            "residual_min_pa": float(finite.min()) if finite.size else float("nan"),
            "residual_max_pa": float(finite.max()) if finite.size else float("nan"),
            "sign_change_in_feasible_interval": bool(
                finite.size and finite.min() < 0. < finite.max()
            ),
        })
    return {
        "q0_min_m3_s": float(q0.min()),
        "q0_max_m3_s": float(q0.max()),
        "zero_flow_branches": int((q0 <= 0).sum()),
        "residual_max_abs_pa": float(r0.abs().max()),
        "jacobian_condition": condition,
        "newton_step_max_m3_s": newton_norm,
        "intervals": intervals,
        "scans": scans,
    }


def run(model, prepared, scenario_ids=None, trunks=None, grid=25):
    """Probe every looped trunk of every requested scenario. Never raises on a stall."""
    scenario_ids = list(scenario_ids or prepared.splits["validation"][:3])
    topology_rows, scenario_rows = [], []
    for trunk, network in model.networks.items():
        if trunks and trunk not in trunks:
            continue
        loops = int(network.cycles.shape[1])
        topology_rows.extend({"trunk": trunk, **row} for row in cycle_topology(network))
        if loops == 0:
            continue
        for scenario in scenario_ids:
            values = prepared.cases[scenario][trunk]
            device = model.physics.table_temperature_k.device
            rates = torch.as_tensor(values["rates_m3_s"], dtype=torch.float64, device=device)
            watercuts = torch.as_tensor(values["watercuts"], dtype=torch.float64, device=device)
            try:
                probe = _loop_probe(network, rates, watercuts, grid=grid)
            except Exception as error:  # diagnostics must survive every failure mode
                scenario_rows.append({"trunk": trunk, "scenario": scenario,
                                      "loop": -1, "error": f"{type(error).__name__}: {error}"})
                continue
            try:
                with torch.no_grad():
                    network(rates, watercuts, validate_pressure=False)
                solved, solve_error = True, ""
            except Exception as error:
                solved, solve_error = False, f"{type(error).__name__}: {error}"
            for interval, scan in zip(probe["intervals"], probe["scans"]):
                scenario_rows.append({
                    "trunk": trunk, "scenario": scenario, "solver_succeeded": solved,
                    "solver_error": solve_error,
                    "source_rate_total_m3_s": float(rates.sum()),
                    "shut_in_sources": int((rates <= 0).sum()),
                    **{k: v for k, v in probe.items() if k not in {"intervals", "scans"}},
                    **interval, **{k: v for k, v in scan.items() if k != "loop"},
                })
    return {"topology": pd.DataFrame(topology_rows),
            "scenarios": pd.DataFrame(scenario_rows)}


def summarize(report):
    """Plain verdict: orientation problem, conditioning problem, or neither."""
    frame = report["scenarios"]
    if frame.empty or "sign_change_in_feasible_interval" not in frame:
        return {"verdict": "no looped trunk was probed"}
    failed = frame.loc[~frame["solver_succeeded"].fillna(False)]
    if failed.empty:
        return {"verdict": "every probed scenario solved", "rows": int(len(frame))}
    reversal = failed.loc[~failed["sign_change_in_feasible_interval"]]
    conditioning = failed.loc[failed["sign_change_in_feasible_interval"]]
    return {
        "verdict": ("orientation: a nonnegative-flow root does not exist"
                    if len(reversal) >= len(conditioning)
                    else "conditioning: a nonnegative-flow root exists but the step control missed it"),
        "failing_rows": int(len(failed)),
        "loops_without_a_feasible_root": int(len(reversal)),
        "loops_with_a_feasible_root": int(len(conditioning)),
        "worst_jacobian_condition": float(failed["jacobian_condition"].max()),
        "trunks": sorted(failed["trunk"].unique().tolist()),
    }


def _build(project_dir, scenarios):
    project_dir = Path(project_dir)
    if str(project_dir) not in sys.path:
        sys.path.insert(0, str(project_dir))
    from liquid_badi.contracts import temperature_kelvin
    from liquid_badi.data import TRUNKS, load_profiles, prepare_data
    from liquid_badi.physics import FluidConfig, LiquidPhysics
    from liquid_badi.pipeline import MultiTrunkModel

    data_file = project_dir.parent / "data_processed/full_data_training_rubiales_CPF2_local.zip"
    member = "full_data_training_rubiales_CPF2_local.csv"
    source_map_file = project_dir.parent / "data_processed/source_branch_mapping_CPF2.csv"
    frame = load_profiles(data_file, "Temperature", "degF", member, list(TRUNKS))
    frame = frame.loc[~frame["scenario"].isin({"92", "110"})].copy()
    prepared = prepare_data(frame, pd.read_csv(source_map_file), seed=2026,
                            source_temperature_tolerance_k=0.1, geometry_tolerance_m=0.1,
                            coordinate_decimals=8, density_unit="lbm/ft3",
                            source_watercut_tolerance=1e-7, source_density_rtol=1e-5)
    pvt = pd.read_csv(project_dir / "pvt_dead_oil_viscosity_transcribed.csv")
    physics = LiquidPhysics(
        FluidConfig(**prepared.audit["fixed_density_constants"],
                    ambient_initial_k=305., ambient_bounds_k=(289., 320.),
                    conductance_initial_w_m_k=2., conductance_bounds_w_m_k=(0.001, 50.),
                    cp_oil_j_kg_k=2000., cp_water_j_kg_k=4180.,
                    water_viscosity_pa_s=0.001, mixing_rule="arithmetic", n_quad=5),
        temperature_kelvin(pvt["temperature_degF"], "degF"),
        pvt["dead_oil_viscosity_cP"].to_numpy() * 0.001, {"kind": "none"})
    model = MultiTrunkModel(prepared.specs, prepared.layouts, physics.export_config(),
                            dict(tolerance_pa=0.01, maximum_iterations=30))
    return model, prepared, prepared.splits["validation"][:scenarios]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-dir", default=str(PROJECT_DIR),
                        help="Folder holding liquid_badi/. Defaults to the parent of sanity_geo/.")
    parser.add_argument("--scenarios", type=int, default=5)
    parser.add_argument("--output-dir", default=None)
    arguments = parser.parse_args()
    model, prepared, scenario_ids = _build(arguments.project_dir, arguments.scenarios)
    report = run(model, prepared, scenario_ids)
    verdict = summarize(report)
    print(json.dumps(verdict, indent=2))
    print(report["topology"].to_string())
    print(report["scenarios"].to_string())
    if arguments.output_dir:
        directory = Path(arguments.output_dir)
        directory.mkdir(parents=True, exist_ok=True)
        report["topology"].to_csv(directory / "cycle_topology.csv", index=False)
        report["scenarios"].to_csv(directory / "cycle_scenarios.csv", index=False)
        with (directory / "cycle_verdict.json").open("w") as stream:
            json.dump(verdict, stream, indent=2)


if __name__ == "__main__":
    main()
