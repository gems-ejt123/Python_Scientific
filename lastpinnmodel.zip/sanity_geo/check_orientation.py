"""Report what the continuity-based edge orientation changes, per trunk.

Read-only. Builds the geometry twice, once with the exported TotalDistance storage
order and once with continuity-derived direction, and prints the difference plus the
nodal mass-balance residual that justifies it.

Lives in sanity_geo/ and imports liquid_badi from the folder above, so it runs from
anywhere:

    python sanity_geo/check_orientation.py
    python sanity_geo/check_orientation.py --export full_data_training_rubiales_CPF2_local_first_10_scenarios.csv
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

# sanity_geo/ sits one level below the project root that holds liquid_badi/.
PROJECT_DIR = Path(__file__).resolve().parent.parent
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from liquid_badi.data import TRUNKS, _geometry, load_profiles
from liquid_badi.evaluation import scenario_split


def build(frame, source_map, trunk, scenario, decimals, tolerance_m, orient):
    trunk_frame = frame.loc[frame["trunk"] == trunk]
    mapping = source_map.loc[source_map["Troncal"] == trunk].copy()
    reference = trunk_frame.loc[trunk_frame["scenario"] == scenario]
    spec, layout, _, _ = _geometry(
        reference, mapping, None, decimals, tolerance_m, orient_by_continuity=orient,
    )
    return spec, layout


def residuals(spec, reference):
    """Relative nodal imbalance using the exported branch rates under spec's direction."""
    rate = {}
    for edge in spec["edges"]:
        values = reference.loc[
            reference["node_id"].astype(str).isin(edge["profile_node_ids"]),
            "FlowrateLiquidInsitu",
        ]
        rate[edge["id"]] = float(values.median())
    balance = {}
    for edge in spec["edges"]:
        balance.setdefault(edge["up"], [0., 0.])[1] += rate[edge["id"]]
        balance.setdefault(edge["down"], [0., 0.])[0] += rate[edge["id"]]
    boundary = {s["node"] for s in spec["sources"].values()} | {spec["sink"]}
    out = {}
    for node, (inflow, outflow) in balance.items():
        if node in boundary:
            continue
        scale = max(inflow, outflow)
        if scale > 0:
            out[node] = abs(inflow - outflow) / scale
    return out


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-dir", default=str(PROJECT_DIR),
                        help="Folder holding liquid_badi/ and the export. Defaults to the parent of sanity_geo/.")
    parser.add_argument("--export", default="full_data_training_rubiales_CPF2_local_first_10_scenarios.csv")
    parser.add_argument("--source-map", default="source_branch_mapping_CPF2.csv")
    parser.add_argument("--temperature-column", default="Temperature")
    parser.add_argument("--temperature-unit", default="degF")
    parser.add_argument("--decimals", type=int, default=8)
    parser.add_argument("--geometry-tolerance-m", type=float, default=0.1)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--trunks", nargs="*", default=None)
    args = parser.parse_args(argv)

    root = Path(args.project_dir)
    trunks = args.trunks or TRUNKS
    frame = load_profiles(
        root / args.export, args.temperature_column, args.temperature_unit, trunks=trunks,
    )
    source_map = pd.read_csv(root / args.source_map)
    scenario = scenario_split(frame["scenario"], seed=args.seed)["train"][0]
    print(f"geometry reference scenario: {scenario}\n")

    clean = True
    for trunk in trunks:
        stored, _ = build(frame, source_map, trunk, scenario,
                          args.decimals, args.geometry_tolerance_m, False)
        fixed, _ = build(frame, source_map, trunk, scenario,
                         args.decimals, args.geometry_tolerance_m, True)
        reference = frame.loc[(frame["trunk"] == trunk) & (frame["scenario"] == scenario)]
        before = residuals(stored, reference)
        after = residuals(fixed, reference)
        audit = fixed["orientation_audit"]

        print(f"=== {trunk} ===")
        print(f"  branches {len(fixed['edges'])}, canonical nodes {len(fixed['nodes'])}")
        print(f"  worst nodal imbalance  stored order {max(before.values(), default=0.):.3%}"
              f"   continuity {max(after.values(), default=0.):.3%}")
        if audit["reversed_edges"]:
            print(f"  reversed ({len(audit['reversed_edges'])}):")
            for edge_id in audit["reversed_edges"]:
                print(f"    {edge_id}")
        else:
            print("  reversed: none, the export was already in flow order")
        if audit["unresolved_edges"]:
            clean = False
            print(f"  UNRESOLVED, kept storage order ({len(audit['unresolved_edges'])}):")
            for edge_id in audit["unresolved_edges"]:
                print(f"    {edge_id}")
        if audit["flagged"]:
            clean = False
            print(f"  FLAGGED ({len(audit['flagged'])}):")
            for note in audit["flagged"]:
                print(f"    {note}")
        worst = max(after.values(), default=0.)
        if worst > 0.02:
            clean = False
            print(f"  RESIDUAL still {worst:.3%} at {audit['worst_node']}")
        print()

    print("all trunks resolved" if clean else "review the flagged entries above")
    return 0 if clean else 1


if __name__ == "__main__":
    sys.exit(main())
