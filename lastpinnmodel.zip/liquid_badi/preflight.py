"""Blocking input, topology and physics checks that run before ensemble preparation.

This module answers one question: is the export safe to train on. It reads data and
reports; it never edits the export, never fits anything, and never widens a tolerance
to make a check pass.

Two entry points, in the order the notebook uses them:

    report = run_preflight(frame, source_map, ...)   # before prepare_data
    report.raise_if_blocking()
    prepared = prepare_data(...)
    verify_prepared(prepared, excluded_scenario_ids).raise_if_blocking()

Every rule the solver depends on lives in `data.py`, and the checks here call into that
single copy rather than restating it. `_geometry` is invoked directly so its own errors
surface as preflight failures with their original wording, and `orientation_sweep` is
invoked for direction constancy. The only rule that originates here is the profile
alignment test, which had no home in the solver because the solver cannot see it.

Three statuses:

    pass   nothing to do
    warn   expected, explained, does not stop training
    fail   blocking; training on this export would be unsound

Short flowlines are warnings, not failures. A physical pipeline is split into separate
flowline records wherever its diameter or condition changes, so a 27 m record between a
15 in and a 23 in section is the export being correct, not the export being broken.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from .contracts import FT_TO_M, IN_TO_M
from .data import GEOMETRY_COLUMNS, PROFILE_COLUMNS, TRUNKS, _coordinate, _geometry, \
    orientation_summary, orientation_sweep
from .evaluation import scenario_split

PASS, WARN, FAIL = "pass", "warn", "fail"

EARTH_RADIUS_M = 6371008.8

#: Outside these, the value cannot be what the column claims to be. Blocking.
HARD_BOUNDS = {
    "pressure_psia": (0.0, 20000.0),
    "temperature_k": (200.0, 500.0),
    "Watercut": (0.0, 1.0),
    "FlowrateLiquidInsitu": (0.0, 1.0e8),
    "PipeInsideDiameter": (0.0, 120.0),
    "DensityOilInSitu": (0.0, 200.0),
    "DensityWaterInSitu": (0.0, 200.0),
}

#: Inside these is ordinary for this field. Outside is worth a look, not a stop.
SOFT_BOUNDS = {
    "pressure_psia": (14.7, 3000.0),
    "temperature_k": (288.0, 400.0),
    "Watercut": (0.0, 1.0),
    "FlowrateLiquidInsitu": (0.0, 3.0e6),
    "PipeInsideDiameter": (1.0, 60.0),
    "DensityOilInSitu": (40.0, 75.0),
    "DensityWaterInSitu": (55.0, 70.0),
    "Elevation": (-100.0, 4000.0),
}

SHORT_SEGMENT_M = 50.0
ALIGNMENT_MARGIN_PSI = 1.0


@dataclass
class Check:
    name: str
    status: str
    message: str
    detail: dict = field(default_factory=dict)


@dataclass
class PreflightReport:
    """A list of checks plus the two things a notebook needs: a table and a stop."""

    checks: list = field(default_factory=list)
    context: dict = field(default_factory=dict)

    def add(self, name, status, message, **detail):
        self.checks.append(Check(name, status, message, detail))
        return self.checks[-1]

    def extend(self, other):
        self.checks.extend(other.checks)
        self.context.update(other.context)
        return self

    @property
    def failures(self):
        return [check for check in self.checks if check.status == FAIL]

    @property
    def warnings(self):
        return [check for check in self.checks if check.status == WARN]

    @property
    def ok(self):
        return not self.failures

    def table(self):
        return pd.DataFrame([
            {"check": check.name, "status": check.status.upper(), "finding": check.message}
            for check in self.checks
        ])

    def summary(self):
        counts = {status: 0 for status in (PASS, WARN, FAIL)}
        for check in self.checks:
            counts[check.status] += 1
        lines = [
            f"preflight: {counts[PASS]} pass, {counts[WARN]} warn, {counts[FAIL]} fail "
            f"({len(self.checks)} checks)",
        ]
        for check in self.warnings:
            lines.append(f"  WARN {check.name}: {check.message}")
        for check in self.failures:
            lines.append(f"  FAIL {check.name}: {check.message}")
        if self.ok and not self.warnings:
            lines.append("  Every check passed. The export is safe to prepare and train on.")
        elif self.ok:
            lines.append("  No blocking failure. The warnings above are expected and explained.")
        else:
            lines.append("  Blocking. Fix the failures above before ensemble preparation.")
        return "\n".join(lines)

    def raise_if_blocking(self):
        if self.ok:
            return self
        detail = "; ".join(f"{check.name}: {check.message}" for check in self.failures)
        raise ValueError(
            f"Preflight failed {len(self.failures)} blocking check(s). Do not prepare the "
            f"ensemble or train until these are resolved. {detail}"
        )


# ---------------------------------------------------------------------------
# 1. Files
# ---------------------------------------------------------------------------

def check_inputs_exist(paths):
    """Every declared input is present, readable and not empty."""
    report = PreflightReport()
    missing, empty, found = [], [], {}
    for label, path in paths.items():
        if path is None:
            continue
        path = Path(path)
        if not path.is_file():
            missing.append(f"{label} -> {path}")
            continue
        size = path.stat().st_size
        found[label] = {"path": str(path), "bytes": size}
        if size == 0:
            empty.append(f"{label} -> {path}")
    if missing:
        report.add("files.present", FAIL, "Missing required input(s): " + "; ".join(missing),
                   missing=missing)
    elif empty:
        report.add("files.present", FAIL, "Zero-byte input(s): " + "; ".join(empty), empty=empty)
    else:
        report.add("files.present", PASS, f"{len(found)} declared input(s) present.", files=found)
    return report


# ---------------------------------------------------------------------------
# 2. Schema, types, nulls, duplicates
# ---------------------------------------------------------------------------

def check_schema(frame, trunks=None):
    """Required columns, numeric types, no nulls, no duplicate profile rows."""
    report = PreflightReport()
    required = list(dict.fromkeys(PROFILE_COLUMNS + ["trunk", "pressure_psia", "temperature_k"]))
    missing = [column for column in required if column not in frame.columns]
    if missing:
        report.add("schema.columns", FAIL,
                   f"Export lacks required column(s) {missing}. load_profiles cannot run.",
                   missing=missing)
        return report
    report.add("schema.columns", PASS, f"All {len(required)} required columns present.")

    numeric = [c for c in GEOMETRY_COLUMNS + [
        "Pressure", "pressure_psia", "Temperature", "temperature_k", "Watercut",
        "FlowrateLiquidInsitu", "DensityOilInSitu", "DensityWaterInSitu", "node_type",
    ] if c in frame.columns]
    non_numeric = [c for c in numeric if not pd.api.types.is_numeric_dtype(frame[c])]
    if non_numeric:
        report.add("schema.dtypes", FAIL,
                   f"Column(s) {non_numeric} did not parse as numeric; check separators and sentinels.",
                   columns=non_numeric)
    else:
        report.add("schema.dtypes", PASS, f"{len(numeric)} physical columns are numeric.")

    null_counts = {c: int(frame[c].isna().sum()) for c in required if frame[c].isna().any()}
    if null_counts:
        report.add("schema.nulls", FAIL,
                   f"Null values in required column(s): {null_counts}.", counts=null_counts)
    else:
        report.add("schema.nulls", PASS, "No nulls in any required column.")

    keys = ["trunk", "scenario", "node_id"]
    duplicated = frame.duplicated(subset=keys, keep=False)
    if duplicated.any():
        sample = frame.loc[duplicated, keys].head(10).to_dict("records")
        report.add("schema.duplicates", FAIL,
                   f"{int(duplicated.sum())} rows share a (trunk, scenario, node_id) key; "
                   "a profile point must appear once per simulation.",
                   rows=int(duplicated.sum()), examples=sample)
    else:
        report.add("schema.duplicates", PASS, "Every profile row has a unique (trunk, scenario, node_id).")

    expected = set(trunks or TRUNKS)
    present = set(frame["trunk"].dropna().unique())
    if expected - present:
        report.add("schema.trunks", FAIL,
                   f"Trunk(s) absent from the export: {sorted(expected - present)}. "
                   "Dropping a difficult trunk is not a repair.",
                   missing=sorted(expected - present))
    else:
        extra = sorted(present - expected)
        report.add("schema.trunks", PASS,
                   f"All {len(expected)} selected trunks present"
                   + (f"; {len(extra)} additional trunk(s) will be filtered out." if extra else "."),
                   unused=extra)

    per_trunk = frame.groupby("trunk")["scenario"].nunique()
    if per_trunk.nunique() > 1:
        report.add("schema.scenario_coverage", FAIL,
                   f"Trunks do not share the same simulation set: {per_trunk.to_dict()}. "
                   "Whole simulations must stay together across trunks.",
                   per_trunk=per_trunk.to_dict())
    else:
        report.add("schema.scenario_coverage", PASS,
                   f"Every trunk carries the same {int(per_trunk.iloc[0])} simulations.")
    return report


# ---------------------------------------------------------------------------
# 3. Identifier consistency across export, source map and topology
# ---------------------------------------------------------------------------

def read_topology(path):
    """The topology CSVs are semicolon separated and name their ends, not their direction."""
    frame = pd.read_csv(path, sep=";")
    # topology_Troncal7_7A.csv names the branch column `tuberia`; without this rename the
    # identifier cross-check silently sees a topology table with no branch names at all.
    renames = {"Flowline/BranchEquipment": "BranchEquipment", "tuberia": "BranchEquipment",
               "nodo_origin": "node_from", "nodo_origen": "node_from",
               "nodo_end": "node_to", "nodo_destino": "node_to",
               "latitud_orign": "lat_from", "longitude_origin": "long_from",
               "latitud_end": "lat_to", "longitud_end": "long_to"}
    return frame.rename(columns={k: v for k, v in renames.items() if k in frame.columns})


def check_identifiers(frame, source_map, topology=None):
    """Flowline names must agree across the export, the source map and any topology file."""
    report = PreflightReport()
    export_branches = set(frame["BranchEquipment"].astype(str))

    required = {"source", "lat", "long", "BranchEquipment", "Troncal"}
    if not required <= set(source_map.columns):
        report.add("identifiers.source_map_columns", FAIL,
                   f"Source map lacks {sorted(required - set(source_map.columns))}.")
        return report
    report.add("identifiers.source_map_columns", PASS, "Source map has its five required columns.")

    unknown = sorted(set(source_map["BranchEquipment"].astype(str)) - export_branches)
    if unknown:
        report.add("identifiers.source_branches", FAIL,
                   f"{len(unknown)} mapped source branch(es) do not exist in the export: "
                   f"{unknown[:5]}. A source cannot inject into a branch that was not exported.",
                   unknown=unknown)
    else:
        report.add("identifiers.source_branches", PASS,
                   f"All {source_map['BranchEquipment'].nunique()} mapped source branches exist in the export.")

    duplicated = source_map["source"].duplicated()
    if duplicated.any():
        report.add("identifiers.source_unique", FAIL,
                   f"{int(duplicated.sum())} duplicate source name(s) in the map; "
                   "individual source rates are required.",
                   duplicates=sorted(source_map.loc[duplicated, "source"].unique()))
    else:
        report.add("identifiers.source_unique", PASS,
                   f"{len(source_map)} sources, each named once.")

    for trunk in sorted(frame["trunk"].unique()):
        if source_map.loc[source_map["Troncal"] == trunk].empty:
            report.add("identifiers.source_coverage", FAIL,
                       f"No source mapping for {trunk}.", trunk=trunk)
            break
    else:
        report.add("identifiers.source_coverage", PASS, "Every trunk has at least one mapped source.")

    for label, table in (topology or {}).items():
        if "BranchEquipment" not in table.columns:
            report.add(f"identifiers.topology[{label}]", FAIL,
                       "Topology file has no Flowline/BranchEquipment column.")
            continue
        named = set(table["BranchEquipment"].astype(str))
        absent = sorted(named - export_branches)
        if absent:
            report.add(f"identifiers.topology[{label}]", WARN,
                       f"{len(absent)} flowline(s) named in the topology file are not in the export: "
                       f"{absent[:5]}. Expected when the topology file covers a wider case than the "
                       "exported trunks; blocking only if one of them should have been exported.",
                       absent=absent)
        else:
            report.add(f"identifiers.topology[{label}]", PASS,
                       f"All {len(named)} topology flowlines appear in the export.")
    return report


# ---------------------------------------------------------------------------
# 4. Distance ordering, resets and units
# ---------------------------------------------------------------------------

def _haversine_m(lon1, lat1, lon2, lat2):
    lon1, lat1, lon2, lat2 = (np.radians(np.asarray(v, dtype=float)) for v in (lon1, lat1, lon2, lat2))
    a = np.sin((lat2 - lat1) / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2
    return 2 * EARTH_RADIUS_M * np.arcsin(np.sqrt(np.clip(a, 0., 1.)))


def check_distances(frame, scenarios=None):
    """TotalDistance is nonnegative, starts at zero and strictly increases inside a branch.

    It resets to zero at every new branch record. That reset is the file format, not a
    discontinuity in the pipeline, so it is reported as information rather than a warning.
    """
    report = PreflightReport()
    selected = _select_scenarios(frame, scenarios, count=3)
    subset = frame.loc[frame["scenario"].isin(selected)]

    if (subset["TotalDistance"] < 0).any():
        report.add("distance.nonnegative", FAIL,
                   f"{int((subset['TotalDistance'] < 0).sum())} rows carry a negative TotalDistance.")
    else:
        report.add("distance.nonnegative", PASS, "No negative TotalDistance.")

    ordered = subset.sort_values(["trunk", "scenario", "BranchEquipment", "TotalDistance"])
    grouped = ordered.groupby(["trunk", "scenario", "BranchEquipment"], sort=False)

    starts = grouped["TotalDistance"].first()
    off_origin = starts[starts.abs() > 1e-9]
    if len(off_origin):
        report.add("distance.origin", FAIL,
                   f"{len(off_origin)} branch profile(s) do not start at distance zero, "
                   f"e.g. {off_origin.index[0][2]} at {float(off_origin.iloc[0]):.3f}.",
                   examples=[list(i) for i in off_origin.index[:5]])
    else:
        report.add("distance.origin", PASS,
                   f"All {len(starts)} branch profiles start at zero; the reset between records "
                   "is the export format and is expected.")

    steps = grouped["TotalDistance"].diff()
    flat = ordered.loc[steps.notna() & (steps <= 0)]
    if len(flat):
        report.add("distance.monotonic", FAIL,
                   f"{len(flat)} row(s) repeat or reverse TotalDistance inside a branch; "
                   "_geometry rejects non-increasing profiles.",
                   branches=sorted(flat["BranchEquipment"].unique())[:5])
    else:
        report.add("distance.monotonic", PASS, "TotalDistance strictly increases within every branch.")

    # Units. Elevation is metres. TotalDistance is scaled by FT_TO_M downstream, so the
    # exported column must be feet. Great-circle spacing between consecutive points is an
    # independent metre ruler, so their ratio decides it without appealing to the header.
    horizontal = _haversine_m(ordered["long"].shift(), ordered["lat"].shift(),
                              ordered["long"], ordered["lat"])
    step_values = steps.to_numpy(float)
    # steps is NaN at the first row of every branch, so this never straddles two branches.
    usable = (np.isfinite(step_values) & (step_values > 1.0)
              & np.isfinite(horizontal) & (horizontal > 1.0))
    if int(usable.sum()) < 50:
        report.add("distance.units", WARN,
                   "Too few usable consecutive points to measure the distance unit independently.")
    else:
        ratio = float(np.median(horizontal[usable] / step_values[usable]))
        feet_error, metre_error = abs(ratio - FT_TO_M) / FT_TO_M, abs(ratio - 1.0)
        if feet_error < 0.10:
            report.add("distance.units", PASS,
                       f"TotalDistance is in feet ({ratio:.4f} m of ground per unit against "
                       f"{FT_TO_M} expected), which matches the FT_TO_M scaling in _geometry.",
                       metres_per_unit=ratio)
        elif metre_error < 0.10:
            report.add("distance.units", FAIL,
                       f"TotalDistance appears to be in metres ({ratio:.4f} m of ground per unit). "
                       "_geometry multiplies it by FT_TO_M, so every pipe length would be understated "
                       "by 3.28x and every friction loss with it.",
                       metres_per_unit=ratio)
        else:
            report.add("distance.units", FAIL,
                       f"TotalDistance matches neither feet nor metres ({ratio:.4f} m of ground per "
                       "unit). Establish the unit from the PIPESIM export settings before training.",
                       metres_per_unit=ratio)

    diameters = subset["PipeInsideDiameter"].to_numpy(float)
    if np.nanmedian(diameters) < 1.0:
        report.add("diameter.units", FAIL,
                   f"Median PipeInsideDiameter is {np.nanmedian(diameters):.4f}, which looks like "
                   "metres. _geometry multiplies it by IN_TO_M and expects inches.")
    else:
        report.add("diameter.units", PASS,
                   f"PipeInsideDiameter is in inches (median {np.nanmedian(diameters):.2f} in, "
                   f"{np.nanmedian(diameters) * IN_TO_M:.3f} m).")
    return report


# ---------------------------------------------------------------------------
# 5. Physical ranges
# ---------------------------------------------------------------------------

def check_ranges(frame):
    """Hard bounds block; soft bounds only draw attention."""
    report = PreflightReport()
    blocking = {}
    for column, (low, high) in HARD_BOUNDS.items():
        if column not in frame.columns:
            continue
        values = frame[column].to_numpy(float)
        bad = int((~np.isfinite(values)).sum() + ((values < low) | (values > high)).sum())
        if bad:
            blocking[column] = {"rows": bad, "allowed": [low, high],
                                "observed": [float(np.nanmin(values)), float(np.nanmax(values))]}
    if blocking:
        report.add("ranges.hard", FAIL,
                   "Values outside the physically possible range: "
                   + "; ".join(f"{c} {d['rows']} rows in {d['observed']}" for c, d in blocking.items()),
                   detail=blocking)
    else:
        report.add("ranges.hard", PASS,
                   f"{len(HARD_BOUNDS)} physical columns are finite and inside their possible range.")

    unusual = {}
    for column, (low, high) in SOFT_BOUNDS.items():
        if column not in frame.columns:
            continue
        values = frame[column].to_numpy(float)
        count = int(((values < low) | (values > high)).sum())
        if count:
            unusual[column] = {"rows": count, "typical": [low, high],
                               "observed": [float(np.nanmin(values)), float(np.nanmax(values))]}
    if unusual:
        report.add("ranges.typical", WARN,
                   "Outside the usual field range but not impossible: "
                   + "; ".join(f"{c} {d['rows']} rows spanning {d['observed']}"
                               for c, d in unusual.items()),
                   detail=unusual)
    else:
        report.add("ranges.typical", PASS, "Every physical column sits inside its usual field range.")

    sinks = frame.loc[frame["node_type"] == -1, "pressure_psia"]
    if len(sinks) and float(np.abs(sinks - 44.7).max()) > 1.0:
        report.add("ranges.sink_anchor", WARN,
                   f"Labelled sink pressure departs from the 44.7 psia anchor by up to "
                   f"{float(np.abs(sinks - 44.7).max()):.2f} psi. The solver anchors exactly, so "
                   "this shows up as a fixed label error at the sink rather than a model error.",
                   max_deviation_psi=float(np.abs(sinks - 44.7).max()))
    else:
        report.add("ranges.sink_anchor", PASS, "Sink labels agree with the 44.7 psia anchor.")
    return report


# ---------------------------------------------------------------------------
# 6. Topology: connectivity, reachability, components, cycles, short segments
# ---------------------------------------------------------------------------

def _components(nodes, edges):
    parent = {node: node for node in nodes}

    def find(node):
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    for edge in edges:
        a, b = find(edge["up"]), find(edge["down"])
        if a != b:
            parent[a] = b
    groups = {}
    for node in nodes:
        groups.setdefault(find(node), []).append(node)
    return list(groups.values())


def _reaches_sink(edges, sink, start):
    """Follow directed edges up -> down from one source and see whether the sink is hit."""
    outgoing = {}
    for edge in edges:
        outgoing.setdefault(edge["up"], []).append(edge["down"])
    seen, stack = {start}, [start]
    while stack:
        node = stack.pop()
        if node == sink:
            return True
        for neighbour in outgoing.get(node, []):
            if neighbour not in seen:
                seen.add(neighbour)
                stack.append(neighbour)
    return False


def check_topology(frame, source_map, *, scenario=None, seed=2026, coordinate_decimals=8,
                   geometry_tolerance_m=0.1, short_segment_m=SHORT_SEGMENT_M, trunks=None):
    """Build the graph exactly as the solver does, then interrogate it.

    `_geometry` is called rather than reimplemented, so every structural rule the solver
    enforces is checked here with its own wording, and connectivity questions are asked of
    the same edge list the solver will receive.

    The default reference simulation is the one `prepare_data` will use, the first training
    ID for this seed. Checking a different simulation would test a graph the solver never
    builds, and the geometry is shared anyway.
    """
    report = PreflightReport()
    scenario = str(scenario) if scenario is not None else scenario_split(frame["scenario"],
                                                                        seed=seed)["train"][0]
    report.context["topology_reference_scenario"] = scenario
    selected = sorted(set(trunks or frame["trunk"].unique()))
    summary, short_records, cycle_records = [], [], []

    for trunk in selected:
        trunk_frame = frame.loc[(frame["trunk"] == trunk) & (frame["scenario"] == str(scenario))]
        mapping = source_map.loc[source_map["Troncal"] == trunk].copy()
        if trunk_frame.empty:
            report.add(f"topology[{trunk}].build", FAIL,
                       f"No rows for scenario {scenario}.")
            continue
        try:
            spec, layout, _, _ = _geometry(trunk_frame, mapping, None, coordinate_decimals,
                                           geometry_tolerance_m)
        except (ValueError, KeyError) as error:
            report.add(f"topology[{trunk}].build", FAIL,
                       f"_geometry rejected the trunk: {error}", trunk=trunk)
            continue

        edges, nodes, sink = spec["edges"], set(spec["nodes"]), spec["sink"]
        source_nodes = {name: record["node"] for name, record in spec["sources"].items()}

        groups = _components(nodes, edges)
        if len(groups) != 1:
            sizes = sorted((len(g) for g in groups), reverse=True)
            report.add(f"topology[{trunk}].connected", FAIL,
                       f"The network splits into {len(groups)} disconnected pieces of sizes {sizes}. "
                       "A piece with no path to the sink cannot be solved.",
                       component_sizes=sizes)
            continue

        stranded = [name for name, node in source_nodes.items() if not _reaches_sink(edges, sink, node)]
        if stranded:
            report.add(f"topology[{trunk}].reachability", FAIL,
                       f"{len(stranded)} source(s) have no directed path to the sink after "
                       f"orientation: {stranded[:5]}. Direction, not connectivity, is the suspect.",
                       sources=stranded)
        else:
            report.add(f"topology[{trunk}].reachability", PASS,
                       f"All {len(source_nodes)} sources reach the sink following the oriented edges.")

        loops = len(edges) - len(nodes) + 1
        if loops:
            cycle_records.append({"trunk": trunk, "independent_loops": loops})

        for edge in edges:
            span = float(edge["distance_m"][-1])
            if span < short_segment_m:
                short_records.append({
                    "trunk": trunk, "edge": edge["id"], "length_m": span,
                    "diameter_in": float(np.median(edge["diameter_m"])) / IN_TO_M,
                    "points": len(edge["distance_m"]),
                })

        audit = spec.get("orientation_audit", {})
        summary.append({
            "trunk": trunk, "branches": len(edges), "nodes": len(nodes),
            "sources": len(source_nodes), "independent_loops": loops,
            "reversed_at_reference": len(audit.get("reversed_edges", [])),
            "unresolved": len(audit.get("unresolved_edges", [])),
            "worst_continuity_residual": audit.get("worst_relative_continuity_residual", 0.),
        })
        unresolved = audit.get("unresolved_edges", [])
        if unresolved:
            report.add(f"topology[{trunk}].orientation_reference", FAIL,
                       f"{len(unresolved)} branch(es) could not be oriented from continuity in the "
                       f"reference scenario: {unresolved[:5]}.",
                       unresolved=unresolved)
        elif audit.get("flagged"):
            report.add(f"topology[{trunk}].orientation_reference", FAIL,
                       f"{len(audit['flagged'])} orientation conflict(s) or rate mismatches at "
                       "junctions in the reference scenario.",
                       flagged=audit["flagged"][:5])
        else:
            report.add(f"topology[{trunk}].orientation_reference", PASS,
                       f"All {len(edges)} branches oriented from continuity; worst junction imbalance "
                       f"{audit.get('worst_relative_continuity_residual', 0.):.2%}.")

    if cycle_records:
        report.add("topology.cycles", WARN,
                   "Undirected loops present: "
                   + ", ".join(f"{r['trunk']} {r['independent_loops']}" for r in cycle_records)
                   + ". These are ordinary parallel source-to-sink paths and are solved by the "
                     "implicit cycle-flow step; they are not directed circulation.",
                   detail=cycle_records)
    else:
        report.add("topology.cycles", PASS, "No undirected loops; every trunk is a tree.")

    if short_records:
        shortest = min(short_records, key=lambda r: r["length_m"])
        report.add("topology.short_segments", WARN,
                   f"{len(short_records)} branch record(s) shorter than {short_segment_m:g} m, the "
                   f"shortest being {shortest['edge']} at {shortest['length_m']:.1f} m "
                   f"({shortest['diameter_in']:.2f} in). A pipeline is split into a new flowline "
                   "record wherever its diameter or condition changes, so these are intentional and "
                   "must not be merged away.",
                   detail=short_records)
    else:
        report.add("topology.short_segments", PASS,
                   f"No branch record shorter than {short_segment_m:g} m.")

    report.context["topology_summary"] = pd.DataFrame(summary)
    report.context["short_segments"] = pd.DataFrame(short_records)
    return report


# ---------------------------------------------------------------------------
# 7. Direction constancy across simulations
# ---------------------------------------------------------------------------

def check_orientation_constancy(frame, source_map, *, seed=2026, geometry_tolerance_m=0.1,
                                coordinate_decimals=8, trunks=None, scenarios=None,
                                scenario_count=25, residual_tolerance=0.02):
    """One fixed orientation is only sound if no branch ever reverses. Ask data.py."""
    report = PreflightReport()
    selected = _select_scenarios(frame, scenarios, count=scenario_count)
    try:
        sweep = orientation_sweep(frame, source_map, seed=seed,
                                  geometry_tolerance_m=geometry_tolerance_m,
                                  coordinate_decimals=coordinate_decimals, trunks=trunks,
                                  scenarios=selected, residual_tolerance=residual_tolerance)
    except ValueError as error:
        report.add("orientation.sweep", FAIL, f"orientation_sweep could not run: {error}")
        return report

    report.context["orientation_summary"] = orientation_summary(sweep)
    report.context["orientation_sweep"] = sweep
    for trunk, record in sweep["trunks"].items():
        flipping = record["flipping_edges"]
        unresolved = record["unresolved_edges_with_flow"]
        worst = record["worst_continuity_residual"]["relative_residual"]
        if flipping:
            report.add(f"orientation[{trunk}].constant", FAIL,
                       f"{len(flipping)} branch(es) reverse direction while carrying flow, e.g. "
                       f"{flipping[0]['edge']} in {flipping[0]['reversed_scenarios']} simulations. "
                       "A single stored direction cannot represent them.",
                       flipping=flipping[:5])
        elif unresolved:
            report.add(f"orientation[{trunk}].constant", FAIL,
                       f"{len(unresolved)} branch(es) with flow stay unresolved in at least one "
                       "simulation.", unresolved=unresolved)
        elif worst > residual_tolerance:
            report.add(f"orientation[{trunk}].constant", FAIL,
                       f"Worst junction mass imbalance {worst:.2%} exceeds the "
                       f"{residual_tolerance:.0%} tolerance, in scenario "
                       f"{record['worst_continuity_residual']['scenario']}.",
                       worst=record["worst_continuity_residual"])
        else:
            note = (f"; {len(record['always_zero_flow_edges'])} branch(es) never carry flow and have "
                    "no direction to find" if record["always_zero_flow_edges"] else "")
            report.add(f"orientation[{trunk}].constant", PASS,
                       f"Every branch keeps one direction across {sweep['scenarios_checked']} "
                       f"simulations; worst junction imbalance {worst:.2%}{note}.")
    return report


# ---------------------------------------------------------------------------
# 8. Profile alignment: do the state columns describe the same points as the geometry?
# ---------------------------------------------------------------------------

def _branch_endpoints(case, decimals):
    rows = []
    for branch, profile in case.groupby("BranchEquipment", sort=False):
        profile = profile.sort_values("TotalDistance")
        if len(profile) < 2:
            continue
        for end, point in (("near", profile.iloc[0]), ("far", profile.iloc[-1])):
            rows.append({
                "branch": branch, "end": end,
                "node": _coordinate(point, decimals),
                "pressure_psia": float(point["pressure_psia"]),
                "elevation_m": float(point["Elevation"]),
            })
    return pd.DataFrame(rows)


def _score_alignment(ends, branch):
    rows = ends.loc[ends["branch"] == branch]
    if len(rows) != 2:
        return None
    near = rows.loc[rows["end"] == "near"].iloc[0]
    far = rows.loc[rows["end"] == "far"].iloc[0]
    if near["node"] == far["node"]:
        return None
    detail = {}
    for label, row in (("near", near), ("far", far)):
        # Judge against the other branches at this node. Including the row being judged
        # would let a misaligned branch drag the consensus toward its own wrong value.
        peers = ends.loc[(ends["node"] == row["node"]) & (ends.index != row.name)]
        if peers.empty:
            return None  # free end, nothing to compare against
        detail[label] = {
            "stored_p": float(row["pressure_psia"]),
            "peer_p": float(peers["pressure_psia"].median()),
            "stored_z": float(row["elevation_m"]),
            "peer_z": float(peers["elevation_m"].median()),
        }
    as_stored = (abs(detail["near"]["stored_p"] - detail["near"]["peer_p"])
                 + abs(detail["far"]["stored_p"] - detail["far"]["peer_p"]))
    swapped = (abs(detail["far"]["stored_p"] - detail["near"]["peer_p"])
               + abs(detail["near"]["stored_p"] - detail["far"]["peer_p"]))
    geometry_error = (abs(detail["near"]["stored_z"] - detail["near"]["peer_z"])
                      + abs(detail["far"]["stored_z"] - detail["far"]["peer_z"]))
    return {"branch": branch, "cost_as_stored_psi": as_stored, "cost_if_swapped_psi": swapped,
            "improvement_psi": as_stored - swapped, "geometry_error_m": geometry_error}


def check_profile_alignment(frame, *, scenarios=None, scenario_count=3, coordinate_decimals=8,
                            margin_psi=ALIGNMENT_MARGIN_PSI, trunks=None):
    """Do a branch's state columns describe the same points as its geometry columns?

    Every profile row carries two independent blocks, geometry (TotalDistance, Elevation,
    long, lat) and state (Pressure, Temperature, Watercut, rate, densities). For almost
    every branch they describe the same point. For a few they do not: row i holds the
    geometry of point i and the state of point n-1-i.

    Pressure is the giveaway because it is single valued at a junction. A misaligned branch
    reports the far node's pressure at the near node, so a junction that should agree to
    twelve digits disagrees by psi. Orientation logic cannot see this, which is what makes
    it dangerous: the branch trains silently against pressure targets bound to wrong nodes.

    The test is a comparison, not a threshold, and a branch is flagged only when swapping
    its two ends beats the stored order by a wide margin in every scenario checked.
    """
    report = PreflightReport()
    selected = _select_scenarios(frame, scenarios, count=scenario_count)
    records = []
    for trunk in sorted(trunks or frame["trunk"].unique()):
        trunk_frame = frame.loc[frame["trunk"] == trunk]
        for scenario in selected:
            case = trunk_frame.loc[trunk_frame["scenario"] == scenario]
            if case.empty:
                continue
            ends = _branch_endpoints(case, coordinate_decimals)
            for branch in ends["branch"].unique():
                result = _score_alignment(ends, branch)
                if result is not None:
                    records.append({"trunk": trunk, "scenario": scenario, **result})

    detail = pd.DataFrame(records)
    if detail.empty:
        report.add("alignment.profile", WARN,
                   "No branch had two distinct endpoints with neighbours to compare against.")
        return report

    summary = detail.groupby(["trunk", "branch"]).agg(
        scenarios_checked=("scenario", "size"),
        worst_cost_as_stored_psi=("cost_as_stored_psi", "max"),
        worst_cost_if_swapped_psi=("cost_if_swapped_psi", "max"),
        min_improvement_psi=("improvement_psi", "min"),
        worst_geometry_error_m=("geometry_error_m", "max"),
    ).reset_index()
    summary["misaligned"] = summary["min_improvement_psi"] > margin_psi
    flagged = summary.loc[summary["misaligned"]]
    report.context["alignment_summary"] = summary.sort_values("min_improvement_psi", ascending=False)

    if flagged.empty:
        report.add("alignment.profile", PASS,
                   f"All {len(summary)} branches carry state and geometry for the same points "
                   f"across {len(selected)} simulations.")
    else:
        names = [f"{row.trunk} {row.branch}" for row in flagged.itertuples()]
        report.add("alignment.profile", FAIL,
                   f"{len(flagged)} branch(es) store state opposite to geometry: {names}. "
                   "Elevation still matches the neighbours at both ends, so the coordinates are "
                   "right and the state block is what is reversed. Confirm each against the "
                   "PIPESIM case before changing anything; the export is the suspect, not the "
                   "simulation.",
                   branches=names,
                   table=flagged.to_dict("records"))
    return report


# ---------------------------------------------------------------------------
# 9. Split integrity
# ---------------------------------------------------------------------------

def check_splits(frame, *, seed=2026, excluded_scenario_ids=None):
    """Splits are by whole simulation ID, so leakage can only enter through an ID in two places."""
    report = PreflightReport()
    excluded = {str(value) for value in (excluded_scenario_ids or [])}
    present = set(frame["scenario"].astype(str))

    leaked = sorted(excluded & present)
    if leaked:
        report.add("splits.exclusions", FAIL,
                   f"Excluded simulation(s) {leaked} are still in the frame handed to prepare_data.",
                   scenarios=leaked)
    else:
        report.add("splits.exclusions", PASS,
                   f"{len(excluded)} excluded simulation(s) removed before splitting.")

    try:
        splits = scenario_split(frame["scenario"], seed=seed)
    except ValueError as error:
        report.add("splits.build", FAIL, f"scenario_split refused: {error}")
        return report

    sets = {name: set(ids) for name, ids in splits.items()}
    overlaps = {f"{a}&{b}": sorted(sets[a] & sets[b])
                for a, b in (("train", "validation"), ("train", "test"), ("validation", "test"))
                if sets[a] & sets[b]}
    if overlaps:
        report.add("splits.disjoint", FAIL,
                   f"Simulation IDs appear in more than one split: {overlaps}.", overlaps=overlaps)
    else:
        report.add("splits.disjoint", PASS,
                   f"train {len(sets['train'])} / validation {len(sets['validation'])} / "
                   f"test {len(sets['test'])}, pairwise disjoint.")

    union = set().union(*sets.values())
    if union != present:
        report.add("splits.coverage", FAIL,
                   f"{len(present - union)} simulation(s) fall in no split and "
                   f"{len(union - present)} split ID(s) are not in the frame.",
                   missing=sorted(present - union)[:10], unknown=sorted(union - present)[:10])
    else:
        report.add("splits.coverage", PASS,
                   f"All {len(present)} simulations land in exactly one split.")

    # Node IDs repeat across simulations by design: it is the same pipe network every time.
    # The only leakage that matters is a simulation whose trunks land in different splits,
    # which cannot happen when the split key is the scenario ID. Confirm it anyway.
    per_scenario_trunks = frame.groupby("scenario")["trunk"].nunique()
    if per_scenario_trunks.nunique() > 1:
        report.add("splits.whole_scenarios", FAIL,
                   "Simulations do not all carry the same number of trunks, so a split moves "
                   f"partial simulations: {per_scenario_trunks.value_counts().to_dict()}.")
    else:
        report.add("splits.whole_scenarios", PASS,
                   f"Every simulation carries all {int(per_scenario_trunks.iloc[0])} trunks, so a "
                   "split never separates a simulation's nodes.")
    report.context["splits"] = splits
    return report


# ---------------------------------------------------------------------------
# 10. Finite model inputs and targets
# ---------------------------------------------------------------------------

def check_model_inputs(frame):
    """Targets and solver inputs must be finite and positive before any scaling."""
    report = PreflightReport()
    columns = ["pressure_psia", "temperature_k", "FlowrateLiquidInsitu", "Watercut",
               "PipeInsideDiameter", "DensityOilInSitu", "DensityWaterInSitu",
               "TotalDistance", "Elevation"]
    nonfinite = {c: int((~np.isfinite(frame[c].to_numpy(float))).sum())
                 for c in columns if c in frame.columns}
    offenders = {c: n for c, n in nonfinite.items() if n}
    if offenders:
        report.add("inputs.finite", FAIL,
                   f"Nonfinite values reach the solver: {offenders}.", detail=offenders)
    else:
        report.add("inputs.finite", PASS,
                   f"All {len(nonfinite)} solver inputs and targets are finite.")

    positive = {c: int((frame[c].to_numpy(float) <= 0).sum())
                for c in ("pressure_psia", "temperature_k", "PipeInsideDiameter",
                          "DensityOilInSitu", "DensityWaterInSitu") if c in frame.columns}
    offenders = {c: n for c, n in positive.items() if n}
    if offenders:
        report.add("inputs.positive", FAIL,
                   f"Nonpositive values in strictly positive column(s): {offenders}.")
    else:
        report.add("inputs.positive", PASS,
                   "Pressure, temperature, diameter and densities are strictly positive.")

    # The Huber scales are 2 psi and 2% of the label, so a target range spanning orders of
    # magnitude is worth knowing about before the loss is dominated by one regime.
    pressure = frame["pressure_psia"].to_numpy(float)
    report.context["target_range"] = {
        "pressure_psia": [float(pressure.min()), float(pressure.max())],
        "temperature_k": [float(frame["temperature_k"].min()), float(frame["temperature_k"].max())],
    }
    return report


def verify_prepared(prepared, excluded_scenario_ids=None):
    """Run after prepare_data: the case payload the training loop will actually consume."""
    report = PreflightReport()
    excluded = {str(value) for value in (excluded_scenario_ids or [])}

    if any(not excluded.isdisjoint(ids) for ids in prepared.splits.values()):
        report.add("prepared.exclusions", FAIL,
                   "An excluded simulation survived into a split.")
    else:
        report.add("prepared.exclusions", PASS, "No excluded simulation reaches a split.")

    bad_cases, bad_sinks, bad_layout = [], [], []
    for scenario, case in prepared.cases.items():
        for trunk, values in case.items():
            arrays = {
                "rates_m3_s": np.asarray(values["rates_m3_s"], dtype=float),
                "watercuts": np.asarray(values["watercuts"], dtype=float),
                "pressure_psia": np.asarray(values["pressure_psia"], dtype=float),
                "temperature_k": np.asarray(values["temperature_k"], dtype=float),
            }
            for name, array in arrays.items():
                if array.size == 0 or not np.isfinite(array).all():
                    bad_cases.append(f"{scenario}/{trunk}/{name}")
            if arrays["pressure_psia"].min(initial=1.) <= 0:
                bad_cases.append(f"{scenario}/{trunk}/pressure_psia nonpositive")
            if arrays["rates_m3_s"].min(initial=0.) < 0:
                bad_cases.append(f"{scenario}/{trunk}/rates_m3_s negative")
            if sum(bool(flag) for flag in values["is_sink"]) != 1:
                bad_sinks.append(f"{scenario}/{trunk}")
            if len(values["node_ids"]) != len(arrays["pressure_psia"]):
                bad_layout.append(f"{scenario}/{trunk}")
            missing = [n for n in values["node_ids"] if n not in prepared.layouts[trunk]]
            if missing:
                bad_layout.append(f"{scenario}/{trunk} missing {missing[:3]}")

    if bad_cases:
        report.add("prepared.finite", FAIL,
                   f"{len(bad_cases)} case array(s) are empty, nonfinite or out of range, e.g. "
                   f"{bad_cases[:5]}.", examples=bad_cases[:20])
    else:
        report.add("prepared.finite", PASS,
                   f"All arrays across {len(prepared.cases)} simulations are finite and in range.")
    if bad_sinks:
        report.add("prepared.sink", FAIL,
                   f"{len(bad_sinks)} trunk-case(s) do not have exactly one sink node, e.g. "
                   f"{bad_sinks[:5]}.")
    else:
        report.add("prepared.sink", PASS, "Exactly one anchored sink node per trunk per simulation.")
    if bad_layout:
        report.add("prepared.layout", FAIL,
                   f"{len(bad_layout)} case(s) reference nodes the layout does not place, e.g. "
                   f"{bad_layout[:5]}.")
    else:
        report.add("prepared.layout", PASS, "Every case node maps to a branch and profile index.")

    for trunk, spec in prepared.specs.items():
        edges, nodes = spec["edges"], set(spec["nodes"])
        stranded = [name for name, record in spec["sources"].items()
                    if not _reaches_sink(edges, spec["sink"], record["node"])]
        if stranded:
            report.add(f"prepared.reachability[{trunk}]", FAIL,
                       f"{len(stranded)} source(s) cannot reach the sink in the prepared spec: "
                       f"{stranded[:5]}.")
        else:
            report.add(f"prepared.reachability[{trunk}]", PASS,
                       f"{len(edges)} branches, {len(nodes)} nodes, every source reaches the sink.")
    return report


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def _select_scenarios(frame, scenarios, count):
    available = sorted(set(frame["scenario"].astype(str)))
    if scenarios is not None:
        chosen = [str(value) for value in scenarios]
        missing = [value for value in chosen if value not in available]
        if missing:
            raise ValueError(f"Requested scenarios are absent: {missing}")
        return chosen
    if len(available) <= count:
        return available
    # Spread the sample over the whole range rather than taking the first few, so a
    # regime that only appears in late simulations is not invisible to the checks.
    index = np.linspace(0, len(available) - 1, count).round().astype(int)
    return [available[i] for i in sorted(set(index.tolist()))]


def run_preflight(frame, source_map, *, paths=None, topology=None, trunks=None, seed=2026,
                  geometry_tolerance_m=0.1, coordinate_decimals=8,
                  excluded_scenario_ids=None, topology_scenario=None,
                  range_scenarios=None, orientation_scenarios=None,
                  orientation_scenario_count=25, alignment_scenarios=None,
                  alignment_scenario_count=3, short_segment_m=SHORT_SEGMENT_M,
                  alignment_margin_psi=ALIGNMENT_MARGIN_PSI, residual_tolerance=0.02):
    """Every check, in one report, on the frame that is about to become the ensemble.

    Structural checks that depend on a whole network are run on a spread sample of
    simulations rather than all of them, because building the graph 300 times costs
    minutes and buys nothing: the geometry is shared. Direction constancy is the exception
    that must be swept, and `orientation_scenarios` controls how wide that sweep is.
    """
    report = PreflightReport()
    if paths:
        report.extend(check_inputs_exist(paths))
    report.extend(check_schema(frame, trunks))
    if report.failures:
        return report  # Nothing below can be trusted once the schema is wrong.
    report.extend(check_identifiers(frame, source_map, topology))
    report.extend(check_distances(frame, range_scenarios))
    report.extend(check_ranges(frame))
    report.extend(check_model_inputs(frame))
    report.extend(check_splits(frame, seed=seed, excluded_scenario_ids=excluded_scenario_ids))
    report.extend(check_topology(frame, source_map, scenario=topology_scenario, seed=seed,
                                 coordinate_decimals=coordinate_decimals,
                                 geometry_tolerance_m=geometry_tolerance_m,
                                 short_segment_m=short_segment_m, trunks=trunks))
    report.extend(check_profile_alignment(frame, scenarios=alignment_scenarios,
                                          scenario_count=alignment_scenario_count,
                                          coordinate_decimals=coordinate_decimals,
                                          margin_psi=alignment_margin_psi, trunks=trunks))
    report.extend(check_orientation_constancy(frame, source_map, seed=seed,
                                              geometry_tolerance_m=geometry_tolerance_m,
                                              coordinate_decimals=coordinate_decimals,
                                              trunks=trunks, scenarios=orientation_scenarios,
                                              scenario_count=orientation_scenario_count,
                                              residual_tolerance=residual_tolerance))
    return report
