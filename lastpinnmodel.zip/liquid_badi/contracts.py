"""Explicit units and deployment-boundary validation; no simulator fallbacks."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


PSI_TO_PA = 6894.757293168
BBL_DAY_TO_M3_S = 0.158987294928 / 86400.
FT_TO_M = 0.3048
IN_TO_M = 0.0254
STANDARD_ATMOSPHERE_PSI = 14.6959487755

# Units the rest of the package expects once an export has been loaded. These are not a
# claim about any particular file: they are the targets that `load_profiles` converts the
# caller's declared units into. `_geometry` scales TotalDistance by FT_TO_M and
# PipeInsideDiameter by IN_TO_M, elevation is consumed as metres, pressures are psia and
# source rates are barrels per day, which is where these values come from.
EXPORT_UNIT_TARGETS = {
    "TotalDistance": "ft",
    "Elevation": "m",
    "PipeInsideDiameter": "in",
    "Pressure": "psia",
    "FlowrateLiquidInsitu": "bbl/day",
    "Watercut": "fraction",
    "DensityOilInSitu": "kg/m3",
    "DensityWaterInSitu": "kg/m3",
    "Temperature": "K",
}

_LENGTH_TO_M = {
    "m": 1., "km": 1000., "cm": 0.01, "mm": 0.001,
    "ft": FT_TO_M, "in": IN_TO_M, "mi": 1609.344,
}
_RATE_TO_M3_S = {
    "bbl/day": BBL_DAY_TO_M3_S, "stb/day": BBL_DAY_TO_M3_S, "bpd": BBL_DAY_TO_M3_S,
    "m3/s": 1., "m3/day": 1. / 86400., "m3/d": 1. / 86400., "m3/h": 1. / 3600.,
    "l/s": 1e-3, "gal/min": 0.003785411784 / 60.,
}
_DENSITY_TO_KG_M3 = {
    "kg/m3": 1., "kg/l": 1000., "g/cm3": 1000., "lb/ft3": 16.018463374, "lbm/ft3": 16.018463374,
}
# Affine, as psia = value * scale + offset. Gauge units carry the atmospheric offset.
_PRESSURE_TO_PSIA = {
    "psia": (1., 0.), "psig": (1., STANDARD_ATMOSPHERE_PSI),
    "bara": (14.503773773, 0.), "barg": (14.503773773, STANDARD_ATMOSPHERE_PSI),
    "pa": (1. / PSI_TO_PA, 0.), "kpa": (1000. / PSI_TO_PA, 0.), "mpa": (1e6 / PSI_TO_PA, 0.),
    "atm": (14.6959487755, 0.), "kgf/cm2": (14.223343307, 0.),
}
_FRACTION_TO_UNITY = {"fraction": 1., "frac": 1., "-": 1., "percent": 0.01, "pct": 0.01, "%": 0.01}
_UNIT_TABLES = (_LENGTH_TO_M, _RATE_TO_M3_S, _DENSITY_TO_KG_M3, _FRACTION_TO_UNITY)


def unit_conversion(unit, target):
    """Return (scale, offset) so that `value * scale + offset` is `value` expressed in `target`.

    Both the source and the target are named explicitly by the caller. An unrecognised
    name, or a name from the wrong physical kind, is an error rather than a silent
    pass-through: a wrong unit that loads quietly is far more expensive than one that
    refuses to load at all.
    """
    if not isinstance(unit, str) or not isinstance(target, str):
        raise ValueError(f"Units must be named as strings, not {unit!r} -> {target!r}.")
    source, goal = unit.strip().lower(), target.strip().lower()
    for table in _UNIT_TABLES:
        if goal in table:
            if source not in table:
                raise ValueError(
                    f"Cannot convert {unit!r} to {target!r}. Expected one of {sorted(table)}."
                )
            return table[source] / table[goal], 0.
    if goal in _PRESSURE_TO_PSIA:
        if source not in _PRESSURE_TO_PSIA:
            raise ValueError(
                f"Cannot convert {unit!r} to {target!r}. Expected one of "
                f"{sorted(_PRESSURE_TO_PSIA)}."
            )
        scale_in, offset_in = _PRESSURE_TO_PSIA[source]
        scale_out, offset_out = _PRESSURE_TO_PSIA[goal]
        return scale_in / scale_out, (offset_in - offset_out) / scale_out
    raise ValueError(f"No conversion target named {target!r}.")


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def temperature_kelvin(values, unit):
    values = np.asarray(values, dtype=float)
    if not np.isfinite(values).all():
        raise ValueError("Temperature contains missing or nonfinite values.")
    if unit == "degF":
        result = (values - 32.) * 5. / 9. + 273.15
    elif unit == "degC":
        result = values + 273.15
    elif unit == "K":
        result = values.copy()
    else:
        raise ValueError("Temperature unit must be explicitly degF, degC, or K.")
    if (result <= 0).any():
        raise ValueError("Temperature must be above absolute zero.")
    return result


def geometry_fingerprint(geometry):
    encoded = json.dumps(
        geometry, sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def fixed_source_temperatures(source_observations, training_ids, tolerance_k=0.1):
    """Extract constants only from training simulations, validating each source."""
    required = {"scenario", "source_id", "temperature_k"}
    if not required <= set(source_observations.columns):
        raise ValueError(f"Missing source-temperature columns: {required - set(source_observations.columns)}")
    if not np.isfinite(tolerance_k) or tolerance_k < 0:
        raise ValueError("Source-temperature constancy tolerance must be finite and nonnegative.")
    frame = source_observations.copy()
    if frame[["scenario", "source_id"]].isna().any().any():
        raise ValueError("Missing source or scenario identifier.")
    frame["scenario"] = frame["scenario"].astype(str)
    frame["source_id"] = frame["source_id"].astype(str)
    training_ids = {str(value) for value in training_ids}
    if not training_ids:
        raise ValueError("Training simulation IDs cannot be empty.")
    frame = frame.loc[frame["scenario"].isin(training_ids)]
    if frame.empty:
        raise ValueError("No training source-temperature observations.")
    if not np.isfinite(frame["temperature_k"].to_numpy(dtype=float)).all():
        raise ValueError("Training source temperatures must be finite.")
    if (frame["temperature_k"] <= 0).any():
        raise ValueError("Training source temperatures must be positive kelvin.")
    constants, audit = {}, []
    for source, group in frame.groupby("source_id", sort=True):
        if group["scenario"].duplicated().any():
            raise ValueError(f"Duplicate source/scenario temperature for {source}.")
        if set(group["scenario"]) != training_ids:
            raise ValueError(f"Source {source} is missing in some training simulations.")
        low, high = float(group["temperature_k"].min()), float(group["temperature_k"].max())
        if high - low > tolerance_k:
            raise ValueError(
                f"Source {source} is not fixed: temperature spans {low:.6g}-{high:.6g} K "
                f"(allowed range {tolerance_k:g} K). Supply measured deployment temperatures "
                "or reconcile the export; do not substitute the mean silently."
            )
        constants[str(source)] = float(group["temperature_k"].median())
        audit.append({
            "source_id": str(source), "temperature_min_k": low,
            "temperature_max_k": high, "training_scenarios": len(group),
            "saved_temperature_k": constants[str(source)],
            "constancy_tolerance_k": tolerance_k,
        })
    return constants, audit


def validate_source_inputs(source_ids, rates, watercuts):
    expected = set(source_ids)
    for name, values in (("rates", rates), ("watercuts", watercuts)):
        if set(values) != expected:
            raise ValueError(
                f"{name} source keys differ: missing={sorted(expected - set(values))}, "
                f"unexpected={sorted(set(values) - expected)}."
            )
    q = np.array([rates[key] for key in source_ids], dtype=float)
    wc = np.array([watercuts[key] for key in source_ids], dtype=float)
    if not np.isfinite(q).all() or (q < 0).any():
        raise ValueError("Source liquid rates must be finite and nonnegative.")
    if not np.isfinite(wc).all() or ((wc < 0) | (wc > 1)).any():
        raise ValueError("Watercut must be a fraction in [0, 1], not a percentage.")
    return q, wc
