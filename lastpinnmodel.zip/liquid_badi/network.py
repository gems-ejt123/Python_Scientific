"""Canonical-junction integration and implicit cycle-flow balancing."""
from __future__ import annotations

from collections import deque
import copy
import math

import torch
from torch import nn

from .contracts import PSI_TO_PA, geometry_fingerprint


class LiquidNetwork(nn.Module):
    """Fixed directed acyclic branch graph; undirected hydraulic cycles allowed.

    Each branch has a resolved length/elevation/diameter profile. Genuine
    reverse flow or directed circulation requires a different transport
    orientation and is rejected, never replaced with guessed flows.
    """

    def __init__(self, spec, physics, tolerance_pa=0.01, maximum_iterations=30):
        super().__init__()
        self.spec = copy.deepcopy(spec)
        self.physics = physics
        self.tolerance_pa, self.maximum_iterations = tolerance_pa, maximum_iterations
        if tolerance_pa <= 0 or maximum_iterations < 1:
            raise ValueError("Positive solver tolerance and iteration count are required.")
        self.nodes = list(spec["nodes"])
        self.sources = copy.deepcopy(spec["sources"])
        self.edges = spec["edges"]
        self.sink = spec["sink"]
        if len(set(self.nodes)) != len(self.nodes) or self.sink not in self.nodes:
            raise ValueError("Network needs unique node IDs and a declared sink.")
        if not self.edges or not self.sources:
            raise ValueError("Network requires branches and prescribed sources.")
        if len({e["id"] for e in self.edges}) != len(self.edges):
            raise ValueError("Duplicate branch ID.")
        self.index = {n: i for i, n in enumerate(self.nodes)}
        self.incoming = {n: [] for n in self.nodes}
        self.outgoing = {n: [] for n in self.nodes}
        for i, edge in enumerate(self.edges):
            u, v = edge["up"], edge["down"]
            if u not in self.index or v not in self.index or u == v:
                raise ValueError(f"Invalid endpoints for branch {edge['id']}.")
            s, z, d = edge["distance_m"], edge["elevation_m"], edge["diameter_m"]
            if len(s) < 2 or len(z) != len(s) or len(d) != len(s) - 1:
                raise ValueError(f"Inconsistent profile arrays for {edge['id']}.")
            if s[0] != 0 or any(b <= a for a, b in zip(s, s[1:])):
                raise ValueError(f"Branch {edge['id']} requires increasing distance from zero.")
            rough = edge.get("roughness_m", 0.00004572)
            loss = edge.get("minor_loss_k", [0.] * len(d))
            if (not all(math.isfinite(v) for v in s + z + d + list(loss))
                    or any(v <= 0 for v in d) or len(loss) != len(d)
                    or any(v < 0 for v in loss) or not math.isfinite(rough) or rough < 0):
                raise ValueError(f"Invalid geometry/roughness/losses on {edge['id']}.")
            for name, value in (("s", s), ("z", z), ("d", d),
                                ("rough", [rough] * len(d)), ("loss", loss)):
                self.register_buffer(f"{name}_{i}", torch.tensor(value, dtype=torch.float64))
            self.incoming[v].append(i)
            self.outgoing[u].append(i)
        for source, boundary in self.sources.items():
            if boundary["node"] not in self.index or boundary["node"] == self.sink:
                raise ValueError(f"Invalid source node for {source}.")
            if not math.isfinite(boundary["temperature_k"]) or boundary["temperature_k"] <= 0:
                raise ValueError(f"Invalid fixed source temperature for {source}.")
        if self.outgoing[self.sink]:
            raise ValueError("Sink cannot have an outgoing branch.")
        if any(not self.outgoing[n] for n in self.nodes if n != self.sink):
            raise ValueError("Every branch must drain toward the single declared sink.")
        degree = {n: len(self.incoming[n]) for n in self.nodes}
        queue = deque(n for n in self.nodes if degree[n] == 0)
        self.order = []
        while queue:
            n = queue.popleft()
            self.order.append(n)
            for e in self.outgoing[n]:
                v = self.edges[e]["down"]
                degree[v] -= 1
                if degree[v] == 0:
                    queue.append(v)
        if len(self.order) != len(self.nodes):
            raise ValueError("Directed circulation is unsupported; verify branch orientation.")
        prescribed = {s["node"] for s in self.sources.values()}
        if any(not self.incoming[n] and n not in prescribed for n in self.nodes):
            raise ValueError("Missing source specification at a graph root.")
        self.source_ids = list(self.sources)
        self._make_cycles()
        self.geometry_hash = geometry_fingerprint(spec)

    def _make_cycles(self):
        parents = {n: n for n in self.nodes}

        def root(n):
            while parents[n] != n:
                n = parents[n]
            return n

        tree = {n: [] for n in self.nodes}
        chords = []
        for i, e in enumerate(self.edges):
            u, v = e["up"], e["down"]
            if root(u) == root(v):
                chords.append(i)
            else:
                parents[root(u)] = root(v)
                tree[u].append((v, i, 1.))
                tree[v].append((u, i, -1.))
        if len({root(n) for n in self.nodes}) != 1:
            raise ValueError("Disconnected network.")
        self.tree = tree
        cycles = torch.zeros(len(self.edges), len(chords), dtype=torch.float64)
        for j, e in enumerate(chords):
            start, goal = self.edges[e]["down"], self.edges[e]["up"]
            queue, paths = deque([start]), {start: []}
            while queue and goal not in paths:
                node = queue.popleft()
                for nxt, edge, sign in tree[node]:
                    if nxt not in paths:
                        paths[nxt] = paths[node] + [(edge, sign)]
                        queue.append(nxt)
            cycles[e, j] = 1.
            for edge, sign in paths[goal]:
                cycles[edge, j] = sign
        self.register_buffer("cycles", cycles)

    def _inputs(self, rates, watercuts):
        expected = (len(self.source_ids),)
        if tuple(rates.shape) != expected or tuple(watercuts.shape) != expected:
            raise ValueError(f"Source tensors must follow source_ids and have shape {expected}.")
        if not bool(torch.isfinite(rates).all() & torch.isfinite(watercuts).all()):
            raise ValueError("Nonfinite source inputs.")
        if bool((rates < 0).any() | (watercuts < 0).any() | (watercuts > 1).any()):
            raise ValueError("Rates must be nonnegative; watercut must be in [0,1].")
        return {
            node: [i for i, name in enumerate(self.source_ids) if self.sources[name]["node"] == node]
            for node in self.nodes
        }

    def _initial_flows(self, rates, source_at):
        q = [rates.new_zeros(()) for _ in self.edges]
        for node in self.order:
            total = sum((q[e] for e in self.incoming[node]), rates.new_zeros(()))
            total = total + sum((rates[i] for i in source_at[node]), rates.new_zeros(()))
            for e in self.outgoing[node]:
                q[e] = total / len(self.outgoing[node])
        return torch.stack(q)

    def _transport(self, q, rates, watercuts, source_at):
        p = self.physics
        wc, inlet = [None] * len(self.edges), [None] * len(self.edges)
        node_t, drops, profiles_t = {}, [None] * len(self.edges), [None] * len(self.edges)
        for node in self.order:
            flow, water, capacity, energy = [rates.new_zeros(()) for _ in range(4)]
            for e in self.incoming[node]:
                flow, water = flow + q[e], water + q[e] * wc[e]
                c = p.heat_capacity_rate(q[e], wc[e])
                capacity, energy = capacity + c, energy + c * profiles_t[e][-1]
            for i in source_at[node]:
                flow, water = flow + rates[i], water + rates[i] * watercuts[i]
                c = p.heat_capacity_rate(rates[i], watercuts[i])
                temperature = self.sources[self.source_ids[i]]["temperature_k"]
                capacity, energy = capacity + c, energy + c * temperature
            mix_wc = torch.where(flow > 1e-12, water / flow.clamp_min(1e-12), flow * 0.)
            node_t[node] = torch.where(
                capacity > 1e-12, energy / capacity.clamp_min(1e-12), p.ambient_k,
            )
            for e in self.outgoing[node]:
                wc[e], inlet[e] = mix_wc, node_t[node]
                s, z, d = (getattr(self, f"{k}_{e}") for k in ("s", "z", "d"))
                profiles_t[e] = p.temperature_at(inlet[e], s, q[e], wc[e])
                drop = p.segment_drop(
                    q[e], wc[e], inlet[e], s[:-1], s.diff(), z.diff(), d,
                    getattr(self, f"rough_{e}"),
                )
                dynamic = 0.5 * p.density(wc[e]) * (4 * q[e] / (math.pi * d.square())).square()
                transitions = torch.cat([dynamic.diff(), dynamic.new_zeros(1)])
                drops[e] = drop + transitions + dynamic * getattr(self, f"loss_{e}")
        return {
            "wc": torch.stack(wc), "inlet": torch.stack(inlet), "node_t": node_t,
            "drops": drops, "temperature_profiles": profiles_t,
        }

    def _loop_direction(self, jac, r):
        """Newton direction, Levenberg-damped when the loop Jacobian is ill-conditioned.

        Damping only conditions the linear solve; the accepted root is still the
        one satisfying the untouched loop residual tolerance.
        """
        scale = float(jac.abs().max())
        if not math.isfinite(scale) or scale <= 0:
            raise RuntimeError(
                "Degenerate loop Jacobian: the cycle basis carries no pressure sensitivity."
            )
        eye = torch.eye(jac.shape[0], dtype=jac.dtype, device=jac.device)
        for damping in (0., 1e-12, 1e-9, 1e-6, 1e-3):
            try:
                step = torch.linalg.solve(jac + damping * scale * eye, r)
            except RuntimeError:
                continue
            if bool(torch.isfinite(step).all()):
                return step
        raise RuntimeError(
            "Loop Jacobian is singular; the cycle basis is not independently drivable."
        )

    def _feasible_fraction(self, q_current, direction, margin=0.995):
        """Fraction-to-the-boundary cap keeping every branch flow nonnegative.

        The iterate moves to q_current - alpha * (cycles @ direction), so only
        branches whose flow decreases can bind. Returns the cap and that branch.
        """
        dq = self.cycles @ direction
        shrinking = dq > 0
        if not bool(shrinking.any()):
            return 1., -1
        limits = q_current[shrinking] / dq[shrinking]
        local = int(torch.argmin(limits))
        binding = int(torch.nonzero(shrinking).flatten()[local])
        return min(1., margin * float(limits[local])), binding

    def _loop_failure(self, q_current, r, jac, binding):
        try:
            condition = float(torch.linalg.cond(jac))
        except RuntimeError:
            condition = float("nan")
        detail = ""
        if 0 <= binding < len(self.edges):
            edge = self.edges[binding]
            detail = (
                f" The binding branch is {edge['id']} ({edge['up']} -> {edge['down']}) at "
                f"{float(q_current[binding]):.6g} m3/s; loop closure requires driving it "
                "negative, which is genuine reverse flow under the exported orientation."
            )
        return RuntimeError(
            f"Cycle solve stalled. Max loop residual {float(r.abs().max()):.6g} Pa against a "
            f"{self.tolerance_pa:g} Pa tolerance; loop Jacobian condition number "
            f"{condition:.6g}." + detail
            + " Verify branch orientation before relaxing the solver."
        )

    def forward(self, rates, watercuts, validate_pressure=True):
        source_at = self._inputs(rates, watercuts)
        q0 = self._initial_flows(rates, source_at)
        q, iterations = q0, 0
        if self.cycles.shape[1] and bool((q0 > 0).any()):
            outer_grad = torch.is_grad_enabled()
            with torch.enable_grad():
                def residual(z):
                    trial = self._transport(q0 + self.cycles @ z, rates, watercuts, source_at)
                    return self.cycles.T @ torch.stack([d.sum() for d in trial["drops"]])

                z = q0.new_zeros(self.cycles.shape[1], requires_grad=True)
                for iterations in range(1, self.maximum_iterations + 1):
                    r = residual(z).detach()
                    if float(r.abs().max()) <= self.tolerance_pa:
                        break
                    objective = float(r.square().sum())
                    jac = torch.autograd.functional.jacobian(residual, z).detach()
                    q_current = (q0.detach() + self.cycles @ z.detach()).clamp_min(0.)
                    directions = [self._loop_direction(jac, r)]
                    gradient = jac.transpose(0, 1) @ r
                    curvature = float((jac @ gradient).square().sum())
                    if curvature > 0:
                        # Cauchy point: the steepest-descent fallback when the
                        # Newton direction is not usable inside the feasible set.
                        directions.append(gradient * (float(gradient.square().sum()) / curvature))
                    accepted, binding = False, -1
                    # 0.995 keeps ordinary steps off the boundary; the 1.0 retry lets a
                    # branch settle at exactly zero flow, which is a legitimate root.
                    attempts = [(d, m) for d in directions for m in (0.995, 1.0)]
                    for direction, margin in attempts:
                        alpha, binding = self._feasible_fraction(q_current, direction, margin)
                        while alpha > 1e-14:
                            candidate = z.detach() - alpha * direction
                            if float(residual(candidate).detach().square().sum()) < objective:
                                z = candidate.requires_grad_(True)
                                accepted = True
                                break
                            alpha *= 0.5
                        if accepted:
                            break
                    if not accepted:
                        raise self._loop_failure(q_current, r, jac, binding)
                r = residual(z)
                if float(r.detach().abs().max()) > self.tolerance_pa:
                    raise RuntimeError("Cycle momentum solve exceeded its convergence budget.")
                # One implicit correction differentiates the converged root, not the iterations.
                jac = torch.autograd.functional.jacobian(residual, z).detach()
                z_implicit = z.detach() - self._loop_direction(jac, residual(z.detach()))
                q = q0 + self.cycles @ z_implicit
                if not outer_grad:
                    q = q.detach()
        if bool((q.detach() < -1e-12).any()):
            raise RuntimeError("Negative branch flow under the declared transport orientation.")
        state = self._transport(q, rates, watercuts, source_at)
        totals = torch.stack([d.sum() for d in state["drops"]])
        node_p = {self.sink: rates.new_tensor(44.7 * PSI_TO_PA)}
        queue = deque([self.sink])
        while queue:
            node = queue.popleft()
            for neighbor, edge, sign in self.tree[node]:
                if neighbor not in node_p:
                    node_p[neighbor] = node_p[node] - sign * totals[edge]
                    queue.append(neighbor)
        pressure = torch.stack([node_p[n] for n in self.nodes])
        profiles_p = []
        for i, edge in enumerate(self.edges):
            drops = state["drops"][i]
            suffix = torch.flip(torch.cumsum(torch.flip(drops, [0]), 0), [0])
            interior = node_p[edge["down"]] + suffix[1:]
            profiles_p.append(torch.cat([
                node_p[edge["up"]].reshape(1), interior, node_p[edge["down"]].reshape(1),
            ]))
        all_pressures = torch.cat([pressure, *profiles_p])
        if not bool(torch.isfinite(all_pressures).all()):
            raise FloatingPointError("Nonfinite absolute network pressure.")
        if validate_pressure and bool((all_pressures <= 0).any()):
            raise ValueError("Nonpositive psia prediction; no pressure floor was applied.")
        residuals, water_residuals, energy_residuals = [], [], []
        for node in self.nodes:
            injected = sum((rates[i] for i in source_at[node]), rates.new_zeros(()))
            if node != self.sink:
                residuals.append(
                    sum((q[e] for e in self.outgoing[node]), rates.new_zeros(()))
                    - sum((q[e] for e in self.incoming[node]), rates.new_zeros(())) - injected,
                )
                water_residuals.append(
                    sum((q[e] * state["wc"][e] for e in self.outgoing[node]), rates.new_zeros(()))
                    - sum((q[e] * state["wc"][e] for e in self.incoming[node]), rates.new_zeros(()))
                    - sum((rates[i] * watercuts[i] for i in source_at[node]), rates.new_zeros(()))
                )
                energy_residuals.append(
                    sum((self.physics.heat_capacity_rate(q[e], state["wc"][e]) * state["inlet"][e]
                         for e in self.outgoing[node]), rates.new_zeros(()))
                    - sum((self.physics.heat_capacity_rate(q[e], state["wc"][e])
                           * state["temperature_profiles"][e][-1]
                           for e in self.incoming[node]), rates.new_zeros(()))
                    - sum((self.physics.heat_capacity_rate(rates[i], watercuts[i])
                           * self.sources[self.source_ids[i]]["temperature_k"]
                           for i in source_at[node]), rates.new_zeros(()))
                )
        return {
            **state, "pressure_pa": pressure,
            "temperature_k": torch.stack([state["node_t"][n] for n in self.nodes]),
            "pressure_profiles_pa": profiles_p, "flow_m3_s": q,
            "cycle_residual_pa": self.cycles.T @ totals,
            "flow_residual_m3_s": torch.stack(residuals),
            "water_residual_m3_s": torch.stack(water_residuals),
            "oil_residual_m3_s": torch.stack(residuals) - torch.stack(water_residuals),
            "junction_enthalpy_residual_w": torch.stack(energy_residuals),
            "iterations": iterations, "geometry_hash": self.geometry_hash,
        }

    def query(self, state, edge_id, distance_m):
        if state["geometry_hash"] != self.geometry_hash:
            raise ValueError("Prediction state belongs to a different geometry.")
        ids = [e["id"] for e in self.edges]
        if edge_id not in ids:
            raise ValueError(f"Unknown branch {edge_id}.")
        i = ids.index(edge_id)
        s, z, d = (getattr(self, f"{k}_{i}") for k in ("s", "z", "d"))
        x = s.new_tensor(distance_m)
        if not math.isfinite(distance_m) or distance_m < 0 or distance_m > float(s[-1]):
            raise ValueError("Query distance lies outside the selected branch.")
        if distance_m == float(s[-1]):
            return state["pressure_profiles_pa"][i][-1], state["temperature_profiles"][i][-1]
        j = int(torch.searchsorted(s, x, right=True)) - 1
        if distance_m == float(s[j]):
            return state["pressure_profiles_pa"][i][j], state["temperature_profiles"][i][j]
        fraction = (x - s[j]) / (s[j + 1] - s[j])
        q, wc, inlet = state["flow_m3_s"][i], state["wc"][i], state["inlet"][i]
        partial = self.physics.segment_drop(
            q, wc, inlet, s[j], x - s[j], fraction * (z[j + 1] - z[j]),
            d[j], getattr(self, f"rough_{i}")[j],
        )
        pressure = state["pressure_profiles_pa"][i][j] - partial
        temperature = self.physics.temperature_at(inlet, x, q, wc)
        return pressure, temperature
