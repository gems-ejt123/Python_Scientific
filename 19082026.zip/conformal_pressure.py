"""
conformal_pressure.py - Adaptive split-conformal prediction intervals for the
BADI per-trunk pressure surrogate.

Turns the model's single point pressure P_hat into a calibrated interval
[P_lower, P_upper] with (1 - alpha) marginal coverage. Three adaptive ingredients:

  * Mondrian (per-trunk) calibration    -> valid coverage *within each trunk*, not
                                           just pooled across the whole network.
  * Level-adaptive normalization        -> wider bands where the surrogate is less
                                           certain (the >250 psi tail), tighter where
                                           it is sharp. Keeps average width small at
                                           fixed coverage.
  * ACI online recalibration (optional) -> nudges alpha as ground truth arrives at
                                           deployment so coverage holds under drift
                                           (Gibbs & Candes, 2021).

Split-conformal validity: with calibration residuals r_i and a per-row scale s_i,
the nonconformity score is |r_i| / s_i. qhat = the finite-sample (1-alpha) quantile
of those scores. Then P(|r| <= qhat * s(x)) >= 1 - alpha for an exchangeable new point.
The scale s(x) only shapes the width; it never breaks the coverage guarantee.

Pure numpy / pandas. Serializes to one JSON file next to the model bundle.
"""
from __future__ import annotations
import json
import numpy as np
import pandas as pd

_EPS = 1e-6


class ConformalPressure:
    def __init__(self, alpha=0.10, mondrian=True, scale="level",
                 p0=250.0, min_group=30, aci_gamma=0.0):
        """
        alpha      : target miscoverage (0.10 -> 90% intervals).
        mondrian   : per-trunk quantiles (True) vs one pooled quantile (False).
        scale      : 'const'  -> classic split conformal (uniform width per trunk).
                     'level'  -> width grows with predicted pressure above p0 (tail).
                     'delta'  -> width grows with |P_hat - P_backbone| (needs backbone col).
        p0         : pressure knee for the 'level' scale (psi).
        min_group  : trunks with fewer calibration points fall back to the pooled pool.
        aci_gamma  : ACI step size for online recalibration (0 = off).
        """
        self.alpha = float(alpha)
        self.alpha_target = float(alpha)      # ACI drifts self.alpha around this
        self.mondrian = bool(mondrian)
        self.scale = str(scale)
        self.p0 = float(p0)
        self.min_group = int(min_group)
        self.aci_gamma = float(aci_gamma)
        # fitted state
        self.scale_a = 1.0                    # scale = a + b * feature
        self.scale_b = 0.0
        self.scores_global = np.empty(0)
        self.scores_by_trunk = {}             # trunk -> np.ndarray of scores
        self.qhat_global = None
        self.qhat_by_trunk = {}

    # ---------------- scale model ----------------
    def _feature(self, pred, backbone=None):
        pred = np.asarray(pred, float)
        if self.scale == "const":
            return np.zeros_like(pred)
        if self.scale == "level":
            return np.maximum(0.0, (pred - self.p0) / self.p0)
        if self.scale == "delta":
            if backbone is None:
                raise ValueError("scale='delta' needs a backbone column")
            return np.abs(pred - np.asarray(backbone, float))
        raise ValueError(f"unknown scale '{self.scale}'")

    def _fit_scale(self, pred, abs_resid, backbone=None):
        if self.scale == "const":
            self.scale_a, self.scale_b = 1.0, 0.0
            return
        f = self._feature(pred, backbone)
        # non-negative least squares on [1, f] -> a + b f ~ |resid|
        A = np.column_stack([np.ones_like(f), f])
        coef, *_ = np.linalg.lstsq(A, np.asarray(abs_resid, float), rcond=None)
        a, b = float(coef[0]), float(coef[1])
        # keep the scale strictly positive and non-decreasing in the feature
        self.scale_a = max(a, _EPS)
        self.scale_b = max(b, 0.0)

    def _scale_of(self, pred, backbone=None):
        f = self._feature(pred, backbone)
        return np.maximum(self.scale_a + self.scale_b * f, _EPS)

    # ---------------- quantile ----------------
    @staticmethod
    def _conformal_quantile(scores, alpha):
        s = np.sort(np.asarray(scores, float))
        n = s.size
        if n == 0:
            return None
        q = np.ceil((n + 1) * (1.0 - alpha)) / n
        q = min(q, 1.0)                       # n small -> use the max score (conservative)
        return float(np.quantile(s, q, method="higher"))

    def _refresh_qhat(self):
        self.qhat_global = self._conformal_quantile(self.scores_global, self.alpha)
        self.qhat_by_trunk = {}
        for t, sc in self.scores_by_trunk.items():
            if self.mondrian and sc.size >= self.min_group:
                self.qhat_by_trunk[t] = self._conformal_quantile(sc, self.alpha)
            else:
                self.qhat_by_trunk[t] = self.qhat_global   # pooled fallback

    def set_alpha(self, alpha):
        """Change the confidence level and recompute qhat (no re-calibration)."""
        self.alpha = float(alpha)
        self._refresh_qhat()
        return self

    # ---------------- calibration ----------------
    def calibrate(self, df, y_col, pred_col, trunk_col=None, backbone_col=None):
        y = df[y_col].to_numpy(float)
        yhat = df[pred_col].to_numpy(float)
        bb = df[backbone_col].to_numpy(float) if (backbone_col and backbone_col in df) else None
        resid = np.abs(y - yhat)

        self._fit_scale(yhat, resid, bb)
        s = self._scale_of(yhat, bb)
        scores = resid / s
        self.scores_global = scores.copy()

        self.scores_by_trunk = {}
        if trunk_col is not None and trunk_col in df:
            tr = df[trunk_col].astype(str).to_numpy()
            for t in np.unique(tr):
                self.scores_by_trunk[t] = scores[tr == t]
        self._refresh_qhat()
        return self

    # ---------------- prediction ----------------
    def predict(self, df, pred_col, trunk_col=None, backbone_col=None,
                out_prefix="Pressure", clip_low=0.0):
        out = df.copy()
        yhat = out[pred_col].to_numpy(float)
        bb = out[backbone_col].to_numpy(float) if (backbone_col and backbone_col in out) else None
        s = self._scale_of(yhat, bb)

        if trunk_col is not None and trunk_col in out and self.qhat_by_trunk:
            tr = out[trunk_col].astype(str).to_numpy()
            qh = np.array([self.qhat_by_trunk.get(t, self.qhat_global) for t in tr], float)
        else:
            qh = np.full(yhat.shape, self.qhat_global if self.qhat_global is not None else np.nan)

        half = qh * s
        lo = yhat - half
        if clip_low is not None:
            lo = np.maximum(lo, clip_low)
        out[f"{out_prefix}_lower"] = lo
        out[f"{out_prefix}_upper"] = yhat + half
        out[f"{out_prefix}_width"] = out[f"{out_prefix}_upper"] - out[f"{out_prefix}_lower"]
        return out

    # ---------------- diagnostics ----------------
    def coverage(self, df, y_col, pred_col, trunk_col=None, backbone_col=None):
        p = self.predict(df, pred_col, trunk_col, backbone_col)
        y = p[y_col].to_numpy(float)
        inside = (y >= p[f"Pressure_lower"].to_numpy(float)) & (y <= p[f"Pressure_upper"].to_numpy(float))
        width = p["Pressure_width"].to_numpy(float)
        rep = {"overall": {"coverage": float(inside.mean()), "mean_width": float(width.mean()),
                           "n": int(inside.size), "target": 1 - self.alpha}}
        if trunk_col is not None and trunk_col in df:
            tr = df[trunk_col].astype(str).to_numpy()
            per = {}
            for t in np.unique(tr):
                m = tr == t
                per[t] = {"coverage": float(inside[m].mean()),
                          "mean_width": float(width[m].mean()), "n": int(m.sum())}
            rep["by_trunk"] = per
        return rep

    # ---------------- ACI online recalibration ----------------
    def aci_update(self, covered):
        """One online step after observing whether the emitted interval covered y.
        Returns the updated alpha. Call set_alpha implicitly (qhat refreshed)."""
        if self.aci_gamma <= 0:
            return self.alpha
        err = 0.0 if covered else 1.0
        new_alpha = self.alpha + self.aci_gamma * (self.alpha_target - err)
        self.alpha = float(np.clip(new_alpha, 1e-3, 0.5))
        self._refresh_qhat()
        return self.alpha

    # ---------------- persistence ----------------
    def save(self, path):
        state = {
            "alpha": self.alpha, "alpha_target": self.alpha_target,
            "mondrian": self.mondrian, "scale": self.scale, "p0": self.p0,
            "min_group": self.min_group, "aci_gamma": self.aci_gamma,
            "scale_a": self.scale_a, "scale_b": self.scale_b,
            "scores_global": self.scores_global.tolist(),
            "scores_by_trunk": {t: sc.tolist() for t, sc in self.scores_by_trunk.items()},
        }
        with open(path, "w") as f:
            json.dump(state, f)
        return path

    @classmethod
    def load(cls, path):
        with open(path) as f:
            st = json.load(f)
        cp = cls(alpha=st["alpha"], mondrian=st["mondrian"], scale=st["scale"],
                 p0=st["p0"], min_group=st["min_group"], aci_gamma=st["aci_gamma"])
        cp.alpha_target = st["alpha_target"]
        cp.scale_a, cp.scale_b = st["scale_a"], st["scale_b"]
        cp.scores_global = np.array(st["scores_global"], float)
        cp.scores_by_trunk = {t: np.array(v, float) for t, v in st["scores_by_trunk"].items()}
        cp._refresh_qhat()
        return cp


# ---------------- convenience: calibrate straight from training results ----------------
def build_blind_frame(per_trunk_results, pred_col="P_pred", true_col="P_true"):
    """Concatenate each trunk's held-out BLIND predictions into one calibration frame
    with a 'trunk' column. The blind split is never seen in training or early stopping,
    so it is a clean conformal calibration set."""
    frames = []
    for r in per_trunk_results:
        bdf = r.get("blind_df")
        if bdf is None or len(bdf) == 0:
            continue
        g = bdf.copy()
        g["trunk"] = r["trunk"]
        frames.append(g)
    if not frames:
        raise ValueError("no blind predictions found in per_trunk_results")
    return pd.concat(frames, ignore_index=True)


def fit_from_blind(per_trunk_results, alpha=0.10, scale="level", mondrian=True,
                   holdout=0.3, seed=42, pred_col="P_pred", true_col="P_true"):
    """Build the calibration frame, run an HONEST coverage check (split blind into
    fit/test), then refit on all blind points for the artifact.
    Returns (calibrator_fitted_on_all, report_dataframe)."""
    cal = build_blind_frame(per_trunk_results, pred_col, true_col)
    rng = np.random.RandomState(seed)
    mask = rng.rand(len(cal)) >= holdout          # True = fit part
    fit_df, test_df = cal[mask], cal[~mask]

    probe = ConformalPressure(alpha=alpha, scale=scale, mondrian=mondrian)
    probe.calibrate(fit_df, true_col, pred_col, trunk_col="trunk")
    rep = probe.coverage(test_df, true_col, pred_col, trunk_col="trunk")
    rows = [{"trunk": "ALL", **rep["overall"]}]
    for t, d in rep.get("by_trunk", {}).items():
        rows.append({"trunk": t, "target": 1 - alpha, **d})
    report = pd.DataFrame(rows)

    final = ConformalPressure(alpha=alpha, scale=scale, mondrian=mondrian)
    final.calibrate(cal, true_col, pred_col, trunk_col="trunk")
    return final, report
