"""
Collocation-augmented physics loss for the steady-state ESP VFM.

What this adds to ``PhysicsVFMLoss``
------------------------------------
The base loss evaluates ``R_ipr`` and ``R_pump`` only where labels exist, i.e.
on the 86 measured rows, all inside a 55-61 Hz band. This subclass adds the
*same two residuals* evaluated on unlabelled collocation points drawn from the
deployment frequency range (see ``physics/collocation.py``), which is what makes
the model a PINN in the Raissi sense rather than a physics-regularized
regressor.

    L = [ base: u_d L_data + u_i L_ipr + u_p L_pump ]
        + u_ci L_col_ipr + u_cp L_col_pump + w_dead L_dead

Two extra homoscedastic-uncertainty weights ``log_vars_col = [s_ci, s_cp]``
follow the same Kendall/Gal/Cipolla scheme as the base terms, so the labelled
and unlabelled residuals are balanced automatically instead of by hand.

Is this just a pseudo-label in disguise?
----------------------------------------
At a collocation point both residuals are driven to zero, and they vanish
*simultaneously* only at the coupled operating point q*. So at convergence the
effect resembles training on (x_col, q*). Three things make it a residual
constraint rather than a frozen label:

  1. q* is never formed in the graph. The gradient reaches the network only
     through dR/dq, so the physics -- not a stored number -- supplies the
     direction.
  2. The calibration (PI, dPr, k_head, dp_offset, visc) is *shared* with the
     labelled terms and keeps moving, so the constraint surface moves with it.
     A pseudo-label would freeze at the initial calibration.
  3. The points are re-placed during training (``recollocate_every`` in the
     trainer). Freezing them is exactly what would degrade this into distillation.

Dead points are handled as an inequality, not an equality
---------------------------------------------------------
At low frequency the pump can fail to cover the static lift even at zero flow
(``alive=False``): the balance has *no* positive root, so ``R_pump = 0`` is
unsatisfiable and forcing it would corrupt the calibration. For those points the
physically true statement is the inequality "no rate is sustainable", enforced as
a one-sided hinge pushing q to zero:

    L_dead = mean( relu(q)^2 ) / q_scale^2

These are the most informative points in the whole set -- they are the only
thing in the training signal that knows the well can die.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from esp_steady import ipr_residual, pump_energy_residual
from vfm_loss import PhysicsVFMLoss


class CollocationVFMLoss(PhysicsVFMLoss):
    """
    ``PhysicsVFMLoss`` + unlabelled collocation residuals.

    Extra parameters
    ----------------
    col_init_log_vars : tuple(float, float)
        Initial log-variances (s_col_ipr, s_col_pump).
    dead_weight : float
        Fixed multiplier on the dead-well hinge. Kept *fixed* rather than
        uncertainty-weighted: an adaptive weight would learn to switch it off
        (its residual is the hardest to satisfy), which is the opposite of what
        we want, since these points carry the extrapolation signal.
    """

    def __init__(self, *args, col_init_log_vars=(0.0, 0.0), dead_weight=1.0,
                 **kwargs):
        super().__init__(*args, **kwargs)
        s = torch.tensor(col_init_log_vars, dtype=torch.float32)
        if self.learn_weights:
            self.log_vars_col = nn.Parameter(s)
        else:
            self.register_buffer("log_vars_col", s)
        self.dead_weight = float(dead_weight)

    # ------------------------------------------------------------------ #
    def collocation_residuals(self, q_norm_col, phys_col, PI):
        """
        Physical rate and both residuals at the collocation points.

        ``phys_col`` carries ``Pr_Pa`` *without* dPr; the offset is added here so
        the labelled and unlabelled IPR use the identical effective reservoir
        pressure.
        """
        q = self.denorm_q(q_norm_col.squeeze(-1))
        dPr = self.reservoir_offset()
        R_ipr = ipr_residual(q, phys_col["Pr_Pa"] + dPr, phys_col["PWF_Pa"], PI)
        k_head, dp_offset = self.pump_calibration()
        visc = self.viscosity_strength()
        R_pump = pump_energy_residual(
            q, phys_col["f"], phys_col["PIP_Pa"], phys_col["THP_Pa"],
            phys_col["rho"], phys_col["mu"], self.pump, self.geom,
            k_head=k_head, dp_offset=dp_offset, visc_strength=visc,
            visc_nu_ref_cst=self.visc_nu_ref_cst,
        )
        return q, R_ipr, R_pump

    # ------------------------------------------------------------------ #
    def forward(self, q_norm_pred, q_norm_true, phys, PI,
                physics_weight=1.0, mono_penalty=None,
                q_norm_col=None, phys_col=None, alive_col=None,
                col_weight=1.0):
        """
        Base loss plus the collocation terms.

        Parameters
        ----------
        q_norm_col : torch.Tensor (n_col, 1) or None
            Network output at the collocation points (normalized). ``None``
            disables the collocation block entirely, recovering the base loss.
        phys_col : dict of torch.Tensor (n_col,)
            Keys 'PIP_Pa', 'THP_Pa', 'Pr_Pa', 'PWF_Pa', 'f', 'rho', 'mu'.
        alive_col : torch.Tensor (n_col,) bool
            False where the coupled solve found no positive root (dead well).
        col_weight : float
            Independent curriculum multiplier for the collocation block. Kept
            separate from ``physics_weight`` so the unlabelled residuals can be
            ramped in *after* the labelled ones, once the calibration that
            places the points is already roughly right.
        """
        total, parts = super().forward(
            q_norm_pred, q_norm_true, phys, PI,
            physics_weight=physics_weight, mono_penalty=mono_penalty,
        )
        parts.update({"L_col_ipr": 0.0, "L_col_pump": 0.0, "L_dead": 0.0,
                      "frac_alive": 1.0, "n_col": 0})

        if q_norm_col is None or phys_col is None or col_weight <= 0.0:
            return total, parts

        q_col, R_ipr_c, R_pump_c = self.collocation_residuals(
            q_norm_col, phys_col, PI)
        n_col = q_col.numel()
        parts["n_col"] = int(n_col)

        if alive_col is None:
            alive = torch.ones_like(q_col, dtype=torch.bool)
        else:
            alive = alive_col.to(torch.bool)
        dead = ~alive
        n_alive = int(alive.sum().item())
        parts["frac_alive"] = n_alive / max(1, n_col)

        zero = q_col.new_zeros(())
        if n_alive > 0:
            L_col_ipr = torch.mean((R_ipr_c[alive] / self.q_scale) ** 2)
            L_col_pump = torch.mean((R_pump_c[alive] / self.p_scale) ** 2)
        else:
            L_col_ipr, L_col_pump = zero, zero

        n_dead = n_col - n_alive
        if n_dead > 0:
            L_dead = torch.mean(
                (torch.relu(q_col[dead]) / self.q_scale) ** 2)
        else:
            L_dead = zero

        s_ci, s_cp = self.log_vars_col[0], self.log_vars_col[1]
        total = (total
                 + torch.exp(-s_ci) * col_weight * L_col_ipr + s_ci
                 + torch.exp(-s_cp) * col_weight * L_col_pump + s_cp
                 + self.dead_weight * col_weight * L_dead)

        parts["L_col_ipr"] = float(L_col_ipr.item())
        parts["L_col_pump"] = float(L_col_pump.item())
        parts["L_dead"] = float(L_dead.item())
        parts["R_col_ipr_rms"] = float(
            torch.sqrt(torch.mean(R_ipr_c ** 2)).item())
        parts["R_col_pump_rms"] = float(
            torch.sqrt(torch.mean(R_pump_c ** 2)).item())
        parts["total"] = total.item()
        return total, parts
