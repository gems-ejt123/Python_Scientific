"""
Evaluation and physics audits for the steady-state ESP VFM.

Beyond standard regression metrics (R^2, MAPE, RMSE on the liquid rate) this
module runs the physics-defensibility checks the VFM must pass before handoff:

  * Pump-curve residual RMS  - do predicted operating points sit on the
    affinity-scaled datasheet curve?
  * Productivity-index recovery - does the trained PI match the field ``IP``
    column (an independent estimate)?
  * Conformal interval coverage / width - is the UQ honest on the held-out,
    forward-in-time validation block?
  * Operating-point overlay - predicted (q, head) vs the real pump curve.

All flow quantities are reported in field units (bbl/d) for petrophysicist
readability while internal computation stays SI.
"""

from __future__ import annotations

import numpy as np
import torch

from real_data_loader import BBLPD_TO_M3S, PSI_TO_PA
from esp_steady import pump_energy_residual, ipr_residual, DEFAULT_GEOMETRY, G, FT_TO_M


def m3s_to_bblpd(q):
    return np.asarray(q) / BBLPD_TO_M3S


# --------------------------------------------------------------------------- #
#  Point metrics                                                               #
# --------------------------------------------------------------------------- #
def regression_metrics(y_true, y_pred):
    """R^2, MAPE [%], MAE and RMSE in bbl/d for the liquid-rate target."""
    yt = m3s_to_bblpd(y_true)
    yp = m3s_to_bblpd(y_pred)
    err = yp - yt
    ss_res = np.sum(err ** 2)
    ss_tot = np.sum((yt - yt.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    mape = float(np.mean(np.abs(err / yt)) * 100.0)
    return {
        "R2": float(r2),
        "MAPE_%": mape,
        "MAE_bblpd": float(np.mean(np.abs(err))),
        "RMSE_bblpd": float(np.sqrt(np.mean(err ** 2))),
        "bias_bblpd": float(np.mean(err)),
    }


def classify_performance(metrics):
    """Skill-card performance level from R^2 and MAPE."""
    r2, mape = metrics["R2"], metrics["MAPE_%"]
    if r2 > 0.95 and mape < 3:
        return "Excellent"
    if r2 > 0.90 and mape < 5:
        return "Good"
    if r2 > 0.80 and mape < 10:
        return "Fair"
    return "Poor"


# --------------------------------------------------------------------------- #
#  Uncertainty                                                                 #
# --------------------------------------------------------------------------- #
def interval_metrics(y_true, lower, upper):
    """Empirical coverage and mean interval width [bbl/d]."""
    yt = m3s_to_bblpd(y_true)
    lo, up = m3s_to_bblpd(lower), m3s_to_bblpd(upper)
    covered = (yt >= lo) & (yt <= up)
    return {
        "coverage": float(np.mean(covered)),
        "mean_width_bblpd": float(np.mean(up - lo)),
    }


# --------------------------------------------------------------------------- #
#  Physics audits                                                              #
# --------------------------------------------------------------------------- #
def pump_residual_audit(q_pred, phys, idx, pump, geom=None,
                        k_head=1.0, dp_offset=0.0):
    """RMS / mean-abs of the pump energy-balance residual at predicted flow [psi].

    Pass the trained ``k_head``/``dp_offset`` (e.g. ``ensemble.k_head``,
    ``ensemble.dp_offset``) to audit the *calibrated* curve the model actually
    enforced; defaults reproduce the raw datasheet residual.
    """
    geom = geom or DEFAULT_GEOMETRY
    tq = lambda a: torch.tensor(a, dtype=torch.float32)
    R = pump_energy_residual(
        tq(q_pred), tq(phys["f"][idx]), tq(phys["PIP_Pa"][idx]),
        tq(phys["THP_Pa"][idx]), tq(phys["rho"][idx]), tq(phys["mu"][idx]),
        pump, geom, k_head=k_head, dp_offset=dp_offset,
    ).detach().numpy()
    return {
        "pump_resid_rms_psi": float(np.sqrt(np.mean(R ** 2)) / PSI_TO_PA),
        "pump_resid_mae_psi": float(np.mean(np.abs(R)) / PSI_TO_PA),
    }


def ipr_audit(q_pred, phys, idx, PI, IP_field_mean=None, dPr=0.0):
    """IPR residual + recovered productivity index in field units (bbl/d/psi).

    ``dPr`` [Pa] is the trained additive reservoir-pressure correction (0.0 when
    ``learn_Pr=False``). It must match what the model was trained with, otherwise
    the residual reported here is not the residual the loss actually minimized.
    """
    Pr = phys["Pr_Pa"][idx] + dPr
    Pwf = phys["PWF_Pa"][idx]
    R = q_pred - PI * (Pr - Pwf)
    PI_field = PI / BBLPD_TO_M3S * PSI_TO_PA
    out = {
        "ipr_resid_rms_bblpd": float(np.sqrt(np.mean((R / BBLPD_TO_M3S) ** 2))),
        "PI_bblpd_psi": float(PI_field),
        "Pr_offset_psi": float(dPr / PSI_TO_PA),
        "drawdown_mean_psi": float(np.mean(Pr - Pwf) / PSI_TO_PA),
    }
    if IP_field_mean is not None:
        out["PI_vs_IP_rel_err_%"] = float(abs(PI_field - IP_field_mean) / IP_field_mean * 100)
    return out


def physical_plausibility(q_pred):
    """Hard physical sanity flags on the predicted liquid rate."""
    q = np.asarray(q_pred)
    return {
        "all_positive": bool(np.all(q > 0)),
        "q_min_bblpd": float(m3s_to_bblpd(q).min()),
        "q_max_bblpd": float(m3s_to_bblpd(q).max()),
    }


# --------------------------------------------------------------------------- #
#  Overfitting diagnostics                                                     #
# --------------------------------------------------------------------------- #
def overfitting_report(y, pred, splits):
    """
    State-of-the-art overfitting diagnostics across named splits
    (e.g. {"train": idx, "val": idx, "blind": idx}).

    Reports, per split: RMSE / MAE / MAPE / R2 / bias plus residual std.
    Cross-split: generalization gap (RMSE ratio vs train, R2 drop) and
    two-sample Kolmogorov-Smirnov + Levene tests on the residual
    distributions (p > 0.05 -> residuals statistically indistinguishable
    from train -> no evidence of overfitting).
    """
    from scipy import stats

    resid = {name: m3s_to_bblpd(pred[idx]) - m3s_to_bblpd(y[idx])
             for name, idx in splits.items() if len(idx)}
    out = {}
    for name, idx in splits.items():
        if not len(idx):
            continue
        m = regression_metrics(y[idx], pred[idx])
        m["resid_std_bblpd"] = float(np.std(resid[name]))
        out[name] = m

    rmse_tr = out["train"]["RMSE_bblpd"]
    r2_tr = out["train"]["R2"]
    gaps = {}
    for name in splits:
        if name == "train" or name not in out:
            continue
        ks = stats.ks_2samp(resid["train"], resid[name])
        lev = stats.levene(resid["train"], resid[name])
        gaps[name] = {
            "RMSE_ratio_vs_train": float(out[name]["RMSE_bblpd"] / rmse_tr),
            "R2_drop_vs_train": float(r2_tr - out[name]["R2"]),
            "KS_stat": float(ks.statistic), "KS_pvalue": float(ks.pvalue),
            "Levene_pvalue": float(lev.pvalue),
        }
    out["overfitting_gaps"] = gaps
    # Rule of thumb: ratio < 1.5 and KS p > 0.05 on the blind block => healthy.
    worst = max((g["RMSE_ratio_vs_train"] for g in gaps.values()), default=1.0)
    out["verdict"] = ("no overfitting" if worst < 1.3 else
                      "mild overfitting" if worst < 2.0 else "overfitting")
    return out


def plot_residual_comparison(y, pred, splits):
    """Boxplot + histogram of residuals [bbl/d] per split (train/val/blind)."""
    import matplotlib.pyplot as plt
    resid = {name: m3s_to_bblpd(pred[idx]) - m3s_to_bblpd(y[idx])
             for name, idx in splits.items() if len(idx)}
    names = list(resid)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].boxplot([resid[n] for n in names], tick_labels=names)
    axes[0].axhline(0, color="k", lw=1, ls="--")
    axes[0].set_ylabel("residual [bbl/d]")
    axes[0].set_title("Residuals per split")
    axes[0].grid(alpha=0.3)
    for i, n_ in enumerate(names):
        axes[1].hist(resid[n_], bins=15, alpha=0.55, label=n_, color=f"C{i}",
                     density=True)
    axes[1].axvline(0, color="k", lw=1, ls="--")
    axes[1].set_xlabel("residual [bbl/d]")
    axes[1].set_title("Residual distributions")
    axes[1].legend(); axes[1].grid(alpha=0.3)
    plt.tight_layout()
    return fig


# --------------------------------------------------------------------------- #
#  Plotting                                                                    #
# --------------------------------------------------------------------------- #
def plot_timeseries(dates, y_true, mean, lower=None, upper=None,
                    train_idx=None, val_idx=None, ax=None):
    """Measured vs predicted liquid rate over time with optional conformal band."""
    import matplotlib.pyplot as plt
    if ax is None:
        _, ax = plt.subplots(figsize=(11, 4))
    yt = m3s_to_bblpd(y_true)
    ym = m3s_to_bblpd(mean)
    ax.plot(dates, yt, "k.-", lw=1, ms=5, label="Measured BFPD")
    ax.plot(dates, ym, "C0.-", lw=1, ms=4, label="PINN-VFM")
    if lower is not None and upper is not None:
        ax.fill_between(dates, m3s_to_bblpd(lower), m3s_to_bblpd(upper),
                        color="C0", alpha=0.2, label="Conformal interval")
    if val_idx is not None and len(val_idx):
        ax.axvline(dates[val_idx[0]], color="r", ls="--", lw=1, label="train/val split")
    ax.set_ylabel("Liquid rate [bbl/d]")
    ax.set_xlabel("Date")
    ax.legend(loc="best", fontsize=8)
    ax.grid(alpha=0.3)
    return ax


def plot_parity(y_true, y_pred, ax=None, title="Parity"):
    """Predicted vs measured parity plot in bbl/d."""
    import matplotlib.pyplot as plt
    if ax is None:
        _, ax = plt.subplots(figsize=(5, 5))
    yt = m3s_to_bblpd(y_true)
    yp = m3s_to_bblpd(y_pred)
    lim = [min(yt.min(), yp.min()) * 0.98, max(yt.max(), yp.max()) * 1.02]
    ax.plot(lim, lim, "k--", lw=1)
    ax.scatter(yt, yp, s=25, alpha=0.7)
    ax.set_xlim(lim)
    ax.set_ylim(lim)
    ax.set_xlabel("Measured BFPD [bbl/d]")
    ax.set_ylabel("Predicted BFPD [bbl/d]")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    return ax


def plot_pump_operating_points(pump, q_pred, phys, idx, ax=None):
    """Overlay predicted operating points (q, measured head) on the datasheet curve."""
    import matplotlib.pyplot as plt
    if ax is None:
        _, ax = plt.subplots(figsize=(6, 5))
    q_curve = m3s_to_bblpd(pump.q_m3s)
    h_curve = pump.head_m / FT_TO_M
    ax.plot(q_curve, h_curve, "C1-", lw=2, label="Datasheet curve (60 Hz)")

    rho = phys["rho"][idx]
    PIP = phys["PIP_Pa"][idx]
    THP = phys["THP_Pa"][idx]
    H_meas = (THP + rho * G * pump.geom.dh_lift_m - PIP) / (rho * G) / FT_TO_M
    ax.scatter(m3s_to_bblpd(q_pred), H_meas, s=30, color="C0", alpha=0.7,
               label="Predicted operating points")
    ax.set_xlabel("Liquid rate [bbl/d]")
    ax.set_ylabel("Head [ft]")
    ax.set_title("ESP operating points vs pump curve")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    return ax


def plot_loss_history(histories, ax=None, show_dPr=True):
    """
    Mean (over the ensemble) training-loss component curves.

    If ``show_dPr`` and the histories carry a ``dPr_Pa`` trace that actually
    moves (i.e. the run used ``learn_Pr=True``), the learned reservoir-pressure
    correction is overlaid in psi on a right-hand linear axis. dPr is not a
    loss component, so it gets its own axis instead of sharing the log scale.
    """
    import matplotlib.pyplot as plt
    if ax is None:
        _, ax = plt.subplots(figsize=(8, 4))
    handles = []
    for key, color in [("L_data", "C0"), ("L_ipr", "C1"), ("L_pump", "C2")]:
        stacked = np.stack([h[key] for h in histories], axis=0).mean(axis=0)
        handles += ax.semilogy(stacked, color=color, label=key)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss component")
    ax.grid(alpha=0.3)

    if show_dPr and all("dPr_Pa" in h for h in histories):
        dpr_psi = np.stack([h["dPr_Pa"] for h in histories],
                           axis=0).mean(axis=0) / PSI_TO_PA
        if np.ptp(dpr_psi) > 1e-6:          # stays 0 when learn_Pr=False
            ax2 = ax.twinx()
            handles += ax2.plot(dpr_psi, color="C3", ls="--", label="dPr [psi]")
            ax2.set_ylabel("dPr [psi]", color="C3")
            ax2.tick_params(axis="y", labelcolor="C3")
            ax2.axhline(0.0, color="C3", lw=0.6, alpha=0.4)

    ax.legend(handles, [h.get_label() for h in handles], loc="best")
    return ax


def full_report(ensemble, bundle, splits, pump):
    """
    Run the complete metric + physics audit suite and return a nested dict.

    Parameters
    ----------
    ensemble : VFMEnsemble (already fitted and conformally calibrated)
    bundle   : RealDataBundle
    splits   : (train_idx, val_idx, blind_idx)
    pump     : ESPPumpCurve
    """
    train_idx, val_idx, blind_idx = splits
    X, y, phys = bundle.X, bundle.y, bundle.phys
    IP_field_mean = float(bundle.df["IP"].mean())

    report = {}
    for name, idx in [("train", train_idx), ("val", val_idx), ("blind", blind_idx)]:
        if len(idx) == 0:
            continue
        mean, lo, up = ensemble.predict_interval(X[idx])
        m = regression_metrics(y[idx], mean)
        m["level"] = classify_performance(m)
        m.update(interval_metrics(y[idx], lo, up))
        m.update(pump_residual_audit(mean, phys, idx, pump,
                                     k_head=ensemble.k_head,
                                     dp_offset=ensemble.dp_offset))
        m.update(ipr_audit(mean, phys, idx, ensemble.PI, IP_field_mean,
                           dPr=getattr(ensemble, "dPr", 0.0)))
        m.update(physical_plausibility(mean))
        report[name] = m

    report["PI_recovered_bblpd_psi"] = ensemble.PI / BBLPD_TO_M3S * PSI_TO_PA
    report["IP_field_mean_bblpd_psi"] = IP_field_mean
    report["conformal_halfwidth_bblpd"] = ensemble.q_hat / BBLPD_TO_M3S
    report["pump_k_head"] = ensemble.k_head
    report["pump_dp_offset_psi"] = ensemble.dp_offset / PSI_TO_PA
    report["Pr_offset_psi"] = getattr(ensemble, "dPr", 0.0) / PSI_TO_PA
    return report
