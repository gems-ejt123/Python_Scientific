"""
Kolmogorov-Arnold Network backbone for the steady-state ESP VFM.

Why a KAN here
--------------
An MLP puts fixed activations on the *nodes* and learns the weights on the
edges. A KAN puts learnable univariate splines on the *edges* and only sums at
the nodes. For a problem like this one -- 8 physically meaningful inputs, ~86
rows, and a target that is a smooth low-order function of each input -- that is
the more appropriate inductive bias: each edge spline is directly readable as
"the contribution of feature j", which is exactly the kind of per-feature
response an engineer wants to sanity-check against the pump curve and the IPR.

The physics is unchanged
------------------------
This module only replaces the function approximator. ``CollocationVFMLoss``,
the IPR / pump-energy residuals, the collocation sampler, the monotonicity
prior and the conformal wrapper never look inside the backbone -- they only
need ``(batch, n_features) -> (batch, 1)`` in normalized target space, plus
differentiability w.r.t. the input for the ``dq/df`` prior. So
``KANVFMNet`` is a drop-in for ``VFMNet`` via ``VFMTrainer(net_cls=...)``.

Three things that actually matter in practice
---------------------------------------------
1. **``grid_range`` decides whether the KAN can extrapolate at all.**
   A B-spline basis is identically zero outside its knot span. Outside
   ``grid_range`` a KAN edge collapses to ``scale_base * base_fun(x)`` (silu),
   i.e. it degenerates to a plain shallow net. The whole point of the
   collocation notebook is to constrain 40-70 Hz while the labels only cover
   55-61 Hz, so the *normalized* collocation inputs land well outside
   ``[-1, 1]``. Passing a ``grid_range`` that covers the collocation box (see
   ``suggest_grid_range``) is not a tuning detail -- with the default
   ``[-1, 1]`` the extrapolation splines are dead weights and the KAN cannot
   respond to the collocation residuals at all.

2. **``save_act`` must be off.** PyKAN caches every intermediate activation on
   each forward to support its plotting / symbolic-regression tools. Over
   thousands of full-batch epochs with a second forward pass for the
   monotonicity autograd, that is pure overhead. We only need gradients.

3. **Spline smoothness.** ``k=3`` cubic splines are C^2, so the first-order
   autograd used by the monotonicity prior is well defined and continuous.
   Do not drop to ``k=1``.

Requires ``pykan``:  ``pip install pykan``
"""

from __future__ import annotations

import inspect
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# --------------------------------------------------------------------------- #
#  Optional dependency                                                         #
# --------------------------------------------------------------------------- #
def _import_kan():
    """Import PyKAN's ``KAN`` with an actionable error if it is missing."""
    try:
        from kan import KAN  # noqa: WPS433
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "KANVFMNet requires PyKAN. Install it into the training env:\n"
            "    pip install pykan\n"
            f"(original error: {exc})"
        ) from exc
    return KAN


def pykan_available() -> bool:
    """True if PyKAN can be imported (use to gate notebook cells)."""
    try:
        import kan  # noqa: F401, WPS433
        return True
    except ImportError:
        return False


# --------------------------------------------------------------------------- #
#  Grid range helper                                                           #
# --------------------------------------------------------------------------- #
def suggest_grid_range(scaler, X_list, margin=0.15):
    """
    Symmetric spline knot span covering every normalized input the model will
    ever see, labelled *and* collocation.

    Parameters
    ----------
    scaler : FeatureScaler (fitted)
    X_list : sequence of np.ndarray
        Raw (unscaled) feature matrices, e.g. ``[X_train, X_col]``.
    margin : float
        Fractional padding added to the extreme, so the outermost knots are not
        sitting exactly on the outermost sample.

    Returns
    -------
    (lo, hi) : tuple of float
        Pass straight to ``KANVFMNet(grid_range=...)``.

    Notes
    -----
    The span is made symmetric on purpose. PyKAN uses one ``grid_range`` for all
    edges in a layer, so an asymmetric span would waste knots on features that
    never reach that side.
    """
    ext = 1.0
    for X in X_list:
        if X is None or len(X) == 0:
            continue
        Xn = scaler.transform_X(np.asarray(X, dtype=float))
        ext = max(ext, float(np.abs(Xn).max()))
    ext *= (1.0 + margin)
    return (-ext, ext)


# --------------------------------------------------------------------------- #
#  Backbone                                                                    #
# --------------------------------------------------------------------------- #
class KANVFMNet(nn.Module):
    """
    PyKAN backbone wrapped to the ``VFMNet`` contract.

    Parameters
    ----------
    n_features : int
        Input width (set by the trainer).
    hidden : int
        Width of each hidden KAN layer. KANs are parameter-hungry per edge
        (``grid + k`` coefficients each), so keep this small: 5-10 for 86 rows.
    n_layers : int
        Number of hidden layers. Depth 2 is already a universal approximator in
        the Kolmogorov-Arnold sense; depth 3+ mostly buys overfitting here.
    grid : int
        Spline intervals per edge. More grid = sharper but more overfit-prone.
    k : int
        Spline order. 3 (cubic, C^2) -- required for the autograd monotonicity
        prior to be smooth.
    grid_range : tuple(float, float)
        Knot span in *normalized* input units. See the module docstring: this is
        the single most important setting for extrapolation. Use
        ``suggest_grid_range``.
    base_fun : str
        Residual branch on each edge ('silu' or 'identity'). This branch is what
        carries the response outside ``grid_range``, so do not disable it.
    noise_scale : float
        Spline init noise. Small (0.1) keeps the initial map near the base
        branch, which pairs well with the data-first curriculum.
    positive_output : bool
        Softplus on the normalized output. Use with ``FeatureScaler('scale')``;
        under min-max scaling this imposes ``q > y_min``, not ``q > 0``.
    out_shift : float
        Offset subtracted *after* the Softplus, in normalized target units.
        Set to ``y_min / y_range`` to move the bound from ``q > y_min`` to the
        physical ``q > 0`` while keeping a min-max scaler. Mirrors
        ``VFMNet.out_shift`` -- see that class docstring for the derivation.
        Default 0.0 (legacy behaviour).
    seed : int or None
        ``None`` (default) draws the seed from the *ambient* torch RNG. This
        matters for ensembling: PyKAN calls ``torch.manual_seed(seed)`` inside
        its own ``__init__``, so a fixed ``seed`` in ``net_kwargs`` would make
        every ensemble member byte-identical and silently collapse the epistemic
        spread to zero. ``VFMTrainer.fit`` seeds torch per member before building
        the net, so ``None`` gives one distinct-but-reproducible KAN per member.
    sparse_init, grid_eps, device
        Passed through to PyKAN when that version supports them.

    Notes
    -----
    ``lamb_l1`` / ``regularization`` are deliberately absent. PyKAN's sparsity
    penalty is computed from cached activations (``save_act=True``), which we
    disable for speed; and an L1 pull toward zero fights the physics residuals
    for control of the same edges. Regularize with ``weight_decay`` on the
    optimizer instead, as the trainer already does.
    """

    def __init__(self, n_features, hidden=6, n_layers=2, grid=5, k=3,
                 grid_range=(-1.5, 1.5), base_fun="silu", noise_scale=0.1,
                 positive_output=True, out_shift=0.0, sparse_init=False,
                 grid_eps=0.02, seed=None, device="cpu", **_ignored):
        super().__init__()
        KAN = _import_kan()

        if seed is None:
            # Consume the ambient RNG so each ensemble member differs; PyKAN
            # re-seeds torch from this value internally.
            seed = int(torch.randint(0, 2 ** 31 - 1, (1,)).item())
        self.seed = int(seed)
        self.positive_output = bool(positive_output)
        self.out_shift = float(out_shift)
        self.width = [int(n_features)] + [int(hidden)] * int(n_layers) + [1]
        self.grid_range = (float(grid_range[0]), float(grid_range[1]))

        wanted = {
            "width": self.width,
            "grid": int(grid),
            "k": int(k),
            "seed": self.seed,
            "device": device,
            "grid_range": list(self.grid_range),
            "base_fun": base_fun,
            "noise_scale": float(noise_scale),
            "sparse_init": bool(sparse_init),
            "grid_eps": float(grid_eps),
            # Bookkeeping we do not want: activation caching (slow) and
            # automatic checkpoint files written to ./model on construction.
            "save_act": False,
            "auto_save": False,
            "symbolic_enabled": False,
        }
        # PyKAN's signature has churned across 0.0.x / 0.1.x / 0.2.x; only pass
        # what this installed version actually accepts.
        accepted = inspect.signature(KAN.__init__).parameters
        kwargs = {kk: vv for kk, vv in wanted.items() if kk in accepted}
        self.kan = KAN(**kwargs)

        # Belt and braces: older versions set these as plain attributes after
        # __init__ rather than accepting them as arguments.
        for attr, val in (("save_act", False), ("auto_save", False),
                          ("symbolic_enabled", False)):
            if hasattr(self.kan, attr):
                setattr(self.kan, attr, val)

    # ------------------------------------------------------------------ #
    def forward(self, x):
        """
        Parameters
        ----------
        x : torch.Tensor (batch, n_features)  -- normalized features.

        Returns
        -------
        q_norm : torch.Tensor (batch, 1) -- normalized rate, bounded below by
        ``-out_shift`` when ``positive_output``.
        """
        out = self.kan(x)
        if out.dim() == 1:
            out = out.unsqueeze(-1)
        if self.positive_output:
            out = F.softplus(out) - self.out_shift
        return out

    # ------------------------------------------------------------------ #
    @torch.no_grad()
    def refine_grid(self, x):
        """
        Re-place the spline knots on the empirical distribution of ``x``
        (PyKAN's ``update_grid_from_samples``).

        Call sparingly and only *before* the physics curriculum ramps in:
        moving the knots changes the function the optimizer is descending, so
        doing it mid-ramp shows up as a loss discontinuity. Silently a no-op on
        PyKAN versions without the method.
        """
        fn = getattr(self.kan, "update_grid_from_samples", None)
        if fn is None:
            return False
        fn(x)
        return True

    def edge_activations(self, x, layer=0):
        """
        Per-edge spline responses of one layer, for interpretability plots.

        Returns
        -------
        np.ndarray (batch, n_in, n_out) or None if unsupported by this PyKAN
        version.
        """
        act_fun = getattr(self.kan, "act_fun", None)
        if act_fun is None or layer >= len(act_fun):
            return None
        with torch.no_grad():
            out = act_fun[layer](x)
        # PyKAN returns (y, preacts, postacts, postspline); postacts is (batch,
        # n_out, n_in) in 0.2.x.
        postacts = out[2] if isinstance(out, (tuple, list)) and len(out) >= 3 else None
        if postacts is None:
            return None
        return postacts.detach().cpu().numpy().transpose(0, 2, 1)


# --------------------------------------------------------------------------- #
def make_kan_ensemble(n_models, seed0=0, **kwargs):
    """Deep ensemble of ``KANVFMNet`` with distinct seeds."""
    models = []
    for i in range(n_models):
        torch.manual_seed(seed0 + i)
        kwargs = dict(kwargs)
        kwargs["seed"] = seed0 + i
        models.append(KANVFMNet(**kwargs))
    return models
