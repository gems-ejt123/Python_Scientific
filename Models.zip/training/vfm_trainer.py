"""
Training, deep-ensembling and conformal UQ for the steady-state ESP VFM.

Pipeline (per model in the ensemble):
  Stage 1 - data fit      : physics curriculum weight = 0, pure data MSE
  Stage 2 - physics ramp  : linearly ramp the IPR + pump-curve residuals in
  Optimizer               : AdamW + OneCycleLR (full-batch; dataset is ~80 rows)
  Inverse problem         : PI (productivity index) is a trainable parameter,
                            PI = PI_ref * exp(log_factor)  (strictly positive)

Uncertainty quantification:
  * Deep ensemble  -> epistemic spread across independently-seeded models
  * Split conformal -> distribution-free prediction intervals calibrated on a
    held-out (chronological) calibration block, with guaranteed marginal
    coverage. Works well on tiny datasets where Gaussian assumptions fail.

Everything trains in normalized space; predictions are returned in physical
units [m^3/s].
"""

from __future__ import annotations

import numpy as np
import torch
from copy import deepcopy

from vfm_network import VFMNet
from vfm_loss import PhysicsVFMLoss, curriculum_weight


# --------------------------------------------------------------------------- #
#  Scaling                                                                     #
# --------------------------------------------------------------------------- #
class FeatureScaler:
    """
    Feature scaler: features -> [-1, 1]. Target scaling depends on ``y_mode``.
    Fit on train only.

    ``y_mode="minmax"`` (default, legacy)
        ``y_norm = (q - q_min) / (q_max - q_min)``  -> train targets in [0, 1].

    ``y_mode="scale"``
        ``y_norm = q / q_max``                      -> y_min = 0, y_range = q_max.

    Why ``y_mode`` exists
    ---------------------
    ``VFMNet`` applies a Softplus to its *normalized* output when
    ``positive_output=True``, and de-normalization is ``q = q_norm*y_range +
    y_min``. Under min-max scaling ``y_min`` is the smallest rate ever seen in
    training (1572 bbl/d on Castilla), so Softplus-positivity guarantees
    ``q > 1572 bbl/d``: the architecture is *structurally incapable* of emitting
    a lower rate. That is invisible while the model only interpolates inside the
    55-61 Hz training band, but it makes the low-frequency collapse (PIPESIM
    gives ~200 bbl/d at 42 Hz) unreachable by construction -- no amount of
    physics weighting can fix it.

    ``y_mode="scale"`` removes the floor: Softplus-positivity then coincides
    with *physical* positivity (q > 0), the whole [0, q_max] range is
    expressible, and ``q_scale`` in the IPR residual becomes the flow
    *magnitude* (2383 bbl/d) rather than the flow *range* (811 bbl/d), which is
    the physically meaningful normalizer. Use it whenever collocation points can
    fall outside the training band. The default is left at ``"minmax"`` so
    existing runs reproduce bit-for-bit.
    """

    def __init__(self, y_mode="minmax"):
        if y_mode not in ("minmax", "scale"):
            raise ValueError(f"y_mode must be 'minmax' or 'scale', got {y_mode!r}")
        self.y_mode = y_mode

    def fit(self, X, y):
        self.x_min = X.min(axis=0)
        self.x_max = X.max(axis=0)
        self.x_range = np.where(self.x_max - self.x_min == 0, 1.0, self.x_max - self.x_min)
        self.y_max = float(y.max())
        if self.y_mode == "scale":
            self.y_min = 0.0
            self.y_range = self.y_max or 1.0
        else:
            self.y_min = float(y.min())
            self.y_range = (self.y_max - self.y_min) or 1.0
        return self

    def transform_X(self, X):
        return 2.0 * (X - self.x_min) / self.x_range - 1.0

    def transform_y(self, y):
        return (y - self.y_min) / self.y_range

    def inverse_y(self, y_norm):
        return y_norm * self.y_range + self.y_min


# --------------------------------------------------------------------------- #
#  Trainer                                                                     #
# --------------------------------------------------------------------------- #
class VFMTrainer:
    """
    Trainer for a single physics-informed VFM model.

    Parameters
    ----------
    pump : ESPPumpCurve
    geom : ESPGeometry
    scaler : FeatureScaler (already fitted)
    PI_ref : float
        Reference productivity index [m^3/s/Pa] (the trainable factor multiplies
        this; init factor = 1).
    device : str
    net_kwargs : dict
        Passed to ``net_cls``.
    net_cls : type or None
        Backbone class. Must accept ``n_features`` plus ``net_kwargs`` and map
        ``(batch, n_features) -> (batch, 1)`` in *normalized* target space.
        ``None`` uses ``VFMNet``. Swapping in ``KANVFMNet`` (see
        ``networks/kan_network.py``) is the only change needed to train the same
        physics with a KAN backbone: everything downstream -- residuals,
        curriculum, monotonicity autograd, ensembling, conformal -- is
        backbone-agnostic.
    """

    def __init__(self, pump, geom, scaler, PI_ref=1.8e-9, device="cpu",
                 net_kwargs=None, feature_names=None, net_cls=None):
        self.pump = pump
        self.geom = geom
        self.scaler = scaler
        self.PI_ref = PI_ref
        self.device = device
        self.net_kwargs = net_kwargs or {}
        self.feature_names = list(feature_names) if feature_names is not None else None
        self.net_cls = net_cls if net_cls is not None else VFMNet

    # Physically-known signs of d q / d feature (used by the monotonicity prior).
    # +1: rate increases with the feature; -1: rate decreases with it.
    MONO_SIGNS = {"Frec": +1.0, "THP_Pa": -1.0, "PWF_Pa": -1.0}

    def _monotone_constraints(self):
        """Map the physical sign rules onto the active feature columns."""
        if not self.feature_names:
            return []
        return [(i, self.MONO_SIGNS[name])
                for i, name in enumerate(self.feature_names)
                if name in self.MONO_SIGNS]

    # ------------------------------------------------------------------ #
    def _phys_to_tensors(self, phys, idx):
        keys = ["PIP_Pa", "THP_Pa", "Pr_Pa", "PWF_Pa", "f", "rho", "mu"]
        return {
            k: torch.tensor(phys[k][idx], dtype=torch.float32, device=self.device)
            for k in keys
        }

    def fit(self, X, y, phys, train_idx,
            epochs=4000, lr=5e-4, weight_decay=1e-4,
            ramp_start_frac=0.5, ramp_end_frac=0.85,
            physics_max_weight=0.1,
            p_scale=1.0e7, seed=0, verbose=False,
            learn_pump_calib=False, calib_reg_weight=1.0e-2,
            mono_weight=0.0,
            learn_PI=True, learn_Pr=False,
            pr_scale=1.0e6, pr_reg_weight=1.0e-2):
        """
        Train one model on ``train_idx`` and return (model, PI_param, loss_fn,
        history).

        ``learn_PI`` / ``learn_Pr`` control which IPR parameters are treated as
        trainable inverse parameters:

        * ``learn_PI=True``  : PI = PI_ref * exp(log_factor) is optimized.
          ``False`` pins PI at ``PI_ref`` (use a literature / well-test value).
        * ``learn_Pr=True``  : an additive reservoir-pressure correction dPr is
          optimized, so the IPR uses ``Pr_data + dPr``. ``False`` (default)
          trusts the Pr column as measured and is bit-for-bit the old behaviour.

        Enabling BOTH lets the IPR residual fit an arbitrary affine function of
        PWF (slope -PI, intercept PI*(Pr+dPr)). That is often what you want when
        Pr is stale or PWF sits on a different datum -- the slope carries the
        physics, the level carries the measurement error -- but it means the
        recovered PI is no longer an independent estimate of the field IP.

        ``physics_max_weight`` caps how strongly the (IPR + pump) residuals are
        enforced relative to the data fit. The Castilla target is a very stable,
        low-variance series, so unbounded physics enforcement biases the point
        prediction; a modest cap keeps MAPE low while still recovering PI and
        keeping operating points on the pump curve. Set 0.0 for a pure-data
        baseline.

        ``mono_weight`` scales a monotonicity prior that penalizes physically
        wrong-sign sensitivities (d q / d Frec < 0, d q / d THP > 0,
        d q / d PWF > 0). Needs ``feature_names`` on the trainer; 0.0 disables it.
        """
        torch.manual_seed(seed)
        np.random.seed(seed)

        Xn = self.scaler.transform_X(X)
        yn = self.scaler.transform_y(y)

        Xt = torch.tensor(Xn[train_idx], dtype=torch.float32, device=self.device)
        yt = torch.tensor(yn[train_idx], dtype=torch.float32,
                          device=self.device).unsqueeze(-1)
        phys_t = self._phys_to_tensors(phys, train_idx)

        model = self.net_cls(n_features=X.shape[1], **self.net_kwargs).to(self.device)

        # PI = PI_ref * exp(log_factor); log_factor init 0 -> PI = PI_ref.
        # With learn_PI=False the tensor stays at 0 and PI is frozen at PI_ref.
        log_factor = torch.zeros(1, device=self.device,
                                 requires_grad=bool(learn_PI))

        loss_fn = PhysicsVFMLoss(
            pump=self.pump, geom=self.geom,
            q_scale=self.scaler.y_range, q_min=self.scaler.y_min,
            p_scale=p_scale, learn_weights=True,
            learn_pump_calib=learn_pump_calib, calib_reg_weight=calib_reg_weight,
            learn_Pr=learn_Pr, pr_scale=pr_scale, pr_reg_weight=pr_reg_weight,
        ).to(self.device)

        # dpr_raw is only a Parameter when learn_Pr=True (a buffer otherwise),
        # so loss_fn.parameters() already respects the flag.
        params = list(model.parameters()) + list(loss_fn.parameters())
        if learn_PI:
            params = params + [log_factor]
        opt = torch.optim.AdamW(params, lr=lr, weight_decay=weight_decay,
                                betas=(0.9, 0.999))
        # Peak the LR early (pct_start=0.1) and gently (max_lr = 1.5*lr) so it
        # has decayed well before the physics curriculum ramps in (ramp_start ~
        # 0.5*epochs). This decouples the LR peak from the ramp and removes the
        # instability spikes seen when both coincided.
        sched = torch.optim.lr_scheduler.OneCycleLR(
            opt, max_lr=lr * 1.5, epochs=epochs, steps_per_epoch=1,
            pct_start=0.1, div_factor=10.0, final_div_factor=100.0,
        )

        ramp_start = int(ramp_start_frac * epochs)
        ramp_end = int(ramp_end_frac * epochs)
        mono_cons = self._monotone_constraints() if mono_weight > 0.0 else []
        history = {"total": [], "L_data": [], "L_ipr": [], "L_pump": [], "PI": [],
                   "k_head": [], "dp_offset_Pa": [], "dPr_Pa": []}

        # Best-checkpoint: once the curriculum reaches its plateau (epoch >=
        # ramp_end) the physics weight is constant, so the total loss is
        # comparable across those epochs; keep the lowest-total state instead of
        # the (possibly noisy / physics-degraded) final epoch. For a pure-data
        # run (physics_max_weight == 0) every epoch is comparable, so consider
        # all of them.
        checkpoint_after = 0 if physics_max_weight == 0.0 else ramp_end
        best_total = float("inf")
        best_model_state = None
        best_loss_state = None
        best_log_factor = log_factor.detach().clone()

        for epoch in range(epochs):
            model.train()
            opt.zero_grad()

            pw = physics_max_weight * curriculum_weight(epoch, ramp_start, ramp_end)
            PI = self.PI_ref * torch.exp(log_factor)

            q_pred = model(Xt)

            # Monotonicity prior: penalize wrong-sign d q / d feature slopes.
            mono_penalty = None
            if mono_cons:
                Xg = Xt.detach().clone().requires_grad_(True)
                grads = torch.autograd.grad(model(Xg).sum(), Xg,
                                            create_graph=True)[0]
                pen = q_pred.new_zeros(())
                for col, sign in mono_cons:
                    pen = pen + torch.mean(torch.relu(-sign * grads[:, col]) ** 2)
                mono_penalty = mono_weight * pen

            loss, parts = loss_fn(q_pred, yt, phys_t, PI, physics_weight=pw,
                                  mono_penalty=mono_penalty)

            # Checkpoint the params that produced this loss (backward/step below
            # do not change them until after this point).
            if epoch >= checkpoint_after and parts["total"] < best_total:
                best_total = parts["total"]
                best_model_state = deepcopy(model.state_dict())
                best_loss_state = deepcopy(loss_fn.state_dict())
                best_log_factor = log_factor.detach().clone()

            loss.backward()
            torch.nn.utils.clip_grad_norm_(params, max_norm=1.0)
            opt.step()
            sched.step()

            history["total"].append(parts["total"])
            history["L_data"].append(parts["L_data"])
            history["L_ipr"].append(parts["L_ipr"])
            history["L_pump"].append(parts["L_pump"])
            history["PI"].append(float(PI.item()))
            history["k_head"].append(parts["k_head"])
            history["dp_offset_Pa"].append(parts["dp_offset_Pa"])
            history["dPr_Pa"].append(parts["dPr_Pa"])

            if verbose and (epoch % max(1, epochs // 10) == 0 or epoch == epochs - 1):
                print(f"  ep {epoch:5d} total={parts['total']:.4e} "
                      f"Ldata={parts['L_data']:.3e} Lipr={parts['L_ipr']:.3e} "
                      f"Lpump={parts['L_pump']:.3e} pw={pw:.2f} "
                      f"PI={PI.item():.3e}")

        # Restore the best checkpoint before returning.
        if best_model_state is not None:
            model.load_state_dict(best_model_state)
            loss_fn.load_state_dict(best_loss_state)
        model.eval()
        return model, best_log_factor, loss_fn, history

    # ------------------------------------------------------------------ #
    def predict(self, model, X):
        """Predict physical liquid rate [m^3/s] for raw (unscaled) features X."""
        Xn = self.scaler.transform_X(X)
        Xt = torch.tensor(Xn, dtype=torch.float32, device=self.device)
        model.eval()
        with torch.no_grad():
            q_norm = model(Xt).squeeze(-1).cpu().numpy()
        return self.scaler.inverse_y(q_norm)


# --------------------------------------------------------------------------- #
#  Deep ensemble                                                               #
# --------------------------------------------------------------------------- #
class VFMEnsemble:
    """A deep ensemble of physics-informed VFM models with conformal UQ."""

    def __init__(self, trainer: VFMTrainer):
        self.trainer = trainer
        self.models = []
        self.pi_factors = []
        self.k_heads = []        # per-model calibrated head-scale [-]
        self.dp_offsets = []     # per-model calibrated pressure offset [Pa]
        self.visc_strengths = [] # per-model viscous head-derating strength [-]
        self.pr_offsets = []     # per-model reservoir-pressure correction [Pa]
        self.histories = []
        self.q_hat = None        # conformal half-width [m^3/s]
        self.alpha = None

    def fit(self, X, y, phys, train_idx, n_models=5, seed0=0, **fit_kwargs):
        self.models, self.pi_factors, self.histories = [], [], []
        self.k_heads, self.dp_offsets, self.visc_strengths = [], [], []
        self.pr_offsets = []
        for i in range(n_models):
            model, log_factor, loss_fn, hist = self.trainer.fit(
                X, y, phys, train_idx, seed=seed0 + i, **fit_kwargs
            )
            self.models.append(model)
            self.pi_factors.append(self.trainer.PI_ref * float(np.exp(log_factor.item())))
            k_head, dp_offset = loss_fn.pump_calibration()
            self.k_heads.append(float(k_head.item()))
            self.dp_offsets.append(float(dp_offset.item()))
            self.visc_strengths.append(float(loss_fn.viscosity_strength().item()))
            self.pr_offsets.append(float(loss_fn.reservoir_offset().item()))
            self.histories.append(hist)
        return self

    def predict(self, X, return_std=True):
        """
        Ensemble prediction in physical units [m^3/s].

        Returns
        -------
        mean : np.ndarray
        std  : np.ndarray (epistemic spread across members), if ``return_std``
        """
        preds = np.stack([self.trainer.predict(m, X) for m in self.models], axis=0)
        mean = preds.mean(axis=0)
        if return_std:
            return mean, preds.std(axis=0)
        return mean

    @property
    def PI(self):
        """Ensemble-mean recovered productivity index [m^3/s/Pa]."""
        return float(np.mean(self.pi_factors))

    @property
    def k_head(self):
        """Ensemble-mean calibrated pump head-scale [-] (1.0 if not learned)."""
        return float(np.mean(self.k_heads)) if self.k_heads else 1.0

    @property
    def dp_offset(self):
        """Ensemble-mean calibrated pump pressure offset [Pa] (0.0 if not learned)."""
        return float(np.mean(self.dp_offsets)) if self.dp_offsets else 0.0

    @property
    def visc_strength(self):
        """Ensemble-mean viscous head-derating strength [-] (0.0 if not learned)."""
        return float(np.mean(self.visc_strengths)) if self.visc_strengths else 0.0

    @property
    def dPr(self):
        """Ensemble-mean reservoir-pressure correction [Pa] (0.0 if not learned).

        The IPR that the trained ensemble actually satisfies is
        ``q = PI * (Pr_data + dPr - Pwf)``; pass this to ``ipr_audit`` /
        ``full_report`` so the audit uses the same drawdown the model saw.
        """
        return float(np.mean(self.pr_offsets)) if self.pr_offsets else 0.0

    # ------------------------------------------------------------------ #
    def calibrate_conformal(self, X, y, cal_idx, alpha=0.1):
        """
        Split-conformal calibration for ``(1-alpha)`` prediction intervals.

        The absolute residuals of the ensemble mean on the held-out calibration
        block give a distribution-free half-width with guaranteed marginal
        coverage:

            q_hat = Quantile_{1-alpha}( |y_cal - mean_cal| )
        """
        if len(cal_idx) == 0:
            raise ValueError("Empty calibration set - request cal_frac > 0 in the split.")
        mean_cal = self.predict(X[cal_idx], return_std=False)
        residuals = np.abs(y[cal_idx] - mean_cal)
        n = len(residuals)
        # Finite-sample conformal quantile level.
        level = np.ceil((n + 1) * (1 - alpha)) / n
        level = min(level, 1.0)
        self.q_hat = float(np.quantile(residuals, level, method="higher"))
        self.alpha = alpha
        return self.q_hat

    def predict_interval(self, X):
        """
        Conformal prediction interval in physical units [m^3/s].

        Returns
        -------
        mean, lower, upper : np.ndarray
        """
        if self.q_hat is None:
            raise RuntimeError("Call calibrate_conformal() before predict_interval().")
        mean = self.predict(X, return_std=False)
        lower = np.clip(mean - self.q_hat, 0.0, None)
        upper = mean + self.q_hat
        return mean, lower, upper
