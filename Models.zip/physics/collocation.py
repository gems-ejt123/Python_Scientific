"""
Collocation-point generation for the steady-state ESP VFM.

Why this module exists
----------------------
In ``real_data_vfm.ipynb`` the physics residuals (``R_ipr``, ``R_pump``) are
evaluated *only on the 86 measured rows*, every one of which sits in a narrow
55-61 Hz band. Outside that band nothing constrains the network, so the MLP
saturates and the predicted rate goes flat -- which is exactly what the
PIPESIM comparison shows (~1950 bbl/d predicted at 42 Hz against PIPESIM's
~200 bbl/d).

A PINN in the Raissi sense enforces its residuals on *collocation points
sampled from the domain*, independently of where the labels happen to be.
This module builds those points.

The placement problem
---------------------
A collocation point cannot be an arbitrary corner of feature space: ``PIP``
and ``PWF`` are model inputs, but for a given frequency they are not free.
The well sits at the intersection of two curves:

    IPR   :  q   = PI * (Pr_eff - Pwf)
    pump  :  PIP + rho g (k_head C_H H(q,f)) + dp_off
             = THP + rho g dh_lift + dP_fric(q)

closed by the measured, essentially constant intake offset

    Pwf = PIP + dP_intake            (402 psi in the Castilla file, every row)

Eliminating Pwf and PIP leaves a single scalar equation in q,

    g(q) = (Pr_eff - q/PI - dP_intake)                 <- PIP from the IPR
           + rho g (k_head C_H H(q,f)) + dp_off
           - THP - rho g dh_lift - dP_fric(q)  = 0

which is *strictly decreasing* in q:

    dg/dq = -1/PI  +  rho g k_head C_H dH/dq  -  d(dP_fric)/dq
             (<0)        (<0, pump curve descends)      (<0)

so the root is unique and plain bisection is unconditionally safe. That is
what ``solve_operating_point`` does, vectorized over an array of frequencies.

Dead wells are a real outcome, not an error
-------------------------------------------
At low frequency the pump can stop covering the static lift even at zero
flow. Then g(0) < 0, there is no positive root, and the physically correct
answer is q* = 0 (the well dies). These points are flagged in ``alive`` and
kept: they carry more information about the low-frequency collapse than any
in-range point does.

    !! Consequence for the target scaler !!
    With the default min-max target scaling of ``FeatureScaler`` the network
    output is ``q = q_norm * y_range + y_min`` with a Softplus on ``q_norm``,
    so the smallest rate the architecture can express is ``y_min`` = 1572
    bbl/d. A near-dead well is *structurally unreachable*. Use
    ``FeatureScaler(y_mode="scale")`` (q_norm = q / y_max, so y_min = 0) with
    collocation, otherwise the low-f residuals are being asked for something
    the network physically cannot output.

All quantities SI: Pa, m^3/s, kg/m^3, Pa.s, m, Hz.
"""

from __future__ import annotations

import numpy as np
import torch

from esp_steady import (DEFAULT_GEOMETRY, friction_dp,
                        viscosity_head_correction)
from real_data_loader import G


# --------------------------------------------------------------------------- #
#  Closure between PWF and PIP                                                 #
# --------------------------------------------------------------------------- #
def intake_offset(phys) -> float:
    """
    Median measured ``PWF - PIP`` offset [Pa].

    On the Castilla file this is a hard constant (402 psi in every row), i.e.
    PWF is a *derived* column: the hydrostatic head between the pump intake and
    the perforations. Using it as the closure introduces no new assumption, it
    just reuses the relation the data already obeys exactly.
    """
    return float(np.median(np.asarray(phys["PWF_Pa"]) - np.asarray(phys["PIP_Pa"])))


# --------------------------------------------------------------------------- #
#  Coupled IPR + pump solve                                                    #
# --------------------------------------------------------------------------- #
def _balance_residual(q, f, THP, rho, mu, Pr_eff, PI, pump, geom,
                      k_head, dp_offset, visc_strength, visc_nu_ref_cst,
                      dP_intake):
    """
    g(q) for the eliminated system [Pa]. Strictly decreasing in q.

    Positive  -> the pump is over-delivering, the well can flow faster.
    Negative  -> the pump cannot sustain this rate.
    """
    t = lambda a: torch.as_tensor(np.asarray(a, dtype=np.float64),
                                  dtype=torch.float32)
    q_t, f_t = t(q), t(f)
    rho_t, mu_t = t(rho), t(mu)
    with torch.no_grad():
        H = pump.head(q_t, f_t).numpy().astype(np.float64)
        C_H = viscosity_head_correction(rho_t, mu_t, strength=visc_strength,
                                        nu_ref_cst=visc_nu_ref_cst).numpy().astype(np.float64)
        dp_f = friction_dp(q_t, rho_t, mu_t, geom).numpy().astype(np.float64)

    PWF = Pr_eff - q / PI                      # IPR
    PIP = PWF - dP_intake                      # measured intake closure
    return (PIP + rho * G * (k_head * C_H * H) + dp_offset
            - THP - rho * G * geom.dh_lift_m - dp_f)


def solve_operating_point(f, THP, rho, mu, Pr_eff, PI, pump, geom=None,
                          k_head=1.0, dp_offset=0.0, visc_strength=0.0,
                          visc_nu_ref_cst=200.0, dP_intake=0.0,
                          n_bisect=60, q_floor=0.0):
    """
    Solve the coupled IPR + pump-energy system for the steady operating point.

    Every array argument is broadcast to a common shape; scalars are fine.

    Returns
    -------
    dict with keys ``q`` [m^3/s], ``PWF_Pa``, ``PIP_Pa``, ``alive`` (bool array;
    False where the pump cannot lift the column even at zero flow, in which case
    ``q`` is set to ``q_floor`` and the pressures to their shut-in values).

    The bisection needs no derivative and cannot diverge, because g is monotone.
    ``n_bisect=60`` halves the bracket 60 times -- far beyond float32 precision.
    """
    geom = geom or DEFAULT_GEOMETRY
    f, THP, rho, mu, Pr_eff = np.broadcast_arrays(
        *[np.asarray(a, dtype=np.float64) for a in (f, THP, rho, mu, Pr_eff)])
    shape = f.shape

    kw = dict(f=f, THP=THP, rho=rho, mu=mu, Pr_eff=Pr_eff, PI=PI, pump=pump,
              geom=geom, k_head=k_head, dp_offset=dp_offset,
              visc_strength=visc_strength, visc_nu_ref_cst=visc_nu_ref_cst,
              dP_intake=dP_intake)

    # Bracket. Lower end q=0 (shut in). Upper end = absolute open-flow
    # potential, the rate the IPR alone would give at atmospheric bottomhole
    # pressure; no real operating point can exceed it.
    q_lo = np.zeros(shape)
    q_hi = np.maximum(PI * (Pr_eff - dP_intake - 1.0e5), 1.0e-6)

    g_lo = _balance_residual(q_lo, **kw)
    alive = g_lo > 0.0                      # pump covers the lift at q = 0

    # Guarantee a sign change on the live points (g is decreasing, so if the
    # upper end is still positive the bracket is too narrow -- widen it).
    g_hi = _balance_residual(q_hi, **kw)
    for _ in range(8):
        need = alive & (g_hi > 0.0)
        if not np.any(need):
            break
        q_hi = np.where(need, q_hi * 2.0, q_hi)
        g_hi = _balance_residual(q_hi, **kw)

    lo, hi = q_lo.copy(), q_hi.copy()
    for _ in range(n_bisect):
        mid = 0.5 * (lo + hi)
        g_mid = _balance_residual(mid, **kw)
        pos = g_mid > 0.0                   # root is to the right of mid
        lo = np.where(pos, mid, lo)
        hi = np.where(pos, hi, mid)
    q = 0.5 * (lo + hi)

    q = np.where(alive, q, q_floor)
    PWF = Pr_eff - q / PI
    PIP = PWF - dP_intake
    return {"q": q, "PWF_Pa": PWF, "PIP_Pa": PIP, "alive": alive}


# --------------------------------------------------------------------------- #
#  Diagnostic: does the calibrated energy balance extrapolate sanely?          #
# --------------------------------------------------------------------------- #
def energy_balance_sweep(f_grid, base, Pr_eff, PI, pump, geom=None,
                         k_head=1.0, dp_offset=0.0, visc_strength=0.0,
                         visc_nu_ref_cst=200.0, dP_intake=0.0):
    """
    Sweep the *pure physics* operating point across ``f_grid``, holding the
    context variables at ``base`` (dict with THP_Pa, rho, mu).

    Run this BEFORE training with collocation. The collocation points inherit
    whatever error the calibration carries, and ``dp_offset`` is the dangerous
    one: it is a constant in Pa, so at low frequency -- where the developed head
    is small -- it can dominate the balance and place the points somewhere
    unphysical. If this sweep does not roughly track PIPESIM, fix the
    calibration before trusting any collocation-trained model.

    Returns a dict of arrays suitable for direct plotting.
    """
    f_grid = np.asarray(f_grid, dtype=np.float64)
    sol = solve_operating_point(
        f=f_grid,
        THP=np.full_like(f_grid, base["THP_Pa"]),
        rho=np.full_like(f_grid, base["rho"]),
        mu=np.full_like(f_grid, base["mu"]),
        Pr_eff=np.full_like(f_grid, Pr_eff),
        PI=PI, pump=pump, geom=geom, k_head=k_head, dp_offset=dp_offset,
        visc_strength=visc_strength, visc_nu_ref_cst=visc_nu_ref_cst,
        dP_intake=dP_intake,
    )
    sol["f"] = f_grid
    return sol


# --------------------------------------------------------------------------- #
#  Collocation sampler                                                         #
# --------------------------------------------------------------------------- #
class CollocationSampler:
    """
    Draws physically-consistent collocation points across a frequency range.

    Design choice: the *context* variables (THP, manifold pressure, density,
    viscosity, water cut) are bootstrapped from real training rows rather than
    sampled from independent marginals, so their joint structure and physical
    plausibility are preserved. Only the frequency is extrapolated, because the
    frequency axis is the one the model fails on. ``PIP`` and ``PWF`` are then
    *solved*, never sampled -- they are outputs of the coupled system, not free
    coordinates.

    Parameters
    ----------
    feature_names : list[str]
        Model input order. Must contain 'Frec'; 'PIP_Pa'/'PWF_Pa' are filled
        from the solve when present.
    X_train, phys_train, train_idx
        Source of the bootstrap pool and of ``dP_intake`` / ``Pr``.
    f_range : (float, float)
        Deployment frequency span to cover, e.g. (40.0, 70.0).
    pump, geom
        Physics objects.
    """

    CONTEXT = ("THP_Pa", "Pm_Pa", "rho", "mu", "BSW")

    def __init__(self, feature_names, X_train, phys_train, train_idx,
                 f_range, pump, geom=None, visc_nu_ref_cst=200.0, seed=0):
        self.feature_names = list(feature_names)
        if "Frec" not in self.feature_names:
            raise ValueError("'Frec' must be one of the model features.")
        self.pump = pump
        self.geom = geom or DEFAULT_GEOMETRY
        self.f_range = (float(f_range[0]), float(f_range[1]))
        self.visc_nu_ref_cst = float(visc_nu_ref_cst)
        self.rng = np.random.default_rng(seed)

        idx = np.asarray(train_idx)
        self.pool = np.asarray(X_train, dtype=np.float64)[idx]      # (n_tr, n_feat)
        self.dP_intake = intake_offset(
            {k: np.asarray(phys_train[k])[idx] for k in ("PWF_Pa", "PIP_Pa")})
        self.Pr_data = float(np.median(np.asarray(phys_train["Pr_Pa"])[idx]))

        self._col = {name: i for i, name in enumerate(self.feature_names)}

    # ------------------------------------------------------------------ #
    def sample(self, n, PI, dPr=0.0, k_head=1.0, dp_offset=0.0,
               visc_strength=0.0, f_jitter=True):
        """
        Draw ``n`` collocation points with the *current* calibration.

        Because the placement depends on (PI, dPr, k_head, dp_offset, visc),
        which are themselves being learned, call this again every few hundred
        epochs so the points track the calibration instead of freezing at its
        initial value. That re-placement is what keeps the scheme a residual
        constraint rather than a disguised pseudo-label.

        Returns
        -------
        X_col : (n, n_features) float64, raw SI units, in ``feature_names`` order
        phys_col : dict of arrays for the residuals
        info : dict with 'q_star', 'alive', 'f'
        """
        n_pool = self.pool.shape[0]
        rows = self.rng.integers(0, n_pool, size=n)
        X = self.pool[rows].copy()                     # bootstrap the context

        f_lo, f_hi = self.f_range
        f = self.rng.uniform(f_lo, f_hi, size=n)
        if not f_jitter:
            f = np.linspace(f_lo, f_hi, n)
        X[:, self._col["Frec"]] = f

        get = lambda name: (X[:, self._col[name]] if name in self._col
                            else None)
        THP = get("THP_Pa")
        rho = get("rho")
        mu = get("mu")
        if THP is None or rho is None or mu is None:
            raise ValueError("Collocation needs THP_Pa, rho and mu as features.")

        Pr_eff = np.full(n, self.Pr_data + float(dPr))
        sol = solve_operating_point(
            f=f, THP=THP, rho=rho, mu=mu, Pr_eff=Pr_eff, PI=PI,
            pump=self.pump, geom=self.geom, k_head=k_head, dp_offset=dp_offset,
            visc_strength=visc_strength, visc_nu_ref_cst=self.visc_nu_ref_cst,
            dP_intake=self.dP_intake,
        )

        if "PIP_Pa" in self._col:
            X[:, self._col["PIP_Pa"]] = sol["PIP_Pa"]
        if "PWF_Pa" in self._col:
            X[:, self._col["PWF_Pa"]] = sol["PWF_Pa"]

        phys_col = {
            "PIP_Pa": sol["PIP_Pa"],
            "THP_Pa": THP,
            "PWF_Pa": sol["PWF_Pa"],
            "Pr_Pa": np.full(n, self.Pr_data),   # dPr is added inside the loss
            "f": f,
            "rho": rho,
            "mu": mu,
        }
        info = {"q_star": sol["q"], "alive": sol["alive"], "f": f}
        return X, phys_col, info
