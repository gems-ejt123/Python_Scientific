"""
Physics-informed loss for the steady-state ESP VFM.

Total loss (self-adaptively weighted):

    L = u_data * L_data + u_ipr * L_ipr + u_pump * L_pump

where each L_i is a normalized MSE:

    L_data : (q_pred - q_meas)^2                          (data fit on the target)
    L_ipr  : ( R_ipr  / q_scale )^2                       (inflow-performance)
    L_pump : ( R_pump / p_scale )^2                       (ESP energy / pump curve)

Instead of the manual S0->S1 weight schedule of Franklin (2022), the term
weights are learned via homoscedastic-uncertainty weighting (Kendall, Gal &
Cipolla, 2018). Each task gets a learnable log-variance ``s_i`` and contributes

    exp(-s_i) * L_i + s_i

so noisy / hard residuals are automatically down-weighted while still being
regularized, and no hand-tuning of [w_bc, w1, w2, w3] is required. An optional
linear curriculum ramp scales the physics terms in over the first part of
training (data first, physics second).

Residuals are evaluated in *physical* SI units (the network output is
de-normalized first), then divided by characteristic scales so the data and
physics terms are commensurate.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from esp_steady import ipr_residual, pump_energy_residual


class PhysicsVFMLoss(nn.Module):
    """
    Self-adaptive physics-informed loss for steady-state VFM.

    Parameters
    ----------
    pump : ESPPumpCurve
        Real ESP head curve (provides ``head(q, f)``).
    geom : ESPGeometry
        Well geometry used by the energy balance.
    q_scale : float
        Characteristic flow scale [m^3/s] for normalizing the IPR residual and
        de-normalizing the network output (typically the training q range).
    q_min : float
        Minimum training q [m^3/s] (for de-normalization).
    p_scale : float
        Characteristic pressure scale [Pa] for the pump residual (e.g. the pump
        pressure boost ~rho*g*H).
    learn_weights : bool
        If True, use learnable uncertainty weighting; else fixed ``init_weights``.
    init_log_vars : tuple
        Initial log-variances (s_data, s_ipr, s_pump).
    """

    def __init__(self, pump, geom, q_scale, q_min, p_scale=1.0e7,
                 learn_weights=True, init_log_vars=(0.0, 0.0, 0.0),
                 learn_pump_calib=False, calib_reg_weight=1.0e-2,
                 visc_nu_ref_cst=200.0):
        super().__init__()
        self.pump = pump
        self.geom = geom
        self.q_scale = float(q_scale)
        self.q_min = float(q_min)
        self.p_scale = float(p_scale)
        self.learn_weights = learn_weights
        self.learn_pump_calib = learn_pump_calib
        self.calib_reg_weight = float(calib_reg_weight)

        s = torch.tensor(init_log_vars, dtype=torch.float32)
        if learn_weights:
            self.log_vars = nn.Parameter(s)          # [s_data, s_ipr, s_pump]
            self.log_var_mono = nn.Parameter(torch.zeros((), dtype=torch.float32))
        else:
            self.register_buffer("log_vars", s)
            self.register_buffer("log_var_mono", torch.zeros((), dtype=torch.float32))

        # Global pump-curve calibration (removes systematic datasheet mismatch
        # so the pump residual constrains q without biasing it):
        #   k_head    = exp(log_k_head)          -> multiplicative head-scale (~1)
        #   dp_offset = dp_off_raw * p_scale     -> additive pressure offset [Pa]
        #   visc      = softplus(visc_raw)       -> viscous head-derating strength
        # k_head/dp_offset init at identity/zero; visc_raw init strongly negative
        # so the derating starts ~off (water curve) and only grows if the data
        # jointly demand it. ``visc_nu_ref_cst`` sets the O(1) viscosity scale so
        # heavy-oil samples give a moderate (not runaway) correction.
        self.visc_nu_ref_cst = float(visc_nu_ref_cst)
        z0 = torch.zeros(1, dtype=torch.float32)
        visc0 = torch.full((1,), -4.0, dtype=torch.float32)   # softplus(-4) ~ 0.018
        if learn_pump_calib:
            self.log_k_head = nn.Parameter(z0.clone())
            self.dp_off_raw = nn.Parameter(z0.clone())
            self.visc_raw = nn.Parameter(visc0.clone())
        else:
            self.register_buffer("log_k_head", z0.clone())
            self.register_buffer("dp_off_raw", z0.clone())
            self.register_buffer("visc_raw", visc0.clone())

    # ------------------------------------------------------------------ #
    def pump_calibration(self):
        """Return the current (k_head [-], dp_offset [Pa]) as tensors."""
        k_head = torch.exp(self.log_k_head).squeeze()
        dp_offset = (self.dp_off_raw * self.p_scale).squeeze()
        return k_head, dp_offset

    # ------------------------------------------------------------------ #
    def viscosity_strength(self):
        """Current viscous head-derating strength (>= 0) as a scalar tensor."""
        return torch.nn.functional.softplus(self.visc_raw).squeeze()

    # ------------------------------------------------------------------ #
    def denorm_q(self, q_norm):
        """Map a normalized prediction back to physical liquid rate [m^3/s]."""
        return q_norm * self.q_scale + self.q_min

    # ------------------------------------------------------------------ #
    def forward(self, q_norm_pred, q_norm_true, phys, PI,
                physics_weight=1.0, mono_penalty=None):
        """
        Compute the total weighted loss and a breakdown dict.

        Parameters
        ----------
        q_norm_pred : torch.Tensor, shape (batch, 1)
            Network output (normalized).
        q_norm_true : torch.Tensor, shape (batch, 1)
            Measured liquid rate (normalized).
        phys : dict of torch.Tensor, each shape (batch,)
            Physical drivers: 'PIP_Pa', 'THP_Pa', 'Pr_Pa', 'PWF_Pa', 'f',
            'rho', 'mu'.
        PI : torch.Tensor (scalar)
            Trainable productivity index [m^3/s/Pa] (already made positive by
            the caller, e.g. via softplus).
        physics_weight : float
            Curriculum multiplier in [0, 1] applied to the physics terms.
        mono_penalty : torch.Tensor (scalar), optional
            Precomputed monotonicity hinge penalty on d q / d feature (wrong-sign
            slopes). Added as an extra uncertainty-weighted, curriculum-scaled
            physics prior. ``None`` disables it (default).

        Returns
        -------
        total_loss : torch.Tensor
        parts : dict
            Raw (unweighted) component values for monitoring.
        """
        q_pred = q_norm_pred.squeeze(-1)
        q_true = q_norm_true.squeeze(-1)

        # --- data term (normalized space) ---
        L_data = torch.mean((q_pred - q_true) ** 2)

        # --- physics residuals in physical units ---
        q_phys = self.denorm_q(q_pred)
        R_ipr = ipr_residual(q_phys, phys["Pr_Pa"], phys["PWF_Pa"], PI)
        k_head, dp_offset = self.pump_calibration()
        visc = self.viscosity_strength()
        R_pump = pump_energy_residual(
            q_phys, phys["f"], phys["PIP_Pa"], phys["THP_Pa"],
            phys["rho"], phys["mu"], self.pump, self.geom,
            k_head=k_head, dp_offset=dp_offset, visc_strength=visc,
            visc_nu_ref_cst=self.visc_nu_ref_cst,
        )

        L_ipr = torch.mean((R_ipr / self.q_scale) ** 2)
        L_pump = torch.mean((R_pump / self.p_scale) ** 2)

        # Apply curriculum ramp to the physics terms only.
        L_ipr_w = physics_weight * L_ipr
        L_pump_w = physics_weight * L_pump

        # --- self-adaptive (uncertainty) weighting ---
        s_data, s_ipr, s_pump = self.log_vars[0], self.log_vars[1], self.log_vars[2]
        total = (
            torch.exp(-s_data) * L_data + s_data
            + torch.exp(-s_ipr) * L_ipr_w + s_ipr
            + torch.exp(-s_pump) * L_pump_w + s_pump
        )

        # --- monotonicity prior (curriculum-scaled, uncertainty-weighted) ---
        if mono_penalty is not None:
            s_mono = self.log_var_mono
            total = total + torch.exp(-s_mono) * physics_weight * mono_penalty + s_mono

        # L2 prior keeping the pump calibration near identity (only active when
        # calibration is trainable; scaled by the physics curriculum so it ramps
        # in with the pump term).
        if self.learn_pump_calib and self.calib_reg_weight > 0.0:
            calib_reg = self.calib_reg_weight * (
                self.log_k_head.pow(2).sum() + self.dp_off_raw.pow(2).sum()
                + visc.pow(2)
            )
            total = total + physics_weight * calib_reg

        k_head, dp_offset = self.pump_calibration()
        parts = {
            "L_data": L_data.item(),
            "L_ipr": L_ipr.item(),
            "L_pump": L_pump.item(),
            "L_mono": float(mono_penalty.item()) if mono_penalty is not None else 0.0,
            "w_data": float(torch.exp(-s_data).item()),
            "w_ipr": float(torch.exp(-s_ipr).item()),
            "w_pump": float(torch.exp(-s_pump).item()),
            "R_ipr_rms": float(torch.sqrt(torch.mean(R_ipr ** 2)).item()),
            "R_pump_rms": float(torch.sqrt(torch.mean(R_pump ** 2)).item()),
            "k_head": float(k_head.item()),
            "dp_offset_Pa": float(dp_offset.item()),
            "visc_strength": float(visc.item()),
            "total": total.item(),
        }
        return total, parts


def curriculum_weight(epoch, ramp_start, ramp_end):
    """
    Linear data-first physics-second curriculum multiplier in [0, 1].

    0 before ``ramp_start`` (pure data fit), linearly ramps to 1 by
    ``ramp_end``, then stays at 1.
    """
    if epoch <= ramp_start:
        return 0.0
    if epoch >= ramp_end:
        return 1.0
    return (epoch - ramp_start) / max(1, (ramp_end - ramp_start))
