"""CPF2 profile adapter. Ambiguous source/geometry records are explicit errors."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .contracts import (
    BBL_DAY_TO_M3_S, FT_TO_M, IN_TO_M, fixed_source_temperatures,
)
from .evaluation import scenario_split
from .ingest import normalize_labels, read_export


TRUNKS = [
    "RUBIALES_TRONCAL_10", "RUBIALES_TRONCAL_2-2A", "RUBIALES_TRONCAL_4-9",
    "RUBIALES_TRONCAL_7-7A", "RUBIALES_TRONCAL_7C",
]
GEOMETRY_COLUMNS = ["TotalDistance", "Elevation", "PipeInsideDiameter", "long", "lat"]
PROFILE_COLUMNS = [
    "scenario", "Troncal", "node_id", "node_type", "BranchEquipment",
    "Pressure", "FlowrateLiquidInsitu", "Watercut",
    "DensityOilInSitu", "DensityWaterInSitu", *GEOMETRY_COLUMNS,
]


def inspect_export(path, temperature_column="Temperature", member=None):
    header = read_export(path, member=member, nrows=0)
    required = set(PROFILE_COLUMNS + [temperature_column])
    return {
        "path": str(path), "member": member,
        "columns": header.columns.tolist(),
        "missing_columns": sorted(required - set(header.columns)),
        "temperature_available": temperature_column in header.columns,
    }


def load_profiles(path, temperature_column, temperature_unit, member=None, trunks=None,
                  elevation_unit="ft"):
    audit = inspect_export(path, temperature_column, member)
    if audit["missing_columns"]:
        raise ValueError(
            f"CPF2 preflight failed: missing {audit['missing_columns']}. Supply the "
            "temperature-enabled export and explicit temperature units. PVT calibration "
            "points must not be substituted for node temperatures."
        )
    frame = read_export(path, member=member, usecols=PROFILE_COLUMNS + [temperature_column])
    frame = frame.loc[frame["Troncal"].isin(trunks or TRUNKS)].copy()
    expected = set(trunks or TRUNKS)
    if set(frame["Troncal"]) != expected:
        raise ValueError(f"Missing requested trunks: {sorted(expected - set(frame['Troncal']))}")
    frame = normalize_labels(
        frame, scenario_column="scenario", pressure_column="Pressure",
        temperature_column=temperature_column, temperature_unit=temperature_unit,
        trunk_column="Troncal",
    )
    for column in [*GEOMETRY_COLUMNS, "FlowrateLiquidInsitu", "Watercut",
                   "DensityOilInSitu", "DensityWaterInSitu"]:
        frame[column] = pd.to_numeric(frame[column], errors="raise")
        if not np.isfinite(frame[column].to_numpy()).all():
            raise ValueError(f"Nonfinite CPF2 column {column}.")
    # PIPESIM writes this export in field units: TotalDistance and Elevation are both feet.
    # TotalDistance is converted at its point of use in `_geometry`; Elevation is consumed in
    # several places (edge `elevation_m`, the junction-consistency test, the source-inlet
    # spread test) so it is converted once here and is metres everywhere downstream.
    if elevation_unit not in {"ft", "m"}:
        raise ValueError(f"elevation_unit must be 'ft' or 'm', not {elevation_unit!r}.")
    if elevation_unit == "ft":
        frame["Elevation"] = frame["Elevation"] * FT_TO_M
    if (frame["FlowrateLiquidInsitu"] < 0).any() or not frame["Watercut"].between(0, 1).all():
        raise ValueError("Invalid source/local flow or watercut units; check sentinels.")
    if (frame[["PipeInsideDiameter", "DensityOilInSitu", "DensityWaterInSitu"]] <= 0).any().any():
        raise ValueError("Nonpositive diameter/density; check units and sentinels.")
    frame["node_id"] = frame["node_id"].astype(str)
    if frame.duplicated(["trunk", "scenario", "node_id"]).any():
        raise ValueError("Duplicate trunk/scenario/node_id labels.")
    return frame


@dataclass
class PreparedData:
    specs: dict
    layouts: dict
    cases: dict
    splits: dict
    audit: dict


def _coordinate(row, decimals):
    return f"{float(row['long']):.{decimals}f},{float(row['lat']):.{decimals}f}"


def _reverse_edge(edge, layout):
    """Flip an edge end for end, keeping every per-node and per-segment array aligned.

    Segment k of the reversed edge is the same physical pipe as segment n-2-k of the
    original, so the per-segment arrays reverse alongside the per-node ones.
    """
    distance = edge["distance_m"]
    span = distance[-1]
    edge["distance_m"] = [span - value for value in reversed(distance)]
    edge["elevation_m"] = list(reversed(edge["elevation_m"]))
    edge["diameter_m"] = list(reversed(edge["diameter_m"]))
    edge["minor_loss_k"] = list(reversed(edge["minor_loss_k"]))
    edge["profile_node_ids"] = list(reversed(edge["profile_node_ids"]))
    edge["up"], edge["down"] = edge["down"], edge["up"]
    for position, node_id in enumerate(edge["profile_node_ids"]):
        layout[node_id]["profile_index"] = position


def _orient_by_continuity(edges, flows, sink, source_nodes, layout, relative_tolerance=0.02):
    """Orient every edge so the exported branch rates satisfy nodal continuity.

    The export stores each profile in increasing TotalDistance, which is a storage
    convention and not a statement about flow direction: a branch written from its
    downstream end inwards arrives here reversed. Pressure ordering cannot arbitrate
    short junction-to-junction segments, because their true drop is smaller than the
    scatter between the pressures neighbouring branches report at the shared node.
    Continuity can, so direction is taken from the rates and the known boundaries.
    """
    incidence = {}
    for index, edge in enumerate(edges):
        incidence.setdefault(edge["up"], []).append(index)
        incidence.setdefault(edge["down"], []).append(index)

    def other_end(index, node):
        edge = edges[index]
        return edge["down"] if edge["up"] == node else edge["up"]

    fixed, notes = {}, []

    def close(a, b):
        scale = max(abs(a), abs(b))
        return scale > 0 and abs(a - b) <= relative_tolerance * scale

    def assign(index, node, into_node, rule, detail=None):
        far = other_end(index, node)
        wanted = (far, node) if into_node else (node, far)
        if index in fixed:
            if fixed[index] != wanted:
                notes.append({
                    "edge": edges[index]["id"], "rule": "conflict", "at": node,
                    "held": fixed[index], "proposed": wanted, **(detail or {}),
                })
            return False
        fixed[index] = wanted
        notes.append({
            "edge": edges[index]["id"], "rule": rule, "at": node,
            "up": wanted[0], "down": wanted[1], **(detail or {}),
        })
        return True

    # Boundaries are the only directions known without appeal to rates.
    for index in incidence.get(sink, []):
        assign(index, sink, True, "sink is terminal")
    for node in set(source_nodes.values()):
        for index in incidence.get(node, []):
            assign(index, node, False, "injection leaves its source")

    progress = True
    while progress:
        progress = False
        for node, incident in incidence.items():
            unknown = [i for i in incident if i not in fixed]
            known = [i for i in incident if i in fixed]
            if not unknown or not known:
                continue
            inflow = sum(flows[i] for i in known if fixed[i][1] == node)
            outflow = sum(flows[i] for i in known if fixed[i][0] == node)

            # Rule 1, exact: one edge left, so it carries whatever does not balance.
            if len(unknown) == 1:
                index = unknown[0]
                imbalance = inflow - outflow
                if abs(imbalance) > relative_tolerance * max(inflow, outflow, flows[index]):
                    detail = {"imbalance": float(imbalance), "branch_rate": float(flows[index])}
                    if not close(abs(imbalance), flows[index]):
                        progress |= assign(index, node, imbalance < 0, "residual, rate mismatch", detail)
                    else:
                        progress |= assign(index, node, imbalance < 0, "residual", detail)
                    continue

            # Rule 2, the junction rule: at a tee one branch carries the sum of the
            # others, so every other branch runs opposite to it. A single known edge
            # then pins the whole node, which Rule 1 cannot do with two unknowns.
            order = sorted(incident, key=lambda i: flows[i], reverse=True)
            trunk_edge, rest = order[0], order[1:]
            if not rest or not close(flows[trunk_edge], sum(flows[i] for i in rest)):
                continue
            reference_edge = known[0]
            reference_into = fixed[reference_edge][1] == node
            trunk_into = reference_into if reference_edge == trunk_edge else not reference_into
            detail = {"combined_branch": edges[trunk_edge]["id"]}
            for index in incident:
                into = trunk_into if index == trunk_edge else not trunk_into
                progress |= assign(index, node, into, "junction sum", detail)

    unresolved = [edges[i]["id"] for i in range(len(edges)) if i not in fixed]
    reversed_ids = []
    for index, edge in enumerate(edges):
        if index in fixed and (edge["up"], edge["down"]) != fixed[index]:
            _reverse_edge(edge, layout)
            reversed_ids.append(edge["id"])

    residuals = {}
    boundary = set(source_nodes.values()) | {sink}
    for node, incident in incidence.items():
        if node in boundary:
            continue
        inflow = sum(flows[i] for i in incident if edges[i]["down"] == node)
        outflow = sum(flows[i] for i in incident if edges[i]["up"] == node)
        scale = max(inflow, outflow)
        if scale > 0:
            residuals[node] = abs(inflow - outflow) / scale
    suspect = {"conflict", "residual, rate mismatch"}
    return {
        "reversed_edges": reversed_ids,
        "unresolved_edges": unresolved,
        "flagged": [note for note in notes if note["rule"] in suspect],
        "worst_relative_continuity_residual": float(max(residuals.values(), default=0.)),
        "worst_node": max(residuals, key=residuals.get) if residuals else None,
        "resolution": notes,
    }


def _geometry(reference, mapping, temperatures, decimals, geometry_tolerance_m,
              orient_by_continuity=True):
    reference = reference.sort_values(["BranchEquipment", "TotalDistance"]).copy()
    reference["_coordinate"] = reference.apply(lambda r: _coordinate(r, decimals), axis=1)
    by_id = reference.set_index("node_id")
    endpoint_keys = set()
    for _, branch in reference.groupby("BranchEquipment", sort=True):
        endpoint_keys.update(branch.iloc[[0, -1]]["_coordinate"])
    source_rows, source_nodes = {}, {}
    for source, record in mapping.set_index("source").iterrows():
        candidates = reference.loc[reference["BranchEquipment"] == record["BranchEquipment"]]
        if candidates.empty:
            raise ValueError(f"Mapped source {source} references a missing branch.")
        distance = np.hypot(candidates["long"] - record["long"], candidates["lat"] - record["lat"])
        selected = candidates.loc[distance <= 10 ** (-decimals + 1)]
        if len(selected) != 1:
            raise ValueError(
                f"Source {source} has {len(selected)} matching profile rows. Correct the "
                "source mapping explicitly; source rates cannot be copied from another node."
            )
        row = selected.iloc[0]
        if int(row["node_type"]) != 1:
            raise ValueError(
                f"Source {source} maps to non-source row {row['node_id']}. "
                "An accumulated branch flow is not an independent source injection."
            )
        source_rows[str(source)] = [str(row["node_id"])]
        source_nodes[str(source)] = row["_coordinate"]
        endpoint_keys.add(row["_coordinate"])
    if len({rows[0] for rows in source_rows.values()}) != len(source_rows):
        raise ValueError("Several sources map to one profile row; individual source rates are required.")
    if len(set(source_nodes.values())) != len(source_nodes):
        raise ValueError(
            "Ambiguous source ownership at a shared junction: separately mapped sources "
            "must not be silently combined."
        )
    branch_inlets = set(reference.groupby("BranchEquipment", sort=False).head(1)["node_id"])
    exported_inlets = reference.loc[reference["node_type"] == 1]
    for source, node in source_nodes.items():
        members = exported_inlets.loc[exported_inlets["_coordinate"] == node, "node_id"].tolist()
        if not set(members) <= branch_inlets:
            raise ValueError(f"Source {source} contains a non-inlet source row; injection labels required.")
        # Keep the explicit mapping anchor first; only the injection is aggregated, never the pipes.
        source_rows[source].extend(row for row in members if row != source_rows[source][0])
    observed_sources = set(reference.loc[reference["node_type"] == 1, "node_id"])
    if {row for rows in source_rows.values() for row in rows} != observed_sources:
        raise ValueError("The source map does not cover exactly the exported source rows.")
    sinks = set(reference.loc[reference["node_type"] == -1, "_coordinate"])
    if len(sinks) != 1:
        raise ValueError(f"Expected one canonical sink coordinate, found {len(sinks)}.")
    edges, layout, nodes, edge_flows = [], {}, set(), []
    for name, branch in reference.groupby("BranchEquipment", sort=True):
        branch = branch.reset_index(drop=True)
        cut = [i for i, key in enumerate(branch["_coordinate"]) if key in endpoint_keys]
        if len(branch) < 2 or (branch["TotalDistance"].diff().dropna() <= 0).any():
            raise ValueError(f"Branch {name} has missing or non-increasing profile distance.")
        for section, (a, b) in enumerate(zip(cut, cut[1:])):
            g = branch.iloc[a:b + 1]
            up, down = g.iloc[0]["_coordinate"], g.iloc[-1]["_coordinate"]
            if up == down:
                raise ValueError(f"Positive-length self-loop in {name}; reconcile coincident coordinates.")
            edge_id = f"{name}::part{section}"
            s = g["TotalDistance"].to_numpy(float) * FT_TO_M
            d = g["PipeInsideDiameter"].to_numpy(float) * IN_TO_M
            edges.append({
                "id": edge_id, "up": up, "down": down,
                "distance_m": (s - s[0]).tolist(),
                "elevation_m": g["Elevation"].to_numpy(float).tolist(),
                "diameter_m": d[:-1].tolist(),
                "profile_node_ids": g["node_id"].astype(str).tolist(),
                "roughness_m": 0.00004572,
                "minor_loss_k": [0.] * (len(g) - 1),
            })
            # Median over the section, not an endpoint value: the rate is reported at
            # in-situ conditions and drifts slightly along the profile.
            edge_flows.append(float(np.median(g["FlowrateLiquidInsitu"].to_numpy(float))))
            nodes.update([up, down])
            for position, (_, row) in enumerate(g.iterrows()):
                layout[str(row["node_id"])] = {
                    "edge_id": edge_id, "profile_index": position,
                    "is_sink": row["_coordinate"] in sinks,
                }
    if set(layout) != set(reference["node_id"]):
        raise ValueError("Not every profile row belongs to a resolved branch.")
    for node in nodes:
        elevations = reference.loc[reference["_coordinate"] == node, "Elevation"]
        if elevations.max() - elevations.min() > geometry_tolerance_m:
            raise ValueError(f"Conflicting elevations at junction {node}.")
    orientation = None
    if orient_by_continuity:
        orientation = _orient_by_continuity(
            edges, edge_flows, next(iter(sinks)), source_nodes, layout,
        )
    incoming_nodes = {e["down"] for e in edges}
    if incoming_nodes & set(source_nodes.values()):
        raise ValueError("Source located on an inflowing branch requires separate injection-rate labels.")
    spec = {
        "nodes": sorted(nodes), "sink": next(iter(sinks)), "edges": edges,
        "sources": {
            source: {"node": node, "profile_node_ids": source_rows[source], **(
                {"temperature_k": temperatures[source]} if temperatures is not None else {}
            )}
            for source, node in source_nodes.items()
        },
    }
    if orientation is not None:
        spec["orientation_audit"] = orientation
    return spec, layout, source_rows, by_id


def orientation_sweep(frame, source_map, *, seed=2026, geometry_tolerance_m=0.01,
                      coordinate_decimals=8, trunks=None, scenarios=None,
                      relative_tolerance=0.02, residual_tolerance=0.02):
    """Re-derive edge orientation in every simulation and report any branch that flips.

    The solver is handed one fixed orientation, taken from the geometry reference
    scenario. That is only sound if no branch ever reverses across the sweep. A branch
    that genuinely reverses, for instance when a shut-in cluster comes back online,
    cannot be represented by a single direction and would not announce itself: the model
    would train and then predict badly on the subset where the direction is wrong.

    A branch carrying no flow has no direction to find, so it is reported separately
    rather than counted as a failure.
    """
    from copy import deepcopy

    if not frame["scenario"].map(lambda value: isinstance(value, str)).all():
        raise ValueError("orientation_sweep requires normalized string scenario IDs from load_profiles.")
    split = scenario_split(frame["scenario"], seed=seed)
    reference_scenario = split["train"][0]
    selected = sorted(set(frame["scenario"]) if scenarios is None else {str(s) for s in scenarios})
    missing = [s for s in selected if s not in set(frame["scenario"])]
    if missing:
        raise ValueError(f"Requested scenarios are absent: {missing}")

    report, clean = {}, True
    for trunk, trunk_frame in frame.groupby("trunk", sort=True):
        if trunks is not None and trunk not in trunks:
            continue
        mapping = source_map.loc[source_map["Troncal"] == trunk].copy()
        if mapping.empty:
            raise ValueError(f"Missing source mapping in {trunk}.")
        reference = trunk_frame.loc[trunk_frame["scenario"] == reference_scenario]
        spec, layout, _, _ = _geometry(
            reference, mapping, None, coordinate_decimals, geometry_tolerance_m,
        )
        sink = spec["sink"]
        source_nodes = {name: record["node"] for name, record in spec["sources"].items()}
        anchor = {edge["id"]: (edge["up"], edge["down"]) for edge in spec["edges"]}

        # One pivot beats a per-edge lookup in every scenario. Median is order free, so
        # it does not matter that a reversed edge holds its node IDs back to front.
        rate_table = trunk_frame.pivot(
            index="node_id", columns="scenario", values="FlowrateLiquidInsitu",
        )
        edge_rates = {
            edge["id"]: rate_table.loc[edge["profile_node_ids"]].median(axis=0)
            for edge in spec["edges"]
        }

        tally = {edge["id"]: {"agrees": 0, "reversed": 0, "unresolved": 0, "zero_flow": 0,
                             "min_rate": np.inf, "max_rate": 0., "flip_scenarios": []}
                 for edge in spec["edges"]}
        flagged, worst = {}, {"relative_residual": 0., "scenario": None, "node": None}
        for scenario in selected:
            probe_edges = deepcopy(spec["edges"])
            probe_layout = deepcopy(layout)
            flows = [float(edge_rates[edge["id"]][scenario]) for edge in probe_edges]
            audit = _orient_by_continuity(
                probe_edges, flows, sink, source_nodes, probe_layout, relative_tolerance,
            )
            unresolved = set(audit["unresolved_edges"])
            if audit["flagged"]:
                flagged[scenario] = audit["flagged"]
                clean = False
            if audit["worst_relative_continuity_residual"] > worst["relative_residual"]:
                worst = {"relative_residual": audit["worst_relative_continuity_residual"],
                         "scenario": scenario, "node": audit["worst_node"]}
            for edge, rate in zip(probe_edges, flows):
                record = tally[edge["id"]]
                record["min_rate"] = min(record["min_rate"], rate)
                record["max_rate"] = max(record["max_rate"], rate)
                if rate <= 0.:
                    record["zero_flow"] += 1
                if edge["id"] in unresolved:
                    record["unresolved"] += 1
                elif (edge["up"], edge["down"]) == anchor[edge["id"]]:
                    record["agrees"] += 1
                else:
                    record["reversed"] += 1
                    record["flip_scenarios"].append(scenario)

        # A flip only matters where the branch was actually carrying liquid.
        flipping = [
            {"edge": edge_id, "reversed_scenarios": record["reversed"],
             "first_examples": record["flip_scenarios"][:5],
             "min_rate_bbl_day": None if not np.isfinite(record["min_rate"]) else record["min_rate"],
             "max_rate_bbl_day": record["max_rate"]}
            for edge_id, record in tally.items()
            if record["reversed"] > 0 and record["max_rate"] > 0.
        ]
        dead = [edge_id for edge_id, record in tally.items() if record["max_rate"] <= 0.]
        unresolved_edges = {
            edge_id: record["unresolved"] for edge_id, record in tally.items()
            if record["unresolved"] > 0 and record["max_rate"] > 0.
        }
        if flipping or unresolved_edges or worst["relative_residual"] > residual_tolerance:
            clean = False
        report[trunk] = {
            "reference_reversed_edges": spec["orientation_audit"]["reversed_edges"],
            "flipping_edges": flipping,
            "unresolved_edges_with_flow": unresolved_edges,
            "always_zero_flow_edges": dead,
            "flagged_scenarios": flagged,
            "worst_continuity_residual": worst,
            "branches": len(spec["edges"]),
        }
    return {
        "reference_scenario": reference_scenario,
        "scenarios_checked": len(selected),
        "relative_tolerance": relative_tolerance,
        "residual_tolerance": residual_tolerance,
        "scope": ("direction constancy of every branch across simulations; not geometry, "
                  "labels or physics"),
        "trunks": report,
        "clean": clean,
    }


def orientation_summary(sweep):
    """Flatten an orientation_sweep report into one row per trunk for display."""
    rows = []
    for trunk, record in sweep["trunks"].items():
        rows.append({
            "trunk": trunk,
            "branches": record["branches"],
            "reversed_at_reference": len(record["reference_reversed_edges"]),
            "branches_that_flip": len(record["flipping_edges"]),
            "unresolved_with_flow": len(record["unresolved_edges_with_flow"]),
            "always_zero_flow": len(record["always_zero_flow_edges"]),
            "flagged_scenarios": len(record["flagged_scenarios"]),
            "worst_continuity_residual": record["worst_continuity_residual"]["relative_residual"],
            "worst_scenario": record["worst_continuity_residual"]["scenario"],
        })
    return pd.DataFrame(rows)


def _source_inlet_state(inlets, context, temperature_tolerance_k, geometry_tolerance_m,
                        watercut_tolerance, density_rtol):
    columns = ["pressure_psia", "Elevation", "temperature_k", "Watercut",
               "DensityOilInSitu", "DensityWaterInSitu", "FlowrateLiquidInsitu"]
    if not np.isfinite(inlets[columns].to_numpy(float)).all():
        raise ValueError(f"Nonfinite source inlet values: {context}.")
    if ((inlets["FlowrateLiquidInsitu"] < 0).any()
            or not inlets["Watercut"].between(0, 1).all()
            or (inlets[["temperature_k", "DensityOilInSitu", "DensityWaterInSitu"]] <= 0).any().any()):
        raise ValueError(f"Invalid source flow, watercut, temperature or density: {context}.")
    spreads = {}
    for column, atol, rtol in (
        ("pressure_psia", 0., 0.),
        ("Elevation", geometry_tolerance_m, 0.),
        ("temperature_k", temperature_tolerance_k, 0.),
        ("Watercut", watercut_tolerance, 0.),
        ("DensityOilInSitu", 0., density_rtol),
        ("DensityWaterInSitu", 0., density_rtol),
    ):
        values = inlets[column].to_numpy(float)
        spread = float(values.max() - values.min())
        tolerance = atol + rtol * float(np.abs(values).min())
        spreads[column] = spread
        if spread > tolerance:
            raise ValueError(
                f"Shared-source inlet disagreement: {context}/{column}; "
                f"spread {spread:.12g} exceeds tolerance {tolerance:.12g}. "
                "Reconcile the source association or inlet labels; branches were not merged."
            )
    rates = inlets["FlowrateLiquidInsitu"].to_numpy(float)
    watercuts = inlets["Watercut"].to_numpy(float)
    total = float(rates.sum())
    watercut = float(np.dot(rates, watercuts) / total) if total > 0 else float(watercuts[0])
    return {
        "rate_m3_s": total * BBL_DAY_TO_M3_S, "watercut": watercut,
        "temperature_k": float(inlets["temperature_k"].iloc[0]),
        "temperature_min_k": float(inlets["temperature_k"].min()),
        "temperature_max_k": float(inlets["temperature_k"].max()),
        "inlet_spreads": spreads,
        "zero_flow": total == 0,
        "branch_observations": {
            "node_ids": inlets.index.tolist(),
            "rates_bbl_day": rates.tolist(), "watercuts": watercuts.tolist(),
            "oil_densities": inlets["DensityOilInSitu"].tolist(),
            "water_densities": inlets["DensityWaterInSitu"].tolist(),
        },
    }


def _scenario_geometry_issues(group, reference_by_id, trunk, scenario,
                              geometry_tolerance_m, coordinate_decimals):
    issues = []

    def record(column, reason, difference=None, tolerance=None):
        issues.append({
            "trunk": str(trunk), "scenario": str(scenario), "column": column,
            "reason": reason, "max_difference": difference, "tolerance": tolerance,
        })

    if group.index.has_duplicates:
        record("node_id", f"Duplicate geometry node IDs in {trunk}, scenario {scenario}.")
        return issues
    if set(group.index) != set(reference_by_id.index):
        missing = sorted(set(reference_by_id.index) - set(group.index))
        extra = sorted(set(group.index) - set(reference_by_id.index))
        record("node_id", f"Geometry node set changed in {trunk}, scenario {scenario}. "
                         f"Missing={missing}; extra={extra}.")
        return issues
    aligned = group.loc[reference_by_id.index]
    for column in ("BranchEquipment", "node_type"):
        if not aligned[column].eq(reference_by_id[column]).all():
            record(column, f"{column} identity changed in {trunk}, scenario {scenario}.")
    for column, scale, tolerance in (
        ("TotalDistance", FT_TO_M, geometry_tolerance_m),
        ("Elevation", 1., geometry_tolerance_m),
        ("PipeInsideDiameter", IN_TO_M, geometry_tolerance_m),
        ("long", 1., 10 ** -coordinate_decimals),
        ("lat", 1., 10 ** -coordinate_decimals),
    ):
        if not np.isfinite(aligned[column].to_numpy(float)).all():
            record(column, f"Nonfinite {column} geometry in {trunk}, scenario {scenario}.")
            continue
        difference = float((aligned[column] - reference_by_id[column]).abs().max()) * scale
        if difference > tolerance:
            record(column,
                   f"{column} geometry changed in {trunk}, scenario {scenario}: "
                   f"max difference {difference:g}. Reconcile geometry; no silent replacement.",
                   difference, tolerance)
    return issues


def filter_inconsistent_scenarios(frame, *, seed=2026, geometry_tolerance_m=0.01,
                                 coordinate_decimals=8):
    """Drop whole simulations with geometry/identity mismatches, returning a full audit."""
    if not np.isfinite(geometry_tolerance_m) or geometry_tolerance_m < 0:
        raise ValueError("geometry_tolerance_m must be finite and nonnegative.")
    if not isinstance(coordinate_decimals, int) or not 0 <= coordinate_decimals <= 15:
        raise ValueError("coordinate_decimals must be an integer between 0 and 15.")
    if frame.empty or frame[["trunk", "scenario", "node_id"]].isna().any().any():
        raise ValueError("Scenario screening requires nonempty data and nonmissing identifiers.")
    if not frame["scenario"].map(lambda value: isinstance(value, str)).all():
        raise ValueError("Scenario screening requires normalized string scenario IDs from load_profiles.")
    reference_scenario = scenario_split(frame["scenario"], seed=seed)["train"][0]
    scenarios = sorted(set(frame["scenario"]))
    issues = []
    for trunk, trunk_frame in frame.groupby("trunk", sort=True):
        reference = trunk_frame.loc[trunk_frame["scenario"] == reference_scenario].set_index("node_id")
        if reference.empty or reference.index.has_duplicates:
            raise ValueError(
                f"Invalid screening reference {reference_scenario} in {trunk}: "
                "missing rows or duplicate node IDs. Reconcile the reference, not the other scenarios."
            )
        reference_issues = _scenario_geometry_issues(
            reference, reference, trunk, reference_scenario, geometry_tolerance_m, coordinate_decimals,
        )
        if reference_issues:
            raise ValueError(f"Invalid screening reference: {reference_issues[0]['reason']}")
        grouped = {scenario: rows for scenario, rows in trunk_frame.groupby("scenario", sort=True)}
        for scenario in scenarios:
            if scenario not in grouped:
                issues.append({
                    "trunk": str(trunk), "scenario": scenario, "column": "scenario",
                    "reason": f"Missing trunk {trunk} in scenario {scenario}.",
                    "max_difference": None, "tolerance": None,
                })
                continue
            issues.extend(_scenario_geometry_issues(
                grouped[scenario].set_index("node_id"), reference, trunk, scenario,
                geometry_tolerance_m, coordinate_decimals,
            ))
    excluded = sorted({issue["scenario"] for issue in issues})
    kept = frame.loc[~frame["scenario"].isin(excluded)].copy()
    if kept["scenario"].nunique() < 3:
        raise ValueError(
            f"Geometry screening would leave fewer than three scenarios; "
            f"reference={reference_scenario}, exclusions={excluded}. Input data was not changed."
        )
    audit = {
        "reference_scenario": reference_scenario,
        "scope": "geometry, node/branch identity and trunk coverage; not physics/label outliers",
        "excluded_scenario_ids": excluded,
        "retained_scenarios": int(kept["scenario"].nunique()),
        "removed_rows_by_trunk": frame.loc[frame["scenario"].isin(excluded)].groupby("trunk").size().to_dict(),
        "geometry_tolerance_m": geometry_tolerance_m, "coordinate_decimals": coordinate_decimals,
        "issues": issues,
    }
    return kept, audit


def prepare_data(frame, source_map, *, seed=2026, source_temperature_tolerance_k=0.1,
                 geometry_tolerance_m=0.01, coordinate_decimals=8, density_unit="lbm/ft3",
                 source_watercut_tolerance=1e-7, source_density_rtol=1e-5,
                 geometry_reference_scenario=None):
    if density_unit not in {"lbm/ft3", "kg/m3"}:
        raise ValueError("Explicit density unit must be lbm/ft3 or kg/m3.")
    for name, value in (
        ("source_temperature_tolerance_k", source_temperature_tolerance_k),
        ("geometry_tolerance_m", geometry_tolerance_m),
        ("source_watercut_tolerance", source_watercut_tolerance),
        ("source_density_rtol", source_density_rtol),
    ):
        if not np.isfinite(value) or value < 0:
            raise ValueError(f"{name} must be finite and nonnegative.")
    split = scenario_split(frame["scenario"], seed=seed)
    reference_scenario = (split["train"][0] if geometry_reference_scenario is None
                          else str(geometry_reference_scenario))
    if reference_scenario not in set(frame["scenario"]):
        raise ValueError(f"Geometry reference scenario {reference_scenario} is absent.")
    specs, layouts, cases, audits = {}, {}, {}, {}
    for trunk, trunk_frame in frame.groupby("trunk", sort=True):
        ids = set(trunk_frame["scenario"])
        if ids != set(frame["scenario"]):
            raise ValueError(f"Trunk {trunk} does not have the same simulation IDs as the other trunks.")
        mapping = source_map.loc[source_map["Troncal"] == trunk].copy()
        if mapping.empty or mapping["source"].duplicated().any():
            raise ValueError(f"Missing or duplicate source mapping in {trunk}.")
        reference = trunk_frame.loc[trunk_frame["scenario"] == reference_scenario]
        reference_by_id = reference.set_index("node_id")
        reference_issues = _scenario_geometry_issues(
            reference_by_id, reference_by_id, trunk, reference_scenario,
            geometry_tolerance_m, coordinate_decimals,
        )
        if reference_issues:
            raise ValueError(f"Invalid geometry reference: {reference_issues[0]['reason']}")
        spec, layout, source_rows, reference_by_id = _geometry(
            reference, mapping, None, coordinate_decimals, geometry_tolerance_m,
        )
        observations = []
        specs[trunk], layouts[trunk] = spec, layout
        source_ids = list(spec["sources"])
        source_audits = {
            source: {
                "profile_node_ids": rows,
                "branches": reference_by_id.loc[rows, "BranchEquipment"].tolist(),
                "max_inlet_spreads": {}, "zero_flow_scenarios": 0,
            } for source, rows in source_rows.items()
        }
        row_order = reference["node_id"].tolist()
        for scenario, group in trunk_frame.groupby("scenario", sort=True):
            group = group.set_index("node_id")
            geometry_issues = _scenario_geometry_issues(
                group, reference_by_id, trunk, scenario, geometry_tolerance_m, coordinate_decimals,
            )
            if geometry_issues:
                raise ValueError(geometry_issues[0]["reason"])
            source_states = {}
            for source, row_ids in source_rows.items():
                inlets = group.loc[row_ids]
                coordinates = inlets.apply(lambda row: _coordinate(row, coordinate_decimals), axis=1)
                if not coordinates.eq(spec["sources"][source]["node"]).all():
                    raise ValueError(f"Source junction changed: {trunk}/{source}/{scenario}.")
                state = _source_inlet_state(
                    inlets, f"{trunk}/{source}/{scenario}", source_temperature_tolerance_k,
                    geometry_tolerance_m, source_watercut_tolerance, source_density_rtol,
                )
                source_states[source] = state
                observations.append({
                    "scenario": scenario, "source_id": source,
                    "temperature_k": state["temperature_k"],
                    "temperature_min_k": state["temperature_min_k"],
                    "temperature_max_k": state["temperature_max_k"],
                })
                audit = source_audits[source]
                audit["zero_flow_scenarios"] += int(state["zero_flow"])
                for column, spread in state["inlet_spreads"].items():
                    audit["max_inlet_spreads"][column] = max(
                        audit["max_inlet_spreads"].get(column, 0.), spread,
                    )
            ordered = group.loc[row_order]
            cases.setdefault(str(scenario), {})[trunk] = {
                "rates_m3_s": [source_states[s]["rate_m3_s"] for s in source_ids],
                "watercuts": [source_states[s]["watercut"] for s in source_ids],
                "source_branch_observations": {
                    s: source_states[s]["branch_observations"] for s in source_ids
                },
                "node_ids": row_order,
                "pressure_psia": ordered["pressure_psia"].tolist(),
                "temperature_k": ordered["temperature_k"].tolist(),
                "is_sink": [layout[n]["is_sink"] for n in row_order],
            }
        temperatures, temperature_audit = fixed_source_temperatures(
            pd.DataFrame(observations), split["train"], source_temperature_tolerance_k,
        )
        for row in observations:
            temperature = temperatures[row["source_id"]]
            if max(abs(row["temperature_min_k"] - temperature),
                   abs(row["temperature_max_k"] - temperature)) > source_temperature_tolerance_k:
                raise ValueError(
                    f"Fixed source temperature violated: {trunk}/{row['source_id']}/{row['scenario']}."
                )
        for source, temperature in temperatures.items():
            spec["sources"][source]["temperature_k"] = temperature
        for audit in temperature_audit:
            audit.update(source_audits[audit["source_id"]])
        audits[trunk] = {
            "sources": temperature_audit, "branches": len(spec["edges"]),
            "canonical_nodes": len(spec["nodes"]), "profile_rows": len(reference),
            "simulation_count": len(ids),
            "orientation": spec.get("orientation_audit"),
        }
    training = frame.loc[frame["scenario"].isin(split["train"])]
    density_scale = 16.01846337396 if density_unit == "lbm/ft3" else 1.
    densities = {
        "rho_oil_kg_m3": float(training["DensityOilInSitu"].median()) * density_scale,
        "rho_water_kg_m3": float(training["DensityWaterInSitu"].median()) * density_scale,
    }
    return PreparedData(specs, layouts, cases, split, {
        "geometry_reference_scenario": reference_scenario,
        "trunks": audits, "fixed_density_constants": densities,
        "density_estimation": "training-only medians of phase-density labels; no pressure calibration",
        "source_aggregation": {
            "rates": "sum of branch inlet liquid volumes; one external injection per mapped source",
            "watercut": "liquid-flow-weighted; mapped anchor watercut at zero total flow",
            "mass_convention": "phase-volume conservation using frozen model phase densities",
            "branch_density_unit": density_unit,
            "pressure_tolerance_psia": 0.,
            "elevation_tolerance_m": geometry_tolerance_m,
            "temperature_tolerance_k": source_temperature_tolerance_k,
            "watercut_tolerance": source_watercut_tolerance,
            "density_rtol": source_density_rtol,
            "density_comparison": "max-minus-min <= rtol * min(abs(density)) within each scenario",
        },
        "oil_stock_tank_sg_from_api13": 141.5 / (13 + 131.5),
        "water_stock_tank_sg": 1.02,
        "provisional_property_model": "constant-density oil/water, dead-oil viscosity approximation",
    })
