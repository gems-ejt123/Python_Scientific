"""
Dataset generation for PINN-VFM training.

Generates synthetic data using APRBS (Amplitude-Modulated Pseudo-Random Binary Signals)
as exogenous inputs, simulates the ESP model, adds measurement noise (Table 3),
and builds input/output sequences for LSTM training (Eq. 7).
"""

import numpy as np
from scipy.interpolate import interp1d
from esp_model import ESPModel, ESPParams


def generate_aprbs(n_samples, dt, low, high, min_hold=10, max_hold=100, seed=None):
    """
    Generate an Amplitude-Modulated Pseudo-Random Binary Signal (APRBS).

    Parameters
    ----------
    n_samples : int
        Number of time samples.
    dt : float
        Sampling time [s].
    low, high : float
        Signal amplitude bounds.
    min_hold, max_hold : int
        Min/max samples to hold each random level.
    seed : int, optional
        Random seed.

    Returns
    -------
    signal : ndarray, shape (n_samples,)
    """
    rng = np.random.RandomState(seed)
    signal = np.zeros(n_samples)
    idx = 0
    while idx < n_samples:
        level = rng.uniform(low, high)
        hold = rng.randint(min_hold, max_hold + 1)
        end = min(idx + hold, n_samples)
        signal[idx:end] = level
        idx = end
    return signal


def generate_exogenous_inputs(n_samples, dt=1.0, seed=42):
    """
    Generate APRBS exogenous inputs for the ESP model.

    Returns u(t) = [f(t), Zc(t), Pm(t), Pr(t)] at each timestep.

    Parameters
    ----------
    n_samples : int
        Number of samples.
    dt : float
        Sampling time [s].
    seed : int
        Base random seed.

    Returns
    -------
    u_array : ndarray, shape (n_samples, 4)
        Columns: [f, Zc, Pm, Pr].
    """
    # ESP frequency: 45-65 Hz (around f0=60)
    f = generate_aprbs(n_samples, dt, low=45.0, high=65.0,
                       min_hold=50, max_hold=200, seed=seed)

    # Choke opening: 30-100%
    Zc = generate_aprbs(n_samples, dt, low=30.0, high=100.0,
                        min_hold=50, max_hold=200, seed=seed + 1)

    # Manifold pressure: ±10% around 2e6 Pa
    Pm = generate_aprbs(n_samples, dt, low=1.8e6, high=2.2e6,
                        min_hold=80, max_hold=300, seed=seed + 2)

    # Reservoir pressure: slow variations around 1.26e7 Pa
    Pr = generate_aprbs(n_samples, dt, low=1.1e7, high=1.4e7,
                        min_hold=200, max_hold=500, seed=seed + 3)

    return np.column_stack([f, Zc, Pm, Pr])


def generate_dataset(n_samples=6000, dt=1.0, params=None, seed=42):
    """
    Generate a complete synthetic dataset by simulating the ESP model
    with APRBS excitation signals.

    This reproduces the dataset in Figure 7 of Franklin et al. (2022).

    Parameters
    ----------
    n_samples : int
        Number of time samples (default: 6000 as in the paper).
    dt : float
        Sampling time in seconds (default: 1.0).
    params : ESPParams, optional
        Model parameters. Uses defaults (Table 2) if None.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    t : ndarray, shape (n_samples,)
        Time vector.
    y : ndarray, shape (n_samples, 3)
        States [Pbh, Pwh, q] at each timestep.
    u : ndarray, shape (n_samples, 4)
        Exogenous inputs [f, Zc, Pm, Pr] at each timestep.
    """
    model = ESPModel(params)

    # Generate exogenous inputs
    u_array = generate_exogenous_inputs(n_samples, dt, seed)
    t_array = np.arange(n_samples) * dt

    # Create interpolation function for inputs
    u_interp = interp1d(t_array, u_array, axis=0, kind='zero',
                        fill_value='extrapolate')

    # Compute initial steady state from first input values
    u0 = u_array[0]
    y0 = model.compute_steady_state(u0)
    print(f"Initial steady state: Pbh={y0[0]:.2e} Pa, Pwh={y0[1]:.2e} Pa, q={y0[2]:.6f} m³/s")

    # Simulate
    print(f"Simulating {n_samples} samples at dt={dt}s...")
    sol = model.simulate(
        y0=y0,
        t_span=(0, (n_samples - 1) * dt),
        t_eval=t_array,
        u_func=u_interp,
        method='Radau'
    )

    if not sol.success:
        raise RuntimeError(f"Simulation failed: {sol.message}")

    y_out = sol.y.T  # (n_samples, 3)
    print(f"Simulation complete. Final state: Pbh={y_out[-1,0]:.2e}, "
          f"Pwh={y_out[-1,1]:.2e}, q={y_out[-1,2]:.6f}")

    return t_array, y_out, u_array


def add_noise(signals, noise_std, seed=None):
    """
    Add multiplicative Gaussian noise as in Eq. 13 and Table 3.

    sn = (1 + n) * sr, where n ~ N(0, sigma)

    Parameters
    ----------
    signals : ndarray, shape (n_samples, n_signals)
        Clean signals.
    noise_std : list or ndarray
        Standard deviation for each signal column.
    seed : int, optional
        Random seed.

    Returns
    -------
    noisy_signals : ndarray
        Signals with added noise.
    """
    rng = np.random.RandomState(seed)
    noise_std = np.asarray(noise_std)
    noise = rng.randn(*signals.shape) * noise_std[np.newaxis, :]
    return (1.0 + noise) * signals


# Noise standard deviations from Table 3
NOISE_STD_STATES = [0.01, 0.01, 0.01]          # Pbh, Pwh, q
NOISE_STD_INPUTS = [0.001, 0.005, 0.01, 0.0]   # f, Zc, Pm, Pr (Pr assumed known)


def build_sequences(y_measured, u_measured, Nh=30):
    """
    Build input/output sequences for LSTM training as per Eq. 7.

    Each sample:
      Input X(k) = [yr(k-1), ..., yr(k-Nh), u(k-1), ..., u(k-Nh)]
      Output y_hat(k) = [Pbh(k), Pwh(k), q(k)]

    Where yr = [Pbh, Pwh] (measured states) and u = [f, Zc, Pm, Pr].

    Parameters
    ----------
    y_measured : ndarray, shape (n_samples, 3)
        States (possibly noisy). Columns: [Pbh, Pwh, q].
    u_measured : ndarray, shape (n_samples, 4)
        Exogenous inputs (possibly noisy). Columns: [f, Zc, Pm, Pr].
    Nh : int
        History window length (default: 30 as found optimal).

    Returns
    -------
    X : ndarray, shape (n_sequences, Nh, n_features)
        Input sequences. n_features = 2 (yr) + 4 (u) = 6.
    Y : ndarray, shape (n_sequences, 3)
        Target outputs [Pbh, Pwh, q] at the prediction timestep.
    """
    yr = y_measured[:, :2]  # Measured states: [Pbh, Pwh]
    n_samples = len(y_measured)

    # Combined feature vector at each timestep
    features = np.concatenate([yr, u_measured], axis=1)  # (n_samples, 6)
    n_features = features.shape[1]

    n_sequences = n_samples - Nh
    X = np.zeros((n_sequences, Nh, n_features))
    Y = np.zeros((n_sequences, 3))

    for k in range(Nh, n_samples):
        # Input: history from (k-Nh) to (k-1)
        X[k - Nh] = features[k - Nh:k]
        # Target: states at k
        Y[k - Nh] = y_measured[k]

    return X, Y


def train_val_split(X, Y, train_ratio=0.7):
    """
    Split sequences into train/validation preserving temporal order.

    Parameters
    ----------
    X : ndarray, shape (n_sequences, Nh, n_features)
    Y : ndarray, shape (n_sequences, 3)
    train_ratio : float
        Fraction for training (default: 0.7 as in paper).

    Returns
    -------
    X_train, Y_train, X_val, Y_val
    """
    n = len(X)
    n_train = int(n * train_ratio)
    return X[:n_train], Y[:n_train], X[n_train:], Y[n_train:]
