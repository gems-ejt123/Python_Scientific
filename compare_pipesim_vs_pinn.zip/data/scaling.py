"""
Scaling and normalization for the ESP PINN-VFM.

The ESP model is a natural multi-scale system:
  - Pressures: O(10^7 Pa)
  - Flow rate: O(10^-3 m³/s)

Without scaling, ODE residuals are heavily imbalanced, causing training
to fail or converge very slowly. This module provides:
  1. Data normalization (min-max) for network inputs/outputs
  2. ODE scaling factors for balanced residual computation

Reference: Langtangen & Pedersen (2016), Scaling of Differential Equations.
"""

import numpy as np
import torch


class ESPScaler:
    """
    Min-max scaler fitted on training data for all signals.

    Handles separate scaling for:
    - yr: measured states [Pbh, Pwh] (network inputs)
    - u:  exogenous inputs [f, Zc, Pm, Pr] (network inputs)
    - y:  all states [Pbh, Pwh, q] (network outputs)
    """

    def __init__(self):
        self.fitted = False
        # Storage for min/max values
        self.y_min = None
        self.y_max = None
        self.u_min = None
        self.u_max = None

    def fit(self, y, u):
        """
        Fit scaler on training data.

        Parameters
        ----------
        y : ndarray, shape (n_samples, 3)
            States [Pbh, Pwh, q].
        u : ndarray, shape (n_samples, 4)
            Inputs [f, Zc, Pm, Pr].
        """
        self.y_min = y.min(axis=0)
        self.y_max = y.max(axis=0)
        self.u_min = u.min(axis=0)
        self.u_max = u.max(axis=0)

        # Prevent division by zero
        y_range = self.y_max - self.y_min
        u_range = self.u_max - self.u_min
        y_range[y_range == 0] = 1.0
        u_range[u_range == 0] = 1.0
        self.y_range = y_range
        self.u_range = u_range

        self.fitted = True

    def normalize_y(self, y):
        """Normalize states to [0, 1]."""
        return (y - self.y_min) / self.y_range

    def denormalize_y(self, y_norm):
        """Denormalize states back to physical units."""
        return y_norm * self.y_range + self.y_min

    def normalize_u(self, u):
        """Normalize inputs to [0, 1]."""
        return (u - self.u_min) / self.u_range

    def denormalize_u(self, u_norm):
        """Denormalize inputs back to physical units."""
        return u_norm * self.u_range + self.u_min

    def normalize_sequences(self, X, Y):
        """
        Normalize pre-built sequences.

        X has shape (n_seq, Nh, 6) where features = [Pbh, Pwh, f, Zc, Pm, Pr].
        Y has shape (n_seq, 3) where targets = [Pbh, Pwh, q].
        """
        X_norm = X.copy()
        # First 2 features are yr = [Pbh, Pwh]
        X_norm[:, :, 0] = (X[:, :, 0] - self.y_min[0]) / self.y_range[0]
        X_norm[:, :, 1] = (X[:, :, 1] - self.y_min[1]) / self.y_range[1]
        # Next 4 features are u = [f, Zc, Pm, Pr]
        for i in range(4):
            X_norm[:, :, 2 + i] = (X[:, :, 2 + i] - self.u_min[i]) / self.u_range[i]

        Y_norm = self.normalize_y(Y)
        return X_norm, Y_norm

    def get_ode_scale_factors(self):
        """
        Compute scaling factors for ODE residuals.

        The ODE residuals are computed in normalized space. To balance them,
        we need to account for the range of each state variable and the
        time scale.

        Returns
        -------
        scale : dict with keys 'Pbh', 'Pwh', 'q' containing the
                characteristic scales for each equation's residual.
        """
        return {
            'Pbh': self.y_range[0],
            'Pwh': self.y_range[1],
            'q': self.y_range[2],
        }

    def to_torch(self, device='cpu'):
        """Convert scale arrays to torch tensors."""
        return {
            'y_min': torch.tensor(self.y_min, dtype=torch.float32, device=device),
            'y_max': torch.tensor(self.y_max, dtype=torch.float32, device=device),
            'y_range': torch.tensor(self.y_range, dtype=torch.float32, device=device),
            'u_min': torch.tensor(self.u_min, dtype=torch.float32, device=device),
            'u_max': torch.tensor(self.u_max, dtype=torch.float32, device=device),
            'u_range': torch.tensor(self.u_range, dtype=torch.float32, device=device),
        }
