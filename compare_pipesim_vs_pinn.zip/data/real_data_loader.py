"""
Real-data loader for the Castilla ESP-lifted well (Virtual Flow Metering).

The synthetic Franklin (2022) pipeline assumes a dense 1-s transient time series.
The real Castilla data is the opposite regime: ~85 *daily-average* snapshots,
sampled irregularly (weekly to 3-weekly) between 2023 and 2026 for a SINGLE well.
We therefore treat it as a quasi-steady-state VFM problem (see `esp_steady.py`).

This module:
  1. Parses the semicolon-delimited CSV (dd/mm/yyyy dates, comma-thousands numbers).
  2. Converts every physical quantity to SI internally (Pa, m3/s, kg/m3, Pa.s, m).
  3. Drops target-leaking / constant columns.
  4. Builds a leakage-safe *chronological* train/val(/calibration) split and
     blocked CV folds.

Field columns (raw CSV):
  Fecha; BFPD; BOPD; BWPD; KPCD; BS&W; API; Frec; PIP; PWF; Res_Press; IP;
  THP; Manifold_Troncal; Densidad; Visosidad; Zc

Notes on leakage (do NOT use as model inputs):
  - BOPD, BWPD : algebraic split of BFPD via BS&W  -> derived from the target.
  - IP         : == BFPD / (Res_Press - PWF)        -> derived from the target.
  - KPCD       : gas rate, identically 0 here.
  - Zc         : choke opening, identically 1 (no choke installed).
  - Res_Press  : constant (2022 psi) -> carries no per-sample information.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from dataclasses import dataclass, field


# --------------------------------------------------------------------------- #
#  Unit conversion constants (field -> SI)                                     #
# --------------------------------------------------------------------------- #
PSI_TO_PA = 6894.757293        # psi  -> Pa
BBL_TO_M3 = 0.158987294928     # barrel -> m^3
DAY_S = 86400.0                # day  -> s
BBLPD_TO_M3S = BBL_TO_M3 / DAY_S   # bbl/day -> m^3/s   (= 1.84013e-6)
LBFT3_TO_KGM3 = 16.018463      # lb/ft^3 -> kg/m^3
FT_TO_M = 0.3048               # ft   -> m
IN_TO_M = 0.0254               # inch -> m
CP_TO_PAS = 1e-3               # cP   -> Pa.s
G = 9.81                       # gravitational acceleration [m/s^2]


# Default model-input feature set (physical SI units).
# These are physically independent drivers of the flow rate; leaking and
# constant columns are intentionally excluded (see module docstring).
DEFAULT_FEATURES = [
    "Frec",       # ESP frequency [Hz]
    "PIP_Pa",     # pump intake pressure [Pa]
    "THP_Pa",     # tubing-head pressure [Pa]
    "Pm_Pa",      # manifold (Manifold_Troncal) pressure [Pa]
    "rho",        # fluid density [kg/m^3]
    "mu",         # fluid viscosity [Pa.s]
    "BSW",        # water cut [fraction]
]

TARGET = "q"      # liquid rate [m^3/s] (BFPD converted to SI)


@dataclass
class RealDataBundle:
    """Container for the cleaned real-data arrays and metadata."""
    df: pd.DataFrame                       # full cleaned frame (SI columns added)
    feature_names: list                    # ordered model-input columns
    X: np.ndarray                          # (n, n_features) model inputs (SI)
    y: np.ndarray                          # (n,) target liquid rate [m^3/s]
    dates: np.ndarray                      # (n,) datetime64 sorted ascending
    phys: dict                             # arrays needed by the physics residuals
    meta: dict = field(default_factory=dict)


# --------------------------------------------------------------------------- #
#  Parsing                                                                     #
# --------------------------------------------------------------------------- #
def _to_float(series: pd.Series) -> pd.Series:
    """Robustly coerce a string column with comma-thousands to float."""
    if series.dtype.kind in "fi":
        return series.astype(float)
    cleaned = (
        series.astype(str)
        .str.strip()
        .str.replace(",", "", regex=False)   # drop thousands separators
        .replace({"": np.nan, "nan": np.nan})
    )
    return pd.to_numeric(cleaned, errors="coerce")


def load_real_data(
    csv_path: str,
    feature_names: list | None = None,
    dropna: bool = True,
) -> RealDataBundle:
    """
    Load and clean the Castilla real-data CSV into SI units.

    Parameters
    ----------
    csv_path : str
        Path to ``data_fluid_pressure_density_more.csv``.
    feature_names : list, optional
        Ordered list of model-input columns (defaults to ``DEFAULT_FEATURES``).
    dropna : bool
        Drop rows with missing values in the required columns.

    Returns
    -------
    RealDataBundle
    """
    feature_names = feature_names or list(DEFAULT_FEATURES)

    raw = pd.read_csv(csv_path, sep=";", dtype=str)
    raw.columns = [c.strip() for c in raw.columns]

    df = pd.DataFrame()
    # Dates (day-first dd/mm/yyyy)
    df["date"] = pd.to_datetime(raw["Fecha"].str.strip(), dayfirst=True, errors="coerce")

    # Numeric field columns
    numeric_cols = [
        "BFPD", "BOPD", "BWPD", "KPCD", "BS&W", "API", "Frec", "PIP", "PWF",
        "Res_Press", "IP", "THP", "Manifold_Troncal", "Densidad", "Visosidad", "Zc",
    ]
    for col in numeric_cols:
        if col in raw.columns:
            df[col] = _to_float(raw[col])

    # THP < manifold is non-physical (flow must go well -> troncal): clamp
    # THP up to the manifold pressure (most flagged rows are exact ties anyway).
    if "Manifold_Troncal" in df.columns:
        df["THP"] = df[["THP", "Manifold_Troncal"]].max(axis=1)

    # ------------------------------------------------------------------ #
    #  SI conversions                                                     #
    # ------------------------------------------------------------------ #
    df["q"] = df["BFPD"] * BBLPD_TO_M3S                  # liquid rate [m^3/s]
    df["PIP_Pa"] = df["PIP"] * PSI_TO_PA                 # intake pressure [Pa]
    df["PWF_Pa"] = df["PWF"] * PSI_TO_PA                 # flowing BHP [Pa]
    df["THP_Pa"] = df["THP"] * PSI_TO_PA                 # tubing-head pressure [Pa]
    df["Pm_Pa"] = df["Manifold_Troncal"] * PSI_TO_PA     # manifold pressure [Pa]
    df["Pr_Pa"] = df["Res_Press"] * PSI_TO_PA            # reservoir pressure [Pa]
    df["rho"] = df["Densidad"] * LBFT3_TO_KGM3           # density [kg/m^3]
    df["mu"] = df["Visosidad"] * CP_TO_PAS               # viscosity [Pa.s]
    df["BSW"] = df["BS&W"] / 100.0                       # water cut [fraction]

    # Sort chronologically and drop unusable rows
    df = df.sort_values("date").reset_index(drop=True)

    required = list(dict.fromkeys(feature_names + ["q", "PWF_Pa", "Pr_Pa", "THP_Pa", "PIP_Pa"]))
    if dropna:
        df = df.dropna(subset=required).reset_index(drop=True)

    X = df[feature_names].to_numpy(dtype=np.float64)
    y = df["q"].to_numpy(dtype=np.float64)
    dates = df["date"].to_numpy()

    # Quantities consumed by the steady-state physics residuals (all SI)
    phys = {
        "PIP_Pa": df["PIP_Pa"].to_numpy(dtype=np.float64),
        "THP_Pa": df["THP_Pa"].to_numpy(dtype=np.float64),
        "PWF_Pa": df["PWF_Pa"].to_numpy(dtype=np.float64),
        "Pr_Pa": df["Pr_Pa"].to_numpy(dtype=np.float64),
        "Pm_Pa": df["Pm_Pa"].to_numpy(dtype=np.float64),
        "f": df["Frec"].to_numpy(dtype=np.float64),
        "rho": df["rho"].to_numpy(dtype=np.float64),
        "mu": df["mu"].to_numpy(dtype=np.float64),
    }

    meta = {
        "n_rows": len(df),
        "date_min": str(df["date"].min().date()) if len(df) else None,
        "date_max": str(df["date"].max().date()) if len(df) else None,
        "q_bblpd_mean": float(df["BFPD"].mean()),
        "csv_path": csv_path,
    }

    return RealDataBundle(
        df=df, feature_names=feature_names, X=X, y=y, dates=dates,
        phys=phys, meta=meta,
    )


# --------------------------------------------------------------------------- #
#  Leakage-safe splits                                                         #
# --------------------------------------------------------------------------- #
def chronological_split(n, val_frac=0.2, cal_frac=0.0):
    """
    Chronological (no-shuffle) index split into train / [calibration] / val.

    The most recent ``val_frac`` samples form the held-out validation set so the
    evaluation mimics true forward-in-time deployment. An optional calibration
    block (taken from the end of the training portion) is reserved for
    split-conformal prediction intervals.

    Returns
    -------
    train_idx, cal_idx, val_idx : np.ndarray
        ``cal_idx`` is empty when ``cal_frac == 0``.
    """
    idx = np.arange(n)
    n_val = max(1, int(round(n * val_frac)))
    n_train_full = n - n_val
    n_cal = int(round(n * cal_frac))
    n_cal = min(n_cal, max(0, n_train_full - 1))

    train_idx = idx[: n_train_full - n_cal]
    cal_idx = idx[n_train_full - n_cal: n_train_full]
    val_idx = idx[n_train_full:]
    return train_idx, cal_idx, val_idx


def train_val_blind_split(n, train_frac=0.80, val_frac=0.15, blind_frac=0.05):
    """
    Chronological train / validation / blind-test index split.

    * train : oldest ``train_frac`` block, used for fitting and scaling.
    * val   : next ``val_frac`` block, used for model selection and
      split-conformal calibration.
    * blind : the most recent ``blind_frac`` block, NEVER touched during
      training, scaling or calibration -- only for the final report.

    Fractions must sum to 1; each block gets at least 1 sample.
    """
    if abs(train_frac + val_frac + blind_frac - 1.0) > 1e-9:
        raise ValueError("train_frac + val_frac + blind_frac must sum to 1")
    idx = np.arange(n)
    n_blind = max(1, int(round(n * blind_frac)))
    n_val = max(1, int(round(n * val_frac)))
    n_train = n - n_val - n_blind
    if n_train < 1:
        raise ValueError("split leaves no training samples")
    return (idx[:n_train],
            idx[n_train:n_train + n_val],
            idx[n_train + n_val:])


def blocked_cv_folds(n, n_folds=5):
    """
    Contiguous blocked K-fold indices (no shuffling).

    Each fold is a contiguous time block held out for validation while the rest
    is used for training. This respects temporal structure and avoids the
    look-ahead leakage that plain shuffled K-fold would introduce on a time
    series.

    Yields
    ------
    (train_idx, val_idx) : tuple of np.ndarray
    """
    idx = np.arange(n)
    bounds = np.linspace(0, n, n_folds + 1).astype(int)
    for k in range(n_folds):
        lo, hi = bounds[k], bounds[k + 1]
        val_idx = idx[lo:hi]
        train_idx = np.concatenate([idx[:lo], idx[hi:]])
        if len(val_idx) == 0 or len(train_idx) == 0:
            continue
        yield train_idx, val_idx


if __name__ == "__main__":
    import sys

    path = (
        sys.argv[1]
        if len(sys.argv) > 1
        else "Castilla_Real_Data/data_fluid_pressure_density_more.csv"
    )
    bundle = load_real_data(path)
    print("Meta:", bundle.meta)
    print("Features:", bundle.feature_names)
    print("X shape:", bundle.X.shape, "y shape:", bundle.y.shape)
    print("q [m^3/s] range:", bundle.y.min(), "->", bundle.y.max())
    print("q [bbl/d] range:",
          bundle.y.min() / BBLPD_TO_M3S, "->", bundle.y.max() / BBLPD_TO_M3S)
    tr, cal, va = chronological_split(bundle.meta["n_rows"], val_frac=0.2, cal_frac=0.15)
    print(f"split sizes -> train={len(tr)} cal={len(cal)} val={len(va)}")
