"""
Training pipeline for PINN-VFM.

Implements the two-stage training strategy from Franklin et al. (2022):
  Stage 1: Adam optimizer with uniform weights S0 = [1, 1, 1, 1]
  Stage 2: L-BFGS optimizer with tuned weights S1 = [1, 2, 1.9, 0.01]

Weight change from S0 to S1 occurs at a specified epoch (default: 1300).
L-BFGS requires full-batch training.

Reference: Section 4 of Franklin et al. (2022), Figs. 8-9.
"""

import torch
import torch.nn as nn
import numpy as np
import time
from copy import deepcopy


class PINNTrainer:
    """
    Trainer for PINN-VFM with Adam → L-BFGS scheduling.

    Parameters
    ----------
    model : PINNLSTM
        The neural network.
    loss_fn : PINNLoss
        PINN loss function.
    device : str
        'cuda' or 'cpu'.
    lr_adam : float
        Learning rate for Adam (default: 1e-3).
    adam_epochs : int
        Number of epochs with Adam before switching to L-BFGS (default: 300).
    weight_change_epoch : int
        Epoch at which to change from S0 to S1 weights (default: 1300).
    S0 : list
        Initial uniform weights [w_bc, w1, w2, w3].
    S1 : list
        Tuned weights after weight_change_epoch.
    total_epochs : int
        Total number of training epochs.
    """

    def __init__(self, model, loss_fn, device='cpu',
                 lr_adam=1e-3,
                 adam_epochs=300,
                 weight_change_epoch=1300,
                 S0=None, S1=None,
                 total_epochs=2000,
                 trainable_params=None,
                 param_refs=None):

        self.model = model.to(device)
        self.loss_fn = loss_fn
        self.device = device
        self.lr_adam = lr_adam
        self.adam_epochs = adam_epochs
        self.weight_change_epoch = weight_change_epoch
        self.S0 = S0 or [1.0, 1.0, 1.0, 1.0]
        self.S1 = S1 or [1.0, 2.0, 1.9, 0.01]
        self.total_epochs = total_epochs

        # Trainable parameters (for inverse problem)
        self.trainable_params = trainable_params or {}
        # Reference values for factor-parameterized params (name -> float)
        self.param_refs = param_refs or {}

        # Build optimizer parameter groups
        self._build_optimizers()

        # History tracking
        self.history = {
            'epoch': [],
            'train_loss': [],
            'val_loss': [],
            'L_bc': [],
            'L_y1': [],
            'L_y2': [],
            'L_y3': [],
            'optimizer': [],
            'weights': [],
        }
        # Track trainable parameters
        for name in self.trainable_params:
            self.history[f'param_{name}'] = []

    def _build_optimizers(self):
        """Build Adam and L-BFGS optimizers with all trainable parameters."""
        all_params = list(self.model.parameters())
        for name, param in self.trainable_params.items():
            all_params.append(param)

        self.optimizer_adam = torch.optim.Adam(all_params, lr=self.lr_adam)
        self.optimizer_lbfgs = torch.optim.LBFGS(
            all_params,
            lr=1.0,
            max_iter=20,
            history_size=50,
            tolerance_grad=1e-7,
            tolerance_change=1e-9,
            line_search_fn='strong_wolfe'
        )

    def _to_tensor(self, arr):
        """Convert numpy array to torch tensor on device."""
        return torch.tensor(arr, dtype=torch.float32, device=self.device)

    def train(self, X_train_consec, Y_train_anchor, u_train_consec,
              X_val, Y_val,
              X_train_single=None, Y_train_single=None,
              batch_size=64, print_every=50):
        """
        Execute the full training loop.

        Parameters
        ----------
        X_train_consec : ndarray, shape (n_train, n_consec, Nh, n_features)
            Consecutive windows for PINN residual computation.
        Y_train_anchor : ndarray, shape (n_train, 3)
            Targets for boundary condition loss.
        u_train_consec : ndarray, shape (n_train, n_consec, 4)
            Inputs for residual computation.
        X_val : ndarray, shape (n_val, Nh, n_features)
            Validation input sequences.
        Y_val : ndarray, shape (n_val, 3)
            Validation targets.
        X_train_single : ndarray, optional
            Single-step training inputs (for BC loss in Adam phase).
        Y_train_single : ndarray, optional
            Single-step training targets.
        batch_size : int
            Mini-batch size for Adam phase.
        print_every : int
            Print progress every N epochs.
        """
        # Convert to tensors
        X_tc = self._to_tensor(X_train_consec)
        Y_ta = self._to_tensor(Y_train_anchor)
        u_tc = self._to_tensor(u_train_consec)
        X_v = self._to_tensor(X_val)
        Y_v = self._to_tensor(Y_val)

        if X_train_single is not None:
            X_ts = self._to_tensor(X_train_single)
            Y_ts = self._to_tensor(Y_train_single)
        else:
            X_ts = X_tc[:, 0]  # Use first window of each consecutive block
            Y_ts = Y_ta

        n_train = len(X_tc)
        best_val_loss = float('inf')
        best_model_state = None

        # Set initial weights
        self.loss_fn.set_weights(self.S0)
        print(f"Training with S0={self.S0}, Adam optimizer")
        print(f"Will switch to L-BFGS at epoch {self.adam_epochs}")
        print(f"Will change weights to S1={self.S1} at epoch {self.weight_change_epoch}")
        print("=" * 80)

        t_start = time.time()

        for epoch in range(1, self.total_epochs + 1):
            # ---- Weight scheduling ----
            if epoch == self.weight_change_epoch:
                self.loss_fn.set_weights(self.S1)
                print(f"\n>>> Epoch {epoch}: Weights changed to S1={self.S1}")

            # ---- Optimizer selection ----
            use_lbfgs = epoch > self.adam_epochs

            if use_lbfgs:
                # L-BFGS: full-batch closure
                train_loss, loss_dict = self._lbfgs_step(
                    X_tc, Y_ta, u_tc, X_ts, Y_ts)
            else:
                # Adam: mini-batch
                train_loss, loss_dict = self._adam_step(
                    X_tc, Y_ta, u_tc, X_ts, Y_ts, batch_size)

            # ---- Validation ----
            val_loss = self._validate(X_v, Y_v)

            # ---- Track best model ----
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_model_state = deepcopy(self.model.state_dict())

            # ---- Record history ----
            self.history['epoch'].append(epoch)
            self.history['train_loss'].append(train_loss)
            self.history['val_loss'].append(val_loss)
            self.history['L_bc'].append(loss_dict.get('L_bc', 0))
            self.history['L_y1'].append(loss_dict.get('L_y1', 0))
            self.history['L_y2'].append(loss_dict.get('L_y2', 0))
            self.history['L_y3'].append(loss_dict.get('L_y3', 0))
            self.history['optimizer'].append('LBFGS' if use_lbfgs else 'Adam')
            self.history['weights'].append(
                self.S1 if epoch >= self.weight_change_epoch else self.S0)

            for name, param in self.trainable_params.items():
                self.history[f'param_{name}'].append(param.item())

            # ---- Print ----
            if epoch % print_every == 0 or epoch == 1:
                opt_name = 'LBFGS' if use_lbfgs else 'Adam'
                param_str = ""
                for name, param in self.trainable_params.items():
                    val = param.item()
                    ref = self.param_refs.get(name)
                    if ref is not None:
                        param_str += f"  {name}={val:.4f} ({name.replace('_factor','')}={ref*val:.4e})"
                    else:
                        param_str += f"  {name}={val:.6e}"
                elapsed = time.time() - t_start
                print(f"Epoch {epoch:5d}/{self.total_epochs} [{opt_name:5s}] "
                      f"train={train_loss:.6e}  val={val_loss:.6e}  "
                      f"bc={loss_dict.get('L_bc',0):.4e}  "
                      f"r1={loss_dict.get('L_y1',0):.4e}  "
                      f"r2={loss_dict.get('L_y2',0):.4e}  "
                      f"r3={loss_dict.get('L_y3',0):.4e}"
                      f"{param_str}  [{elapsed:.0f}s]")

        # Restore best model
        if best_model_state is not None:
            self.model.load_state_dict(best_model_state)
            print(f"\nRestored best model (val_loss={best_val_loss:.6e})")

        print(f"\nTraining complete in {time.time() - t_start:.1f}s")
        return self.history

    def _adam_step(self, X_tc, Y_ta, u_tc, X_ts, Y_ts, batch_size):
        """One Adam training step with mini-batching."""
        self.model.train()
        n = len(X_ts)
        indices = torch.randperm(n, device=self.device)

        total_loss = 0.0
        total_dict = {'L_bc': 0, 'L_y1': 0, 'L_y2': 0, 'L_y3': 0}
        n_batches = 0

        for start in range(0, n, batch_size):
            end = min(start + batch_size, n)
            idx = indices[start:end]

            self.optimizer_adam.zero_grad()

            # Single-step prediction for BC loss
            y_pred = self.model(X_ts[idx])

            # Consecutive windows for residual loss
            # Use subset of consecutive data
            idx_consec = idx[idx < len(X_tc)]
            if len(idx_consec) > 0:
                loss, loss_dict = self.loss_fn(
                    y_pred=y_pred,
                    y_true=Y_ts[idx],
                    model=self.model,
                    X_consecutive=X_tc[idx_consec],
                    u_consecutive=u_tc[idx_consec]
                )
            else:
                loss, loss_dict = self.loss_fn(y_pred=y_pred, y_true=Y_ts[idx])

            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer_adam.step()

            total_loss += loss.item()
            for key in total_dict:
                total_dict[key] += loss_dict.get(key, 0)
            n_batches += 1

        avg_loss = total_loss / max(n_batches, 1)
        for key in total_dict:
            total_dict[key] /= max(n_batches, 1)

        return avg_loss, total_dict

    def _lbfgs_step(self, X_tc, Y_ta, u_tc, X_ts, Y_ts):
        """One L-BFGS training step (full batch)."""
        self.model.train()

        loss_container = [None]
        dict_container = [None]

        def closure():
            self.optimizer_lbfgs.zero_grad()

            # Single-step predictions
            y_pred = self.model(X_ts)

            # Full loss with residuals
            loss, loss_dict = self.loss_fn(
                y_pred=y_pred,
                y_true=Y_ts,
                model=self.model,
                X_consecutive=X_tc,
                u_consecutive=u_tc
            )

            # NaN/Inf guard: prevent corrupting optimizer state
            if torch.isnan(loss) or torch.isinf(loss):
                self.optimizer_lbfgs.zero_grad()
                loss_container[0] = float('nan')
                dict_container[0] = loss_dict
                return torch.tensor(1e6, device=loss.device, requires_grad=True)

            loss.backward()

            # Gradient clipping (matches Adam step)
            torch.nn.utils.clip_grad_norm_(
                list(self.model.parameters()) + [p for p in self.trainable_params.values()],
                max_norm=1.0
            )

            loss_container[0] = loss.item()
            dict_container[0] = loss_dict
            return loss

        self.optimizer_lbfgs.step(closure)
        return loss_container[0], dict_container[0]

    def _validate(self, X_val, Y_val):
        """Compute validation loss (MSE on all states, no physics)."""
        self.model.eval()
        with torch.no_grad():
            y_pred = self.model(X_val)
            val_loss = torch.mean((y_pred - Y_val) ** 2).item()
        return val_loss
