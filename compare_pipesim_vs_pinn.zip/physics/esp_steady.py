"""
Steady-state ESP physics for the Castilla real-data VFM.

Why steady state?
-----------------
The Franklin (2022) reproduction (`esp_model.py`) integrates a 3-state ODE in
time and enforces the *dynamic* residuals dPbh/dt, dPwh/dt, dq/dt via numerical
time-derivatives. That requires a dense, uniformly-sampled transient. The real
Castilla data is ~82 irregular daily-average snapshots, so the well is observed
in quasi-steady operation: d/dt -> 0 and the ODE residuals collapse to two
*algebraic* balances that we can enforce point-wise:

  1. Inflow performance (IPR):
         q = PI * (Pr - Pwf)
     => R_ipr = q - PI * (Pr - Pwf)

  2. ESP energy / pump-curve balance (no choke; outflow boundary is the
     measured tubing-head pressure THP).  The pressure the pump must deliver to
     lift the column to surface is

         P_disch_required(q) = THP + rho*g*dh_lift + dP_friction(q)

     and the pressure the pump actually delivers from its (affinity-scaled)
     head curve is

         P_disch_pump(q,f) = PIP + rho*g*H(q,f)

     => R_pump = PIP + rho*g*H(q,f) - THP - rho*g*dh_lift - dP_friction(q)

The pump head curve H60(Q) is taken from the *real* ESP datasheet
(``esp_efficiency.csv``) instead of the synthetic polynomial, and corrected for
frequency with the affinity laws:

         H(q,f) = (f/f0)^2 * H60( q * f0/f )

All quantities are SI (Pa, m^3/s, kg/m^3, m). Residuals are returned in Pascals.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import torch
from dataclasses import dataclass

from real_data_loader import FT_TO_M, IN_TO_M, BBLPD_TO_M3S, G


# --------------------------------------------------------------------------- #
#  Well / ESP geometry (from the Castilla completion diagram & ESP datasheet)  #
# --------------------------------------------------------------------------- #
@dataclass
class ESPGeometry:
    """Geometry and reference constants for the Castilla ESP well (SI)."""
    f0: float = 60.0                              # ESP nominal frequency [Hz]
    dh_lift_m: float = 5799.0 * FT_TO_M           # intake TVD -> hydrostatic lift [m]
    L_disch_m: float = 6108.0 * FT_TO_M           # discharge tubing length [m]
    D_disch_m: float = 4.95 * IN_TO_M             # discharge tubing ID [m]

    @property
    def A_disch(self) -> float:
        """Discharge cross-sectional area [m^2]."""
        return np.pi * self.D_disch_m ** 2 / 4.0


DEFAULT_GEOMETRY = ESPGeometry()


# --------------------------------------------------------------------------- #
#  Differentiable pump-curve interpolation                                     #
# --------------------------------------------------------------------------- #
def _torch_interp1d(x, xp, fp):
    """
    Piecewise-linear, autograd-friendly 1-D interpolation (like ``np.interp``).

    ``xp`` must be sorted ascending. Values outside ``[xp[0], xp[-1]]`` are
    linearly extrapolated from the nearest segment so the physics residual stays
    differentiable even when the network briefly proposes an off-curve flow.

    Parameters
    ----------
    x  : torch.Tensor, any shape          - query points
    xp : torch.Tensor, shape (m,)         - sorted sample abscissae
    fp : torch.Tensor, shape (m,)         - sample ordinates

    Returns
    -------
    torch.Tensor, same shape as ``x``
    """
    x_flat = x.reshape(-1)
    # Index of the right end of the containing segment, clamped to interior.
    i = torch.searchsorted(xp, x_flat, right=True)
    i = torch.clamp(i, 1, xp.numel() - 1)
    x0, x1 = xp[i - 1], xp[i]
    y0, y1 = fp[i - 1], fp[i]
    slope = (y1 - y0) / (x1 - x0)
    out = y0 + slope * (x_flat - x0)
    return out.reshape(x.shape)


class ESPPumpCurve:
    """
    Real ESP head/efficiency curve loaded from the datasheet CSV.

    The CSV (``esp_efficiency.csv``) is given at the nominal frequency f0 with
    columns ``Flowrate Bbl/d``, ``head, ft``, ``Efi %``, ``Power , hp``.
    Internally everything is stored in SI (m^3/s and m of head) and exposed as
    differentiable torch operators.
    """

    def __init__(self, csv_path: str, geometry: ESPGeometry = None,
                 device: str = "cpu"):
        self.geom = geometry or DEFAULT_GEOMETRY
        self.device = device

        df = pd.read_csv(csv_path, sep=";")
        df.columns = [c.strip() for c in df.columns]

        q_bblpd = pd.to_numeric(df["Flowrate Bbl/d"], errors="coerce").to_numpy()
        head_ft = pd.to_numeric(df["head, ft"], errors="coerce").to_numpy()
        eff_pct = pd.to_numeric(df.filter(like="Efi").iloc[:, 0], errors="coerce").to_numpy()

        order = np.argsort(q_bblpd)
        self.q_m3s = q_bblpd[order] * BBLPD_TO_M3S       # [m^3/s]
        self.head_m = head_ft[order] * FT_TO_M           # [m]
        self.eff = eff_pct[order] / 100.0                # [fraction]

        self._q_t = torch.tensor(self.q_m3s, dtype=torch.float32, device=device)
        self._h_t = torch.tensor(self.head_m, dtype=torch.float32, device=device)
        self._e_t = torch.tensor(self.eff, dtype=torch.float32, device=device)

    # -- numpy helpers (for sanity checks / plotting) -- #
    def head60_np(self, q_m3s):
        """Datasheet head [m] at nominal frequency for flow ``q`` [m^3/s]."""
        return np.interp(q_m3s, self.q_m3s, self.head_m)

    def efficiency_np(self, q_m3s):
        return np.interp(q_m3s, self.q_m3s, self.eff)

    # -- differentiable head curve with affinity laws -- #
    def head(self, q, f):
        """
        Affinity-corrected ESP head [m].

        H(q,f) = (f/f0)^2 * H60( q * f0/f )

        Parameters
        ----------
        q : torch.Tensor   - liquid rate [m^3/s] (must be > 0)
        f : torch.Tensor   - ESP frequency [Hz]
        """
        dev = self._q_t.device
        if torch.is_tensor(q):
            out_dev = q.device
            q = q.to(dev)
        else:
            out_dev = dev
        if torch.is_tensor(f):
            f = f.to(dev)
        f0 = self.geom.f0
        ratio = f / f0
        ratio = torch.clamp(ratio, min=1e-3)
        q_equiv = q / ratio                       # flow referred to f0
        h60 = _torch_interp1d(q_equiv, self._q_t, self._h_t)
        return (ratio ** 2 * h60).to(out_dev)


# --------------------------------------------------------------------------- #
#  Friction (small but kept for completeness)                                  #
# --------------------------------------------------------------------------- #
def friction_dp(q, rho, mu, geom: ESPGeometry):
    """
    Darcy-Weisbach friction pressure drop in the discharge tubing [Pa].

    Uses a Blasius turbulent friction factor f_D = 0.316 * Re^-0.25.
    For this well friction is ~a few psi (hydrostatic lift dominates), but it is
    retained so the energy balance stays complete and differentiable.
    """
    A = geom.A_disch
    D = geom.D_disch_m
    q_abs = torch.clamp(torch.abs(q), min=1e-9)
    v = q_abs / A
    Re = torch.clamp(rho * v * D / torch.clamp(mu, min=1e-6), min=1.0)
    fD = 0.316 * Re ** (-0.25)
    dp = fD * (geom.L_disch_m / D) * 0.5 * rho * v ** 2
    return dp * torch.sign(q)


# --------------------------------------------------------------------------- #
#  Viscous-fluid head derating (heavy-oil ESP)                                 #
# --------------------------------------------------------------------------- #
def viscosity_head_correction(rho, mu, strength=0.0, nu_ref_cst=1.0,
                              exponent=0.5):
    """
    Differentiable ESP head-derating factor C_H in (0, 1] for viscous fluids.

    The datasheet head/efficiency curves are water-based, but Castilla is a
    heavy-oil well; per HI 9.6.7 / Turzo (2000) the delivered head derates with
    kinematic viscosity. A compact, smooth, monotone-decreasing surrogate:

        nu_cSt = (mu / rho) * 1e6                         # m^2/s -> cSt
        C_H    = 1 / (1 + strength * (nu_cSt / nu_ref_cst) ** exponent)

    ``strength = 0`` recovers the raw datasheet curve (C_H = 1). Differentiable
    for all nu > 0. Unlike the global ``k_head`` scalar this is viscosity- (hence
    sample-) dependent, so it removes the part of the datasheet mismatch that a
    single constant cannot represent.
    """
    nu_cst = torch.clamp(mu / torch.clamp(rho, min=1e-6), min=1e-12) * 1.0e6
    return 1.0 / (1.0 + strength * (nu_cst / nu_ref_cst) ** exponent)


# --------------------------------------------------------------------------- #
#  Steady-state residuals                                                      #
# --------------------------------------------------------------------------- #
def ipr_residual(q, Pr, Pwf, PI):
    """
    Inflow-performance residual [m^3/s].

        R_ipr = q - PI * (Pr - Pwf)

    ``PI`` is the (trainable) productivity index [m^3/s/Pa]. Comparable to the
    field ``IP`` column once converted (1 m^3/s/Pa = ... see evaluation).
    """
    return q - PI * (Pr - Pwf)


def pump_energy_residual(q, f, PIP, THP, rho, mu, pump: ESPPumpCurve,
                         geom: ESPGeometry = None, k_head=1.0, dp_offset=0.0,
                         visc_strength=0.0, visc_nu_ref_cst=1.0,
                         visc_exponent=0.5):
    """
    ESP energy-balance residual [Pa].

        R_pump = PIP + rho*g*(k_head*C_H*H(q,f)) + dp_offset
                 - THP - rho*g*dh_lift - dP_friction(q)

    A value of zero means the proposed operating point (q, head) lies exactly on
    the (calibrated) affinity-scaled datasheet pump curve, given the measured
    intake/outlet pressures.

    Calibration knobs
    -----------------
    k_head : float or torch.Tensor
        Global multiplicative head-scale (default 1.0 = raw datasheet curve).
        Absorbs stage wear / datasheet mismatch so the curve *level* matches the
        real well without biasing q; the curve *shape* (q-f coupling) is kept.
    dp_offset : float or torch.Tensor
        Global additive pressure offset [Pa] (default 0.0). Absorbs systematic
        error in dh_lift, gauge references, etc.
    visc_strength : float or torch.Tensor
        Strength of the viscous head-derating factor C_H (default 0.0 = off,
        i.e. water datasheet). See ``viscosity_head_correction``.

    With the defaults this reduces to the original uncalibrated balance.
    """
    geom = geom or pump.geom
    H = pump.head(q, f)                                   # [m]
    C_H = viscosity_head_correction(rho, mu, strength=visc_strength,
                                    nu_ref_cst=visc_nu_ref_cst,
                                    exponent=visc_exponent)
    dp_fric = friction_dp(q, rho, mu, geom)               # [Pa]
    P_disch_pump = PIP + rho * G * (k_head * C_H * H) + dp_offset
    P_disch_req = THP + rho * G * geom.dh_lift_m + dp_fric
    return P_disch_pump - P_disch_req


if __name__ == "__main__":
    # Quick physics sanity check on the real operating point.
    from real_data_loader import load_real_data, PSI_TO_PA

    bundle = load_real_data("Castilla_Real_Data/data_fluid_pressure_density_more.csv")
    pump = ESPPumpCurve("Castilla_Real_Data/esp_efficiency.csv")

    p = bundle.phys
    q_t = torch.tensor(bundle.y, dtype=torch.float32)
    f_t = torch.tensor(p["f"], dtype=torch.float32)
    PIP = torch.tensor(p["PIP_Pa"], dtype=torch.float32)
    THP = torch.tensor(p["THP_Pa"], dtype=torch.float32)
    rho = torch.tensor(p["rho"], dtype=torch.float32)
    mu = torch.tensor(p["mu"], dtype=torch.float32)
    Pr = torch.tensor(p["Pr_Pa"], dtype=torch.float32)
    Pwf = torch.tensor(p["PWF_Pa"], dtype=torch.float32)

    # Operating head from measurements vs datasheet head at the measured flow.
    H_meas = (THP + rho * G * DEFAULT_GEOMETRY.dh_lift_m - PIP) / (rho * G)
    H_curve = pump.head(q_t, f_t)
    print("measured operating head [ft] mean:", float(H_meas.mean()) / FT_TO_M)
    print("datasheet  head        [ft] mean:", float(H_curve.mean()) / FT_TO_M)

    Rp = pump_energy_residual(q_t, f_t, PIP, THP, rho, mu, pump)
    print("pump residual [psi] mean abs:", float(Rp.abs().mean()) / PSI_TO_PA)

    # Recover PI by least squares (closed form) for a baseline.
    dpr = (Pr - Pwf)
    PI_ls = float((q_t * dpr).sum() / (dpr * dpr).sum())
    print("PI (LS) [m^3/s/Pa]:", PI_ls)
    # IP column is bbl/d/psi; convert PI to compare.
    PI_field = PI_ls / BBLPD_TO_M3S * PSI_TO_PA
    print("PI (LS) [bbl/d/psi]:", PI_field, " | IP column mean:", float(bundle.df["IP"].mean()))
