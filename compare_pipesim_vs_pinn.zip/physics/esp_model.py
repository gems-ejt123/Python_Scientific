"""
ESP-lifted oil well system model.

Three-state ODE system from Binder et al. (2015) / Franklin et al. (2022), Eq. 11.
State vector: y = [Pbh, Pwh, q]
Exogenous inputs: u = [f, Zc, Pm, Pr]

Reference: Table 2 of Franklin et al. (2022) for parameter values.
"""

import numpy as np
from scipy.integrate import solve_ivp
from dataclasses import dataclass, field


@dataclass
class ESPParams:
    """Model parameters and constants from Table 2 (Binder et al. 2015)."""
    # Physical constants
    g: float = 9.81            # Gravitational acceleration [m/s²]

    # Well geometry
    A1: float = 0.008107       # Cross-section area below ESP [m²]
    A2: float = 0.008107       # Cross-section area above ESP [m²]
    D1: float = 0.1016         # Pipe diameter below ESP [m]
    D2: float = 0.1016         # Pipe diameter above ESP [m]
    hw: float = 1000.0         # Total vertical distance [m]
    L1: float = 500.0          # Length reservoir to ESP [m]
    L2: float = 1200.0         # Length ESP to choke [m]
    V1: float = 4.054          # Pipe volume below ESP [m³]
    V2: float = 9.729          # Pipe volume above ESP [m³]

    # Fluid and reservoir
    rho: float = 950.0         # Fluid density [kg/m³]
    Pr: float = 1.26e7         # Reservoir pressure [Pa]
    PI: float = 2.32e-9        # Productivity index [m³/s/Pa]
    mu: float = 0.025          # Viscosity [Pa·s]

    # ESP and valve
    f0: float = 60.0           # ESP reference frequency [Hz]
    Cc: float = 2e-5           # Choke valve constant
    b1: float = 1.5e9          # Bulk modulus below ESP [Pa]
    b2: float = 1.5e9          # Bulk modulus above ESP [Pa]
    M: float = 1.992e8         # Fluid inertia [kg/m⁴]


DEFAULT_PARAMS = ESPParams()


class ESPModel:
    """
    ESP-lifted oil well dynamic model.

    Implements the 3rd-order nonlinear ODE system (Eq. 11) with:
    - Inflow performance relationship (IPR)
    - Choke valve equation
    - Fanning friction correlations (F1, F2)
    - ESP head curve with viscosity correction and affinity laws
    """

    def __init__(self, params: ESPParams = None):
        self.p = params or ESPParams()

    # ------------------------------------------------------------------ #
    #  Algebraic sub-models                                               #
    # ------------------------------------------------------------------ #

    def inflow_rate(self, Pbh):
        """Reservoir inflow: qr = PI * (Pr - Pbh)."""
        return self.p.PI * (self.p.Pr - Pbh)

    def choke_flow(self, Pwh, Pm, Zc):
        """Choke valve flow: qch = Cc * (Zc/100) * sqrt(|Pwh - Pm|)."""
        return self.p.Cc * (Zc / 100.0) * np.sqrt(np.abs(Pwh - Pm))

    def friction_below_esp(self, q):
        """Fanning friction below ESP (F1)."""
        q_safe = np.maximum(np.abs(q), 1e-10)
        p = self.p
        Re_term = (p.mu / (p.rho * p.D1 * q_safe)) ** 0.25
        F1 = 0.158 * (p.rho * p.L1 * q_safe**2) / (p.D1 * p.A1**2) * Re_term
        return F1 * np.sign(q)

    def friction_above_esp(self, q):
        """Fanning friction above ESP (F2)."""
        q_safe = np.maximum(np.abs(q), 1e-10)
        p = self.p
        Re_term = (p.mu / (p.rho * p.D2 * q_safe)) ** 0.25
        F2 = 0.158 * (p.rho * p.L2 * q_safe**2) / (p.D2 * p.A2**2) * Re_term
        return F2 * np.sign(q)

    def esp_head(self, f, q):
        """
        ESP head with viscosity correction and affinity laws.

        H = CH * H0(q0) * (f/f0)²
        where q0 = q / (Cq * f/f0)
        """
        p = self.p
        mu = p.mu

        # Viscosity correction factors
        Cq = 2.7944*mu**4 - 6.8104*mu**3 + 6.0032*mu**2 - 2.6266*mu + 1.0
        CH = -0.03 * mu + 1.0

        # Affinity-law corrected flow
        freq_ratio = f / p.f0
        freq_ratio_safe = np.maximum(np.abs(freq_ratio), 1e-10)
        q0 = q / (Cq * freq_ratio_safe)

        # Head at reference frequency (polynomial)
        H0 = -1.2454e6 * q0**2 + 7.4959e3 * q0 + 9.5970e2

        # Total head
        H = CH * H0 * freq_ratio**2
        return H

    # ------------------------------------------------------------------ #
    #  ODE right-hand side                                                #
    # ------------------------------------------------------------------ #

    def rhs(self, y, u):
        """
        Right-hand side of the ODE system (Eq. 11).

        Parameters
        ----------
        y : array_like, shape (3,)
            State vector [Pbh, Pwh, q].
        u : array_like, shape (4,)
            Exogenous inputs [f, Zc, Pm, Pr].

        Returns
        -------
        dydt : ndarray, shape (3,)
            Time derivatives [dPbh/dt, dPwh/dt, dq/dt].
        """
        Pbh, Pwh, q = y
        f, Zc, Pm, Pr = u
        p = self.p

        # Temporarily override Pr if provided as input
        Pr_eff = Pr

        # Flow rates
        qr = p.PI * (Pr_eff - Pbh)
        qch = p.Cc * (Zc / 100.0) * np.sqrt(np.abs(Pwh - Pm))

        # Friction
        F1 = self.friction_below_esp(q)
        F2 = self.friction_above_esp(q)

        # ESP head
        H = self.esp_head(f, q)

        # State derivatives (Eq. 11)
        dPbh_dt = (p.b1 / p.V1) * (qr - q)
        dPwh_dt = (p.b2 / p.V2) * (q - qch)
        dq_dt = (1.0 / p.M) * (Pbh - Pwh - p.rho * p.g * p.hw
                                 - F1 - F2 + p.rho * p.g * H)

        return np.array([dPbh_dt, dPwh_dt, dq_dt])

    def rhs_for_solver(self, t, y, u_func):
        """Wrapper for scipy solve_ivp (interpolates u at time t)."""
        u = u_func(t)
        return self.rhs(y, u)

    # ------------------------------------------------------------------ #
    #  Simulation                                                         #
    # ------------------------------------------------------------------ #

    def simulate(self, y0, t_span, t_eval, u_func, method='Radau', **kwargs):
        """
        Simulate the ESP model over a time interval.

        Parameters
        ----------
        y0 : array_like, shape (3,)
            Initial state [Pbh0, Pwh0, q0].
        t_span : tuple
            (t_start, t_end).
        t_eval : array_like
            Times at which to store the solution.
        u_func : callable
            Function u_func(t) -> [f, Zc, Pm, Pr] at time t.
        method : str
            ODE solver method ('Radau' recommended for stiff system).

        Returns
        -------
        sol : OdeResult
            Solution object with .t and .y attributes.
        """
        sol = solve_ivp(
            fun=lambda t, y: self.rhs_for_solver(t, y, u_func),
            t_span=t_span,
            y0=y0,
            t_eval=t_eval,
            method=method,
            rtol=1e-8,
            atol=1e-10,
            **kwargs
        )
        return sol

    def compute_steady_state(self, u, y0_guess=None, tol=1e-6, max_iter=5000):
        """
        Find steady-state by long simulation until derivatives are small.

        Parameters
        ----------
        u : array_like, shape (4,)
            Constant exogenous inputs [f, Zc, Pm, Pr].
        y0_guess : array_like, optional
            Initial guess for states. If None, uses heuristic.

        Returns
        -------
        y_ss : ndarray, shape (3,)
            Steady-state [Pbh, Pwh, q].
        """
        if y0_guess is None:
            # Heuristic: Pbh ~ Pr, Pwh ~ Pm, q ~ small positive
            y0_guess = np.array([self.p.Pr * 0.9, self.p.Pr * 0.3, 0.01])

        u_const = lambda t: u
        t_end = 500.0  # long enough for transients to die out
        sol = self.simulate(
            y0=y0_guess,
            t_span=(0, t_end),
            t_eval=np.linspace(0, t_end, max_iter),
            u_func=u_const,
            method='Radau'
        )

        return sol.y[:, -1]
