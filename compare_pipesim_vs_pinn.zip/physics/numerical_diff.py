"""
Numerical differentiation for PINN residual computation.

Since the LSTM inputs are not (t, x) directly, automatic differentiation cannot
compute the time derivatives of the outputs. Instead, numerical differentiation
is applied to the network output sequence (Section 2, Remark 1).

Three-point schemes are used:
  - Progressive (forward) 3-point for the first point
  - Central 2-point for interior points
  - Regressive (backward) 3-point for the last point

Reference: Franklin et al. (2022), Eq. 8 and surrounding discussion.
"""

import torch


def numerical_derivative(y_seq, dt=1.0):
    """
    Compute first-order numerical derivatives of a sequence using
    progressive, central, and regressive finite differences.

    Parameters
    ----------
    y_seq : torch.Tensor, shape (batch, seq_len, n_states)
        Sequence of predicted states from multiple consecutive forward passes.
    dt : float
        Time step between consecutive predictions.

    Returns
    -------
    dy_dt : torch.Tensor, shape (batch, seq_len, n_states)
        Numerical derivatives at each point in the sequence.
    """
    batch, seq_len, n_states = y_seq.shape
    dy_dt = torch.zeros_like(y_seq)

    if seq_len < 3:
        # Fallback to simple forward difference if sequence is too short
        if seq_len == 2:
            dy_dt[:, 0] = (y_seq[:, 1] - y_seq[:, 0]) / dt
            dy_dt[:, 1] = (y_seq[:, 1] - y_seq[:, 0]) / dt
        return dy_dt

    # Progressive 3-point (forward difference) for first point:
    # dy/dt ≈ (-3*y[0] + 4*y[1] - y[2]) / (2*dt)
    dy_dt[:, 0] = (-3.0 * y_seq[:, 0] + 4.0 * y_seq[:, 1] - y_seq[:, 2]) / (2.0 * dt)

    # Central 2-point for interior points:
    # dy/dt ≈ (y[i+1] - y[i-1]) / (2*dt)
    for i in range(1, seq_len - 1):
        dy_dt[:, i] = (y_seq[:, i + 1] - y_seq[:, i - 1]) / (2.0 * dt)

    # Regressive 3-point (backward difference) for last point:
    # dy/dt ≈ (3*y[-1] - 4*y[-2] + y[-3]) / (2*dt)
    dy_dt[:, -1] = (3.0 * y_seq[:, -1] - 4.0 * y_seq[:, -2] + y_seq[:, -3]) / (2.0 * dt)

    return dy_dt


def compute_ode_residuals(dy_dt, y_pred, u, model_params, scaler_tensors, dt=1.0):
    """
    Compute ODE residuals in physical (denormalized) space.

    residual = dy/dt - F(y, u)

    where F is the right-hand side of Eq. 11.

    Parameters
    ----------
    dy_dt : torch.Tensor, shape (batch, seq_len, 3)
        Numerical derivatives in normalized space.
    y_pred : torch.Tensor, shape (batch, seq_len, 3)
        Predicted states in normalized space.
    u : torch.Tensor, shape (batch, seq_len, 4)
        Exogenous inputs in normalized space.
    model_params : dict
        ESP model parameters (as torch tensors, possibly trainable).
    scaler_tensors : dict
        Scaling factors from ESPScaler.to_torch().
    dt : float
        Sampling time [s].

    Returns
    -------
    residuals : torch.Tensor, shape (batch, seq_len, 3)
        ODE residuals [r1, r2, r3] for the three equations.
    """
    # Denormalize to physical space
    y_range = scaler_tensors['y_range']
    y_min = scaler_tensors['y_min']
    u_range = scaler_tensors['u_range']
    u_min = scaler_tensors['u_min']

    y_phys = y_pred * y_range.unsqueeze(0).unsqueeze(0) + y_min.unsqueeze(0).unsqueeze(0)
    u_phys = u * u_range.unsqueeze(0).unsqueeze(0) + u_min.unsqueeze(0).unsqueeze(0)

    # Convert numerical derivative from normalized to physical:
    # d(y_phys)/dt = y_range * d(y_norm)/dt / dt_norm
    # Since we compute dy_dt already with dt in physical seconds,
    # and y_norm = (y_phys - y_min)/y_range,
    # then dy_phys/dt = y_range * dy_norm/dt
    dy_dt_phys = dy_dt * y_range.unsqueeze(0).unsqueeze(0) / dt

    # Extract physical variables
    Pbh = y_phys[:, :, 0]
    Pwh = y_phys[:, :, 1]
    q = y_phys[:, :, 2]

    f_esp = u_phys[:, :, 0]
    Zc = u_phys[:, :, 1]
    Pm = u_phys[:, :, 2]
    Pr = u_phys[:, :, 3]

    # Model parameters (some may be trainable)
    # Support factor-parameterization: PI = PI_ref * PI_factor, rho = rho_ref * rho_factor
    p = model_params
    g = p['g']
    rho = p['rho_ref'] * p['rho_factor'] if 'rho_factor' in p else p['rho']
    PI = p['PI_ref'] * p['PI_factor'] if 'PI_factor' in p else p['PI']
    mu = p['mu']
    b1 = p['b1']; V1 = p['V1']
    b2 = p['b2']; V2 = p['V2']
    M = p['M']; hw = p['hw']
    Cc = p['Cc']
    D1 = p['D1']; D2 = p['D2']
    A1 = p['A1']; A2 = p['A2']
    L1 = p['L1']; L2 = p['L2']
    f0 = p['f0']

    # ---- Algebraic equations ----

    # Inflow
    qr = PI * (Pr - Pbh)

    # Choke flow
    qch = Cc * (Zc / 100.0) * torch.sqrt(torch.abs(Pwh - Pm) + 1e-10)

    # Friction
    q_safe = torch.clamp(torch.abs(q), min=1e-10)
    F1 = 0.158 * (rho * L1 * q_safe**2) / (D1 * A1**2) * (mu / (rho * D1 * q_safe))**0.25
    F1 = F1 * torch.sign(q)
    F2 = 0.158 * (rho * L2 * q_safe**2) / (D2 * A2**2) * (mu / (rho * D2 * q_safe))**0.25
    F2 = F2 * torch.sign(q)

    # ESP head with viscosity correction
    Cq = 2.7944*mu**4 - 6.8104*mu**3 + 6.0032*mu**2 - 2.6266*mu + 1.0
    CH = -0.03 * mu + 1.0
    freq_ratio = f_esp / f0
    freq_safe = torch.clamp(torch.abs(freq_ratio), min=1e-10)
    q0 = q / (Cq * freq_safe)
    H0 = -1.2454e6 * q0**2 + 7.4959e3 * q0 + 9.5970e2
    H = CH * H0 * freq_ratio**2

    # ---- ODE right-hand side (Eq. 11) ----
    F_Pbh = (b1 / V1) * (qr - q)
    F_Pwh = (b2 / V2) * (q - qch)
    F_q = (1.0 / M) * (Pbh - Pwh - rho * g * hw - F1 - F2 + rho * g * H)

    # ---- Residuals: dy/dt - F(y,u) ----
    r1 = dy_dt_phys[:, :, 0] - F_Pbh
    r2 = dy_dt_phys[:, :, 1] - F_Pwh
    r3 = dy_dt_phys[:, :, 2] - F_q

    residuals = torch.stack([r1, r2, r3], dim=-1)
    return residuals
