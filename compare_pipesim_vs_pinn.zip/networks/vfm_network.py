"""
Steady-state VFM network for the Castilla ESP well.

The dynamic LSTM (`network.py`, Franklin 2022) needs a dense transient sequence.
For ~82 sparse daily snapshots a small, fully-differentiable MLP is the right
tool, and it keeps the architecture compatible with PDE/algebraic-residual
autograd. Design rules follow the PINN skill:

  * tanh / swish hidden activations only (infinitely differentiable) - never ReLU
  * a scaled skip (residual) connection to preserve the physical signal
  * optional Fourier feature encoding for sharper input sensitivity
  * identity output head + Softplus so the predicted liquid rate is strictly > 0
    (a soft physical bound, applied in normalized space then de-scaled)

The network predicts the single VFM target q (liquid rate). Inputs are expected
pre-normalized to roughly [-1, 1] (see `MinMaxScaler` in `vfm_trainer.py`).
"""

from __future__ import annotations

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class FourierFeatures(nn.Module):
    """
    Random Fourier feature encoding: x -> [x, sin(Bx), cos(Bx)].

    Helps the MLP resolve sharper input-output sensitivity on a tiny dataset.
    ``B`` is fixed (not trained) so the encoding stays a deterministic basis.
    """

    def __init__(self, in_dim, n_frequencies=8, scale=1.0, seed=0):
        super().__init__()
        g = torch.Generator().manual_seed(seed)
        B = torch.randn(in_dim, n_frequencies, generator=g) * scale
        self.register_buffer("B", B)
        self.out_dim = in_dim + 2 * n_frequencies

    def forward(self, x):
        proj = 2.0 * math.pi * x @ self.B
        return torch.cat([x, torch.sin(proj), torch.cos(proj)], dim=-1)


def _activation(name: str):
    name = name.lower()
    if name == "tanh":
        return nn.Tanh()
    if name in ("swish", "silu"):
        return nn.SiLU()
    if name == "gelu":
        return nn.GELU()
    if name == "mish":
        return nn.Mish()
    if name == "softplus":
        return nn.Softplus()
    raise ValueError(
        f"Unsupported physics activation '{name}'. "
        "Use one of: tanh, swish/silu, gelu, mish (all smooth / C^inf). "
        "Avoid ReLU (no 2nd derivative) and periodic sine/Snake (oscillate "
        "outside the training range -> poor extrapolation)."
    )


class VFMNet(nn.Module):
    """
    Small physics-informed MLP regressor for steady-state VFM.

    Parameters
    ----------
    n_features : int
        Number of (normalized) input features.
    hidden : int
        Hidden width.
    n_layers : int
        Number of hidden layers.
    activation : str
        'tanh' or 'swish' (no ReLU - second derivatives must exist).
    skip_scale : float
        Weight of the input->pre-output skip connection (0.1-0.2 recommended).
    use_fourier : bool
        Enable random Fourier feature encoding of the inputs.
    n_frequencies : int
        Number of Fourier frequencies when ``use_fourier`` is True.
    positive_output : bool
        Apply Softplus so the (normalized) output is strictly positive.
    dropout : float
        Optional dropout for ensemble diversity / mild regularization.
    """

    def __init__(self, n_features, hidden=32, n_layers=3, activation="tanh",
                 skip_scale=0.1, use_fourier=False, n_frequencies=8,
                 positive_output=True, dropout=0.0):
        super().__init__()
        self.positive_output = positive_output
        self.skip_scale = skip_scale

        if use_fourier:
            self.encoder = FourierFeatures(n_features, n_frequencies)
            enc_dim = self.encoder.out_dim
        else:
            self.encoder = None
            enc_dim = n_features

        act = activation
        layers = []
        prev = enc_dim
        for _ in range(n_layers):
            layers.append(nn.Linear(prev, hidden))
            layers.append(nn.LayerNorm(hidden))   # stable under heterogeneous physics grads
            layers.append(_activation(act))
            if dropout > 0:
                layers.append(nn.Dropout(dropout))
            prev = hidden
        self.backbone = nn.Sequential(*layers)

        # Scaled skip from encoded inputs straight to the pre-output features.
        self.skip = nn.Linear(enc_dim, hidden)
        self.head = nn.Linear(hidden, 1)         # identity head (linear)

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight, gain=1.0)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x):
        """
        Parameters
        ----------
        x : torch.Tensor, shape (batch, n_features)
            Normalized inputs.

        Returns
        -------
        q_norm : torch.Tensor, shape (batch, 1)
            Predicted target in normalized space (strictly positive when
            ``positive_output`` is True).
        """
        h = self.encoder(x) if self.encoder is not None else x
        feat = self.backbone(h) + self.skip_scale * self.skip(h)
        out = self.head(feat)
        if self.positive_output:
            out = F.softplus(out)
        return out


def make_ensemble(n_models, seed0=0, **kwargs):
    """
    Build a deep ensemble of ``VFMNet`` with distinct random seeds.

    A deep ensemble is the most robust way to get both a strong point estimate
    and an epistemic-uncertainty signal on a tiny (~80-row) dataset.

    Returns
    -------
    list[VFMNet]
    """
    models = []
    for i in range(n_models):
        torch.manual_seed(seed0 + i)
        models.append(VFMNet(**kwargs))
    return models
