"""
PINN-oriented LSTM architecture for ESP-lifted oil well VFM.

Architecture from Figure 6 of Franklin et al. (2022):
  - Two stacked LSTM layers with Ncells cells each
  - Sequence-to-one (many-to-one) architecture
  - Input: historical sequence [yr(k-Nh:k-1), u(k-Nh:k-1)]
  - Output: predicted states [Pbh(k), Pwh(k), q(k)]

The repeat-vector and time-distributed layers from the paper are implemented
as standard PyTorch operations.
"""

import torch
import torch.nn as nn


class PINNLSTM(nn.Module):
    """
    PINN-oriented LSTM for ESP Virtual Flow Metering.

    Parameters
    ----------
    n_features : int
        Number of input features per timestep (default: 6 = 2 states + 4 inputs).
    n_states : int
        Number of output states (default: 3 = Pbh, Pwh, q).
    n_cells : int
        Number of LSTM cells per layer (default: 15, optimal from paper).
    n_layers : int
        Number of stacked LSTM layers (default: 2).
    dropout : float
        Dropout between LSTM layers (default: 0.0).
    """

    def __init__(self, n_features=6, n_states=3, n_cells=15, n_layers=2, dropout=0.0):
        super().__init__()

        self.n_features = n_features
        self.n_states = n_states
        self.n_cells = n_cells
        self.n_layers = n_layers

        # Stacked LSTM layers (Fig. 6b: two layers with Ncells LSTM cells each)
        self.lstm = nn.LSTM(
            input_size=n_features,
            hidden_size=n_cells,
            num_layers=n_layers,
            batch_first=True,
            dropout=dropout if n_layers > 1 else 0.0
        )

        # Time-distributed dense output layer
        # Maps from LSTM hidden state to predicted states
        self.output_layer = nn.Linear(n_cells, n_states)

    def forward(self, x):
        """
        Forward pass: sequence-to-one prediction.

        Parameters
        ----------
        x : torch.Tensor, shape (batch, Nh, n_features)
            Input sequences of historical [yr, u] data.

        Returns
        -------
        y_hat : torch.Tensor, shape (batch, n_states)
            Predicted states at the next timestep.
        """
        # LSTM forward pass
        # lstm_out: (batch, Nh, n_cells)
        # (h_n, c_n): final hidden and cell states
        lstm_out, (h_n, c_n) = self.lstm(x)

        # Sequence-to-one: use only the last timestep output
        last_output = lstm_out[:, -1, :]  # (batch, n_cells)

        # Dense output
        y_hat = self.output_layer(last_output)  # (batch, n_states)

        return y_hat

    def predict_sequence(self, x_sequences):
        """
        Predict a sequence of outputs from consecutive input windows.

        This is needed for computing numerical derivatives of the output
        for the PINN loss.

        Parameters
        ----------
        x_sequences : torch.Tensor, shape (batch, n_consecutive, Nh, n_features)
            Consecutive overlapping input windows.

        Returns
        -------
        y_seq : torch.Tensor, shape (batch, n_consecutive, n_states)
            Predicted states at each consecutive timestep.
        """
        batch, n_cons, Nh, n_feat = x_sequences.shape

        # Reshape to process all windows at once
        x_flat = x_sequences.reshape(batch * n_cons, Nh, n_feat)
        y_flat = self.forward(x_flat)  # (batch * n_cons, n_states)

        # Reshape back
        y_seq = y_flat.reshape(batch, n_cons, self.n_states)
        return y_seq


class PureLSTM(nn.Module):
    """
    Pure data-driven LSTM baseline (Architecture A).

    Same structure as PINNLSTM but only predicts q (flow rate).
    No physics regularization.
    """

    def __init__(self, n_features=6, n_cells=15, n_layers=2, dropout=0.0):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=n_features,
            hidden_size=n_cells,
            num_layers=n_layers,
            batch_first=True,
            dropout=dropout if n_layers > 1 else 0.0
        )
        self.output_layer = nn.Linear(n_cells, 1)  # Single output: q

    def forward(self, x):
        lstm_out, _ = self.lstm(x)
        last_output = lstm_out[:, -1, :]
        q_hat = self.output_layer(last_output)
        return q_hat
