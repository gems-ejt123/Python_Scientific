"""
PINN loss function for ESP-VFM.

Implements the weighted multi-objective loss from Eq. 12:
  L(θ, λ) = w_bc * L_bc + w1 * L_y1 + w2 * L_y2 + w3 * L_y3

where:
  - L_bc: boundary condition loss (MSE of predicted vs. observed Pbh, Pwh)
  - L_y1: residual of dPbh/dt ODE
  - L_y2: residual of dPwh/dt ODE
  - L_y3: residual of dq/dt ODE

The loss weights transition from S0=[1,1,1,1] to S1=[1,2,1.9,0.01]
during training to balance the multi-scale residuals.

Reference: Franklin et al. (2022), Eqs. 9-12 and Section 4.
"""

import torch
import torch.nn as nn
from numerical_diff import numerical_derivative, compute_ode_residuals


class PINNLoss(nn.Module):
    """
    Physics-Informed loss function for ESP-VFM.

    Parameters
    ----------
    esp_params : dict
        ESP model parameters as torch tensors. Keys: 'g', 'rho', 'PI', 'mu',
        'b1', 'b2', 'V1', 'V2', 'M', 'hw', 'Cc', 'D1', 'D2', 'A1', 'A2',
        'L1', 'L2', 'f0'. Some may require_grad for inverse problem.
    scaler_tensors : dict
        Scaling factors from ESPScaler.to_torch().
    weights : list of 4 floats
        [w_bc, w1, w2, w3] - loss term weights.
    dt : float
        Sampling time [s].
    n_residual_points : int
        Number of consecutive predictions for numerical differentiation.
    """

    def __init__(self, esp_params, scaler_tensors, weights=None, dt=1.0,
                 n_residual_points=5):
        super().__init__()

        self.esp_params = esp_params
        self.scaler_tensors = scaler_tensors
        self.dt = dt
        self.n_residual_points = n_residual_points

        # Default uniform weights (S0)
        if weights is None:
            weights = [1.0, 1.0, 1.0, 1.0]
        self.set_weights(weights)

    def set_weights(self, weights):
        """Update loss weights [w_bc, w1, w2, w3]."""
        self.w_bc = weights[0]
        self.w1 = weights[1]
        self.w2 = weights[2]
        self.w3 = weights[3]

    def boundary_condition_loss(self, y_pred, y_true):
        """
        Boundary condition loss (Eq. 10, second part).

        L_bc = (1/Ns) * sum( (y_hat_r - y_r)^2 )

        Only uses measured states (Pbh, Pwh), not q.

        Parameters
        ----------
        y_pred : torch.Tensor, shape (batch, 3)
            Predicted [Pbh, Pwh, q] in normalized space.
        y_true : torch.Tensor, shape (batch, 3)
            True [Pbh, Pwh, q] in normalized space.

        Returns
        -------
        loss : torch.Tensor
            MSE of measured states only.
        """
        # Only use first 2 states (Pbh, Pwh) — q is not measured
        return torch.mean((y_pred[:, :2] - y_true[:, :2]) ** 2)

    def residual_loss(self, model, X_batch, u_batch):
        """
        Compute ODE residual losses from consecutive predictions.

        For each sample in the batch, we need n_residual_points consecutive
        predictions to compute numerical derivatives.

        Parameters
        ----------
        model : PINNLSTM
            The neural network model.
        X_batch : torch.Tensor, shape (batch, n_consecutive, Nh, n_features)
            Consecutive overlapping input windows.
        u_batch : torch.Tensor, shape (batch, n_consecutive, 4)
            Exogenous inputs at each consecutive prediction point (normalized).

        Returns
        -------
        L_y1, L_y2, L_y3 : torch.Tensor
            Mean squared residuals for each ODE equation.
        """
        # Get consecutive predictions
        y_seq = model.predict_sequence(X_batch)  # (batch, n_cons, 3)

        # Numerical derivatives in normalized space
        dy_dt_norm = numerical_derivative(y_seq, dt=1.0)  # dt=1 in index space

        # Compute ODE residuals
        residuals = compute_ode_residuals(
            dy_dt=dy_dt_norm,
            y_pred=y_seq,
            u=u_batch,
            model_params=self.esp_params,
            scaler_tensors=self.scaler_tensors,
            dt=self.dt
        )

        # Normalize residuals by characteristic scales to balance
        scales = self.scaler_tensors['y_range']
        residuals_scaled = residuals / (scales.unsqueeze(0).unsqueeze(0) + 1e-10)

        # Mean squared residual for each ODE (Eq. 10, first part)
        L_y1 = torch.mean(residuals_scaled[:, :, 0] ** 2)
        L_y2 = torch.mean(residuals_scaled[:, :, 1] ** 2)
        L_y3 = torch.mean(residuals_scaled[:, :, 2] ** 2)

        return L_y1, L_y2, L_y3

    def forward(self, y_pred, y_true, model=None, X_consecutive=None,
                u_consecutive=None):
        """
        Compute total PINN loss (Eq. 12).

        Parameters
        ----------
        y_pred : torch.Tensor, shape (batch, 3)
            Single-step predictions (normalized).
        y_true : torch.Tensor, shape (batch, 3)
            True states (normalized).
        model : PINNLSTM, optional
            Required for residual computation.
        X_consecutive : torch.Tensor, optional
            Consecutive input windows for residuals.
        u_consecutive : torch.Tensor, optional
            Consecutive input values for residuals.

        Returns
        -------
        total_loss : torch.Tensor
        loss_dict : dict
            Individual loss components for monitoring.
        """
        # Boundary condition loss (always computed)
        L_bc = self.boundary_condition_loss(y_pred, y_true)

        loss_dict = {'L_bc': L_bc.item()}

        if model is not None and X_consecutive is not None and u_consecutive is not None:
            # Compute ODE residual losses
            L_y1, L_y2, L_y3 = self.residual_loss(model, X_consecutive, u_consecutive)

            # Total loss (Eq. 12)
            total_loss = (self.w_bc * L_bc +
                          self.w1 * L_y1 +
                          self.w2 * L_y2 +
                          self.w3 * L_y3)

            loss_dict.update({
                'L_y1': L_y1.item(),
                'L_y2': L_y2.item(),
                'L_y3': L_y3.item(),
                'total': total_loss.item()
            })
        else:
            # Data-only loss (no physics) — used for validation
            total_loss = self.w_bc * L_bc
            loss_dict['total'] = total_loss.item()

        return total_loss, loss_dict


def build_consecutive_windows(X_all, Y_all, u_all_norm, Nh, n_consecutive=5):
    """
    Build overlapping consecutive windows for PINN residual computation.

    For each anchor index k, we need X(k), X(k+1), ..., X(k+n_consecutive-1)
    to produce a sequence of predictions that can be numerically differentiated.

    Parameters
    ----------
    X_all : ndarray, shape (n_sequences, Nh, n_features)
        All input sequences (normalized).
    Y_all : ndarray, shape (n_sequences, 3)
        All target outputs (normalized).
    u_all_norm : ndarray, shape (n_total_samples, 4)
        All normalized exogenous inputs.
    Nh : int
        History window length.
    n_consecutive : int
        Number of consecutive predictions for numerical differentiation.

    Returns
    -------
    X_consec : ndarray, shape (n_valid, n_consecutive, Nh, n_features)
    Y_anchor : ndarray, shape (n_valid, 3)
        Target at the first point of each consecutive window.
    u_consec : ndarray, shape (n_valid, n_consecutive, 4)
        Exogenous inputs at each prediction point.
    """
    import numpy as np

    n_seq = len(X_all)
    n_valid = n_seq - n_consecutive + 1

    if n_valid <= 0:
        raise ValueError(f"Not enough sequences ({n_seq}) for {n_consecutive} consecutive windows")

    n_features = X_all.shape[2]
    X_consec = np.zeros((n_valid, n_consecutive, Nh, n_features))
    Y_anchor = np.zeros((n_valid, 3))
    u_consec = np.zeros((n_valid, n_consecutive, 4))

    for i in range(n_valid):
        for j in range(n_consecutive):
            X_consec[i, j] = X_all[i + j]
            # Extract u from the last timestep of each window
            # (the prediction point's inputs)
            u_consec[i, j] = X_all[i + j, -1, 2:6]  # last 4 features are u
        Y_anchor[i] = Y_all[i]

    return X_consec, Y_anchor, u_consec
