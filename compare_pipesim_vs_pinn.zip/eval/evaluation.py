"""
Evaluation, metrics, and plotting for PINN-VFM.

Reproduces the visualization style of Figs. 8-15 from Franklin et al. (2022):
  - Training/validation loss curves (Fig. 8)
  - Loss term evolution and weight influence (Fig. 9)
  - State predictions vs. true values (Figs. 10, 13)
  - Parameter tracking convergence (Figs. 11, 14)
  - Out-of-distribution test predictions (Figs. 12, 15)
"""

import numpy as np
import torch
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams.update({'font.size': 10, 'figure.dpi': 120})


def evaluate_model(model, X, Y, scaler, device='cpu'):
    """
    Evaluate model predictions and compute metrics.

    Parameters
    ----------
    model : PINNLSTM
        Trained model.
    X : ndarray, shape (n_sequences, Nh, n_features)
        Input sequences (normalized).
    Y : ndarray, shape (n_sequences, 3)
        True outputs (normalized).
    scaler : ESPScaler
        For denormalization.
    device : str

    Returns
    -------
    metrics : dict
        MSE for each state and overall.
    y_pred_phys : ndarray
        Predictions in physical units.
    y_true_phys : ndarray
        True values in physical units.
    """
    model.eval()
    X_t = torch.tensor(X, dtype=torch.float32, device=device)

    with torch.no_grad():
        Y_pred_norm = model(X_t).cpu().numpy()

    Y_pred_phys = scaler.denormalize_y(Y_pred_norm)
    Y_true_phys = scaler.denormalize_y(Y)

    # MSE per state
    mse_Pbh = np.mean((Y_pred_phys[:, 0] - Y_true_phys[:, 0])**2)
    mse_Pwh = np.mean((Y_pred_phys[:, 1] - Y_true_phys[:, 1])**2)
    mse_q = np.mean((Y_pred_phys[:, 2] - Y_true_phys[:, 2])**2)
    mse_total = np.mean((Y_pred_norm - Y)**2)

    metrics = {
        'mse_Pbh': mse_Pbh,
        'mse_Pwh': mse_Pwh,
        'mse_q': mse_q,
        'mse_normalized': mse_total,
    }

    return metrics, Y_pred_phys, Y_true_phys


def plot_training_history(history, save_path=None):
    """
    Plot training and validation loss curves (reproduces Fig. 8).
    """
    epochs = history['epoch']
    train_loss = history['train_loss']
    val_loss = history['val_loss']

    fig, ax = plt.subplots(1, 1, figsize=(10, 5))
    ax.semilogy(epochs, train_loss, 'b-', alpha=0.7, label='Training loss')
    ax.semilogy(epochs, val_loss, 'r-', alpha=0.7, label='Validation loss')

    # Mark optimizer switch
    adam_epochs = [e for e, o in zip(epochs, history['optimizer']) if o == 'Adam']
    if adam_epochs:
        ax.axvline(x=max(adam_epochs), color='gray', linestyle='--', alpha=0.5,
                   label='Adam → L-BFGS')

    # Mark weight change
    for i, (e, w) in enumerate(zip(epochs, history['weights'])):
        if i > 0 and history['weights'][i] != history['weights'][i-1]:
            ax.axvline(x=e, color='green', linestyle='--', alpha=0.5,
                       label=f'Weights → S1')
            break

    ax.set_xlabel('Epoch')
    ax.set_ylabel('Loss')
    ax.set_title('Training and Validation Loss (cf. Fig. 8)')
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.show()


def plot_loss_components(history, save_path=None):
    """
    Plot individual loss term evolution (reproduces Fig. 9).
    """
    epochs = history['epoch']

    fig, axes = plt.subplots(2, 2, figsize=(12, 8))

    terms = [
        ('L_bc', 'Boundary Condition Loss (L_bc)', 'blue'),
        ('L_y1', 'Residual dPbh/dt (L_y1)', 'red'),
        ('L_y2', 'Residual dPwh/dt (L_y2)', 'green'),
        ('L_y3', 'Residual dq/dt (L_y3)', 'orange'),
    ]

    for ax, (key, title, color) in zip(axes.flat, terms):
        values = history[key]
        ax.semilogy(epochs, values, color=color, alpha=0.7)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Loss')
        ax.set_title(title)
        ax.grid(True, alpha=0.3)

        # Mark weight change
        for i, (e, w) in enumerate(zip(epochs, history['weights'])):
            if i > 0 and history['weights'][i] != history['weights'][i-1]:
                ax.axvline(x=e, color='gray', linestyle='--', alpha=0.5)
                break

    plt.suptitle('Loss Components Evolution (cf. Fig. 9)', fontsize=13)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.show()


def plot_predictions(y_pred, y_true, t=None, n_train=None, save_path=None,
                     title_suffix=""):
    """
    Plot predicted vs. true states (reproduces Figs. 10, 12, 13, 15).
    """
    n = len(y_pred)
    if t is None:
        t = np.arange(n)

    fig, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=True)

    labels = ['$P_{bh}$ [Pa]', '$P_{wh}$ [Pa]', '$q$ [m³/s]']
    colors_true = ['black', 'black', 'gray']
    colors_pred_train = ['red', 'red', 'red']
    colors_pred_val = ['blue', 'blue', 'blue']

    for i, (ax, label) in enumerate(zip(axes, labels)):
        # True values
        ax.plot(t, y_true[:, i], color=colors_true[i], linewidth=0.8,
                label='True', alpha=0.8)

        if n_train is not None:
            # Training predictions
            ax.plot(t[:n_train], y_pred[:n_train, i], color='red',
                    linewidth=0.6, alpha=0.7, label='Prediction (train)')
            # Validation predictions
            ax.plot(t[n_train:], y_pred[n_train:, i], color='blue',
                    linewidth=0.6, alpha=0.7, label='Prediction (val)')
            ax.axvline(x=t[n_train], color='gray', linestyle=':', alpha=0.4)
        else:
            ax.plot(t, y_pred[:, i], color='red', linewidth=0.6,
                    alpha=0.7, label='Prediction')

        ax.set_ylabel(label)
        ax.legend(loc='upper right', fontsize=8)
        ax.grid(True, alpha=0.3)

    note = "(q in gray = non-measured)" if not title_suffix else ""
    axes[0].set_title(f'State Predictions {title_suffix} {note} (cf. Figs. 10, 12)')
    axes[-1].set_xlabel('Sample')
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.show()


def plot_parameter_tracking(history, true_params, save_path=None):
    """
    Plot parameter convergence during training (reproduces Figs. 11, 14).

    Parameters
    ----------
    history : dict
        Training history from PINNTrainer.
    true_params : dict
        True parameter values, e.g. {'PI': 2.32e-9, 'rho': 950.0}.
    """
    param_keys = [k for k in history if k.startswith('param_')]
    if not param_keys:
        print("No trainable parameters tracked.")
        return

    n_params = len(param_keys)
    fig, axes = plt.subplots(n_params, 1, figsize=(10, 4 * n_params))
    if n_params == 1:
        axes = [axes]

    epochs = history['epoch']

    for ax, key in zip(axes, param_keys):
        param_name = key.replace('param_', '')
        values = history[key]
        true_val = true_params.get(param_name, None)

        ax.plot(epochs, values, 'b-', linewidth=1, label=f'Estimated {param_name}')
        if true_val is not None:
            ax.axhline(y=true_val, color='red', linestyle='--',
                       label=f'True {param_name} = {true_val:.4e}')

            # Compute final mismatch
            final_val = values[-1]
            mismatch = abs(final_val - true_val) / abs(true_val) * 100
            ax.set_title(f'{param_name}: final = {final_val:.4e} '
                        f'(mismatch = {mismatch:.2f}%)')

        ax.set_xlabel('Epoch')
        ax.set_ylabel(param_name)
        ax.legend()
        ax.grid(True, alpha=0.3)

        # Mark weight change
        for i, (e, w) in enumerate(zip(epochs, history['weights'])):
            if i > 0 and history['weights'][i] != history['weights'][i-1]:
                ax.axvline(x=e, color='green', linestyle='--', alpha=0.5,
                          label='Weights → S1')
                break

    plt.suptitle('Parameter Tracking (cf. Figs. 11, 14)', fontsize=13)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.show()


def plot_exogenous_inputs(t, u, save_path=None):
    """Plot exogenous input signals (part of Fig. 7)."""
    fig, axes = plt.subplots(4, 1, figsize=(12, 8), sharex=True)

    labels = ['ESP Frequency $f$ [Hz]', 'Choke Opening $Z_c$ [%]',
              'Manifold Pressure $P_m$ [Pa]', 'Reservoir Pressure $P_r$ [Pa]']

    for ax, label, i in zip(axes, labels, range(4)):
        ax.plot(t, u[:, i], 'k-', linewidth=0.5)
        ax.set_ylabel(label)
        ax.grid(True, alpha=0.3)

    axes[-1].set_xlabel('Time [s]')
    axes[0].set_title('Exogenous Inputs (APRBS) — cf. Fig. 7')
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.show()


def plot_dataset(t, y, u, save_path=None):
    """Plot full dataset: states + inputs (reproduces Fig. 7)."""
    fig, axes = plt.subplots(7, 1, figsize=(14, 14), sharex=True)

    # States
    state_labels = ['$P_{bh}$ [Pa]', '$P_{wh}$ [Pa]', '$q$ [m³/s]']
    for i, (ax, label) in enumerate(zip(axes[:3], state_labels)):
        ax.plot(t, y[:, i], 'k-', linewidth=0.5)
        ax.set_ylabel(label)
        ax.grid(True, alpha=0.3)

    # Inputs
    input_labels = ['$f$ [Hz]', '$Z_c$ [%]', '$P_m$ [Pa]', '$P_r$ [Pa]']
    for i, (ax, label) in enumerate(zip(axes[3:], input_labels)):
        ax.plot(t, u[:, i], 'k-', linewidth=0.5)
        ax.set_ylabel(label)
        ax.grid(True, alpha=0.3)

    axes[-1].set_xlabel('Time [s]')
    axes[0].set_title('Dataset: States and Exogenous Inputs (cf. Fig. 7)')
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.show()
