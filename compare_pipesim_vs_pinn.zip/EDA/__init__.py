"""EDA package for the Castilla ESP real-data VFM project."""

from .vfm_eda import (
    data_quality_report,
    plot_missingness,
    outlier_report,
    plot_outliers,
    plot_distributions,
    correlation_report,
    plot_correlations,
    temporal_report,
    plot_temporal_behavior,
    physics_consistency_report,
    plot_physics_checks,
    thp_manifold_table,
    leakage_report,
    executive_summary,
    run_full_eda,
)

__all__ = [
    "data_quality_report", "plot_missingness", "outlier_report",
    "plot_outliers", "plot_distributions", "correlation_report",
    "plot_correlations", "temporal_report", "plot_temporal_behavior",
    "physics_consistency_report", "plot_physics_checks", "thp_manifold_table",
    "leakage_report", "executive_summary", "run_full_eda",
]
