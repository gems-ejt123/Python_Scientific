"""
Exploratory Data Analysis toolkit for the Castilla ESP real-data VFM project.

Every function takes the ``RealDataBundle`` produced by
``real_data_loader.load_real_data`` (and optionally the ``ESPPumpCurve``) and
covers one EDA axis:

  * data quality / missingness         -> data_quality_report, plot_missingness
  * outliers                           -> outlier_report, plot_outliers
  * distributions                      -> plot_distributions
  * correlations                       -> correlation_report, plot_correlations
  * temporal behavior                  -> temporal_report, plot_temporal_behavior
  * physical consistency               -> physics_consistency_report, plot_physics_checks
  * leakage risks                      -> leakage_report
  * executive summary + DL/PIML readiness -> executive_summary

``run_full_eda(bundle, pump)`` orchestrates all of the above and returns a
dict of intermediate results so the notebook can drill into any section.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Raw field columns as they appear in the cleaned frame (field units).
RAW_COLS = ["BFPD", "BOPD", "BWPD", "KPCD", "BS&W", "API", "Frec", "PIP",
            "PWF", "Res_Press", "IP", "THP", "Manifold_Troncal",
            "Densidad", "Visosidad", "Zc"]

# Known target-leaking / constant columns (see real_data_loader docstring).
LEAKING_COLS = {"BOPD": "algebraic split of BFPD (oil)",
                "BWPD": "algebraic split of BFPD (water)",
                "IP": "IP = BFPD / (Res_Press - PWF)"}
CONSTANT_CANDIDATES = {"KPCD": "gas rate, expected 0",
                       "Zc": "choke opening, expected 1 (no choke)",
                       "Res_Press": "reservoir pressure, expected constant"}

# Physically plausible field-unit ranges for hard-bound violation checks.
PHYSICAL_BOUNDS = {
    "BFPD": (0.0, 20000.0),          # bbl/d
    "BS&W": (0.0, 100.0),            # %
    "Frec": (30.0, 70.0),            # Hz (typical VSD band)
    "PIP": (0.0, 5000.0),            # psi
    "PWF": (0.0, 5000.0),            # psi
    "THP": (0.0, 2000.0),            # psi
    "Manifold_Troncal": (0.0, 2000.0),
    "Densidad": (40.0, 75.0),        # lb/ft^3 (~640-1200 kg/m^3)
    "Visosidad": (0.1, 5000.0),      # cP
    "API": (5.0, 50.0),
}


def _present(df: pd.DataFrame, cols) -> list:
    return [c for c in cols if c in df.columns]


# --------------------------------------------------------------------------- #
#  1. Data quality & missingness                                               #
# --------------------------------------------------------------------------- #
def data_quality_report(df: pd.DataFrame) -> pd.DataFrame:
    """Per-column table: dtype, missing, uniques, constants, sentinel hits."""
    cols = _present(df, RAW_COLS)
    rows = []
    for c in cols:
        s = df[c]
        sentinels = int(s.isin([-9999, -999, -9999.25, 9999]).sum())
        lo, hi = PHYSICAL_BOUNDS.get(c, (None, None))
        viol = int(((s < lo) | (s > hi)).sum()) if lo is not None else 0
        rows.append({
            "column": c, "dtype": str(s.dtype),
            "n_missing": int(s.isna().sum()),
            "pct_missing": round(100 * s.isna().mean(), 1),
            "n_unique": int(s.nunique()),
            "is_constant": s.nunique(dropna=True) <= 1,
            "n_sentinel": sentinels,
            "n_bound_violations": viol,
            "min": s.min(), "median": s.median(), "max": s.max(),
        })
    rep = pd.DataFrame(rows).set_index("column")
    dup_dates = int(df["date"].duplicated().sum()) if "date" in df else 0
    rep.attrs["n_rows"] = len(df)
    rep.attrs["n_duplicate_dates"] = dup_dates
    rep.attrs["n_duplicate_rows"] = int(df.duplicated().sum())
    return rep


def plot_missingness(df: pd.DataFrame, ax=None):
    """Bar chart of missing fraction per raw column."""
    cols = _present(df, RAW_COLS)
    miss = df[cols].isna().mean().sort_values(ascending=False) * 100
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 3))
    miss.plot.bar(ax=ax, color="C3")
    ax.set_ylabel("% missing"); ax.set_title("Missing values per column")
    ax.grid(alpha=0.3, axis="y")
    return ax


# --------------------------------------------------------------------------- #
#  2. Outliers                                                                 #
# --------------------------------------------------------------------------- #
def outlier_report(df: pd.DataFrame, iqr_k: float = 1.5,
                   z_thresh: float = 3.0) -> pd.DataFrame:
    """IQR-fence and robust-z outlier counts per raw column."""
    cols = [c for c in _present(df, RAW_COLS)
            if df[c].nunique(dropna=True) > 1]
    rows = []
    for c in cols:
        s = df[c].dropna()
        q1, q3 = s.quantile([0.25, 0.75])
        iqr = q3 - q1
        lo, hi = q1 - iqr_k * iqr, q3 + iqr_k * iqr
        n_iqr = int(((s < lo) | (s > hi)).sum())
        mad = (s - s.median()).abs().median()
        rz = 0.6745 * (s - s.median()) / mad if mad > 0 else s * 0
        n_z = int((rz.abs() > z_thresh).sum())
        rows.append({"column": c, "iqr_low": round(lo, 2), "iqr_high": round(hi, 2),
                     "n_outliers_iqr": n_iqr, "n_outliers_robust_z": n_z,
                     "pct_iqr": round(100 * n_iqr / len(s), 1)})
    return pd.DataFrame(rows).set_index("column")


def plot_outliers(df: pd.DataFrame, cols=None):
    """Standardized boxplots so all variables share one axis."""
    cols = cols or [c for c in _present(df, RAW_COLS)
                    if df[c].nunique(dropna=True) > 1]
    z = (df[cols] - df[cols].mean()) / df[cols].std(ddof=0)
    fig, ax = plt.subplots(figsize=(11, 3.5))
    z.boxplot(ax=ax, rot=45)
    ax.set_ylabel("z-score"); ax.set_title("Standardized boxplots (outlier scan)")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    return fig


# --------------------------------------------------------------------------- #
#  3. Distributions                                                            #
# --------------------------------------------------------------------------- #
def plot_distributions(df: pd.DataFrame, cols=None, bins: int = 20):
    """Histogram grid with skewness annotation."""
    cols = cols or [c for c in _present(df, RAW_COLS)
                    if df[c].nunique(dropna=True) > 1]
    ncols = 4
    nrows = int(np.ceil(len(cols) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(13, 2.4 * nrows))
    for ax, c in zip(np.ravel(axes), cols):
        s = df[c].dropna()
        ax.hist(s, bins=bins, color="C0", alpha=0.8)
        ax.set_title(f"{c}  (skew={s.skew():.2f})", fontsize=9)
        ax.grid(alpha=0.3)
    for ax in np.ravel(axes)[len(cols):]:
        ax.axis("off")
    plt.tight_layout()
    return fig


# --------------------------------------------------------------------------- #
#  4. Correlations                                                             #
# --------------------------------------------------------------------------- #
def correlation_report(df: pd.DataFrame, target: str = "BFPD") -> pd.DataFrame:
    """Pearson & Spearman correlation of every raw column vs the target."""
    cols = [c for c in _present(df, RAW_COLS)
            if c != target and df[c].nunique(dropna=True) > 1]
    rows = []
    for c in cols:
        sub = df[[c, target]].dropna()
        rows.append({"column": c,
                     "pearson": round(sub[c].corr(sub[target]), 3),
                     "spearman": round(sub[c].corr(sub[target], method="spearman"), 3),
                     "known_leak": c in LEAKING_COLS})
    return (pd.DataFrame(rows).set_index("column")
            .sort_values("pearson", key=np.abs, ascending=False))


def plot_correlations(df: pd.DataFrame, cols=None):
    """Pearson heatmap of the informative raw columns."""
    cols = cols or [c for c in _present(df, RAW_COLS)
                    if df[c].nunique(dropna=True) > 1]
    corr = df[cols].corr()
    fig, ax = plt.subplots(figsize=(8.5, 7))
    im = ax.imshow(corr, vmin=-1, vmax=1, cmap="RdBu_r")
    ax.set_xticks(range(len(cols)), cols, rotation=60, ha="right", fontsize=8)
    ax.set_yticks(range(len(cols)), cols, fontsize=8)
    for i in range(len(cols)):
        for j in range(len(cols)):
            ax.text(j, i, f"{corr.iloc[i, j]:.2f}", ha="center", va="center",
                    fontsize=7,
                    color="white" if abs(corr.iloc[i, j]) > 0.6 else "black")
    fig.colorbar(im, shrink=0.8)
    ax.set_title("Pearson correlation matrix")
    plt.tight_layout()
    return fig


# --------------------------------------------------------------------------- #
#  5. Temporal behavior                                                        #
# --------------------------------------------------------------------------- #
def temporal_report(df: pd.DataFrame) -> dict:
    """Sampling-interval statistics + simple trend/regime diagnostics."""
    gaps = df["date"].diff().dt.days.dropna()
    y = df["BFPD"].to_numpy(float)
    t = np.arange(len(y))
    slope = np.polyfit(t, y, 1)[0] if len(y) > 2 else np.nan
    # lag-1 autocorrelation of the target (persistence)
    ac1 = float(np.corrcoef(y[:-1], y[1:])[0, 1]) if len(y) > 2 else np.nan
    return {
        "n_samples": len(df),
        "date_min": str(df["date"].min().date()),
        "date_max": str(df["date"].max().date()),
        "gap_days_median": float(gaps.median()),
        "gap_days_max": float(gaps.max()),
        "n_gaps_gt_30d": int((gaps > 30).sum()),
        "target_trend_bblpd_per_sample": float(slope),
        "target_lag1_autocorr": ac1,
    }


def plot_temporal_behavior(df: pd.DataFrame):
    """Target + drivers vs time, plus sampling-gap histogram."""
    fig, axes = plt.subplots(3, 2, figsize=(13, 8))
    pairs = [("BFPD", "C0"), ("Frec", "C1"), ("PIP", "C2"),
             ("PWF", "C4"), ("BS&W", "C3")]
    for ax, (c, color) in zip(np.ravel(axes)[:5], pairs):
        ax.plot(df["date"], df[c], ".-", color=color, ms=4)
        ax.set_title(f"{c} over time", fontsize=10); ax.grid(alpha=0.3)
        ax.tick_params(axis="x", rotation=30)
    gaps = df["date"].diff().dt.days.dropna()
    ax = np.ravel(axes)[5]
    ax.hist(gaps, bins=20, color="C7")
    ax.set_title(f"Sampling gap [days]  (median={gaps.median():.0f})", fontsize=10)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    return fig


# --------------------------------------------------------------------------- #
#  6. Physical consistency                                                     #
# --------------------------------------------------------------------------- #
def physics_consistency_report(bundle, pump=None) -> pd.DataFrame:
    """
    Sample-wise physics checks (all should PASS for a coherent ESP well):
      pressure ladder Pr > PWF > PIP, THP > manifold, positive drawdown,
      IPR linearity, and (if pump given) datasheet-head agreement.
    """
    df, p = bundle.df, bundle.phys
    checks = []

    def add(name, mask, detail):
        mask = np.asarray(mask)
        checks.append({"check": name, "n_violations": int((~mask).sum()),
                       "pct_pass": round(100 * mask.mean(), 1), "detail": detail})

    add("Pr > PWF (positive drawdown)", p["Pr_Pa"] > p["PWF_Pa"],
        "reservoir must exceed flowing BHP")
    add("PWF > PIP (intake above perfs)", p["PWF_Pa"] > p["PIP_Pa"],
        "hydrostatic column between perforations and intake")
    add("THP >= manifold pressure", p["THP_Pa"] >= p["Pm_Pa"],
        "flow must go well -> troncal (loader clamps THP up to Pm)")
    add("q > 0", bundle.y > 0, "producing well")
    add("0 <= BSW <= 1", (df["BSW"] >= 0) & (df["BSW"] <= 1), "water cut fraction")
    add("rho in [700, 1200] kg/m3", (p["rho"] > 700) & (p["rho"] < 1200),
        "oil-water mixture density")

    # IPR linearity: q vs drawdown through the origin
    dpr = p["Pr_Pa"] - p["PWF_Pa"]
    PI = float((bundle.y * dpr).sum() / (dpr * dpr).sum())
    resid = bundle.y - PI * dpr
    r2 = 1 - resid.var() / bundle.y.var()
    checks.append({"check": "IPR linearity q = PI*(Pr-PWF)", "n_violations": 0,
                   "pct_pass": round(100 * max(r2, 0), 1),
                   "detail": f"R2 of zero-intercept fit (PI={PI:.3e} m3/s/Pa)"})

    if pump is not None:
        import torch
        from esp_steady import DEFAULT_GEOMETRY, G, FT_TO_M
        H_meas = (p["THP_Pa"] + p["rho"] * G * DEFAULT_GEOMETRY.dh_lift_m
                  - p["PIP_Pa"]) / (p["rho"] * G)
        H_curve = pump.head(torch.tensor(bundle.y, dtype=torch.float32),
                            torch.tensor(p["f"], dtype=torch.float32)).cpu().numpy()
        rel = np.abs(H_meas - H_curve) / np.abs(H_curve)
        add("pump head balance within 20%", rel < 0.20,
            f"median |dH|/H = {np.median(rel)*100:.1f}% "
            f"(meas {np.mean(H_meas)/FT_TO_M:.0f} ft vs curve "
            f"{np.mean(H_curve)/FT_TO_M:.0f} ft)")

    return pd.DataFrame(checks).set_index("check")


def plot_physics_checks(bundle, pump=None):
    """IPR crossplot and affinity-scaled operating map."""
    p = bundle.phys
    n_ax = 2 if pump is not None else 1
    fig, axes = plt.subplots(1, n_ax, figsize=(6.2 * n_ax, 4.2))
    axes = np.atleast_1d(axes)

    dpr_psi = (p["Pr_Pa"] - p["PWF_Pa"]) / 6894.757293
    q_bbl = bundle.y / (0.158987294928 / 86400.0)
    ax = axes[0]
    sc = ax.scatter(dpr_psi, q_bbl, c=p["f"], cmap="viridis", s=30)
    PI = float((q_bbl * dpr_psi).sum() / (dpr_psi * dpr_psi).sum())
    xs = np.linspace(0, dpr_psi.max() * 1.05, 50)
    ax.plot(xs, PI * xs, "k--", label=f"IPR fit  PI={PI:.2f} bbl/d/psi")
    ax.set_xlabel("drawdown Pr - PWF [psi]"); ax.set_ylabel("q [bbl/d]")
    ax.set_title("IPR consistency"); ax.legend(); ax.grid(alpha=0.3)
    fig.colorbar(sc, ax=ax, label="Frec [Hz]")

    if pump is not None:
        import torch
        from esp_steady import DEFAULT_GEOMETRY, G, FT_TO_M
        f = p["f"]; f_ref = 60.0
        H_meas = (p["THP_Pa"] + p["rho"] * G * DEFAULT_GEOMETRY.dh_lift_m
                  - p["PIP_Pa"]) / (p["rho"] * G)
        # affinity-law collapse to the reference frequency
        q60 = q_bbl * (f_ref / f)
        H60 = H_meas * (f_ref / f) ** 2 / FT_TO_M
        ax = axes[1]
        ax.scatter(q60, H60, c=f, cmap="viridis", s=30, label="measured (scaled)")
        qs = np.linspace(q60.min() * 0.8, q60.max() * 1.2, 60)
        Hc = pump.head(torch.tensor(qs * 0.158987294928 / 86400.0,
                                    dtype=torch.float32),
                       torch.full((60,), f_ref)).cpu().numpy() / FT_TO_M
        ax.plot(qs, Hc, "r-", label="datasheet curve @60 Hz")
        ax.set_xlabel("q scaled to 60 Hz [bbl/d]"); ax.set_ylabel("head [ft]")
        ax.set_title("Affinity-collapsed operating points vs pump curve")
        ax.legend(); ax.grid(alpha=0.3)
        fig.colorbar(ax.collections[0], ax=ax, label="Frec [Hz]")
    plt.tight_layout()
    return fig


def thp_manifold_table(df: pd.DataFrame, only_violations: bool = True) -> pd.DataFrame:
    """Per-date table of THP vs Manifold_Troncal to audit the pressure check.

    A row is flagged when THP <= Manifold_Troncal (flow could not go
    well -> troncal), which is what fails the 'THP > manifold' check.
    """
    out = df[["date", "BFPD", "Frec", "THP", "Manifold_Troncal"]].copy()
    out["dP_THP_minus_Pm_psi"] = out["THP"] - out["Manifold_Troncal"]
    out["violation"] = out["dP_THP_minus_Pm_psi"] <= 0
    if only_violations:
        out = out[out["violation"]]
    return out.sort_values("date").reset_index(drop=True)


# --------------------------------------------------------------------------- #
#  7. Leakage risks                                                            #
# --------------------------------------------------------------------------- #
def leakage_report(bundle) -> pd.DataFrame:
    """
    Verify the known algebraic identities that make columns target-leaking,
    and flag any *feature actually used by the model* with suspiciously high
    correlation to the target.
    """
    df = bundle.df
    rows = []

    if {"BOPD", "BWPD", "BFPD"} <= set(df.columns):
        err = (df["BOPD"] + df["BWPD"] - df["BFPD"]).abs().max()
        rows.append({"risk": "BOPD + BWPD == BFPD", "kind": "algebraic identity",
                     "evidence": f"max |error| = {err:.2f} bbl/d",
                     "status": "LEAK - excluded" ,
                     "confirmed": err < 1.0})
    if {"IP", "BFPD", "Res_Press", "PWF"} <= set(df.columns):
        ip_calc = df["BFPD"] / (df["Res_Press"] - df["PWF"])
        err = (ip_calc - df["IP"]).abs().median()
        rows.append({"risk": "IP == BFPD/(Pr-PWF)", "kind": "algebraic identity",
                     "evidence": f"median |error| = {err:.3f} bbl/d/psi",
                     "status": "LEAK - excluded",
                     "confirmed": err < 0.05 * df["IP"].abs().median()})

    # correlation screen on the columns the model actually consumes
    for c in bundle.feature_names:
        if c not in df.columns:
            continue
        r = abs(df[c].corr(df["q"]))
        rows.append({"risk": f"feature '{c}' vs target", "kind": "correlation screen",
                     "evidence": f"|pearson| = {r:.3f}",
                     "status": "SUSPECT" if r > 0.95 else "OK",
                     "confirmed": r > 0.95})
    return pd.DataFrame(rows).set_index("risk")


# --------------------------------------------------------------------------- #
#  8. Executive summary & orchestrator                                         #
# --------------------------------------------------------------------------- #
def executive_summary(results: dict) -> None:
    """Resumen ejecutivo corto (en español) de los hallazgos del EDA."""
    q = results["quality"]; t = results["temporal"]
    phys = results["physics"]; leak = results["leakage"]
    out = results["outliers"]

    n = q.attrs["n_rows"]
    n_missing_cols = int((q["n_missing"] > 0).sum())
    n_const = int(q["is_constant"].sum())
    worst = ", ".join(f"{i} {r.pct_iqr:.0f}%" for i, r in
                      out.sort_values("pct_iqr", ascending=False).head(3).iterrows())
    n_phys_fail = int((phys["pct_pass"] < 95).sum())
    n_leaks = int(leak["confirmed"].sum())

    print("=" * 60)
    print("RESUMEN EJECUTIVO — EDA pozo Castilla (ESP)")
    print("=" * 60)
    print(f"""\
* {n} muestras diarias, {t['date_min']} -> {t['date_max']} (gap mediano \
{t['gap_days_median']:.0f} d): serie escasa e irregular.
* Sin valores faltantes ({n_missing_cols} col.); {n_const} columnas constantes (descartar).
* Outliers moderados (IQR): {worst}.
* Física: {n_phys_fail} de {len(phys)} chequeos con <95% de cumplimiento.
* Fuga de información: {n_leaks} identidades confirmadas, ya excluidas de X.
* Recomendaciones: split cronológico + CV por bloques (no barajar),
  escalar solo con el bloque de entrenamiento, winsorizar en vez de borrar filas.
* Preparación: pocos datos para DL puro; PINN pequeña con residuales
  IPR + curva de bomba, ensamble + intervalos conformales para UQ.""")
    print("=" * 60)


def run_full_eda(bundle, pump=None, show: bool = True) -> dict:
    """Run every EDA section, render the figures, and return all results."""
    df = bundle.df
    results = {
        "quality": data_quality_report(df),
        "outliers": outlier_report(df),
        "correlations": correlation_report(df),
        "temporal": temporal_report(df),
        "physics": physics_consistency_report(bundle, pump),
        "leakage": leakage_report(bundle),
    }

    if show:
        print(f"rows={results['quality'].attrs['n_rows']}  "
              f"duplicate rows={results['quality'].attrs['n_duplicate_rows']}  "
              f"duplicate dates={results['quality'].attrs['n_duplicate_dates']}\n")
        print("--- Data quality ---");   print(results["quality"].to_string())
        print("\n--- Outliers ---");     print(results["outliers"].to_string())
        print("\n--- Correlation vs target (BFPD) ---")
        print(results["correlations"].to_string())
        print("\n--- Physical consistency ---")
        print(results["physics"].to_string())
        print("\n--- Leakage risks ---"); print(results["leakage"].to_string())

        plot_missingness(df); plt.show()
        plot_distributions(df); plt.show()
        plot_outliers(df); plt.show()
        plot_correlations(df); plt.show()
        plot_temporal_behavior(df); plt.show()
        plot_physics_checks(bundle, pump); plt.show()
    return results
